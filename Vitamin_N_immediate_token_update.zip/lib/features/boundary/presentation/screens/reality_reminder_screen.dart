import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../app/routes.dart';
import '../../../../core/access/content_access_policy.dart';
import '../../../../design_system/widgets/primary_button.dart';
import '../../../premium/presentation/providers/premium_providers.dart';
import '../../../reality_reminders/domain/entities/reality_reminder.dart';
import '../../../reality_reminders/presentation/providers/reality_reminder_providers.dart';
import '../controllers/say_no_flow_controller.dart';
import '../widgets/flow_header.dart';
import '../widgets/flow_scaffold.dart';
import '../widgets/locked_reality_reminder_card.dart';
import '../widgets/reality_reminder_card.dart';

/// Step 5 — Reality Reminder.
///
/// Step 5 shows exactly one curated Reality Reminder per Say No run.
/// Successive runs rotate through up to four authored reminders for the
/// selected situation. Entitlement gating is preserved underneath the QA
/// unlock policy; no extra reminder is exposed on this screen.
class RealityReminderScreen extends ConsumerWidget {
  const RealityReminderScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final flowState = ref.watch(sayNoFlowControllerProvider);
    final String? categoryId = flowState.selectedCategoryId;
    final String? situationId = flowState.selectedSituationId;

    if (categoryId == null || situationId == null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (context.mounted) context.go(AppRoutes.sayNoCategory);
      });
      return const FlowScaffold(child: SizedBox.shrink());
    }

    final bool isPremium = ref.watch(premiumStatusProvider).value?.isPremium ?? false;
    final bool hasReminderAccess =
        ContentAccessPolicy.canSeeRealityReminder(categoryId, isPremium: isPremium);
    // Other/Custom never has curated reminder content — showing a
    // locked teaser for it would promise something that doesn't
    // exist, so it's excluded from the gate entirely and simply
    // renders nothing below, the same as if content were empty.
    final bool isCustomCategory = categoryId == 'cat_other';
    final bool showLockedTeaser =
        !hasReminderAccess && !isCustomCategory;

    return FlowScaffold(
      bottomBar: PrimaryButton(
        label: 'Continue',
        onPressed: () => context.push(AppRoutes.sayNoConfirm),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          const FlowHeader(title: 'Something to notice'),
          if (showLockedTeaser)
            const LockedRealityReminderCard()
          else
            _RealReminderContent(
              categoryId: categoryId,
              situationId: situationId,
              rotationSeed: flowState.rotationSeed,
            ),
        ],
      ),
    );
  }
}

class _RealReminderContent extends ConsumerWidget {
  const _RealReminderContent({
    required this.categoryId,
    required this.situationId,
    required this.rotationSeed,
  });

  final String categoryId;
  final String situationId;
  final int rotationSeed;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AsyncValue<List<RealityReminder>> remindersAsync = ref.watch(
      realityRemindersForSituationProvider(
        (categoryId: categoryId, situationId: situationId),
      ),
    );

    return remindersAsync.when(
      data: (List<RealityReminder> reminders) {
        if (reminders.isEmpty) {
          // No curated content for this situation — never invented,
          // per spec. Silently render nothing further.
          return const SizedBox.shrink();
        }

        // Exactly one reminder is shown per Say No run. Rotate through the
        // first four authored reminders on successive launches.
        final int rotationLimit = reminders.length < 4 ? reminders.length : 4;
        final int selectedIndex = rotationSeed % rotationLimit;
        final RealityReminder current = reminders[selectedIndex];

        if (ref.read(sayNoFlowControllerProvider).selectedRealityReminderId !=
            current.id) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            ref
                .read(sayNoFlowControllerProvider.notifier)
                .selectRealityReminder(current.id);
          });
        }


        return RealityReminderCard(text: current.text);
      },
      loading: () => const Padding(
        padding: EdgeInsets.only(top: 24),
        child: Center(child: CircularProgressIndicator()),
      ),
      error: (Object error, StackTrace stackTrace) =>
          Text('Could not load a reminder: $error'),
    );
  }
}
