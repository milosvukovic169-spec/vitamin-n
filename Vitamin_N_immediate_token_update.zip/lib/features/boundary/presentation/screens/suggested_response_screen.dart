import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../app/routes.dart';
import '../../../../core/access/content_access_policy.dart';
import '../../../../core/analytics/analytics_providers.dart';
import '../../../../design_system/theme/theme_extensions.dart';
import '../../../../design_system/widgets/app_card.dart';
import '../../../../design_system/widgets/primary_button.dart';
import '../../../premium/presentation/providers/premium_providers.dart';
import '../../../refusal_responses/domain/entities/refusal_response.dart';
import '../../../refusal_responses/domain/entities/response_visibility.dart';
import '../../../refusal_responses/presentation/providers/refusal_response_providers.dart';
import '../../../situations/domain/entities/situation.dart';
import '../../../situations/presentation/providers/situation_providers.dart';
import '../controllers/say_no_flow_controller.dart';
import '../widgets/flow_header.dart';
import '../widgets/flow_scaffold.dart';
import '../widgets/premium_response_teaser_sheet.dart';
import '../widgets/suggested_response_card.dart';

const String _fallbackResponseText =
    'Take a moment to say this in your own words — you know this '
    'situation better than any suggestion could.';

/// Step 4 — Suggested Response.
///
/// Shows one suggested response at a time. Where multiple standard refusal
/// responses are available, users can move both backward and forward without
/// stacking cards. Future Me situations show exactly one response per Say No
/// run; the selected response rotates on each new run.
class SuggestedResponseScreen extends ConsumerStatefulWidget {
  const SuggestedResponseScreen({super.key});

  @override
  ConsumerState<SuggestedResponseScreen> createState() =>
      _SuggestedResponseScreenState();
}

class _SuggestedResponseScreenState
    extends ConsumerState<SuggestedResponseScreen> {
  bool _justCopied = false;
  int? _visibleIndex;

  void _handleCopy(String text) {
    Clipboard.setData(ClipboardData(text: text));
    HapticFeedback.lightImpact();
    setState(() => _justCopied = true);
    Future<void>.delayed(const Duration(seconds: 2), () {
      if (mounted) setState(() => _justCopied = false);
    });
  }


  @override
  Widget build(BuildContext context) {
    final flowState = ref.watch(sayNoFlowControllerProvider);
    final String? categoryId = flowState.selectedCategoryId;
    final String? situationId = flowState.selectedSituationId;
    final bool isCustomSituation = situationId == 'sit_custom_other';
    final Situation? selectedSituation = categoryId == null || situationId == null
        ? null
        : ref.watch(situationByCategoryAndIdProvider(
            (categoryId: categoryId, situationId: situationId),
          )).value;
    final bool isFutureMe =
        selectedSituation?.contentType == SituationContentType.tomorrowYou;

    if (categoryId == null || situationId == null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) context.go(AppRoutes.sayNoCategory);
      });
      return const FlowScaffold(child: SizedBox.shrink());
    }

    if (isCustomSituation) {
      return FlowScaffold(
        bottomBar: PrimaryButton(
          label: 'Continue',
          onPressed: () => context.push(AppRoutes.sayNoReality),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const FlowHeader(title: 'Suggested response'),
            AppCard(
              child: Text(
                _fallbackResponseText,
                style: Theme.of(context).textTheme.titleLarge,
                textAlign: TextAlign.center,
              ),
            ),
            _philosophyLine(context),
          ],
        ),
      );
    }

    final AsyncValue<List<RefusalResponse>> responsesAsync = ref.watch(
      refusalResponsesForSituationProvider(
        (categoryId: categoryId, situationId: situationId),
      ),
    );
    final bool isPremium = ref.watch(premiumStatusProvider).value?.isPremium ?? false;
    final bool hasFullResponseAccess = isFutureMe ||
        ContentAccessPolicy.canSeeAllResponses(isPremium: isPremium);

    return FlowScaffold(
      bottomBar: PrimaryButton(
        label: 'Continue',
        onPressed: () => context.push(AppRoutes.sayNoReality),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          FlowHeader(title: isFutureMe ? 'Future Me' : 'Suggested response'),
          responsesAsync.when(
            data: (List<RefusalResponse> responses) {
              if (responses.isEmpty) {
                return AppCard(
                  child: Text(
                    _fallbackResponseText,
                    style: Theme.of(context).textTheme.titleLarge,
                    textAlign: TextAlign.center,
                  ),
                );
              }

              // Free: exactly 1 (the Recommended response). Premium:
              // up to premiumDisplayCap, even if more is authored.
              final int visibleLimit = ResponseVisibility.visibleCount(
                responses.length,
                isPremium: hasFullResponseAccess,
              );
              // Future Me always displays exactly one response in a flow.
              // We still rotate across the full curated set by flow seed.
              final int futureMeRotationCount = responses.length;
              final int initialIndex = isFutureMe
                  ? flowState.rotationSeed % futureMeRotationCount
                  : 0;
              final int effectiveIndex = (_visibleIndex ?? initialIndex)
                  .clamp(0, visibleLimit - 1);
              final int clampedIndex = effectiveIndex.clamp(0, visibleLimit - 1);
              final RefusalResponse current = responses[clampedIndex];

              if (flowState.selectedRefusalResponseId != current.id) {
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  ref
                      .read(sayNoFlowControllerProvider.notifier)
                      .selectRefusalResponse(current.id);
                });
              }

              final String? premiumNextLabel = hasFullResponseAccess
                  ? ResponseVisibility.nextButtonLabelForPremium(
                      currentIndex: clampedIndex,
                      visibleLimit: visibleLimit,
                    )
                  : null;

              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  SuggestedResponseCard(
                    responseKey: current.id,
                    text: current.text,
                    copyLabel: _justCopied ? 'Copied' : 'Copy',
                    onCopy: () => _handleCopy(current.text),
                  ),
                  _philosophyLine(context, isFutureMe: isFutureMe),
                  if (!isFutureMe &&
                      !ContentAccessPolicy.canUseAnotherWay(isPremium: isPremium))
                    Center(
                      child: TextButton(
                        onPressed: () => showPremiumResponseTeaser(context),
                        child: const Text('Another way 🔒'),
                      ),
                    )
                  else if (!isFutureMe && visibleLimit > 1)
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        TextButton(
                          onPressed: clampedIndex > 0
                              ? () {
                                  setState(() => _visibleIndex = clampedIndex - 1);
                                }
                              : null,
                          child: const Text('Previous'),
                        ),
                        TextButton(
                          onPressed: premiumNextLabel != null
                              ? () {
                                  final int nextIndex = clampedIndex + 1;
                                  setState(() => _visibleIndex = nextIndex);
                                  unawaited(ref.read(analyticsServiceProvider).anotherWayRequested(
                                        categoryId: categoryId,
                                        situationId: situationId,
                                        responseVariantIndex: nextIndex,
                                      ));
                                }
                              : null,
                          child: Text(premiumNextLabel ?? 'Another way'),
                        ),
                      ],
                    ),
                ],
              );
            },
            loading: () => const Padding(
              padding: EdgeInsets.only(top: 48),
              child: Center(child: CircularProgressIndicator()),
            ),
            error: (Object error, StackTrace stackTrace) =>
                Text('Could not load a response: $error'),
          ),
        ],
      ),
    );
  }

  Widget _philosophyLine(BuildContext context, {bool isFutureMe = false}) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: context.spacing.lg),
      child: Text(
        isFutureMe
            ? 'A small note from Future Me.'
            : 'The best boundary is one you can genuinely say.',
        textAlign: TextAlign.center,
        style: Theme.of(context)
            .textTheme
            .bodySmall
            ?.copyWith(color: context.colors.textSecondary),
      ),
    );
  }
}
