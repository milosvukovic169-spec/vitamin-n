import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../app/routes.dart';
import '../../../../core/analytics/analytics_service.dart';
import '../../../../design_system/theme/theme_extensions.dart';
import '../../../../core/access/content_access_policy.dart';
import '../../../../design_system/widgets/app_card.dart';
import '../../../../design_system/widgets/primary_button.dart';
import '../../../boundary/presentation/controllers/say_no_flow_controller.dart';
import '../../../premium/presentation/providers/premium_providers.dart';
import '../../../premium/presentation/screens/premium_screen.dart';
import '../../domain/entities/challenge_program.dart';
import '../providers/challenge_providers.dart';

/// Shows one Challenge's steps as a simple, understated checklist —
/// no streak, no XP, no failure state for a skipped day. Each step is
/// just a checkbox; the optional CTA opens Say No with the
/// challenge's suggested category pre-filled.
class ChallengeDetailScreen extends ConsumerWidget {
  const ChallengeDetailScreen({super.key, required this.challengeId});

  final String challengeId;

  void _openSayNo(BuildContext context, WidgetRef ref, String? categoryId) {
    if (categoryId != null) {
      ref.read(sayNoFlowControllerProvider.notifier).selectCategory(categoryId);
      context.push(AppRoutes.sayNoSituation);
    } else {
      context.push(AppRoutes.sayNoCategory);
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final TextTheme textTheme = Theme.of(context).textTheme;
    final AsyncValue<List<ChallengeProgram>> challengesAsync =
        ref.watch(challengeProgramsProvider);
    final bool isPremium = ref.watch(premiumStatusProvider).value?.isPremium ?? false;

    return Scaffold(
      appBar: AppBar(title: const Text('Challenge')),
      body: SafeArea(
        child: challengesAsync.when(
          data: (List<ChallengeProgram> challenges) {
            final ChallengeProgram? program = challenges
                .cast<ChallengeProgram?>()
                .firstWhere((ChallengeProgram? c) => c?.id == challengeId,
                    orElse: () => null);
            if (program == null) {
              return const Center(child: Text('This challenge is unavailable.'));
            }

            final bool locked = !ContentAccessPolicy.canOpenChallenge(program.id, isPremium: isPremium);

            if (locked) {
              return _LockedChallengeBody(program: program);
            }

            final AsyncValue<Set<String>> completedAsync =
                ref.watch(challengeCompletedStepIdsProvider(program.id));
            final Set<String> completed = completedAsync.value ?? const <String>{};

            return ListView(
              padding: EdgeInsets.all(context.spacing.lg),
              children: <Widget>[
                Text(program.title, style: textTheme.headlineMedium),
                SizedBox(height: context.spacing.xs),
                Text(program.description, style: textTheme.bodyLarge),
                SizedBox(height: context.spacing.sm),
                Text(
                  '${completed.length} of ${program.steps.length} steps completed',
                  style: textTheme.bodySmall,
                ),
                SizedBox(height: context.spacing.lg),
                PrimaryButton(
                  label: 'Open Say No',
                  onPressed: () =>
                      _openSayNo(context, ref, program.suggestedCategoryId),
                ),
                SizedBox(height: context.spacing.lg),
                for (final ChallengeStep step in program.steps)
                  _StepTile(
                    step: step,
                    completed: completed.contains(step.id),
                    onToggle: () => ref
                        .read(challengeProgressRepositoryProvider)
                        .toggleStep(program.id, step.id)
                        .then((_) => ref.invalidate(
                            challengeCompletedStepIdsProvider(program.id))),
                  ),
              ],
            );
          },
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (Object error, StackTrace stackTrace) =>
              Center(child: Text('Could not load this challenge: $error')),
        ),
      ),
    );
  }
}

class _StepTile extends StatelessWidget {
  const _StepTile({
    required this.step,
    required this.completed,
    required this.onToggle,
  });

  final ChallengeStep step;
  final bool completed;
  final VoidCallback onToggle;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      checked: completed,
      label: step.text,
      child: InkWell(
        onTap: onToggle,
        borderRadius: context.radius.mdRadius,
        child: Padding(
          padding: EdgeInsets.symmetric(vertical: context.spacing.xs),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Icon(
                completed ? Icons.check_circle : Icons.circle_outlined,
                color: completed ? context.colors.sageStrong : context.colors.border,
                size: 22,
              ),
              SizedBox(width: context.spacing.sm),
              Expanded(
                child: Text(
                  step.text,
                  style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                        color: completed ? context.colors.textSecondary : null,
                        decoration: completed ? TextDecoration.lineThrough : null,
                      ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _LockedChallengeBody extends StatelessWidget {
  const _LockedChallengeBody({required this.program});

  final ChallengeProgram program;

  @override
  Widget build(BuildContext context) {
    final TextTheme textTheme = Theme.of(context).textTheme;

    return ListView(
      padding: EdgeInsets.all(context.spacing.lg),
      children: <Widget>[
        Text('${program.title} 🔒', style: textTheme.headlineMedium),
        SizedBox(height: context.spacing.sm),
        Text(program.description, style: textTheme.bodyLarge),
        SizedBox(height: context.spacing.lg),
        AppCard(
          backgroundColor: context.colors.cream,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text('${program.steps.length} steps', style: textTheme.labelLarge),
              SizedBox(height: context.spacing.xs),
              for (final ChallengeStep step in program.steps.take(3))
                Padding(
                  padding: EdgeInsets.symmetric(vertical: context.spacing.xs / 2),
                  child: Text('• ${step.text}', style: textTheme.bodyMedium),
                ),
            ],
          ),
        ),
        SizedBox(height: context.spacing.lg),
        PrimaryButton(
          label: 'Unlock with Vitamin N Premium',
          onPressed: () => Navigator.of(context).push<void>(
            MaterialPageRoute<void>(
                  builder: (_) => const PremiumScreen(entryPoint: PremiumEntryPoint.challenge),
                ),
          ),
        ),
      ],
    );
  }
}
