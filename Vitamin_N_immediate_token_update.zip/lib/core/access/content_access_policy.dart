import '../../features/categories/domain/entities/category_access.dart';
import '../../features/challenges/domain/entities/challenge_program.dart';
import '../../features/reality_reminders/domain/entities/reality_reminder.dart';

/// Central source of truth for content entitlement.
///
/// TEMPORARY QA UNLOCK — MUST BE FALSE FOR PRODUCTION RELEASE.
/// Keep production rules intact underneath this override so QA can exercise
/// every path without permanently changing monetization.
abstract final class ContentAccessPolicy {
  static const bool qaUnlockAll = true;

  static bool canOpenCategory(String categoryId, {required bool isPremium}) =>
      qaUnlockAll || isPremium || CategoryAccess.isFree(categoryId);

  static bool canSeeAllResponses({required bool isPremium}) =>
      qaUnlockAll || isPremium;

  static bool canUseAnotherWay({required bool isPremium}) =>
      qaUnlockAll || isPremium;

  static bool canSeeRealityReminder(String categoryId, {required bool isPremium}) =>
      qaUnlockAll || isPremium || RealityReminderAccess.isFreeForCategory(categoryId);

  static bool canOpenChallenge(String challengeId, {required bool isPremium}) =>
      qaUnlockAll || isPremium || ChallengeAccess.isFree(challengeId);
}
