# Vitamin N content maintenance

This project uses stable IDs. Once shipped, do not rename IDs just because display copy changes.

## Add a situation
1. Add it to the matching `assets/content/situations/<category>.json` with a unique stable ID.
2. Set `contentType` explicitly to `interpersonal` or `tomorrowYou`.
3. Add 3–4 strong responses in `assets/content/responses/<category>.json`.
4. Add a concise situation-specific reminder in `assets/content/reality_reminders/<category>.json`.
5. Run content validation and the full Flutter test suite.

## Tomorrow You
Use `contentType: "tomorrowYou"`. Copy must be written from the next day's perspective: warm, brief, lightly dry, never shaming. Do not infer this behavior from category names.

## Access / QA
All effective access is centralized in `lib/core/access/content_access_policy.dart`.
`ContentAccessPolicy.qaUnlockAll` is intentionally `true` for the current QA build. It MUST be `false` for production release. Do not duplicate entitlement checks in widgets; behavior and lock visuals must use the same effective policy.

## Retiring content
Prefer preserving released IDs and references. If an `active` mechanism is introduced/used, hide retired content from discovery while keeping lookup compatibility for History, Favorites and reminders. Do not physically delete referenced released content without a migration plan.

## Challenges / courses
Keep stable challenge/course IDs and use the existing content-driven repositories. Add new definitions through content assets rather than creating one-off screens.
