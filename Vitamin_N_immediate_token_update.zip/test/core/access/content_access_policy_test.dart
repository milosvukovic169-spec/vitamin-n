import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/core/access/content_access_policy.dart';

void main() {
  test('QA build unlocks category, responses, reminders and challenges', () {
    expect(ContentAccessPolicy.qaUnlockAll, isTrue);
    expect(ContentAccessPolicy.canOpenCategory('cat_money', isPremium: false), isTrue);
    expect(ContentAccessPolicy.canSeeAllResponses(isPremium: false), isTrue);
    expect(ContentAccessPolicy.canUseAnotherWay(isPremium: false), isTrue);
    expect(ContentAccessPolicy.canSeeRealityReminder('cat_work', isPremium: false), isTrue);
    expect(ContentAccessPolicy.canOpenChallenge('challenge_work_boundaries', isPremium: false), isTrue);
  });
}
