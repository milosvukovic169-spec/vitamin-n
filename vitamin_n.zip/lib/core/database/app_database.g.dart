// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'app_database.dart';

// ignore_for_file: type=lint
class $CoursesTable extends Courses with TableInfo<$CoursesTable, CourseRow> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CoursesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, false,
      hasAutoIncrement: true,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('PRIMARY KEY AUTOINCREMENT'));
  static const VerificationMeta _cycleNumberMeta =
      const VerificationMeta('cycleNumber');
  @override
  late final GeneratedColumn<int> cycleNumber = GeneratedColumn<int>(
      'cycle_number', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _tokensRemainingMeta =
      const VerificationMeta('tokensRemaining');
  @override
  late final GeneratedColumn<int> tokensRemaining = GeneratedColumn<int>(
      'tokens_remaining', aliasedName, false,
      type: DriftSqlType.int, requiredDuringInsert: true);
  static const VerificationMeta _startedAtMeta =
      const VerificationMeta('startedAt');
  @override
  late final GeneratedColumn<DateTime> startedAt = GeneratedColumn<DateTime>(
      'started_at', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _completedAtMeta =
      const VerificationMeta('completedAt');
  @override
  late final GeneratedColumn<DateTime> completedAt = GeneratedColumn<DateTime>(
      'completed_at', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, cycleNumber, tokensRemaining, startedAt, completedAt];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'courses';
  @override
  VerificationContext validateIntegrity(Insertable<CourseRow> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('cycle_number')) {
      context.handle(
          _cycleNumberMeta,
          cycleNumber.isAcceptableOrUnknown(
              data['cycle_number']!, _cycleNumberMeta));
    } else if (isInserting) {
      context.missing(_cycleNumberMeta);
    }
    if (data.containsKey('tokens_remaining')) {
      context.handle(
          _tokensRemainingMeta,
          tokensRemaining.isAcceptableOrUnknown(
              data['tokens_remaining']!, _tokensRemainingMeta));
    } else if (isInserting) {
      context.missing(_tokensRemainingMeta);
    }
    if (data.containsKey('started_at')) {
      context.handle(_startedAtMeta,
          startedAt.isAcceptableOrUnknown(data['started_at']!, _startedAtMeta));
    } else if (isInserting) {
      context.missing(_startedAtMeta);
    }
    if (data.containsKey('completed_at')) {
      context.handle(
          _completedAtMeta,
          completedAt.isAcceptableOrUnknown(
              data['completed_at']!, _completedAtMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CourseRow map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CourseRow(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id'])!,
      cycleNumber: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}cycle_number'])!,
      tokensRemaining: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}tokens_remaining'])!,
      startedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}started_at'])!,
      completedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}completed_at']),
    );
  }

  @override
  $CoursesTable createAlias(String alias) {
    return $CoursesTable(attachedDatabase, alias);
  }
}

class CourseRow extends DataClass implements Insertable<CourseRow> {
  final int id;
  final int cycleNumber;
  final int tokensRemaining;
  final DateTime startedAt;
  final DateTime? completedAt;
  const CourseRow(
      {required this.id,
      required this.cycleNumber,
      required this.tokensRemaining,
      required this.startedAt,
      this.completedAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['cycle_number'] = Variable<int>(cycleNumber);
    map['tokens_remaining'] = Variable<int>(tokensRemaining);
    map['started_at'] = Variable<DateTime>(startedAt);
    if (!nullToAbsent || completedAt != null) {
      map['completed_at'] = Variable<DateTime>(completedAt);
    }
    return map;
  }

  CoursesCompanion toCompanion(bool nullToAbsent) {
    return CoursesCompanion(
      id: Value(id),
      cycleNumber: Value(cycleNumber),
      tokensRemaining: Value(tokensRemaining),
      startedAt: Value(startedAt),
      completedAt: completedAt == null && nullToAbsent
          ? const Value.absent()
          : Value(completedAt),
    );
  }

  factory CourseRow.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CourseRow(
      id: serializer.fromJson<int>(json['id']),
      cycleNumber: serializer.fromJson<int>(json['cycleNumber']),
      tokensRemaining: serializer.fromJson<int>(json['tokensRemaining']),
      startedAt: serializer.fromJson<DateTime>(json['startedAt']),
      completedAt: serializer.fromJson<DateTime?>(json['completedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'cycleNumber': serializer.toJson<int>(cycleNumber),
      'tokensRemaining': serializer.toJson<int>(tokensRemaining),
      'startedAt': serializer.toJson<DateTime>(startedAt),
      'completedAt': serializer.toJson<DateTime?>(completedAt),
    };
  }

  CourseRow copyWith(
          {int? id,
          int? cycleNumber,
          int? tokensRemaining,
          DateTime? startedAt,
          Value<DateTime?> completedAt = const Value.absent()}) =>
      CourseRow(
        id: id ?? this.id,
        cycleNumber: cycleNumber ?? this.cycleNumber,
        tokensRemaining: tokensRemaining ?? this.tokensRemaining,
        startedAt: startedAt ?? this.startedAt,
        completedAt: completedAt.present ? completedAt.value : this.completedAt,
      );
  CourseRow copyWithCompanion(CoursesCompanion data) {
    return CourseRow(
      id: data.id.present ? data.id.value : this.id,
      cycleNumber:
          data.cycleNumber.present ? data.cycleNumber.value : this.cycleNumber,
      tokensRemaining: data.tokensRemaining.present
          ? data.tokensRemaining.value
          : this.tokensRemaining,
      startedAt: data.startedAt.present ? data.startedAt.value : this.startedAt,
      completedAt:
          data.completedAt.present ? data.completedAt.value : this.completedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('CourseRow(')
          ..write('id: $id, ')
          ..write('cycleNumber: $cycleNumber, ')
          ..write('tokensRemaining: $tokensRemaining, ')
          ..write('startedAt: $startedAt, ')
          ..write('completedAt: $completedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, cycleNumber, tokensRemaining, startedAt, completedAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CourseRow &&
          other.id == this.id &&
          other.cycleNumber == this.cycleNumber &&
          other.tokensRemaining == this.tokensRemaining &&
          other.startedAt == this.startedAt &&
          other.completedAt == this.completedAt);
}

class CoursesCompanion extends UpdateCompanion<CourseRow> {
  final Value<int> id;
  final Value<int> cycleNumber;
  final Value<int> tokensRemaining;
  final Value<DateTime> startedAt;
  final Value<DateTime?> completedAt;
  const CoursesCompanion({
    this.id = const Value.absent(),
    this.cycleNumber = const Value.absent(),
    this.tokensRemaining = const Value.absent(),
    this.startedAt = const Value.absent(),
    this.completedAt = const Value.absent(),
  });
  CoursesCompanion.insert({
    this.id = const Value.absent(),
    required int cycleNumber,
    required int tokensRemaining,
    required DateTime startedAt,
    this.completedAt = const Value.absent(),
  })  : cycleNumber = Value(cycleNumber),
        tokensRemaining = Value(tokensRemaining),
        startedAt = Value(startedAt);
  static Insertable<CourseRow> custom({
    Expression<int>? id,
    Expression<int>? cycleNumber,
    Expression<int>? tokensRemaining,
    Expression<DateTime>? startedAt,
    Expression<DateTime>? completedAt,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (cycleNumber != null) 'cycle_number': cycleNumber,
      if (tokensRemaining != null) 'tokens_remaining': tokensRemaining,
      if (startedAt != null) 'started_at': startedAt,
      if (completedAt != null) 'completed_at': completedAt,
    });
  }

  CoursesCompanion copyWith(
      {Value<int>? id,
      Value<int>? cycleNumber,
      Value<int>? tokensRemaining,
      Value<DateTime>? startedAt,
      Value<DateTime?>? completedAt}) {
    return CoursesCompanion(
      id: id ?? this.id,
      cycleNumber: cycleNumber ?? this.cycleNumber,
      tokensRemaining: tokensRemaining ?? this.tokensRemaining,
      startedAt: startedAt ?? this.startedAt,
      completedAt: completedAt ?? this.completedAt,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (cycleNumber.present) {
      map['cycle_number'] = Variable<int>(cycleNumber.value);
    }
    if (tokensRemaining.present) {
      map['tokens_remaining'] = Variable<int>(tokensRemaining.value);
    }
    if (startedAt.present) {
      map['started_at'] = Variable<DateTime>(startedAt.value);
    }
    if (completedAt.present) {
      map['completed_at'] = Variable<DateTime>(completedAt.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CoursesCompanion(')
          ..write('id: $id, ')
          ..write('cycleNumber: $cycleNumber, ')
          ..write('tokensRemaining: $tokensRemaining, ')
          ..write('startedAt: $startedAt, ')
          ..write('completedAt: $completedAt')
          ..write(')'))
        .toString();
  }
}

class $EntriesTable extends Entries with TableInfo<$EntriesTable, EntryRow> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $EntriesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _categoryIdMeta =
      const VerificationMeta('categoryId');
  @override
  late final GeneratedColumn<String> categoryId = GeneratedColumn<String>(
      'category_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _situationIdMeta =
      const VerificationMeta('situationId');
  @override
  late final GeneratedColumn<String> situationId = GeneratedColumn<String>(
      'situation_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _refusalResponseIdMeta =
      const VerificationMeta('refusalResponseId');
  @override
  late final GeneratedColumn<String> refusalResponseId =
      GeneratedColumn<String>('refusal_response_id', aliasedName, true,
          type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _protectedValueIdsMeta =
      const VerificationMeta('protectedValueIds');
  @override
  late final GeneratedColumn<String> protectedValueIds =
      GeneratedColumn<String>('protected_value_ids', aliasedName, false,
          type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _personalReminderNoteMeta =
      const VerificationMeta('personalReminderNote');
  @override
  late final GeneratedColumn<String> personalReminderNote =
      GeneratedColumn<String>('personal_reminder_note', aliasedName, true,
          type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _customProtectedValueMeta =
      const VerificationMeta('customProtectedValue');
  @override
  late final GeneratedColumn<String> customProtectedValue =
      GeneratedColumn<String>('custom_protected_value', aliasedName, true,
          type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _reflectionPauseShownMeta =
      const VerificationMeta('reflectionPauseShown');
  @override
  late final GeneratedColumn<bool> reflectionPauseShown = GeneratedColumn<bool>(
      'reflection_pause_shown', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints: GeneratedColumn.constraintIsAlways(
          'CHECK ("reflection_pause_shown" IN (0, 1))'),
      defaultValue: const Constant(false));
  static const VerificationMeta _courseIdMeta =
      const VerificationMeta('courseId');
  @override
  late final GeneratedColumn<int> courseId = GeneratedColumn<int>(
      'course_id', aliasedName, false,
      type: DriftSqlType.int,
      requiredDuringInsert: true,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('REFERENCES courses (id)'));
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        categoryId,
        situationId,
        refusalResponseId,
        protectedValueIds,
        personalReminderNote,
        customProtectedValue,
        reflectionPauseShown,
        courseId,
        createdAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'entries';
  @override
  VerificationContext validateIntegrity(Insertable<EntryRow> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('category_id')) {
      context.handle(
          _categoryIdMeta,
          categoryId.isAcceptableOrUnknown(
              data['category_id']!, _categoryIdMeta));
    } else if (isInserting) {
      context.missing(_categoryIdMeta);
    }
    if (data.containsKey('situation_id')) {
      context.handle(
          _situationIdMeta,
          situationId.isAcceptableOrUnknown(
              data['situation_id']!, _situationIdMeta));
    } else if (isInserting) {
      context.missing(_situationIdMeta);
    }
    if (data.containsKey('refusal_response_id')) {
      context.handle(
          _refusalResponseIdMeta,
          refusalResponseId.isAcceptableOrUnknown(
              data['refusal_response_id']!, _refusalResponseIdMeta));
    }
    if (data.containsKey('protected_value_ids')) {
      context.handle(
          _protectedValueIdsMeta,
          protectedValueIds.isAcceptableOrUnknown(
              data['protected_value_ids']!, _protectedValueIdsMeta));
    } else if (isInserting) {
      context.missing(_protectedValueIdsMeta);
    }
    if (data.containsKey('personal_reminder_note')) {
      context.handle(
          _personalReminderNoteMeta,
          personalReminderNote.isAcceptableOrUnknown(
              data['personal_reminder_note']!, _personalReminderNoteMeta));
    }
    if (data.containsKey('custom_protected_value')) {
      context.handle(
          _customProtectedValueMeta,
          customProtectedValue.isAcceptableOrUnknown(
              data['custom_protected_value']!, _customProtectedValueMeta));
    }
    if (data.containsKey('reflection_pause_shown')) {
      context.handle(
          _reflectionPauseShownMeta,
          reflectionPauseShown.isAcceptableOrUnknown(
              data['reflection_pause_shown']!, _reflectionPauseShownMeta));
    }
    if (data.containsKey('course_id')) {
      context.handle(_courseIdMeta,
          courseId.isAcceptableOrUnknown(data['course_id']!, _courseIdMeta));
    } else if (isInserting) {
      context.missing(_courseIdMeta);
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    } else if (isInserting) {
      context.missing(_createdAtMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  EntryRow map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return EntryRow(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      categoryId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}category_id'])!,
      situationId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}situation_id'])!,
      refusalResponseId: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}refusal_response_id']),
      protectedValueIds: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}protected_value_ids'])!,
      personalReminderNote: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}personal_reminder_note']),
      customProtectedValue: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}custom_protected_value']),
      reflectionPauseShown: attachedDatabase.typeMapping.read(
          DriftSqlType.bool, data['${effectivePrefix}reflection_pause_shown'])!,
      courseId: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}course_id'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
    );
  }

  @override
  $EntriesTable createAlias(String alias) {
    return $EntriesTable(attachedDatabase, alias);
  }
}

class EntryRow extends DataClass implements Insertable<EntryRow> {
  final String id;
  final String categoryId;
  final String situationId;
  final String? refusalResponseId;

  /// JSON-encoded list of protected value ids. Kept as a single text
  /// column rather than a join table since it's always read/written
  /// as a whole with the entry, never queried by individual value on
  /// its own — aggregation happens in the repository layer.
  final String protectedValueIds;
  final String? personalReminderNote;

  /// A free-text protected value the user typed under "Other",
  /// alongside (not replacing) [protectedValueIds].
  final String? customProtectedValue;

  /// Whether the Reflection Pause screen was shown during this flow —
  /// kept for future analysis of the pause's effect, never surfaced
  /// to the user as a stat.
  final bool reflectionPauseShown;
  final int courseId;
  final DateTime createdAt;
  const EntryRow(
      {required this.id,
      required this.categoryId,
      required this.situationId,
      this.refusalResponseId,
      required this.protectedValueIds,
      this.personalReminderNote,
      this.customProtectedValue,
      required this.reflectionPauseShown,
      required this.courseId,
      required this.createdAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['category_id'] = Variable<String>(categoryId);
    map['situation_id'] = Variable<String>(situationId);
    if (!nullToAbsent || refusalResponseId != null) {
      map['refusal_response_id'] = Variable<String>(refusalResponseId);
    }
    map['protected_value_ids'] = Variable<String>(protectedValueIds);
    if (!nullToAbsent || personalReminderNote != null) {
      map['personal_reminder_note'] = Variable<String>(personalReminderNote);
    }
    if (!nullToAbsent || customProtectedValue != null) {
      map['custom_protected_value'] = Variable<String>(customProtectedValue);
    }
    map['reflection_pause_shown'] = Variable<bool>(reflectionPauseShown);
    map['course_id'] = Variable<int>(courseId);
    map['created_at'] = Variable<DateTime>(createdAt);
    return map;
  }

  EntriesCompanion toCompanion(bool nullToAbsent) {
    return EntriesCompanion(
      id: Value(id),
      categoryId: Value(categoryId),
      situationId: Value(situationId),
      refusalResponseId: refusalResponseId == null && nullToAbsent
          ? const Value.absent()
          : Value(refusalResponseId),
      protectedValueIds: Value(protectedValueIds),
      personalReminderNote: personalReminderNote == null && nullToAbsent
          ? const Value.absent()
          : Value(personalReminderNote),
      customProtectedValue: customProtectedValue == null && nullToAbsent
          ? const Value.absent()
          : Value(customProtectedValue),
      reflectionPauseShown: Value(reflectionPauseShown),
      courseId: Value(courseId),
      createdAt: Value(createdAt),
    );
  }

  factory EntryRow.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return EntryRow(
      id: serializer.fromJson<String>(json['id']),
      categoryId: serializer.fromJson<String>(json['categoryId']),
      situationId: serializer.fromJson<String>(json['situationId']),
      refusalResponseId:
          serializer.fromJson<String?>(json['refusalResponseId']),
      protectedValueIds: serializer.fromJson<String>(json['protectedValueIds']),
      personalReminderNote:
          serializer.fromJson<String?>(json['personalReminderNote']),
      customProtectedValue:
          serializer.fromJson<String?>(json['customProtectedValue']),
      reflectionPauseShown:
          serializer.fromJson<bool>(json['reflectionPauseShown']),
      courseId: serializer.fromJson<int>(json['courseId']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'categoryId': serializer.toJson<String>(categoryId),
      'situationId': serializer.toJson<String>(situationId),
      'refusalResponseId': serializer.toJson<String?>(refusalResponseId),
      'protectedValueIds': serializer.toJson<String>(protectedValueIds),
      'personalReminderNote': serializer.toJson<String?>(personalReminderNote),
      'customProtectedValue': serializer.toJson<String?>(customProtectedValue),
      'reflectionPauseShown': serializer.toJson<bool>(reflectionPauseShown),
      'courseId': serializer.toJson<int>(courseId),
      'createdAt': serializer.toJson<DateTime>(createdAt),
    };
  }

  EntryRow copyWith(
          {String? id,
          String? categoryId,
          String? situationId,
          Value<String?> refusalResponseId = const Value.absent(),
          String? protectedValueIds,
          Value<String?> personalReminderNote = const Value.absent(),
          Value<String?> customProtectedValue = const Value.absent(),
          bool? reflectionPauseShown,
          int? courseId,
          DateTime? createdAt}) =>
      EntryRow(
        id: id ?? this.id,
        categoryId: categoryId ?? this.categoryId,
        situationId: situationId ?? this.situationId,
        refusalResponseId: refusalResponseId.present
            ? refusalResponseId.value
            : this.refusalResponseId,
        protectedValueIds: protectedValueIds ?? this.protectedValueIds,
        personalReminderNote: personalReminderNote.present
            ? personalReminderNote.value
            : this.personalReminderNote,
        customProtectedValue: customProtectedValue.present
            ? customProtectedValue.value
            : this.customProtectedValue,
        reflectionPauseShown: reflectionPauseShown ?? this.reflectionPauseShown,
        courseId: courseId ?? this.courseId,
        createdAt: createdAt ?? this.createdAt,
      );
  EntryRow copyWithCompanion(EntriesCompanion data) {
    return EntryRow(
      id: data.id.present ? data.id.value : this.id,
      categoryId:
          data.categoryId.present ? data.categoryId.value : this.categoryId,
      situationId:
          data.situationId.present ? data.situationId.value : this.situationId,
      refusalResponseId: data.refusalResponseId.present
          ? data.refusalResponseId.value
          : this.refusalResponseId,
      protectedValueIds: data.protectedValueIds.present
          ? data.protectedValueIds.value
          : this.protectedValueIds,
      personalReminderNote: data.personalReminderNote.present
          ? data.personalReminderNote.value
          : this.personalReminderNote,
      customProtectedValue: data.customProtectedValue.present
          ? data.customProtectedValue.value
          : this.customProtectedValue,
      reflectionPauseShown: data.reflectionPauseShown.present
          ? data.reflectionPauseShown.value
          : this.reflectionPauseShown,
      courseId: data.courseId.present ? data.courseId.value : this.courseId,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('EntryRow(')
          ..write('id: $id, ')
          ..write('categoryId: $categoryId, ')
          ..write('situationId: $situationId, ')
          ..write('refusalResponseId: $refusalResponseId, ')
          ..write('protectedValueIds: $protectedValueIds, ')
          ..write('personalReminderNote: $personalReminderNote, ')
          ..write('customProtectedValue: $customProtectedValue, ')
          ..write('reflectionPauseShown: $reflectionPauseShown, ')
          ..write('courseId: $courseId, ')
          ..write('createdAt: $createdAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      categoryId,
      situationId,
      refusalResponseId,
      protectedValueIds,
      personalReminderNote,
      customProtectedValue,
      reflectionPauseShown,
      courseId,
      createdAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is EntryRow &&
          other.id == this.id &&
          other.categoryId == this.categoryId &&
          other.situationId == this.situationId &&
          other.refusalResponseId == this.refusalResponseId &&
          other.protectedValueIds == this.protectedValueIds &&
          other.personalReminderNote == this.personalReminderNote &&
          other.customProtectedValue == this.customProtectedValue &&
          other.reflectionPauseShown == this.reflectionPauseShown &&
          other.courseId == this.courseId &&
          other.createdAt == this.createdAt);
}

class EntriesCompanion extends UpdateCompanion<EntryRow> {
  final Value<String> id;
  final Value<String> categoryId;
  final Value<String> situationId;
  final Value<String?> refusalResponseId;
  final Value<String> protectedValueIds;
  final Value<String?> personalReminderNote;
  final Value<String?> customProtectedValue;
  final Value<bool> reflectionPauseShown;
  final Value<int> courseId;
  final Value<DateTime> createdAt;
  final Value<int> rowid;
  const EntriesCompanion({
    this.id = const Value.absent(),
    this.categoryId = const Value.absent(),
    this.situationId = const Value.absent(),
    this.refusalResponseId = const Value.absent(),
    this.protectedValueIds = const Value.absent(),
    this.personalReminderNote = const Value.absent(),
    this.customProtectedValue = const Value.absent(),
    this.reflectionPauseShown = const Value.absent(),
    this.courseId = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  EntriesCompanion.insert({
    required String id,
    required String categoryId,
    required String situationId,
    this.refusalResponseId = const Value.absent(),
    required String protectedValueIds,
    this.personalReminderNote = const Value.absent(),
    this.customProtectedValue = const Value.absent(),
    this.reflectionPauseShown = const Value.absent(),
    required int courseId,
    required DateTime createdAt,
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        categoryId = Value(categoryId),
        situationId = Value(situationId),
        protectedValueIds = Value(protectedValueIds),
        courseId = Value(courseId),
        createdAt = Value(createdAt);
  static Insertable<EntryRow> custom({
    Expression<String>? id,
    Expression<String>? categoryId,
    Expression<String>? situationId,
    Expression<String>? refusalResponseId,
    Expression<String>? protectedValueIds,
    Expression<String>? personalReminderNote,
    Expression<String>? customProtectedValue,
    Expression<bool>? reflectionPauseShown,
    Expression<int>? courseId,
    Expression<DateTime>? createdAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (categoryId != null) 'category_id': categoryId,
      if (situationId != null) 'situation_id': situationId,
      if (refusalResponseId != null) 'refusal_response_id': refusalResponseId,
      if (protectedValueIds != null) 'protected_value_ids': protectedValueIds,
      if (personalReminderNote != null)
        'personal_reminder_note': personalReminderNote,
      if (customProtectedValue != null)
        'custom_protected_value': customProtectedValue,
      if (reflectionPauseShown != null)
        'reflection_pause_shown': reflectionPauseShown,
      if (courseId != null) 'course_id': courseId,
      if (createdAt != null) 'created_at': createdAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  EntriesCompanion copyWith(
      {Value<String>? id,
      Value<String>? categoryId,
      Value<String>? situationId,
      Value<String?>? refusalResponseId,
      Value<String>? protectedValueIds,
      Value<String?>? personalReminderNote,
      Value<String?>? customProtectedValue,
      Value<bool>? reflectionPauseShown,
      Value<int>? courseId,
      Value<DateTime>? createdAt,
      Value<int>? rowid}) {
    return EntriesCompanion(
      id: id ?? this.id,
      categoryId: categoryId ?? this.categoryId,
      situationId: situationId ?? this.situationId,
      refusalResponseId: refusalResponseId ?? this.refusalResponseId,
      protectedValueIds: protectedValueIds ?? this.protectedValueIds,
      personalReminderNote: personalReminderNote ?? this.personalReminderNote,
      customProtectedValue: customProtectedValue ?? this.customProtectedValue,
      reflectionPauseShown: reflectionPauseShown ?? this.reflectionPauseShown,
      courseId: courseId ?? this.courseId,
      createdAt: createdAt ?? this.createdAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (categoryId.present) {
      map['category_id'] = Variable<String>(categoryId.value);
    }
    if (situationId.present) {
      map['situation_id'] = Variable<String>(situationId.value);
    }
    if (refusalResponseId.present) {
      map['refusal_response_id'] = Variable<String>(refusalResponseId.value);
    }
    if (protectedValueIds.present) {
      map['protected_value_ids'] = Variable<String>(protectedValueIds.value);
    }
    if (personalReminderNote.present) {
      map['personal_reminder_note'] =
          Variable<String>(personalReminderNote.value);
    }
    if (customProtectedValue.present) {
      map['custom_protected_value'] =
          Variable<String>(customProtectedValue.value);
    }
    if (reflectionPauseShown.present) {
      map['reflection_pause_shown'] =
          Variable<bool>(reflectionPauseShown.value);
    }
    if (courseId.present) {
      map['course_id'] = Variable<int>(courseId.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('EntriesCompanion(')
          ..write('id: $id, ')
          ..write('categoryId: $categoryId, ')
          ..write('situationId: $situationId, ')
          ..write('refusalResponseId: $refusalResponseId, ')
          ..write('protectedValueIds: $protectedValueIds, ')
          ..write('personalReminderNote: $personalReminderNote, ')
          ..write('customProtectedValue: $customProtectedValue, ')
          ..write('reflectionPauseShown: $reflectionPauseShown, ')
          ..write('courseId: $courseId, ')
          ..write('createdAt: $createdAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $SettingsTable extends Settings
    with TableInfo<$SettingsTable, SettingRow> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $SettingsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _keyMeta = const VerificationMeta('key');
  @override
  late final GeneratedColumn<String> key = GeneratedColumn<String>(
      'key', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _valueMeta = const VerificationMeta('value');
  @override
  late final GeneratedColumn<String> value = GeneratedColumn<String>(
      'value', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  @override
  List<GeneratedColumn> get $columns => [key, value];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'settings';
  @override
  VerificationContext validateIntegrity(Insertable<SettingRow> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('key')) {
      context.handle(
          _keyMeta, key.isAcceptableOrUnknown(data['key']!, _keyMeta));
    } else if (isInserting) {
      context.missing(_keyMeta);
    }
    if (data.containsKey('value')) {
      context.handle(
          _valueMeta, value.isAcceptableOrUnknown(data['value']!, _valueMeta));
    } else if (isInserting) {
      context.missing(_valueMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {key};
  @override
  SettingRow map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return SettingRow(
      key: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}key'])!,
      value: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}value'])!,
    );
  }

  @override
  $SettingsTable createAlias(String alias) {
    return $SettingsTable(attachedDatabase, alias);
  }
}

class SettingRow extends DataClass implements Insertable<SettingRow> {
  final String key;
  final String value;
  const SettingRow({required this.key, required this.value});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['key'] = Variable<String>(key);
    map['value'] = Variable<String>(value);
    return map;
  }

  SettingsCompanion toCompanion(bool nullToAbsent) {
    return SettingsCompanion(
      key: Value(key),
      value: Value(value),
    );
  }

  factory SettingRow.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return SettingRow(
      key: serializer.fromJson<String>(json['key']),
      value: serializer.fromJson<String>(json['value']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'key': serializer.toJson<String>(key),
      'value': serializer.toJson<String>(value),
    };
  }

  SettingRow copyWith({String? key, String? value}) => SettingRow(
        key: key ?? this.key,
        value: value ?? this.value,
      );
  SettingRow copyWithCompanion(SettingsCompanion data) {
    return SettingRow(
      key: data.key.present ? data.key.value : this.key,
      value: data.value.present ? data.value.value : this.value,
    );
  }

  @override
  String toString() {
    return (StringBuffer('SettingRow(')
          ..write('key: $key, ')
          ..write('value: $value')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(key, value);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is SettingRow &&
          other.key == this.key &&
          other.value == this.value);
}

class SettingsCompanion extends UpdateCompanion<SettingRow> {
  final Value<String> key;
  final Value<String> value;
  final Value<int> rowid;
  const SettingsCompanion({
    this.key = const Value.absent(),
    this.value = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  SettingsCompanion.insert({
    required String key,
    required String value,
    this.rowid = const Value.absent(),
  })  : key = Value(key),
        value = Value(value);
  static Insertable<SettingRow> custom({
    Expression<String>? key,
    Expression<String>? value,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (key != null) 'key': key,
      if (value != null) 'value': value,
      if (rowid != null) 'rowid': rowid,
    });
  }

  SettingsCompanion copyWith(
      {Value<String>? key, Value<String>? value, Value<int>? rowid}) {
    return SettingsCompanion(
      key: key ?? this.key,
      value: value ?? this.value,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (key.present) {
      map['key'] = Variable<String>(key.value);
    }
    if (value.present) {
      map['value'] = Variable<String>(value.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('SettingsCompanion(')
          ..write('key: $key, ')
          ..write('value: $value, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $FavoritesTable extends Favorites
    with TableInfo<$FavoritesTable, FavoriteRow> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FavoritesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _entityTypeMeta =
      const VerificationMeta('entityType');
  @override
  late final GeneratedColumn<String> entityType = GeneratedColumn<String>(
      'entity_type', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _entityIdMeta =
      const VerificationMeta('entityId');
  @override
  late final GeneratedColumn<String> entityId = GeneratedColumn<String>(
      'entity_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  @override
  List<GeneratedColumn> get $columns => [id, entityType, entityId, createdAt];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'favorites';
  @override
  VerificationContext validateIntegrity(Insertable<FavoriteRow> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('entity_type')) {
      context.handle(
          _entityTypeMeta,
          entityType.isAcceptableOrUnknown(
              data['entity_type']!, _entityTypeMeta));
    } else if (isInserting) {
      context.missing(_entityTypeMeta);
    }
    if (data.containsKey('entity_id')) {
      context.handle(_entityIdMeta,
          entityId.isAcceptableOrUnknown(data['entity_id']!, _entityIdMeta));
    } else if (isInserting) {
      context.missing(_entityIdMeta);
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    } else if (isInserting) {
      context.missing(_createdAtMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  List<Set<GeneratedColumn>> get uniqueKeys => [
        {entityType, entityId},
      ];
  @override
  FavoriteRow map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FavoriteRow(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      entityType: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entity_type'])!,
      entityId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}entity_id'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
    );
  }

  @override
  $FavoritesTable createAlias(String alias) {
    return $FavoritesTable(attachedDatabase, alias);
  }
}

class FavoriteRow extends DataClass implements Insertable<FavoriteRow> {
  final String id;
  final String entityType;
  final String entityId;
  final DateTime createdAt;
  const FavoriteRow(
      {required this.id,
      required this.entityType,
      required this.entityId,
      required this.createdAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['entity_type'] = Variable<String>(entityType);
    map['entity_id'] = Variable<String>(entityId);
    map['created_at'] = Variable<DateTime>(createdAt);
    return map;
  }

  FavoritesCompanion toCompanion(bool nullToAbsent) {
    return FavoritesCompanion(
      id: Value(id),
      entityType: Value(entityType),
      entityId: Value(entityId),
      createdAt: Value(createdAt),
    );
  }

  factory FavoriteRow.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FavoriteRow(
      id: serializer.fromJson<String>(json['id']),
      entityType: serializer.fromJson<String>(json['entityType']),
      entityId: serializer.fromJson<String>(json['entityId']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'entityType': serializer.toJson<String>(entityType),
      'entityId': serializer.toJson<String>(entityId),
      'createdAt': serializer.toJson<DateTime>(createdAt),
    };
  }

  FavoriteRow copyWith(
          {String? id,
          String? entityType,
          String? entityId,
          DateTime? createdAt}) =>
      FavoriteRow(
        id: id ?? this.id,
        entityType: entityType ?? this.entityType,
        entityId: entityId ?? this.entityId,
        createdAt: createdAt ?? this.createdAt,
      );
  FavoriteRow copyWithCompanion(FavoritesCompanion data) {
    return FavoriteRow(
      id: data.id.present ? data.id.value : this.id,
      entityType:
          data.entityType.present ? data.entityType.value : this.entityType,
      entityId: data.entityId.present ? data.entityId.value : this.entityId,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FavoriteRow(')
          ..write('id: $id, ')
          ..write('entityType: $entityType, ')
          ..write('entityId: $entityId, ')
          ..write('createdAt: $createdAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, entityType, entityId, createdAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FavoriteRow &&
          other.id == this.id &&
          other.entityType == this.entityType &&
          other.entityId == this.entityId &&
          other.createdAt == this.createdAt);
}

class FavoritesCompanion extends UpdateCompanion<FavoriteRow> {
  final Value<String> id;
  final Value<String> entityType;
  final Value<String> entityId;
  final Value<DateTime> createdAt;
  final Value<int> rowid;
  const FavoritesCompanion({
    this.id = const Value.absent(),
    this.entityType = const Value.absent(),
    this.entityId = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  FavoritesCompanion.insert({
    required String id,
    required String entityType,
    required String entityId,
    required DateTime createdAt,
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        entityType = Value(entityType),
        entityId = Value(entityId),
        createdAt = Value(createdAt);
  static Insertable<FavoriteRow> custom({
    Expression<String>? id,
    Expression<String>? entityType,
    Expression<String>? entityId,
    Expression<DateTime>? createdAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (entityType != null) 'entity_type': entityType,
      if (entityId != null) 'entity_id': entityId,
      if (createdAt != null) 'created_at': createdAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  FavoritesCompanion copyWith(
      {Value<String>? id,
      Value<String>? entityType,
      Value<String>? entityId,
      Value<DateTime>? createdAt,
      Value<int>? rowid}) {
    return FavoritesCompanion(
      id: id ?? this.id,
      entityType: entityType ?? this.entityType,
      entityId: entityId ?? this.entityId,
      createdAt: createdAt ?? this.createdAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (entityType.present) {
      map['entity_type'] = Variable<String>(entityType.value);
    }
    if (entityId.present) {
      map['entity_id'] = Variable<String>(entityId.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FavoritesCompanion(')
          ..write('id: $id, ')
          ..write('entityType: $entityType, ')
          ..write('entityId: $entityId, ')
          ..write('createdAt: $createdAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $ActiveChallengesTable extends ActiveChallenges
    with TableInfo<$ActiveChallengesTable, ActiveChallengeRow> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ActiveChallengesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, false,
      hasAutoIncrement: true,
      type: DriftSqlType.int,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('PRIMARY KEY AUTOINCREMENT'));
  static const VerificationMeta _programIdMeta =
      const VerificationMeta('programId');
  @override
  late final GeneratedColumn<String> programId = GeneratedColumn<String>(
      'program_id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _startedAtMeta =
      const VerificationMeta('startedAt');
  @override
  late final GeneratedColumn<DateTime> startedAt = GeneratedColumn<DateTime>(
      'started_at', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  @override
  List<GeneratedColumn> get $columns => [id, programId, startedAt];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'active_challenges';
  @override
  VerificationContext validateIntegrity(Insertable<ActiveChallengeRow> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('program_id')) {
      context.handle(_programIdMeta,
          programId.isAcceptableOrUnknown(data['program_id']!, _programIdMeta));
    } else if (isInserting) {
      context.missing(_programIdMeta);
    }
    if (data.containsKey('started_at')) {
      context.handle(_startedAtMeta,
          startedAt.isAcceptableOrUnknown(data['started_at']!, _startedAtMeta));
    } else if (isInserting) {
      context.missing(_startedAtMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ActiveChallengeRow map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ActiveChallengeRow(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id'])!,
      programId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}program_id'])!,
      startedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}started_at'])!,
    );
  }

  @override
  $ActiveChallengesTable createAlias(String alias) {
    return $ActiveChallengesTable(attachedDatabase, alias);
  }
}

class ActiveChallengeRow extends DataClass
    implements Insertable<ActiveChallengeRow> {
  final int id;
  final String programId;
  final DateTime startedAt;
  const ActiveChallengeRow(
      {required this.id, required this.programId, required this.startedAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<int>(id);
    map['program_id'] = Variable<String>(programId);
    map['started_at'] = Variable<DateTime>(startedAt);
    return map;
  }

  ActiveChallengesCompanion toCompanion(bool nullToAbsent) {
    return ActiveChallengesCompanion(
      id: Value(id),
      programId: Value(programId),
      startedAt: Value(startedAt),
    );
  }

  factory ActiveChallengeRow.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ActiveChallengeRow(
      id: serializer.fromJson<int>(json['id']),
      programId: serializer.fromJson<String>(json['programId']),
      startedAt: serializer.fromJson<DateTime>(json['startedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int>(id),
      'programId': serializer.toJson<String>(programId),
      'startedAt': serializer.toJson<DateTime>(startedAt),
    };
  }

  ActiveChallengeRow copyWith(
          {int? id, String? programId, DateTime? startedAt}) =>
      ActiveChallengeRow(
        id: id ?? this.id,
        programId: programId ?? this.programId,
        startedAt: startedAt ?? this.startedAt,
      );
  ActiveChallengeRow copyWithCompanion(ActiveChallengesCompanion data) {
    return ActiveChallengeRow(
      id: data.id.present ? data.id.value : this.id,
      programId: data.programId.present ? data.programId.value : this.programId,
      startedAt: data.startedAt.present ? data.startedAt.value : this.startedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ActiveChallengeRow(')
          ..write('id: $id, ')
          ..write('programId: $programId, ')
          ..write('startedAt: $startedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, programId, startedAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ActiveChallengeRow &&
          other.id == this.id &&
          other.programId == this.programId &&
          other.startedAt == this.startedAt);
}

class ActiveChallengesCompanion extends UpdateCompanion<ActiveChallengeRow> {
  final Value<int> id;
  final Value<String> programId;
  final Value<DateTime> startedAt;
  const ActiveChallengesCompanion({
    this.id = const Value.absent(),
    this.programId = const Value.absent(),
    this.startedAt = const Value.absent(),
  });
  ActiveChallengesCompanion.insert({
    this.id = const Value.absent(),
    required String programId,
    required DateTime startedAt,
  })  : programId = Value(programId),
        startedAt = Value(startedAt);
  static Insertable<ActiveChallengeRow> custom({
    Expression<int>? id,
    Expression<String>? programId,
    Expression<DateTime>? startedAt,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (programId != null) 'program_id': programId,
      if (startedAt != null) 'started_at': startedAt,
    });
  }

  ActiveChallengesCompanion copyWith(
      {Value<int>? id, Value<String>? programId, Value<DateTime>? startedAt}) {
    return ActiveChallengesCompanion(
      id: id ?? this.id,
      programId: programId ?? this.programId,
      startedAt: startedAt ?? this.startedAt,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (programId.present) {
      map['program_id'] = Variable<String>(programId.value);
    }
    if (startedAt.present) {
      map['started_at'] = Variable<DateTime>(startedAt.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ActiveChallengesCompanion(')
          ..write('id: $id, ')
          ..write('programId: $programId, ')
          ..write('startedAt: $startedAt')
          ..write(')'))
        .toString();
  }
}

class $PersonalRemindersTable extends PersonalReminders
    with TableInfo<$PersonalRemindersTable, PersonalReminderRow> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PersonalRemindersTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<String> id = GeneratedColumn<String>(
      'id', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _reminderTextMeta =
      const VerificationMeta('reminderText');
  @override
  late final GeneratedColumn<String> reminderText = GeneratedColumn<String>(
      'text', aliasedName, false,
      type: DriftSqlType.string, requiredDuringInsert: true);
  static const VerificationMeta _categoryIdMeta =
      const VerificationMeta('categoryId');
  @override
  late final GeneratedColumn<String> categoryId = GeneratedColumn<String>(
      'category_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _situationIdMeta =
      const VerificationMeta('situationId');
  @override
  late final GeneratedColumn<String> situationId = GeneratedColumn<String>(
      'situation_id', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _isActiveMeta =
      const VerificationMeta('isActive');
  @override
  late final GeneratedColumn<bool> isActive = GeneratedColumn<bool>(
      'is_active', aliasedName, false,
      type: DriftSqlType.bool,
      requiredDuringInsert: false,
      defaultConstraints:
          GeneratedColumn.constraintIsAlways('CHECK ("is_active" IN (0, 1))'),
      defaultValue: const Constant(true));
  static const VerificationMeta _createdAtMeta =
      const VerificationMeta('createdAt');
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
      'created_at', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  static const VerificationMeta _updatedAtMeta =
      const VerificationMeta('updatedAt');
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
      'updated_at', aliasedName, false,
      type: DriftSqlType.dateTime, requiredDuringInsert: true);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        reminderText,
        categoryId,
        situationId,
        isActive,
        createdAt,
        updatedAt
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'personal_reminders';
  @override
  VerificationContext validateIntegrity(
      Insertable<PersonalReminderRow> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    } else if (isInserting) {
      context.missing(_idMeta);
    }
    if (data.containsKey('text')) {
      context.handle(_reminderTextMeta,
          reminderText.isAcceptableOrUnknown(data['text']!, _reminderTextMeta));
    } else if (isInserting) {
      context.missing(_reminderTextMeta);
    }
    if (data.containsKey('category_id')) {
      context.handle(
          _categoryIdMeta,
          categoryId.isAcceptableOrUnknown(
              data['category_id']!, _categoryIdMeta));
    }
    if (data.containsKey('situation_id')) {
      context.handle(
          _situationIdMeta,
          situationId.isAcceptableOrUnknown(
              data['situation_id']!, _situationIdMeta));
    }
    if (data.containsKey('is_active')) {
      context.handle(_isActiveMeta,
          isActive.isAcceptableOrUnknown(data['is_active']!, _isActiveMeta));
    }
    if (data.containsKey('created_at')) {
      context.handle(_createdAtMeta,
          createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta));
    } else if (isInserting) {
      context.missing(_createdAtMeta);
    }
    if (data.containsKey('updated_at')) {
      context.handle(_updatedAtMeta,
          updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta));
    } else if (isInserting) {
      context.missing(_updatedAtMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PersonalReminderRow map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PersonalReminderRow(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}id'])!,
      reminderText: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}text'])!,
      categoryId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}category_id']),
      situationId: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}situation_id']),
      isActive: attachedDatabase.typeMapping
          .read(DriftSqlType.bool, data['${effectivePrefix}is_active'])!,
      createdAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}created_at'])!,
      updatedAt: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}updated_at'])!,
    );
  }

  @override
  $PersonalRemindersTable createAlias(String alias) {
    return $PersonalRemindersTable(attachedDatabase, alias);
  }
}

class PersonalReminderRow extends DataClass
    implements Insertable<PersonalReminderRow> {
  final String id;
  final String reminderText;
  final String? categoryId;
  final String? situationId;
  final bool isActive;
  final DateTime createdAt;
  final DateTime updatedAt;
  const PersonalReminderRow(
      {required this.id,
      required this.reminderText,
      this.categoryId,
      this.situationId,
      required this.isActive,
      required this.createdAt,
      required this.updatedAt});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['id'] = Variable<String>(id);
    map['text'] = Variable<String>(reminderText);
    if (!nullToAbsent || categoryId != null) {
      map['category_id'] = Variable<String>(categoryId);
    }
    if (!nullToAbsent || situationId != null) {
      map['situation_id'] = Variable<String>(situationId);
    }
    map['is_active'] = Variable<bool>(isActive);
    map['created_at'] = Variable<DateTime>(createdAt);
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  PersonalRemindersCompanion toCompanion(bool nullToAbsent) {
    return PersonalRemindersCompanion(
      id: Value(id),
      reminderText: Value(reminderText),
      categoryId: categoryId == null && nullToAbsent
          ? const Value.absent()
          : Value(categoryId),
      situationId: situationId == null && nullToAbsent
          ? const Value.absent()
          : Value(situationId),
      isActive: Value(isActive),
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
    );
  }

  factory PersonalReminderRow.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PersonalReminderRow(
      id: serializer.fromJson<String>(json['id']),
      reminderText: serializer.fromJson<String>(json['reminderText']),
      categoryId: serializer.fromJson<String?>(json['categoryId']),
      situationId: serializer.fromJson<String?>(json['situationId']),
      isActive: serializer.fromJson<bool>(json['isActive']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<String>(id),
      'reminderText': serializer.toJson<String>(reminderText),
      'categoryId': serializer.toJson<String?>(categoryId),
      'situationId': serializer.toJson<String?>(situationId),
      'isActive': serializer.toJson<bool>(isActive),
      'createdAt': serializer.toJson<DateTime>(createdAt),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  PersonalReminderRow copyWith(
          {String? id,
          String? reminderText,
          Value<String?> categoryId = const Value.absent(),
          Value<String?> situationId = const Value.absent(),
          bool? isActive,
          DateTime? createdAt,
          DateTime? updatedAt}) =>
      PersonalReminderRow(
        id: id ?? this.id,
        reminderText: reminderText ?? this.reminderText,
        categoryId: categoryId.present ? categoryId.value : this.categoryId,
        situationId: situationId.present ? situationId.value : this.situationId,
        isActive: isActive ?? this.isActive,
        createdAt: createdAt ?? this.createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
      );
  PersonalReminderRow copyWithCompanion(PersonalRemindersCompanion data) {
    return PersonalReminderRow(
      id: data.id.present ? data.id.value : this.id,
      reminderText: data.reminderText.present
          ? data.reminderText.value
          : this.reminderText,
      categoryId:
          data.categoryId.present ? data.categoryId.value : this.categoryId,
      situationId:
          data.situationId.present ? data.situationId.value : this.situationId,
      isActive: data.isActive.present ? data.isActive.value : this.isActive,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('PersonalReminderRow(')
          ..write('id: $id, ')
          ..write('reminderText: $reminderText, ')
          ..write('categoryId: $categoryId, ')
          ..write('situationId: $situationId, ')
          ..write('isActive: $isActive, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, reminderText, categoryId, situationId,
      isActive, createdAt, updatedAt);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PersonalReminderRow &&
          other.id == this.id &&
          other.reminderText == this.reminderText &&
          other.categoryId == this.categoryId &&
          other.situationId == this.situationId &&
          other.isActive == this.isActive &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt);
}

class PersonalRemindersCompanion extends UpdateCompanion<PersonalReminderRow> {
  final Value<String> id;
  final Value<String> reminderText;
  final Value<String?> categoryId;
  final Value<String?> situationId;
  final Value<bool> isActive;
  final Value<DateTime> createdAt;
  final Value<DateTime> updatedAt;
  final Value<int> rowid;
  const PersonalRemindersCompanion({
    this.id = const Value.absent(),
    this.reminderText = const Value.absent(),
    this.categoryId = const Value.absent(),
    this.situationId = const Value.absent(),
    this.isActive = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  PersonalRemindersCompanion.insert({
    required String id,
    required String reminderText,
    this.categoryId = const Value.absent(),
    this.situationId = const Value.absent(),
    this.isActive = const Value.absent(),
    required DateTime createdAt,
    required DateTime updatedAt,
    this.rowid = const Value.absent(),
  })  : id = Value(id),
        reminderText = Value(reminderText),
        createdAt = Value(createdAt),
        updatedAt = Value(updatedAt);
  static Insertable<PersonalReminderRow> custom({
    Expression<String>? id,
    Expression<String>? reminderText,
    Expression<String>? categoryId,
    Expression<String>? situationId,
    Expression<bool>? isActive,
    Expression<DateTime>? createdAt,
    Expression<DateTime>? updatedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (reminderText != null) 'text': reminderText,
      if (categoryId != null) 'category_id': categoryId,
      if (situationId != null) 'situation_id': situationId,
      if (isActive != null) 'is_active': isActive,
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  PersonalRemindersCompanion copyWith(
      {Value<String>? id,
      Value<String>? reminderText,
      Value<String?>? categoryId,
      Value<String?>? situationId,
      Value<bool>? isActive,
      Value<DateTime>? createdAt,
      Value<DateTime>? updatedAt,
      Value<int>? rowid}) {
    return PersonalRemindersCompanion(
      id: id ?? this.id,
      reminderText: reminderText ?? this.reminderText,
      categoryId: categoryId ?? this.categoryId,
      situationId: situationId ?? this.situationId,
      isActive: isActive ?? this.isActive,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<String>(id.value);
    }
    if (reminderText.present) {
      map['text'] = Variable<String>(reminderText.value);
    }
    if (categoryId.present) {
      map['category_id'] = Variable<String>(categoryId.value);
    }
    if (situationId.present) {
      map['situation_id'] = Variable<String>(situationId.value);
    }
    if (isActive.present) {
      map['is_active'] = Variable<bool>(isActive.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PersonalRemindersCompanion(')
          ..write('id: $id, ')
          ..write('reminderText: $reminderText, ')
          ..write('categoryId: $categoryId, ')
          ..write('situationId: $situationId, ')
          ..write('isActive: $isActive, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  $AppDatabaseManager get managers => $AppDatabaseManager(this);
  late final $CoursesTable courses = $CoursesTable(this);
  late final $EntriesTable entries = $EntriesTable(this);
  late final $SettingsTable settings = $SettingsTable(this);
  late final $FavoritesTable favorites = $FavoritesTable(this);
  late final $ActiveChallengesTable activeChallenges =
      $ActiveChallengesTable(this);
  late final $PersonalRemindersTable personalReminders =
      $PersonalRemindersTable(this);
  late final Index idxEntriesCreatedAt = Index('idx_entries_created_at',
      'CREATE INDEX idx_entries_created_at ON entries (created_at)');
  late final Index idxEntriesCategoryId = Index('idx_entries_category_id',
      'CREATE INDEX idx_entries_category_id ON entries (category_id)');
  late final Index idxEntriesSituationId = Index('idx_entries_situation_id',
      'CREATE INDEX idx_entries_situation_id ON entries (situation_id)');
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
        courses,
        entries,
        settings,
        favorites,
        activeChallenges,
        personalReminders,
        idxEntriesCreatedAt,
        idxEntriesCategoryId,
        idxEntriesSituationId
      ];
}

typedef $$CoursesTableCreateCompanionBuilder = CoursesCompanion Function({
  Value<int> id,
  required int cycleNumber,
  required int tokensRemaining,
  required DateTime startedAt,
  Value<DateTime?> completedAt,
});
typedef $$CoursesTableUpdateCompanionBuilder = CoursesCompanion Function({
  Value<int> id,
  Value<int> cycleNumber,
  Value<int> tokensRemaining,
  Value<DateTime> startedAt,
  Value<DateTime?> completedAt,
});

final class $$CoursesTableReferences
    extends BaseReferences<_$AppDatabase, $CoursesTable, CourseRow> {
  $$CoursesTableReferences(super.$_db, super.$_table, super.$_typedResult);

  static MultiTypedResultKey<$EntriesTable, List<EntryRow>> _entriesRefsTable(
          _$AppDatabase db) =>
      MultiTypedResultKey.fromTable(db.entries,
          aliasName: 'courses__id__entries__course_id');

  $$EntriesTableProcessedTableManager get entriesRefs {
    final manager = $$EntriesTableTableManager($_db, $_db.entries)
        .filter((f) => f.courseId.id.sqlEquals($_itemColumn<int>('id')!));

    final cache = $_typedResult.readTableOrNull(_entriesRefsTable($_db));
    return ProcessedTableManager(
        manager.$state.copyWith(prefetchedData: cache));
  }
}

class $$CoursesTableFilterComposer
    extends Composer<_$AppDatabase, $CoursesTable> {
  $$CoursesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get cycleNumber => $composableBuilder(
      column: $table.cycleNumber, builder: (column) => ColumnFilters(column));

  ColumnFilters<int> get tokensRemaining => $composableBuilder(
      column: $table.tokensRemaining,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get startedAt => $composableBuilder(
      column: $table.startedAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get completedAt => $composableBuilder(
      column: $table.completedAt, builder: (column) => ColumnFilters(column));

  Expression<bool> entriesRefs(
      Expression<bool> Function($$EntriesTableFilterComposer f) f) {
    final $$EntriesTableFilterComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.id,
        referencedTable: $db.entries,
        getReferencedColumn: (t) => t.courseId,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$EntriesTableFilterComposer(
              $db: $db,
              $table: $db.entries,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return f(composer);
  }
}

class $$CoursesTableOrderingComposer
    extends Composer<_$AppDatabase, $CoursesTable> {
  $$CoursesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get cycleNumber => $composableBuilder(
      column: $table.cycleNumber, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<int> get tokensRemaining => $composableBuilder(
      column: $table.tokensRemaining,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get startedAt => $composableBuilder(
      column: $table.startedAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get completedAt => $composableBuilder(
      column: $table.completedAt, builder: (column) => ColumnOrderings(column));
}

class $$CoursesTableAnnotationComposer
    extends Composer<_$AppDatabase, $CoursesTable> {
  $$CoursesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get cycleNumber => $composableBuilder(
      column: $table.cycleNumber, builder: (column) => column);

  GeneratedColumn<int> get tokensRemaining => $composableBuilder(
      column: $table.tokensRemaining, builder: (column) => column);

  GeneratedColumn<DateTime> get startedAt =>
      $composableBuilder(column: $table.startedAt, builder: (column) => column);

  GeneratedColumn<DateTime> get completedAt => $composableBuilder(
      column: $table.completedAt, builder: (column) => column);

  Expression<T> entriesRefs<T extends Object>(
      Expression<T> Function($$EntriesTableAnnotationComposer a) f) {
    final $$EntriesTableAnnotationComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.id,
        referencedTable: $db.entries,
        getReferencedColumn: (t) => t.courseId,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$EntriesTableAnnotationComposer(
              $db: $db,
              $table: $db.entries,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return f(composer);
  }
}

class $$CoursesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $CoursesTable,
    CourseRow,
    $$CoursesTableFilterComposer,
    $$CoursesTableOrderingComposer,
    $$CoursesTableAnnotationComposer,
    $$CoursesTableCreateCompanionBuilder,
    $$CoursesTableUpdateCompanionBuilder,
    (CourseRow, $$CoursesTableReferences),
    CourseRow,
    PrefetchHooks Function({bool entriesRefs})> {
  $$CoursesTableTableManager(_$AppDatabase db, $CoursesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$CoursesTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$CoursesTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$CoursesTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<int> id = const Value.absent(),
            Value<int> cycleNumber = const Value.absent(),
            Value<int> tokensRemaining = const Value.absent(),
            Value<DateTime> startedAt = const Value.absent(),
            Value<DateTime?> completedAt = const Value.absent(),
          }) =>
              CoursesCompanion(
            id: id,
            cycleNumber: cycleNumber,
            tokensRemaining: tokensRemaining,
            startedAt: startedAt,
            completedAt: completedAt,
          ),
          createCompanionCallback: ({
            Value<int> id = const Value.absent(),
            required int cycleNumber,
            required int tokensRemaining,
            required DateTime startedAt,
            Value<DateTime?> completedAt = const Value.absent(),
          }) =>
              CoursesCompanion.insert(
            id: id,
            cycleNumber: cycleNumber,
            tokensRemaining: tokensRemaining,
            startedAt: startedAt,
            completedAt: completedAt,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) =>
                  (e.readTable(table), $$CoursesTableReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: ({entriesRefs = false}) {
            return PrefetchHooks(
              db: db,
              explicitlyWatchedTables: [if (entriesRefs) db.entries],
              addJoins: null,
              getPrefetchedDataCallback: (items) async {
                return [
                  if (entriesRefs)
                    await $_getPrefetchedData<CourseRow, $CoursesTable,
                            EntryRow>(
                        currentTable: table,
                        referencedTable:
                            $$CoursesTableReferences._entriesRefsTable(db),
                        managerFromTypedResult: (p0) =>
                            $$CoursesTableReferences(db, table, p0).entriesRefs,
                        referencedItemsForCurrentItem: (item,
                                referencedItems) =>
                            referencedItems.where((e) => e.courseId == item.id),
                        typedResults: items)
                ];
              },
            );
          },
        ));
}

typedef $$CoursesTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $CoursesTable,
    CourseRow,
    $$CoursesTableFilterComposer,
    $$CoursesTableOrderingComposer,
    $$CoursesTableAnnotationComposer,
    $$CoursesTableCreateCompanionBuilder,
    $$CoursesTableUpdateCompanionBuilder,
    (CourseRow, $$CoursesTableReferences),
    CourseRow,
    PrefetchHooks Function({bool entriesRefs})>;
typedef $$EntriesTableCreateCompanionBuilder = EntriesCompanion Function({
  required String id,
  required String categoryId,
  required String situationId,
  Value<String?> refusalResponseId,
  required String protectedValueIds,
  Value<String?> personalReminderNote,
  Value<String?> customProtectedValue,
  Value<bool> reflectionPauseShown,
  required int courseId,
  required DateTime createdAt,
  Value<int> rowid,
});
typedef $$EntriesTableUpdateCompanionBuilder = EntriesCompanion Function({
  Value<String> id,
  Value<String> categoryId,
  Value<String> situationId,
  Value<String?> refusalResponseId,
  Value<String> protectedValueIds,
  Value<String?> personalReminderNote,
  Value<String?> customProtectedValue,
  Value<bool> reflectionPauseShown,
  Value<int> courseId,
  Value<DateTime> createdAt,
  Value<int> rowid,
});

final class $$EntriesTableReferences
    extends BaseReferences<_$AppDatabase, $EntriesTable, EntryRow> {
  $$EntriesTableReferences(super.$_db, super.$_table, super.$_typedResult);

  static $CoursesTable _courseIdTable(_$AppDatabase db) =>
      db.courses.createAlias('entries__course_id__courses__id');

  $$CoursesTableProcessedTableManager get courseId {
    final $_column = $_itemColumn<int>('course_id')!;

    final manager = $$CoursesTableTableManager($_db, $_db.courses)
        .filter((f) => f.id.sqlEquals($_column));
    final item = $_typedResult.readTableOrNull(_courseIdTable($_db));
    if (item == null) return manager;
    return ProcessedTableManager(
        manager.$state.copyWith(prefetchedData: [item]));
  }
}

class $$EntriesTableFilterComposer
    extends Composer<_$AppDatabase, $EntriesTable> {
  $$EntriesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get categoryId => $composableBuilder(
      column: $table.categoryId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get situationId => $composableBuilder(
      column: $table.situationId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get refusalResponseId => $composableBuilder(
      column: $table.refusalResponseId,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get protectedValueIds => $composableBuilder(
      column: $table.protectedValueIds,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get personalReminderNote => $composableBuilder(
      column: $table.personalReminderNote,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get customProtectedValue => $composableBuilder(
      column: $table.customProtectedValue,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get reflectionPauseShown => $composableBuilder(
      column: $table.reflectionPauseShown,
      builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  $$CoursesTableFilterComposer get courseId {
    final $$CoursesTableFilterComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.courseId,
        referencedTable: $db.courses,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$CoursesTableFilterComposer(
              $db: $db,
              $table: $db.courses,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return composer;
  }
}

class $$EntriesTableOrderingComposer
    extends Composer<_$AppDatabase, $EntriesTable> {
  $$EntriesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get categoryId => $composableBuilder(
      column: $table.categoryId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get situationId => $composableBuilder(
      column: $table.situationId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get refusalResponseId => $composableBuilder(
      column: $table.refusalResponseId,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get protectedValueIds => $composableBuilder(
      column: $table.protectedValueIds,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get personalReminderNote => $composableBuilder(
      column: $table.personalReminderNote,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get customProtectedValue => $composableBuilder(
      column: $table.customProtectedValue,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get reflectionPauseShown => $composableBuilder(
      column: $table.reflectionPauseShown,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  $$CoursesTableOrderingComposer get courseId {
    final $$CoursesTableOrderingComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.courseId,
        referencedTable: $db.courses,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$CoursesTableOrderingComposer(
              $db: $db,
              $table: $db.courses,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return composer;
  }
}

class $$EntriesTableAnnotationComposer
    extends Composer<_$AppDatabase, $EntriesTable> {
  $$EntriesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get categoryId => $composableBuilder(
      column: $table.categoryId, builder: (column) => column);

  GeneratedColumn<String> get situationId => $composableBuilder(
      column: $table.situationId, builder: (column) => column);

  GeneratedColumn<String> get refusalResponseId => $composableBuilder(
      column: $table.refusalResponseId, builder: (column) => column);

  GeneratedColumn<String> get protectedValueIds => $composableBuilder(
      column: $table.protectedValueIds, builder: (column) => column);

  GeneratedColumn<String> get personalReminderNote => $composableBuilder(
      column: $table.personalReminderNote, builder: (column) => column);

  GeneratedColumn<String> get customProtectedValue => $composableBuilder(
      column: $table.customProtectedValue, builder: (column) => column);

  GeneratedColumn<bool> get reflectionPauseShown => $composableBuilder(
      column: $table.reflectionPauseShown, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  $$CoursesTableAnnotationComposer get courseId {
    final $$CoursesTableAnnotationComposer composer = $composerBuilder(
        composer: this,
        getCurrentColumn: (t) => t.courseId,
        referencedTable: $db.courses,
        getReferencedColumn: (t) => t.id,
        builder: (joinBuilder,
                {$addJoinBuilderToRootComposer,
                $removeJoinBuilderFromRootComposer}) =>
            $$CoursesTableAnnotationComposer(
              $db: $db,
              $table: $db.courses,
              $addJoinBuilderToRootComposer: $addJoinBuilderToRootComposer,
              joinBuilder: joinBuilder,
              $removeJoinBuilderFromRootComposer:
                  $removeJoinBuilderFromRootComposer,
            ));
    return composer;
  }
}

class $$EntriesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $EntriesTable,
    EntryRow,
    $$EntriesTableFilterComposer,
    $$EntriesTableOrderingComposer,
    $$EntriesTableAnnotationComposer,
    $$EntriesTableCreateCompanionBuilder,
    $$EntriesTableUpdateCompanionBuilder,
    (EntryRow, $$EntriesTableReferences),
    EntryRow,
    PrefetchHooks Function({bool courseId})> {
  $$EntriesTableTableManager(_$AppDatabase db, $EntriesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$EntriesTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$EntriesTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$EntriesTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> categoryId = const Value.absent(),
            Value<String> situationId = const Value.absent(),
            Value<String?> refusalResponseId = const Value.absent(),
            Value<String> protectedValueIds = const Value.absent(),
            Value<String?> personalReminderNote = const Value.absent(),
            Value<String?> customProtectedValue = const Value.absent(),
            Value<bool> reflectionPauseShown = const Value.absent(),
            Value<int> courseId = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              EntriesCompanion(
            id: id,
            categoryId: categoryId,
            situationId: situationId,
            refusalResponseId: refusalResponseId,
            protectedValueIds: protectedValueIds,
            personalReminderNote: personalReminderNote,
            customProtectedValue: customProtectedValue,
            reflectionPauseShown: reflectionPauseShown,
            courseId: courseId,
            createdAt: createdAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String categoryId,
            required String situationId,
            Value<String?> refusalResponseId = const Value.absent(),
            required String protectedValueIds,
            Value<String?> personalReminderNote = const Value.absent(),
            Value<String?> customProtectedValue = const Value.absent(),
            Value<bool> reflectionPauseShown = const Value.absent(),
            required int courseId,
            required DateTime createdAt,
            Value<int> rowid = const Value.absent(),
          }) =>
              EntriesCompanion.insert(
            id: id,
            categoryId: categoryId,
            situationId: situationId,
            refusalResponseId: refusalResponseId,
            protectedValueIds: protectedValueIds,
            personalReminderNote: personalReminderNote,
            customProtectedValue: customProtectedValue,
            reflectionPauseShown: reflectionPauseShown,
            courseId: courseId,
            createdAt: createdAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) =>
                  (e.readTable(table), $$EntriesTableReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: ({courseId = false}) {
            return PrefetchHooks(
              db: db,
              explicitlyWatchedTables: [],
              addJoins: <
                  T extends TableManagerState<
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic,
                      dynamic>>(state) {
                if (courseId) {
                  state = state.withJoin(
                    currentTable: table,
                    currentColumn: table.courseId,
                    referencedTable:
                        $$EntriesTableReferences._courseIdTable(db),
                    referencedColumn:
                        $$EntriesTableReferences._courseIdTable(db).id,
                  ) as T;
                }

                return state;
              },
              getPrefetchedDataCallback: (items) async {
                return [];
              },
            );
          },
        ));
}

typedef $$EntriesTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $EntriesTable,
    EntryRow,
    $$EntriesTableFilterComposer,
    $$EntriesTableOrderingComposer,
    $$EntriesTableAnnotationComposer,
    $$EntriesTableCreateCompanionBuilder,
    $$EntriesTableUpdateCompanionBuilder,
    (EntryRow, $$EntriesTableReferences),
    EntryRow,
    PrefetchHooks Function({bool courseId})>;
typedef $$SettingsTableCreateCompanionBuilder = SettingsCompanion Function({
  required String key,
  required String value,
  Value<int> rowid,
});
typedef $$SettingsTableUpdateCompanionBuilder = SettingsCompanion Function({
  Value<String> key,
  Value<String> value,
  Value<int> rowid,
});

class $$SettingsTableFilterComposer
    extends Composer<_$AppDatabase, $SettingsTable> {
  $$SettingsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get key => $composableBuilder(
      column: $table.key, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get value => $composableBuilder(
      column: $table.value, builder: (column) => ColumnFilters(column));
}

class $$SettingsTableOrderingComposer
    extends Composer<_$AppDatabase, $SettingsTable> {
  $$SettingsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get key => $composableBuilder(
      column: $table.key, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get value => $composableBuilder(
      column: $table.value, builder: (column) => ColumnOrderings(column));
}

class $$SettingsTableAnnotationComposer
    extends Composer<_$AppDatabase, $SettingsTable> {
  $$SettingsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get key =>
      $composableBuilder(column: $table.key, builder: (column) => column);

  GeneratedColumn<String> get value =>
      $composableBuilder(column: $table.value, builder: (column) => column);
}

class $$SettingsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $SettingsTable,
    SettingRow,
    $$SettingsTableFilterComposer,
    $$SettingsTableOrderingComposer,
    $$SettingsTableAnnotationComposer,
    $$SettingsTableCreateCompanionBuilder,
    $$SettingsTableUpdateCompanionBuilder,
    (SettingRow, BaseReferences<_$AppDatabase, $SettingsTable, SettingRow>),
    SettingRow,
    PrefetchHooks Function()> {
  $$SettingsTableTableManager(_$AppDatabase db, $SettingsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$SettingsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$SettingsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$SettingsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> key = const Value.absent(),
            Value<String> value = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              SettingsCompanion(
            key: key,
            value: value,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String key,
            required String value,
            Value<int> rowid = const Value.absent(),
          }) =>
              SettingsCompanion.insert(
            key: key,
            value: value,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$SettingsTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $SettingsTable,
    SettingRow,
    $$SettingsTableFilterComposer,
    $$SettingsTableOrderingComposer,
    $$SettingsTableAnnotationComposer,
    $$SettingsTableCreateCompanionBuilder,
    $$SettingsTableUpdateCompanionBuilder,
    (SettingRow, BaseReferences<_$AppDatabase, $SettingsTable, SettingRow>),
    SettingRow,
    PrefetchHooks Function()>;
typedef $$FavoritesTableCreateCompanionBuilder = FavoritesCompanion Function({
  required String id,
  required String entityType,
  required String entityId,
  required DateTime createdAt,
  Value<int> rowid,
});
typedef $$FavoritesTableUpdateCompanionBuilder = FavoritesCompanion Function({
  Value<String> id,
  Value<String> entityType,
  Value<String> entityId,
  Value<DateTime> createdAt,
  Value<int> rowid,
});

class $$FavoritesTableFilterComposer
    extends Composer<_$AppDatabase, $FavoritesTable> {
  $$FavoritesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get entityType => $composableBuilder(
      column: $table.entityType, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get entityId => $composableBuilder(
      column: $table.entityId, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));
}

class $$FavoritesTableOrderingComposer
    extends Composer<_$AppDatabase, $FavoritesTable> {
  $$FavoritesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get entityType => $composableBuilder(
      column: $table.entityType, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get entityId => $composableBuilder(
      column: $table.entityId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));
}

class $$FavoritesTableAnnotationComposer
    extends Composer<_$AppDatabase, $FavoritesTable> {
  $$FavoritesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get entityType => $composableBuilder(
      column: $table.entityType, builder: (column) => column);

  GeneratedColumn<String> get entityId =>
      $composableBuilder(column: $table.entityId, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);
}

class $$FavoritesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $FavoritesTable,
    FavoriteRow,
    $$FavoritesTableFilterComposer,
    $$FavoritesTableOrderingComposer,
    $$FavoritesTableAnnotationComposer,
    $$FavoritesTableCreateCompanionBuilder,
    $$FavoritesTableUpdateCompanionBuilder,
    (FavoriteRow, BaseReferences<_$AppDatabase, $FavoritesTable, FavoriteRow>),
    FavoriteRow,
    PrefetchHooks Function()> {
  $$FavoritesTableTableManager(_$AppDatabase db, $FavoritesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$FavoritesTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$FavoritesTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$FavoritesTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> entityType = const Value.absent(),
            Value<String> entityId = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              FavoritesCompanion(
            id: id,
            entityType: entityType,
            entityId: entityId,
            createdAt: createdAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String entityType,
            required String entityId,
            required DateTime createdAt,
            Value<int> rowid = const Value.absent(),
          }) =>
              FavoritesCompanion.insert(
            id: id,
            entityType: entityType,
            entityId: entityId,
            createdAt: createdAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$FavoritesTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $FavoritesTable,
    FavoriteRow,
    $$FavoritesTableFilterComposer,
    $$FavoritesTableOrderingComposer,
    $$FavoritesTableAnnotationComposer,
    $$FavoritesTableCreateCompanionBuilder,
    $$FavoritesTableUpdateCompanionBuilder,
    (FavoriteRow, BaseReferences<_$AppDatabase, $FavoritesTable, FavoriteRow>),
    FavoriteRow,
    PrefetchHooks Function()>;
typedef $$ActiveChallengesTableCreateCompanionBuilder
    = ActiveChallengesCompanion Function({
  Value<int> id,
  required String programId,
  required DateTime startedAt,
});
typedef $$ActiveChallengesTableUpdateCompanionBuilder
    = ActiveChallengesCompanion Function({
  Value<int> id,
  Value<String> programId,
  Value<DateTime> startedAt,
});

class $$ActiveChallengesTableFilterComposer
    extends Composer<_$AppDatabase, $ActiveChallengesTable> {
  $$ActiveChallengesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get programId => $composableBuilder(
      column: $table.programId, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get startedAt => $composableBuilder(
      column: $table.startedAt, builder: (column) => ColumnFilters(column));
}

class $$ActiveChallengesTableOrderingComposer
    extends Composer<_$AppDatabase, $ActiveChallengesTable> {
  $$ActiveChallengesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get programId => $composableBuilder(
      column: $table.programId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get startedAt => $composableBuilder(
      column: $table.startedAt, builder: (column) => ColumnOrderings(column));
}

class $$ActiveChallengesTableAnnotationComposer
    extends Composer<_$AppDatabase, $ActiveChallengesTable> {
  $$ActiveChallengesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get programId =>
      $composableBuilder(column: $table.programId, builder: (column) => column);

  GeneratedColumn<DateTime> get startedAt =>
      $composableBuilder(column: $table.startedAt, builder: (column) => column);
}

class $$ActiveChallengesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ActiveChallengesTable,
    ActiveChallengeRow,
    $$ActiveChallengesTableFilterComposer,
    $$ActiveChallengesTableOrderingComposer,
    $$ActiveChallengesTableAnnotationComposer,
    $$ActiveChallengesTableCreateCompanionBuilder,
    $$ActiveChallengesTableUpdateCompanionBuilder,
    (
      ActiveChallengeRow,
      BaseReferences<_$AppDatabase, $ActiveChallengesTable, ActiveChallengeRow>
    ),
    ActiveChallengeRow,
    PrefetchHooks Function()> {
  $$ActiveChallengesTableTableManager(
      _$AppDatabase db, $ActiveChallengesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$ActiveChallengesTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$ActiveChallengesTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$ActiveChallengesTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback: ({
            Value<int> id = const Value.absent(),
            Value<String> programId = const Value.absent(),
            Value<DateTime> startedAt = const Value.absent(),
          }) =>
              ActiveChallengesCompanion(
            id: id,
            programId: programId,
            startedAt: startedAt,
          ),
          createCompanionCallback: ({
            Value<int> id = const Value.absent(),
            required String programId,
            required DateTime startedAt,
          }) =>
              ActiveChallengesCompanion.insert(
            id: id,
            programId: programId,
            startedAt: startedAt,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$ActiveChallengesTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $ActiveChallengesTable,
    ActiveChallengeRow,
    $$ActiveChallengesTableFilterComposer,
    $$ActiveChallengesTableOrderingComposer,
    $$ActiveChallengesTableAnnotationComposer,
    $$ActiveChallengesTableCreateCompanionBuilder,
    $$ActiveChallengesTableUpdateCompanionBuilder,
    (
      ActiveChallengeRow,
      BaseReferences<_$AppDatabase, $ActiveChallengesTable, ActiveChallengeRow>
    ),
    ActiveChallengeRow,
    PrefetchHooks Function()>;
typedef $$PersonalRemindersTableCreateCompanionBuilder
    = PersonalRemindersCompanion Function({
  required String id,
  required String reminderText,
  Value<String?> categoryId,
  Value<String?> situationId,
  Value<bool> isActive,
  required DateTime createdAt,
  required DateTime updatedAt,
  Value<int> rowid,
});
typedef $$PersonalRemindersTableUpdateCompanionBuilder
    = PersonalRemindersCompanion Function({
  Value<String> id,
  Value<String> reminderText,
  Value<String?> categoryId,
  Value<String?> situationId,
  Value<bool> isActive,
  Value<DateTime> createdAt,
  Value<DateTime> updatedAt,
  Value<int> rowid,
});

class $$PersonalRemindersTableFilterComposer
    extends Composer<_$AppDatabase, $PersonalRemindersTable> {
  $$PersonalRemindersTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get reminderText => $composableBuilder(
      column: $table.reminderText, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get categoryId => $composableBuilder(
      column: $table.categoryId, builder: (column) => ColumnFilters(column));

  ColumnFilters<String> get situationId => $composableBuilder(
      column: $table.situationId, builder: (column) => ColumnFilters(column));

  ColumnFilters<bool> get isActive => $composableBuilder(
      column: $table.isActive, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnFilters(column));

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnFilters(column));
}

class $$PersonalRemindersTableOrderingComposer
    extends Composer<_$AppDatabase, $PersonalRemindersTable> {
  $$PersonalRemindersTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get id => $composableBuilder(
      column: $table.id, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get reminderText => $composableBuilder(
      column: $table.reminderText,
      builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get categoryId => $composableBuilder(
      column: $table.categoryId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<String> get situationId => $composableBuilder(
      column: $table.situationId, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<bool> get isActive => $composableBuilder(
      column: $table.isActive, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
      column: $table.createdAt, builder: (column) => ColumnOrderings(column));

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
      column: $table.updatedAt, builder: (column) => ColumnOrderings(column));
}

class $$PersonalRemindersTableAnnotationComposer
    extends Composer<_$AppDatabase, $PersonalRemindersTable> {
  $$PersonalRemindersTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get reminderText => $composableBuilder(
      column: $table.reminderText, builder: (column) => column);

  GeneratedColumn<String> get categoryId => $composableBuilder(
      column: $table.categoryId, builder: (column) => column);

  GeneratedColumn<String> get situationId => $composableBuilder(
      column: $table.situationId, builder: (column) => column);

  GeneratedColumn<bool> get isActive =>
      $composableBuilder(column: $table.isActive, builder: (column) => column);

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$PersonalRemindersTableTableManager extends RootTableManager<
    _$AppDatabase,
    $PersonalRemindersTable,
    PersonalReminderRow,
    $$PersonalRemindersTableFilterComposer,
    $$PersonalRemindersTableOrderingComposer,
    $$PersonalRemindersTableAnnotationComposer,
    $$PersonalRemindersTableCreateCompanionBuilder,
    $$PersonalRemindersTableUpdateCompanionBuilder,
    (
      PersonalReminderRow,
      BaseReferences<_$AppDatabase, $PersonalRemindersTable,
          PersonalReminderRow>
    ),
    PersonalReminderRow,
    PrefetchHooks Function()> {
  $$PersonalRemindersTableTableManager(
      _$AppDatabase db, $PersonalRemindersTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$PersonalRemindersTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$PersonalRemindersTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$PersonalRemindersTableAnnotationComposer(
                  $db: db, $table: table),
          updateCompanionCallback: ({
            Value<String> id = const Value.absent(),
            Value<String> reminderText = const Value.absent(),
            Value<String?> categoryId = const Value.absent(),
            Value<String?> situationId = const Value.absent(),
            Value<bool> isActive = const Value.absent(),
            Value<DateTime> createdAt = const Value.absent(),
            Value<DateTime> updatedAt = const Value.absent(),
            Value<int> rowid = const Value.absent(),
          }) =>
              PersonalRemindersCompanion(
            id: id,
            reminderText: reminderText,
            categoryId: categoryId,
            situationId: situationId,
            isActive: isActive,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          createCompanionCallback: ({
            required String id,
            required String reminderText,
            Value<String?> categoryId = const Value.absent(),
            Value<String?> situationId = const Value.absent(),
            Value<bool> isActive = const Value.absent(),
            required DateTime createdAt,
            required DateTime updatedAt,
            Value<int> rowid = const Value.absent(),
          }) =>
              PersonalRemindersCompanion.insert(
            id: id,
            reminderText: reminderText,
            categoryId: categoryId,
            situationId: situationId,
            isActive: isActive,
            createdAt: createdAt,
            updatedAt: updatedAt,
            rowid: rowid,
          ),
          withReferenceMapper: (p0) => p0
              .map((e) => (e.readTable(table), BaseReferences(db, table, e)))
              .toList(),
          prefetchHooksCallback: null,
        ));
}

typedef $$PersonalRemindersTableProcessedTableManager = ProcessedTableManager<
    _$AppDatabase,
    $PersonalRemindersTable,
    PersonalReminderRow,
    $$PersonalRemindersTableFilterComposer,
    $$PersonalRemindersTableOrderingComposer,
    $$PersonalRemindersTableAnnotationComposer,
    $$PersonalRemindersTableCreateCompanionBuilder,
    $$PersonalRemindersTableUpdateCompanionBuilder,
    (
      PersonalReminderRow,
      BaseReferences<_$AppDatabase, $PersonalRemindersTable,
          PersonalReminderRow>
    ),
    PersonalReminderRow,
    PrefetchHooks Function()>;

class $AppDatabaseManager {
  final _$AppDatabase _db;
  $AppDatabaseManager(this._db);
  $$CoursesTableTableManager get courses =>
      $$CoursesTableTableManager(_db, _db.courses);
  $$EntriesTableTableManager get entries =>
      $$EntriesTableTableManager(_db, _db.entries);
  $$SettingsTableTableManager get settings =>
      $$SettingsTableTableManager(_db, _db.settings);
  $$FavoritesTableTableManager get favorites =>
      $$FavoritesTableTableManager(_db, _db.favorites);
  $$ActiveChallengesTableTableManager get activeChallenges =>
      $$ActiveChallengesTableTableManager(_db, _db.activeChallenges);
  $$PersonalRemindersTableTableManager get personalReminders =>
      $$PersonalRemindersTableTableManager(_db, _db.personalReminders);
}
