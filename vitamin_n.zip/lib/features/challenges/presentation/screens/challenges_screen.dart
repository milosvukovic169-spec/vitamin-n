import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../design_system/theme/theme_extensions.dart';
import '../../../premium/presentation/providers/premium_providers.dart';
import '../../domain/entities/challenge_program.dart';
import '../providers/challenge_providers.dart';
import '../widgets/challenge_card.dart';
import 'challenge_detail_screen.dart';

/// Lists all 6 Challenges. Free ones open directly; Premium ones
/// (locked for Free users) still show their real title/description —
/// see [ChallengeCard] — and tapping opens the detail screen too,
/// which is where the actual Premium gate is shown, consistent with
/// "never hide the value behind a generic paywall".
class ChallengesScreen extends ConsumerWidget {
  const ChallengesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AsyncValue<List<ChallengeProgram>> challengesAsync =
        ref.watch(challengeProgramsProvider);
    final bool isPremium = ref.watch(premiumStatusProvider).value?.isPremium ?? false;

    return Scaffold(
      appBar: AppBar(title: const Text('Challenges')),
      body: SafeArea(
        child: challengesAsync.when(
          data: (List<ChallengeProgram> challenges) {
            return ListView.builder(
              padding: EdgeInsets.all(context.spacing.lg),
              itemCount: challenges.length,
              itemBuilder: (BuildContext context, int index) {
                final ChallengeProgram program = challenges[index];
                final bool locked =
                    !isPremium && !ChallengeAccess.isFree(program.id);
                final AsyncValue<Set<String>> completedAsync = ref.watch(
                  challengeCompletedStepIdsProvider(program.id),
                );

                return Padding(
                  padding: EdgeInsets.only(bottom: context.spacing.sm),
                  child: ChallengeCard(
                    title: program.title,
                    description: program.description,
                    iconName: program.iconName,
                    completedSteps: completedAsync.value?.length ?? 0,
                    totalSteps: program.steps.length,
                    locked: locked,
                    onTap: () => Navigator.of(context).push<void>(
                      MaterialPageRoute<void>(
                        builder: (_) => ChallengeDetailScreen(challengeId: program.id),
                      ),
                    ),
                  ),
                );
              },
            );
          },
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (Object error, StackTrace stackTrace) =>
              Center(child: Text('Could not load Challenges: $error')),
        ),
      ),
    );
  }
}
