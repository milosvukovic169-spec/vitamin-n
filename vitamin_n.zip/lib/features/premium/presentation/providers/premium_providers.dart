import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../settings/presentation/providers/settings_providers.dart';
import '../../data/repositories/billing_backed_offerings_repository.dart';
import '../../data/repositories/billing_backed_premium_repository.dart';
import '../../data/repositories/in_app_purchase_billing_repository.dart';
import '../../domain/entities/premium_offering.dart';
import '../../domain/entities/premium_status.dart';
import '../../domain/repositories/billing_repository.dart';
import '../../domain/repositories/premium_offerings_repository.dart';
import '../../domain/repositories/premium_repository.dart';

/// The single [BillingRepository] instance for the app's lifetime.
/// Production wires the real store-backed implementation; tests
/// override this provider with `FakeBillingRepository` (see Phase 7
/// section 35) — nothing downstream needs to know which one is active.
final Provider<BillingRepository> billingRepositoryProvider = Provider<BillingRepository>(
  (Ref ref) {
    final InAppPurchaseBillingRepository repo = InAppPurchaseBillingRepository();
    repo.listen();
    ref.onDispose(repo.dispose);
    return repo;
  },
);

/// The real, billing-backed entitlement repository — replaces Phase
/// 6's StubPremiumRepository in production. Initialization is fired
/// asynchronously (never awaited here) so constructing this provider
/// never blocks app startup (section 18).
final Provider<PremiumRepository> premiumRepositoryProvider = Provider<PremiumRepository>(
  (Ref ref) {
    final BillingBackedPremiumRepository repo = BillingBackedPremiumRepository(
      ref.watch(billingRepositoryProvider),
      ref.watch(settingsRepositoryProvider),
    );
    ref.onDispose(repo.dispose);
    // Fire-and-forget: emits a cached/unknown status immediately, then
    // resolves the real entitlement once the store responds.
    unawaited(repo.initialize());
    return repo;
  },
);

/// The current premium status. [PremiumTier.unknown] while entitlement
/// is still resolving — see [PremiumStatus.isResolving] for UI that
/// wants to specifically avoid flashing Free content during that
/// window (most gating code only needs `.isPremium`, which is safely
/// false for both `unknown` and `free`).
final StreamProvider<PremiumStatus> premiumStatusProvider =
    StreamProvider<PremiumStatus>((Ref ref) {
  return ref.watch(premiumRepositoryProvider).watchStatus();
});

final Provider<PremiumOfferingsRepository> premiumOfferingsRepositoryProvider =
    Provider<PremiumOfferingsRepository>((Ref ref) {
  return BillingBackedOfferingsRepository(ref.watch(billingRepositoryProvider));
});

/// Monthly/Yearly offerings for the Premium screen, with real
/// localized prices from the store — or a null price per offering if
/// the store couldn't resolve it (never a fabricated fallback price;
/// section 21).
final FutureProvider<List<PremiumOffering>> premiumOfferingsProvider =
    FutureProvider<List<PremiumOffering>>((Ref ref) {
  return ref.watch(premiumOfferingsRepositoryProvider).getOfferings();
});
