import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/analytics/analytics_providers.dart';
import '../../../../design_system/theme/theme_extensions.dart';
import '../../../../design_system/widgets/app_card.dart';
import '../../../../design_system/widgets/primary_button.dart';
import '../../../../design_system/widgets/secondary_button.dart';
import '../../../categories/domain/entities/category.dart';
import '../../../categories/domain/entities/category_access.dart';
import '../../../categories/presentation/providers/category_providers.dart';
import '../../../situations/domain/entities/situation.dart';
import '../../../situations/presentation/providers/situation_providers.dart';
import '../../domain/entities/personal_reminder.dart';
import '../providers/personal_reminder_providers.dart';

/// Add or edit a single Personal Reminder — a standalone feature
/// reached only from Settings. Category and Situation are both
/// optional; a completely standalone reminder is valid (Phase 6
/// section 10). Pass [existing] to edit; omit it to create a new one.
class AddEditPersonalReminderScreen extends ConsumerStatefulWidget {
  const AddEditPersonalReminderScreen({super.key, this.existing});

  final PersonalReminder? existing;

  @override
  ConsumerState<AddEditPersonalReminderScreen> createState() =>
      _AddEditPersonalReminderScreenState();
}

class _AddEditPersonalReminderScreenState
    extends ConsumerState<AddEditPersonalReminderScreen> {
  String? _categoryId;
  String? _situationId;
  late bool _isActive;
  final TextEditingController _textController = TextEditingController();
  bool _saving = false;
  String? _errorText;

  @override
  void initState() {
    super.initState();
    _categoryId = widget.existing?.categoryId;
    _situationId = widget.existing?.situationId;
    _isActive = widget.existing?.isActive ?? true;
    _textController.text = widget.existing?.text ?? '';
  }

  @override
  void dispose() {
    _textController.dispose();
    super.dispose();
  }

  bool get _isEditing => widget.existing != null;

  Future<void> _save() async {
    final String text = _textController.text.trim();
    if (text.isEmpty) return;

    // The cascading dropdowns above only ever populate the Situation
    // list from the selected Category, so this should always already
    // hold — but the business rule (section 10: "If Situation is
    // selected, it must correspond to its Category") is enforced here
    // too, at the actual persistence boundary, rather than only being
    // an emergent property of how the form UI happens to be wired.
    String? situationsActualCategoryId;
    if (_situationId != null && _categoryId != null) {
      final Situation? situation = await ref.read(
        situationByCategoryAndIdProvider(
          (categoryId: _categoryId!, situationId: _situationId!),
        ).future,
      );
      situationsActualCategoryId = situation?.categoryId;
    }

    final bool pairingIsValid = ValidatePersonalReminderPairing.isValid(
      categoryId: _categoryId,
      situationId: _situationId,
      situationsActualCategoryId: situationsActualCategoryId,
    );
    if (!pairingIsValid) {
      setState(() => _errorText = "Couldn't save this reminder. Please try again.");
      return;
    }

    setState(() {
      _saving = true;
      _errorText = null;
    });

    try {
      final repo = ref.read(personalReminderRepositoryProvider);
      if (_isEditing) {
        await repo.update(
          widget.existing!.copyWith(
            text: text,
            categoryId: _categoryId,
            clearCategoryId: _categoryId == null,
            situationId: _situationId,
            clearSituationId: _situationId == null,
            isActive: _isActive,
          ),
        );
      } else {
        await repo.create(
          text: text,
          categoryId: _categoryId,
          situationId: _situationId,
        );
        unawaited(ref.read(analyticsServiceProvider).personalReminderCreated());
      }
      ref.invalidate(allPersonalRemindersProvider);
      if (mounted) Navigator.of(context).pop();
    } catch (_) {
      if (mounted) {
        setState(() {
          _saving = false;
          _errorText = "Couldn't save this reminder. Please try again.";
        });
      }
    }
  }

  Future<void> _confirmDelete() async {
    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          backgroundColor: context.colors.surface,
          shape: RoundedRectangleBorder(borderRadius: context.radius.lgRadius),
          title: const Text('Delete this reminder?'),
          content: const Text('This removes the reminder from Vitamin N.'),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: const Text('Delete'),
            ),
          ],
        );
      },
    );
    if (confirmed != true) return;

    try {
      await ref.read(personalReminderRepositoryProvider).delete(widget.existing!.id);
      unawaited(ref.read(analyticsServiceProvider).personalReminderDeleted());
      ref.invalidate(allPersonalRemindersProvider);
      if (mounted) Navigator.of(context).pop();
    } catch (_) {
      if (mounted) {
        setState(() => _errorText = "Couldn't delete this reminder. Please try again.");
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final TextTheme textTheme = Theme.of(context).textTheme;
    final categoriesAsync = ref.watch(categoriesProvider);
    final bool canSave = _textController.text.trim().isNotEmpty;

    return Scaffold(
      appBar: AppBar(
        title: Text(_isEditing ? 'Edit reminder' : 'New reminder'),
        actions: <Widget>[
          if (_isEditing)
            IconButton(
              icon: const Icon(Icons.delete_outline),
              tooltip: 'Delete this reminder',
              onPressed: _confirmDelete,
            ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.all(context.spacing.lg),
          children: <Widget>[
            Text('What do you want to remember next time?', style: textTheme.titleSmall),
            SizedBox(height: context.spacing.sm),
            AppCard(
              child: TextField(
                controller: _textController,
                maxLines: 4,
                onChanged: (_) => setState(() {}),
                decoration: const InputDecoration(
                  border: InputBorder.none,
                  hintText: 'e.g. Check your calendar before saying yes.',
                ),
              ),
            ),
            SizedBox(height: context.spacing.lg),
            Text('Category (optional)', style: textTheme.titleSmall),
            SizedBox(height: context.spacing.sm),
            categoriesAsync.when(
              data: (List<Category> categories) {
                final List<Category> curated = categories
                    .where((Category c) => c.id != CategoryAccess.otherCategoryId)
                    .toList();
                return DropdownButtonFormField<String?>(
                  initialValue: _categoryId,
                  hint: const Text('No category'),
                  items: <DropdownMenuItem<String?>>[
                    const DropdownMenuItem<String?>(value: null, child: Text('No category')),
                    for (final Category c in curated)
                      DropdownMenuItem<String?>(value: c.id, child: Text(c.name)),
                  ],
                  onChanged: (String? value) {
                    setState(() {
                      _categoryId = value;
                      // A situation only makes sense under its own
                      // category — changing category clears it,
                      // enforcing "Situation must correspond to its
                      // Category" (section 10) at the UI level.
                      _situationId = null;
                    });
                  },
                );
              },
              loading: () => const LinearProgressIndicator(),
              error: (Object e, StackTrace st) => Text('Could not load categories: $e'),
            ),
            SizedBox(height: context.spacing.lg),
            Text('Situation (optional)', style: textTheme.titleSmall),
            SizedBox(height: context.spacing.sm),
            if (_categoryId == null)
              Text('Choose a category first.', style: textTheme.bodyMedium)
            else
              Consumer(
                builder: (BuildContext context, WidgetRef ref, _) {
                  final situationsAsync =
                      ref.watch(situationsByCategoryIdProvider(_categoryId!));
                  return situationsAsync.when(
                    data: (List<Situation> situations) {
                      return DropdownButtonFormField<String?>(
                        initialValue: _situationId,
                        hint: const Text('No situation'),
                        items: <DropdownMenuItem<String?>>[
                          const DropdownMenuItem<String?>(
                            value: null,
                            child: Text('No situation'),
                          ),
                          for (final Situation s in situations)
                            DropdownMenuItem<String?>(value: s.id, child: Text(s.title)),
                        ],
                        onChanged: (String? value) => setState(() => _situationId = value),
                      );
                    },
                    loading: () => const LinearProgressIndicator(),
                    error: (Object e, StackTrace st) =>
                        Text('Could not load situations: $e'),
                  );
                },
              ),
            SizedBox(height: context.spacing.lg),
            Semantics(
              toggled: _isActive,
              label: _isActive ? 'Reminder is active' : 'Reminder is inactive',
              child: SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Active'),
                subtitle: const Text(
                  "Inactive reminders stay saved but won't be surfaced elsewhere in the app.",
                ),
                value: _isActive,
                activeThumbColor: context.colors.sageStrong,
                onChanged: (bool value) => setState(() => _isActive = value),
              ),
            ),
            if (_errorText != null) ...<Widget>[
              SizedBox(height: context.spacing.sm),
              Text(
                _errorText!,
                style: textTheme.bodyMedium?.copyWith(color: context.colors.destructive),
              ),
            ],
            SizedBox(height: context.spacing.xl),
            Row(
              children: <Widget>[
                Expanded(
                  child: SecondaryButton(
                    label: 'Cancel',
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                ),
                SizedBox(width: context.spacing.md),
                Expanded(
                  child: PrimaryButton(
                    label: 'Save',
                    loading: _saving,
                    onPressed: canSave && !_saving ? _save : null,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
