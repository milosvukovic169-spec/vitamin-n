import 'package:go_router/go_router.dart';

import '../features/boundary/presentation/screens/category_screen.dart';
import '../features/boundary/presentation/screens/final_confirmation_screen.dart';
import '../features/boundary/presentation/screens/out_of_scope_screen.dart';
import '../features/boundary/presentation/screens/protected_values_screen.dart';
import '../features/boundary/presentation/screens/reality_reminder_screen.dart';
import '../features/boundary/presentation/screens/situation_screen.dart';
import '../features/boundary/presentation/screens/suggested_response_screen.dart';
import 'page_transitions.dart';
import 'root_shell.dart';
import 'routes.dart';

/// Locked Phase 5 flow — Reflection Pause and Personal Reminder are
/// deliberately not routes here anymore; see AppRoutes doc comment.
final GoRouter appRouter = GoRouter(
  initialLocation: AppRoutes.home,
  routes: <RouteBase>[
    GoRoute(
      path: AppRoutes.home,
      pageBuilder: (context, state) =>
          slideFadePage(key: state.pageKey, child: const RootShell()),
    ),
    GoRoute(
      path: AppRoutes.sayNoCategory,
      pageBuilder: (context, state) =>
          slideFadePage(key: state.pageKey, child: const CategoryScreen()),
    ),
    GoRoute(
      path: AppRoutes.sayNoSituation,
      pageBuilder: (context, state) =>
          slideFadePage(key: state.pageKey, child: const SituationScreen()),
    ),
    GoRoute(
      path: AppRoutes.sayNoOutOfScope,
      pageBuilder: (context, state) =>
          slideFadePage(key: state.pageKey, child: const OutOfScopeScreen()),
    ),
    GoRoute(
      path: AppRoutes.sayNoResponse,
      pageBuilder: (context, state) => slideFadePage(
        key: state.pageKey,
        child: const SuggestedResponseScreen(),
      ),
    ),
    GoRoute(
      path: AppRoutes.sayNoReality,
      pageBuilder: (context, state) =>
          slideFadePage(key: state.pageKey, child: const RealityReminderScreen()),
    ),
    GoRoute(
      path: AppRoutes.sayNoConfirm,
      pageBuilder: (context, state) => slideFadePage(
        key: state.pageKey,
        child: const FinalConfirmationScreen(),
      ),
    ),
    GoRoute(
      path: AppRoutes.sayNoProtectedValues,
      pageBuilder: (context, state) => slideFadePage(
        key: state.pageKey,
        child: const ProtectedValuesScreen(),
      ),
    ),
  ],
);
