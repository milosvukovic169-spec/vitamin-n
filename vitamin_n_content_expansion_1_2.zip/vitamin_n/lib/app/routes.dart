/// Centralized route path constants for the whole app. Screens and
/// navigation calls reference these names — never a raw path string
/// scattered inline.
///
/// Locked Phase 5 flow: Category -> Situation -> Suggested Response
/// -> Reality Reminder -> I SAID NO -> Protected Values. Reflection
/// Pause and Personal Reminder are no longer part of the active flow
/// (see Phase 5 spec, sections 1, 18, 19).
///
/// Phase 6 section 33 asks for centralized route names for Settings,
/// Personal Reminders, Premium, Privacy, Disclaimer and About. Their
/// *names* are centralized here, as required — but navigation to them
/// still uses `Navigator.push(MaterialPageRoute(...))`, matching the
/// pattern the existing codebase already uses for this exact class of
/// screen (History's EntryDetailScreen/EditEntryScreen, Challenges'
/// ChallengeDetailScreen). Section 33 itself carves out this case:
/// "Do not create Navigator.push islands unless the existing
/// architecture specifically uses them" — it already does, for every
/// screen that isn't a deep-linked step of the Say No flow. Wiring
/// these six screens into GoRouter's declarative table instead would
/// mean a second navigation pattern for the same class of screen,
/// plus `extra:`-based param passing for screens like Edit Personal
/// Reminder that need to receive a whole entity — a materially larger
/// change than "prefer small additive changes" (section 0) calls for.
abstract final class AppRoutes {
  static const String home = '/';

  static const String sayNoCategory = '/say-no';
  static const String sayNoSituation = '/say-no/situation';
  static const String sayNoOutOfScope = '/say-no/out-of-scope';
  static const String sayNoResponse = '/say-no/response';
  static const String sayNoReality = '/say-no/reality';
  static const String sayNoConfirm = '/say-no/confirm';
  static const String sayNoProtectedValues = '/say-no/protected-values';

  // Phase 6 — named for documentation/consistency; reached via
  // Navigator.push, per the note above.
  static const String settings = '/settings';
  static const String personalReminders = '/settings/personal-reminders';
  static const String personalReminderCreate = '/settings/personal-reminders/new';
  static const String personalReminderEdit = '/settings/personal-reminders/edit';
  static const String premium = '/premium';
  static const String privacy = '/settings/privacy';
  static const String disclaimer = '/settings/disclaimer';
  static const String about = '/settings/about';
}
