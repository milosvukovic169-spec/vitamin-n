import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/analytics/analytics_providers.dart';
import '../design_system/widgets/bottom_navigation.dart';
import '../features/challenges/presentation/screens/challenges_screen.dart';
import '../features/history/presentation/screens/history_screen.dart';
import '../features/home/presentation/screens/home_screen.dart';
import '../features/insights/presentation/screens/insights_screen.dart';
import '../features/premium/presentation/providers/premium_providers.dart';
import '../features/settings/presentation/screens/settings_screen.dart';

/// The app's root navigation shell: Home, History, Insights,
/// Challenges and Settings are all fully built as of Phase 6.
///
/// Per Phase 5 section 1 ("Do NOT create a separate content Library
/// that competes with the Say No flow"), the former "Library" tab
/// slot now hosts Challenges — lightweight nudges that funnel back
/// into Say No, not a response-browsing library.
class RootShell extends ConsumerStatefulWidget {
  const RootShell({super.key});

  @override
  ConsumerState<RootShell> createState() => _RootShellState();
}

class _RootShellState extends ConsumerState<RootShell> with WidgetsBindingObserver {
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    // Fired once per app session, here rather than in main() — this
    // is the first frame the user actually sees, and analytics
    // initialization must never block startup (section 18/47).
    WidgetsBinding.instance.addPostFrameCallback((_) {
      unawaited(ref.read(analyticsServiceProvider).appOpened());
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Billing audit fix: cold start alone isn't enough to catch a
    // subscription that expires or is revoked while the app is
    // simply left open in the background and later resumed, rather
    // than fully restarted. Re-checking on resume is what makes that
    // case actually get caught in bounded time.
    //
    // Not awaited, and deliberately no try/catch here: refreshEntitlement()
    // is designed to never throw (it catches its own failures
    // internally and falls back to the last-known cached value) —
    // see BillingBackedPremiumRepository.refreshEntitlement().
    if (state == AppLifecycleState.resumed) {
      ref.read(premiumRepositoryProvider).refreshEntitlement();
    }
  }

  static const List<BottomNavigationItem> _items = <BottomNavigationItem>[
    BottomNavigationItem(
      icon: Icons.spa_outlined,
      selectedIcon: Icons.spa,
      label: 'Home',
    ),
    BottomNavigationItem(
      icon: Icons.history_outlined,
      selectedIcon: Icons.history,
      label: 'History',
    ),
    BottomNavigationItem(
      icon: Icons.insights_outlined,
      selectedIcon: Icons.insights,
      label: 'Insights',
    ),
    BottomNavigationItem(
      icon: Icons.checklist_outlined,
      selectedIcon: Icons.checklist,
      label: 'Challenges',
    ),
    BottomNavigationItem(
      icon: Icons.settings_outlined,
      selectedIcon: Icons.settings,
      label: 'Settings',
    ),
  ];

  static const List<Widget> _screens = <Widget>[
    HomeScreen(),
    HistoryScreen(),
    InsightsScreen(),
    ChallengesScreen(),
    SettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _currentIndex, children: _screens),
      bottomNavigationBar: BottomNavigation(
        currentIndex: _currentIndex,
        items: _items,
        onTap: (int index) => setState(() => _currentIndex = index),
      ),
    );
  }
}
