import 'dart:ui' show lerpDouble;

import 'package:flutter/material.dart';

/// Corner radii for the "rounded cards" visual language. Values are
/// plain doubles so callers can build either a [BorderRadius] or a
/// [RoundedRectangleBorder] as needed.
class AppBorderRadius extends ThemeExtension<AppBorderRadius> {
  const AppBorderRadius({
    this.sm = 8,
    this.md = 12,
    this.lg = 16,
    this.xl = 24,
    this.pill = 999,
  });

  final double sm;
  final double md;
  final double lg;
  final double xl;
  final double pill;

  static const AppBorderRadius standard = AppBorderRadius();

  BorderRadius get smRadius => BorderRadius.circular(sm);
  BorderRadius get mdRadius => BorderRadius.circular(md);
  BorderRadius get lgRadius => BorderRadius.circular(lg);
  BorderRadius get xlRadius => BorderRadius.circular(xl);
  BorderRadius get pillRadius => BorderRadius.circular(pill);

  @override
  AppBorderRadius copyWith({
    double? sm,
    double? md,
    double? lg,
    double? xl,
    double? pill,
  }) {
    return AppBorderRadius(
      sm: sm ?? this.sm,
      md: md ?? this.md,
      lg: lg ?? this.lg,
      xl: xl ?? this.xl,
      pill: pill ?? this.pill,
    );
  }

  @override
  AppBorderRadius lerp(ThemeExtension<AppBorderRadius>? other, double t) {
    if (other is! AppBorderRadius) {
      return this;
    }
    return AppBorderRadius(
      sm: lerpDouble(sm, other.sm, t)!,
      md: lerpDouble(md, other.md, t)!,
      lg: lerpDouble(lg, other.lg, t)!,
      xl: lerpDouble(xl, other.xl, t)!,
      pill: lerpDouble(pill, other.pill, t)!,
    );
  }
}

extension AppBorderRadiusContext on BuildContext {
  AppBorderRadius get radius => Theme.of(this).extension<AppBorderRadius>()!;
}
