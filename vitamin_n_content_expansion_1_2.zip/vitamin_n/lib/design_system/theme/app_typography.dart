import 'package:flutter/material.dart';

import 'app_colors.dart';

/// Builds the app's [TextTheme]. Currently uses the platform's system
/// font (see [fontFamily]) as a safe fallback since no custom font
/// files are bundled — swap [fontFamily] to 'Inter' once
/// assets/fonts/ contains the actual .ttf files, per the Visual Rules.
///
/// Flutter's standard named slots are used rather than a bespoke set,
/// so every built-in widget that reads `Theme.of(context).textTheme`
/// (AppBar titles, list tiles, etc.) automatically gets the right
/// typeface without per-widget overrides. Screens should still prefer
/// pulling a specific named style (e.g. `textTheme.titleMedium`) over
/// hardcoding a `TextStyle`.
abstract final class AppTypography {
  static const String? fontFamily = null; // system font fallback until Inter's files are bundled

  static TextTheme textTheme(AppColors colors) {
    return TextTheme(
      // Screen-level titles ("Home", onboarding headlines).
      headlineLarge: TextStyle(
        fontSize: 28,
        fontWeight: FontWeight.w600,
        height: 1.25,
        color: colors.textPrimary,
      ),
      headlineMedium: TextStyle(
        fontSize: 24,
        fontWeight: FontWeight.w600,
        height: 1.3,
        color: colors.textPrimary,
      ),
      // Card / section titles.
      titleLarge: TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.w600,
        height: 1.3,
        color: colors.textPrimary,
      ),
      titleMedium: TextStyle(
        fontSize: 17,
        fontWeight: FontWeight.w600,
        height: 1.35,
        color: colors.textPrimary,
      ),
      titleSmall: TextStyle(
        fontSize: 15,
        fontWeight: FontWeight.w500,
        height: 1.35,
        color: colors.textPrimary,
      ),
      // Body copy.
      bodyLarge: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w400,
        height: 1.5,
        color: colors.textPrimary,
      ),
      bodyMedium: TextStyle(
        fontSize: 14,
        fontWeight: FontWeight.w400,
        height: 1.5,
        color: colors.textSecondary,
      ),
      bodySmall: TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w400,
        height: 1.4,
        color: colors.textSecondary,
      ),
      // Buttons and chips.
      labelLarge: TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w600,
        height: 1.2,
        color: colors.textPrimary,
      ),
      labelMedium: TextStyle(
        fontSize: 14,
        fontWeight: FontWeight.w500,
        height: 1.2,
        color: colors.textPrimary,
      ),
      labelSmall: TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w500,
        height: 1.2,
        color: colors.textSecondary,
      ),
    );
  }
}
