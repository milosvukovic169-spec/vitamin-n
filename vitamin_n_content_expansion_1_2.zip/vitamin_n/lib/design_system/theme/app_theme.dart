import 'package:flutter/material.dart';

import 'app_border_radius.dart';
import 'app_colors.dart';
import 'app_elevation.dart';
import 'app_spacing.dart';
import 'app_typography.dart';

/// Assembles the app's light and dark [ThemeData], wiring every
/// design token (colors, spacing, border radius, elevation,
/// typography) together as [ThemeExtension]s plus sane defaults for
/// built-in Material components (buttons, cards, app bars) so screens
/// rarely need per-widget styling overrides.
abstract final class AppTheme {
  static ThemeData get light => _build(AppColors.light);
  static ThemeData get dark => _build(AppColors.dark, brightness: Brightness.dark);

  static ThemeData _build(AppColors colors, {Brightness brightness = Brightness.light}) {
    const AppSpacing spacing = AppSpacing.standard;
    const AppBorderRadius borderRadius = AppBorderRadius.standard;
    final AppElevation elevation = AppElevation.light(shadowColor: colors.shadow);
    final TextTheme textTheme = AppTypography.textTheme(colors);

    final ColorScheme colorScheme = (brightness == Brightness.dark
            ? const ColorScheme.dark()
            : const ColorScheme.light())
        .copyWith(
      primary: colors.sageStrong,
      onPrimary: colors.textOnSage,
      secondary: colors.beige,
      onSecondary: colors.textPrimary,
      surface: colors.surface,
      onSurface: colors.textPrimary,
      error: colors.destructive,
      onError: Colors.white,
    );

    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      scaffoldBackgroundColor: colors.background,
      colorScheme: colorScheme,
      // fontFamily intentionally omitted — falls back to the
      // platform default (Roboto/San Francisco) until Inter's font
      // files are bundled. See AppTypography.fontFamily.
      textTheme: textTheme,
      splashFactory: NoSplash.splashFactory,
      highlightColor: Colors.transparent,
      appBarTheme: AppBarTheme(
        backgroundColor: colors.background,
        foregroundColor: colors.textPrimary,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: textTheme.titleLarge,
      ),
      cardTheme: CardThemeData(
        color: colors.surface,
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(borderRadius: borderRadius.lgRadius),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: colors.cream,
        selectedColor: colors.sage,
        labelStyle: textTheme.labelMedium,
        shape: RoundedRectangleBorder(borderRadius: borderRadius.pillRadius),
        padding: EdgeInsets.symmetric(horizontal: spacing.md, vertical: spacing.xs),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: colors.sageStrong,
          foregroundColor: colors.textOnSage,
          textStyle: textTheme.labelLarge,
          padding: EdgeInsets.symmetric(horizontal: spacing.lg, vertical: spacing.md),
          shape: RoundedRectangleBorder(borderRadius: borderRadius.mdRadius),
          elevation: 0,
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: colors.textPrimary,
          textStyle: textTheme.labelLarge,
          padding: EdgeInsets.symmetric(horizontal: spacing.lg, vertical: spacing.md),
          shape: RoundedRectangleBorder(borderRadius: borderRadius.mdRadius),
          side: BorderSide(color: colors.border),
        ),
      ),
      dividerTheme: DividerThemeData(color: colors.border, thickness: 1, space: 1),
      bottomNavigationBarTheme: BottomNavigationBarThemeData(
        backgroundColor: colors.surface,
        selectedItemColor: colors.sageStrong,
        unselectedItemColor: colors.textSecondary,
        type: BottomNavigationBarType.fixed,
        elevation: 0,
      ),
      extensions: <ThemeExtension<dynamic>>[
        colors,
        spacing,
        borderRadius,
        elevation,
      ],
    );
  }
}
