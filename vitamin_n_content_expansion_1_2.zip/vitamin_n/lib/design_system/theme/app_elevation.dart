import 'package:flutter/material.dart';

/// Soft-shadow elevation tokens. The spec calls for soft shadows
/// rather than Material's harsh default elevation — these are plain
/// [BoxShadow] lists tuned per theme (dark mode needs a stronger,
/// more transparent shadow to read against a dark background).
class AppElevation extends ThemeExtension<AppElevation> {
  const AppElevation({
    required this.none,
    required this.soft,
    required this.medium,
    required this.strong,
  });

  final List<BoxShadow> none;
  final List<BoxShadow> soft;
  final List<BoxShadow> medium;
  final List<BoxShadow> strong;

  static AppElevation light({required Color shadowColor}) {
    return AppElevation(
      none: const <BoxShadow>[],
      soft: <BoxShadow>[
        BoxShadow(color: shadowColor, blurRadius: 12, offset: const Offset(0, 4)),
      ],
      medium: <BoxShadow>[
        BoxShadow(color: shadowColor, blurRadius: 20, offset: const Offset(0, 8)),
      ],
      strong: <BoxShadow>[
        BoxShadow(color: shadowColor, blurRadius: 32, offset: const Offset(0, 12)),
      ],
    );
  }

  @override
  AppElevation copyWith({
    List<BoxShadow>? none,
    List<BoxShadow>? soft,
    List<BoxShadow>? medium,
    List<BoxShadow>? strong,
  }) {
    return AppElevation(
      none: none ?? this.none,
      soft: soft ?? this.soft,
      medium: medium ?? this.medium,
      strong: strong ?? this.strong,
    );
  }

  @override
  AppElevation lerp(ThemeExtension<AppElevation>? other, double t) {
    // Shadow-list interpolation isn't meaningful mid-transition;
    // theme switches are instant crossfades in this app, so a simple
    // threshold swap is sufficient and avoids fragile BoxShadow lerp.
    if (other is! AppElevation) {
      return this;
    }
    return t < 0.5 ? this : other;
  }
}

extension AppElevationContext on BuildContext {
  AppElevation get elevation => Theme.of(this).extension<AppElevation>()!;
}
