/// Barrel file for every custom [ThemeExtension] in the design
/// system, plus their `context.xxx` convenience accessors. Import
/// this single file rather than each token file individually:
///
/// ```dart
/// import 'package:vitamin_n/design_system/theme/theme_extensions.dart';
///
/// final bg = context.colors.background;
/// final gap = context.spacing.md;
/// final radius = context.radius.lgRadius;
/// final shadow = context.elevation.soft;
/// ```
library;

export 'app_border_radius.dart';
export 'app_colors.dart';
export 'app_elevation.dart';
export 'app_spacing.dart';
