import 'package:flutter/material.dart';

import '../animation/tap_scale.dart';
import '../theme/theme_extensions.dart';

/// The base rounded, soft-shadowed card used throughout the app
/// (CategoryCard, SituationTile, SupportCard, etc. all compose this
/// rather than each defining their own container styling).
class AppCard extends StatelessWidget {
  const AppCard({
    super.key,
    required this.child,
    this.onTap,
    this.padding,
    this.backgroundColor,
    this.elevated = true,
  });

  final Widget child;
  final VoidCallback? onTap;
  final EdgeInsetsGeometry? padding;
  final Color? backgroundColor;

  /// Whether to draw the soft shadow. Set false when the card sits on
  /// a surface where a shadow would look muddy (e.g. inside another
  /// elevated card).
  final bool elevated;

  @override
  Widget build(BuildContext context) {
    final BorderRadius borderRadius = context.radius.lgRadius;

    final Widget content = Container(
      padding: padding ?? EdgeInsets.all(context.spacing.md),
      decoration: BoxDecoration(
        color: backgroundColor ?? context.colors.surface,
        borderRadius: borderRadius,
        boxShadow: elevated ? context.elevation.soft : context.elevation.none,
      ),
      child: child,
    );

    if (onTap == null) {
      return content;
    }

    final Widget tappable = Material(
      color: Colors.transparent,
      borderRadius: borderRadius,
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        borderRadius: borderRadius,
        splashColor: Colors.transparent,
        highlightColor: context.colors.sage.withValues(alpha: 0.08),
        child: content,
      ),
    );

    return TapScale(child: tappable);
  }
}
