import 'package:flutter/material.dart';

/// One destination in [BottomNavigation].
class BottomNavigationItem {
  const BottomNavigationItem({
    required this.icon,
    required this.selectedIcon,
    required this.label,
  });

  final IconData icon;
  final IconData selectedIcon;
  final String label;
}

/// The app's bottom navigation bar. Purely prop-driven — takes the
/// current index and a list of items, reports taps via [onTap]. Screen
/// routing/navigation logic belongs to whatever wires this up, not to
/// this widget.
class BottomNavigation extends StatelessWidget {
  const BottomNavigation({
    super.key,
    required this.currentIndex,
    required this.items,
    required this.onTap,
  });

  final int currentIndex;
  final List<BottomNavigationItem> items;
  final ValueChanged<int> onTap;

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      currentIndex: currentIndex,
      onTap: onTap,
      items: <BottomNavigationBarItem>[
        for (final BottomNavigationItem item in items)
          BottomNavigationBarItem(
            icon: Icon(item.icon),
            activeIcon: Icon(item.selectedIcon),
            label: item.label,
          ),
      ],
    );
  }
}
