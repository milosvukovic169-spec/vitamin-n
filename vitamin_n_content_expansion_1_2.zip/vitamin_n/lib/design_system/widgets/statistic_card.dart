import 'package:flutter/material.dart';

import '../theme/theme_extensions.dart';
import 'app_card.dart';

/// A single stat display for Insights/Home (e.g. "12 — My Time
/// protected this month"). Deliberately framed around *what was
/// protected*, never a count of "no"s said or a streak — callers
/// should pass a [label] that names the protected value or category,
/// not a generic "times said no" phrasing.
class StatisticCard extends StatelessWidget {
  const StatisticCard({
    super.key,
    required this.value,
    required this.label,
    this.icon,
  });

  final String value;
  final String label;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    final TextTheme textTheme = Theme.of(context).textTheme;

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          if (icon != null) ...<Widget>[
            Icon(icon, color: context.colors.sageStrong, size: 22),
            SizedBox(height: context.spacing.sm),
          ],
          Text(value, style: textTheme.headlineMedium),
          SizedBox(height: context.spacing.xs),
          Text(label, style: textTheme.bodyMedium),
        ],
      ),
    );
  }
}
