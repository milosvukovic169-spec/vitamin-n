import 'package:flutter/material.dart';

import '../animation/tap_scale.dart';

/// The app's secondary action button (e.g. "Not now", "Skip this
/// step"). Outlined, calmer than [PrimaryButton] — used when an
/// action is optional or less emphasized.
class SecondaryButton extends StatelessWidget {
  const SecondaryButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.expand = true,
  });

  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final bool expand;

  @override
  Widget build(BuildContext context) {
    final Widget button = OutlinedButton(
      onPressed: onPressed,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          if (icon != null) ...<Widget>[
            Icon(icon, size: 20),
            const SizedBox(width: 8),
          ],
          Text(label),
        ],
      ),
    );

    final Widget scaled = TapScale(child: button);
    return expand ? SizedBox(width: double.infinity, child: scaled) : scaled;
  }
}
