import 'package:flutter/material.dart';

import '../animation/tap_scale.dart';
import '../theme/theme_extensions.dart';

/// The app's primary call-to-action button (e.g. "Say No", "Confirm").
/// Solid sage fill, calm press feedback. Purely prop-driven — no
/// provider or navigation knowledge lives here.
class PrimaryButton extends StatelessWidget {
  const PrimaryButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.expand = true,
    this.loading = false,
  });

  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final bool expand;
  final bool loading;

  @override
  Widget build(BuildContext context) {
    final bool enabled = onPressed != null && !loading;

    final Widget button = ElevatedButton(
      onPressed: enabled ? onPressed : null,
      child: loading
          ? SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                valueColor: AlwaysStoppedAnimation<Color>(context.colors.textOnSage),
              ),
            )
          : Row(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                if (icon != null) ...<Widget>[
                  Icon(icon, size: 20),
                  SizedBox(width: context.spacing.sm),
                ],
                Text(label),
              ],
            ),
    );

    final Widget scaled = TapScale(child: button);
    return expand ? SizedBox(width: double.infinity, child: scaled) : scaled;
  }
}
