import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show HapticFeedback;

import '../animation/app_animated_switcher.dart';
import '../theme/theme_extensions.dart';

/// A single N token on the CourseBoard — a soft, off-white ceramic
/// tablet with a printed green "N", filled while unused and an empty
/// outlined circle once consumed.
///
/// Deliberately NOT a pill/capsule (no medicine-dose styling, no
/// glossy half-and-half shading) and NOT a game token (no number, no
/// badge, no metallic/plastic finish) — just a calm, matte ceramic
/// piece with a subtle border and a natural (not glowing) shadow.
///
/// If [onTap] is provided (only ever wired up for a *filled* token —
/// see [CourseBoard]), tapping plays a soft ripple, a gentle haptic
/// tick, and crossfades into the empty state.
///
/// [pulse] drives the brief expanding-ring animation used when a
/// token is consumed programmatically (returning from the Say No
/// flow) rather than by a direct tap — see [CourseBoard]. It has no
/// effect when [reduceMotion] is true.
class NToken extends StatelessWidget {
  const NToken({
    super.key,
    required this.filled,
    this.size = 44,
    this.onTap,
    this.pulse = false,
    this.reduceMotion = false,
  });

  final bool filled;
  final double size;
  final VoidCallback? onTap;
  final bool pulse;
  final bool reduceMotion;

  Widget _bead(BuildContext context, bool isFilled) {
    final AppColors colors = context.colors;

    return Container(
      key: ValueKey<bool>(isFilled),
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: isFilled ? colors.tokenCeramicSurface : colors.tokenEmpty,
        border: Border.all(
          color: isFilled ? colors.border : colors.border,
          width: 1,
        ),
        boxShadow: isFilled
            ? <BoxShadow>[
                BoxShadow(
                  color: colors.shadow,
                  blurRadius: 5,
                  offset: const Offset(0, 2),
                ),
              ]
            : null,
      ),
      alignment: Alignment.center,
      child: isFilled
          ? Text(
              'N',
              style: TextStyle(
                fontSize: size * 0.42,
                fontWeight: FontWeight.w700,
                color: colors.sageStrong,
                height: 1,
              ),
            )
          : null,
    );
  }

  @override
  Widget build(BuildContext context) {
    Widget bead = reduceMotion
        ? _bead(context, filled)
        : AppAnimatedSwitcher(child: _bead(context, filled));

    if (pulse && !reduceMotion) {
      bead = Stack(
        alignment: Alignment.center,
        clipBehavior: Clip.none,
        children: <Widget>[
          _PulseRing(color: context.colors.sage, size: size),
          bead,
        ],
      );
    }

    if (onTap == null) {
      return bead;
    }

    return Material(
      color: Colors.transparent,
      shape: const CircleBorder(),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        customBorder: const CircleBorder(),
        // Intentional ripple: the app theme disables Material's
        // default splash everywhere else for a calmer feel, but this
        // one interaction is explicitly designed to include a soft
        // ripple as part of the token-consumed moment.
        splashFactory: InkRipple.splashFactory,
        splashColor: context.colors.sage.withValues(alpha: 0.35),
        onTap: () {
          HapticFeedback.selectionClick();
          onTap!();
        },
        child: Padding(padding: const EdgeInsets.all(3), child: bead),
      ),
    );
  }
}

/// A one-shot expanding, fading ring — the "ripple" for a
/// programmatically-consumed token (no tap/InkWell involved, so no
/// Material splash is available to reuse).
class _PulseRing extends StatefulWidget {
  const _PulseRing({required this.color, required this.size});

  final Color color;
  final double size;

  @override
  State<_PulseRing> createState() => _PulseRingState();
}

class _PulseRingState extends State<_PulseRing>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 420),
  )..forward();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (BuildContext context, Widget? child) {
        final double t = _controller.value;
        return Opacity(
          opacity: (1 - t).clamp(0.0, 1.0) * 0.45,
          child: Container(
            width: widget.size * (1 + t * 0.6),
            height: widget.size * (1 + t * 0.6),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: widget.color,
            ),
          ),
        );
      },
    );
  }
}
