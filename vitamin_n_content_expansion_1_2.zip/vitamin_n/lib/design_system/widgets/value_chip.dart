import 'package:flutter/material.dart';

import '../animation/tap_scale.dart';
import '../theme/theme_extensions.dart';

/// A pill-shaped, selectable chip — used for Protected Values
/// selection and for filters (e.g. by category) in Library/History.
/// Purely prop-driven: the caller owns selection state.
///
/// Selection is communicated by more than color alone (a border-width
/// change plus a check mark), and the selected state is exposed to
/// assistive technology via [Semantics].
class ValueChip extends StatelessWidget {
  const ValueChip({
    super.key,
    required this.label,
    required this.selected,
    this.onTap,
    this.icon,
    this.enabled = true,
  });

  final String label;
  final bool selected;
  final VoidCallback? onTap;
  final IconData? icon;

  /// When false, the chip renders dimmed and ignores taps — used for
  /// an unselected chip once a selection limit has been reached.
  final bool enabled;

  @override
  Widget build(BuildContext context) {
    final AppColors colors = context.colors;
    final double opacity = enabled ? 1.0 : 0.45;

    final Widget chip = AnimatedContainer(
      duration: const Duration(milliseconds: 150),
      padding: EdgeInsets.symmetric(
        horizontal: context.spacing.md,
        vertical: context.spacing.sm,
      ),
      decoration: BoxDecoration(
        color: selected ? colors.sage : colors.cream,
        borderRadius: context.radius.pillRadius,
        border: Border.all(
          color: selected ? colors.sageStrong : colors.border,
          width: selected ? 1.5 : 1,
        ),
      ),
      child: Opacity(
        opacity: opacity,
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            if (selected && onTap != null) ...<Widget>[
              Icon(Icons.check, size: 16, color: colors.textOnSage),
              SizedBox(width: context.spacing.xs),
            ] else if (icon != null) ...<Widget>[
              Icon(
                icon,
                size: 16,
                color: selected ? colors.textOnSage : colors.textSecondary,
              ),
              SizedBox(width: context.spacing.xs),
            ],
            Text(
              label,
              style: Theme.of(context).textTheme.labelMedium?.copyWith(
                    color: selected ? colors.textOnSage : colors.textPrimary,
                  ),
            ),
          ],
        ),
      ),
    );

    return Semantics(
      selected: selected,
      button: onTap != null,
      label: label,
      child: (onTap == null || !enabled)
          ? chip
          : TapScale(child: GestureDetector(onTap: onTap, child: chip)),
    );
  }
}
