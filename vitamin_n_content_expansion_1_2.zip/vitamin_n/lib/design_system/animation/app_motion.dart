import 'package:flutter/animation.dart';

/// Shared motion tokens. Per the Visual Rules, every animation in the
/// app must stay calm and finish in under 500ms — these constants are
/// the only durations/curves that should be used, so that constraint
/// is enforced by convention in one place rather than by convention
/// scattered across every widget.
abstract final class AppMotion {
  static const Duration fast = Duration(milliseconds: 150);
  static const Duration base = Duration(milliseconds: 250);
  static const Duration slow = Duration(milliseconds: 400);

  /// A gentle, non-bouncy ease — deliberately avoids overshoot curves
  /// (elasticOut, bounceOut) which read as playful/gamified rather
  /// than calm.
  static const Curve calm = Curves.easeOutCubic;

  /// For elements entering the screen (cards, list items).
  static const Curve enter = Curves.easeOut;

  /// For elements leaving (e.g. an N token being consumed).
  static const Curve exit = Curves.easeIn;
}
