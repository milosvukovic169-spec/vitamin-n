import 'package:flutter/material.dart';

import 'app_motion.dart';

/// Wraps any widget with a subtle scale-down-on-press visual — the
/// shared tactile feedback for every tappable surface in the app
/// (buttons, cards, chips). Calm and small (98%), not a bounce.
///
/// Deliberately has **no `onTap` of its own** and uses a [Listener]
/// (raw pointer events, outside the gesture arena) rather than a
/// [GestureDetector] to track press state. This means it can safely
/// wrap a child that already owns its own tap handling — an
/// [ElevatedButton], [InkWell], etc. — without intercepting or
/// duplicating that child's tap. The child remains the single source
/// of truth for whether a tap "counts" (e.g. respects its own
/// `enabled` / `onPressed == null` state); this widget only reacts to
/// the physical press to drive the scale animation.
class TapScale extends StatefulWidget {
  const TapScale({
    super.key,
    required this.child,
    this.pressedScale = 0.98,
  });

  final Widget child;
  final double pressedScale;

  @override
  State<TapScale> createState() => _TapScaleState();
}

class _TapScaleState extends State<TapScale> {
  bool _pressed = false;

  void _setPressed(bool value) {
    if (_pressed != value) {
      setState(() => _pressed = value);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Listener(
      onPointerDown: (_) => _setPressed(true),
      onPointerUp: (_) => _setPressed(false),
      onPointerCancel: (_) => _setPressed(false),
      child: AnimatedScale(
        scale: _pressed ? widget.pressedScale : 1.0,
        duration: AppMotion.fast,
        curve: AppMotion.calm,
        child: widget.child,
      ),
    );
  }
}
