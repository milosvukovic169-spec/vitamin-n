import 'dart:convert';

import 'package:flutter/services.dart' show rootBundle;

/// Loads and parses a bundled JSON array asset.
///
/// All static content (categories, situations, refusal responses, reality
/// reminders, support messages, challenge programs, notifications and
/// protected values) is shipped as a JSON array of objects. This loader
/// is the single place that turns a raw asset file into a
/// `List<Map<String, dynamic>>` that a repository can map into models.
///
/// Content repositories cache the parsed result in memory after the
/// first read, since the underlying files never change at runtime —
/// this keeps every screen read after the first one synchronous-fast
/// without needing a database round trip for read-only content.
class JsonAssetLoader {
  const JsonAssetLoader();

  Future<List<Map<String, dynamic>>> loadList(String assetPath) async {
    final String raw = await rootBundle.loadString(assetPath);
    final dynamic decoded = jsonDecode(raw);

    if (decoded is! List) {
      throw FormatException(
        'Expected a JSON array in $assetPath but found ${decoded.runtimeType}.',
      );
    }

    return decoded.cast<Map<String, dynamic>>();
  }

  /// Loads a single JSON object asset (e.g. one challenge file, which
  /// is a single object with an embedded `steps` array — not itself
  /// an array of top-level items like every other content type).
  Future<Map<String, dynamic>> loadObject(String assetPath) async {
    final String raw = await rootBundle.loadString(assetPath);
    final dynamic decoded = jsonDecode(raw);

    if (decoded is! Map<String, dynamic>) {
      throw FormatException(
        'Expected a JSON object in $assetPath but found ${decoded.runtimeType}.',
      );
    }

    return decoded;
  }
}
