/// Which Premium restriction actually sent the user to the Premium
/// screen (Phase 7 section 32) — deliberately a closed enum, never
/// free text, so this can never leak screen copy or user content.
enum PremiumEntryPoint { settings, lockedCategory, anotherWay, realityReminder, challenge }

extension PremiumEntryPointAnalytics on PremiumEntryPoint {
  String get analyticsValue => switch (this) {
        PremiumEntryPoint.settings => 'settings',
        PremiumEntryPoint.lockedCategory => 'locked_category',
        PremiumEntryPoint.anotherWay => 'another_way',
        PremiumEntryPoint.realityReminder => 'reality_reminder',
        PremiumEntryPoint.challenge => 'challenge',
      };
}

enum PlanType { monthly, yearly }

extension PlanTypeAnalytics on PlanType {
  String get analyticsValue => this == PlanType.monthly ? 'monthly' : 'yearly';
}

/// Vitamin N's one product-analytics abstraction (Phase 7 section 28).
/// Nothing outside `core/analytics` and its real implementation may
/// import an analytics SDK directly — every feature depends on this
/// interface instead, so the underlying provider can change without
/// touching the rest of the app.
///
/// Every method signature is a closed, documented event with only
/// controlled-identifier parameters (section 30/31) — there is no
/// generic `logEvent(String name, Map params)` escape hatch, which is
/// what makes "no free-form user text can reach analytics" true by
/// construction rather than by convention.
abstract class AnalyticsService {
  Future<void> appOpened();

  Future<void> sayNoStarted();
  Future<void> categorySelected({required String categoryId});
  Future<void> situationSelected({required String categoryId, required String situationId});
  Future<void> suggestedResponseViewed({
    required String categoryId,
    required String situationId,
  });
  Future<void> anotherWayRequested({
    required String categoryId,
    required String situationId,
    required int responseVariantIndex,
  });
  Future<void> realityReminderViewed({
    required String categoryId,
    required String situationId,
  });
  Future<void> saidNoCompleted({required String categoryId, required String situationId});
  Future<void> protectedValueSelected({required String protectedValueId});

  Future<void> premiumScreenViewed({required PremiumEntryPoint entryPoint});
  Future<void> premiumPlanSelected({required PlanType planType});
  Future<void> purchaseStarted({required PlanType planType});
  Future<void> purchaseCompleted({required PlanType planType});
  Future<void> purchaseCancelled({required PlanType planType});
  Future<void> purchaseFailed({required PlanType planType});
  Future<void> restoreStarted();
  Future<void> restoreCompleted();
  Future<void> restoreNoPurchaseFound();

  /// Lifecycle only — see Phase 7 section 33. NEVER the reminder
  /// text, its length, or anything derived from its content.
  Future<void> personalReminderCreated();
  Future<void> personalReminderDeleted();
}
