import 'analytics_service.dart';

/// Does nothing. Used for tests (section 35 — tests must never send
/// real analytics events) and as the app's safe default whenever a
/// real provider isn't configured — analytics failing or being
/// absent must never affect app behavior (section 34).
class NoopAnalyticsService implements AnalyticsService {
  const NoopAnalyticsService();

  @override
  Future<void> appOpened() async {}

  @override
  Future<void> sayNoStarted() async {}

  @override
  Future<void> categorySelected({required String categoryId}) async {}

  @override
  Future<void> situationSelected({
    required String categoryId,
    required String situationId,
  }) async {}

  @override
  Future<void> suggestedResponseViewed({
    required String categoryId,
    required String situationId,
  }) async {}

  @override
  Future<void> anotherWayRequested({
    required String categoryId,
    required String situationId,
    required int responseVariantIndex,
  }) async {}

  @override
  Future<void> realityReminderViewed({
    required String categoryId,
    required String situationId,
  }) async {}

  @override
  Future<void> saidNoCompleted({
    required String categoryId,
    required String situationId,
  }) async {}

  @override
  Future<void> protectedValueSelected({required String protectedValueId}) async {}

  @override
  Future<void> premiumScreenViewed({required PremiumEntryPoint entryPoint}) async {}

  @override
  Future<void> premiumPlanSelected({required PlanType planType}) async {}

  @override
  Future<void> purchaseStarted({required PlanType planType}) async {}

  @override
  Future<void> purchaseCompleted({required PlanType planType}) async {}

  @override
  Future<void> purchaseCancelled({required PlanType planType}) async {}

  @override
  Future<void> purchaseFailed({required PlanType planType}) async {}

  @override
  Future<void> restoreStarted() async {}

  @override
  Future<void> restoreCompleted() async {}

  @override
  Future<void> restoreNoPurchaseFound() async {}

  @override
  Future<void> personalReminderCreated() async {}

  @override
  Future<void> personalReminderDeleted() async {}
}
