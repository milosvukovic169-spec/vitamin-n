import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'analytics_service.dart';
import 'noop_analytics_service.dart';

/// The single analytics provider every feature depends on.
///
/// Defaults to [NoopAnalyticsService] — see
/// `firebase_analytics_service.dart`'s doc comment for exactly what
/// real Firebase console setup is required before switching this to
/// construct `FirebaseAnalyticsService` instead. That is the ONLY
/// line that needs to change; nothing else in the app references a
/// concrete analytics implementation.
final Provider<AnalyticsService> analyticsServiceProvider = Provider<AnalyticsService>(
  (Ref ref) => const NoopAnalyticsService(),
);
