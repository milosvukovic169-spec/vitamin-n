import 'package:firebase_analytics/firebase_analytics.dart';

import 'analytics_service.dart';

/// The real analytics implementation, using Firebase Analytics (Phase
/// 7 section 28). This is the only file in the app that imports
/// `firebase_analytics` — every feature depends on [AnalyticsService]
/// instead.
///
/// NOT WIRED IN BY DEFAULT. Firebase requires real console setup
/// (a Firebase project, an Android app registered in it, and a
/// `google-services.json` downloaded into `android/app/`) that cannot
/// be fabricated here — see the Phase 7 report's Firebase checklist
/// for the exact manual steps. Until that's done,
/// `Firebase.initializeApp()` has nothing valid to initialize
/// against, so the app's analytics provider defaults to
/// NoopAnalyticsService. Once Firebase console setup is complete,
/// switch `analyticsServiceProvider` (see `analytics_providers.dart`)
/// to construct this class instead — no other file needs to change,
/// since everything depends on [AnalyticsService].
///
/// Every method here does the same two things: builds a parameter map
/// of ONLY controlled identifiers (never user-entered text — enforced
/// by this class's own method signatures matching [AnalyticsService]
/// exactly, so there's no way to accidentally pass free text through),
/// and swallows any Firebase-level failure so analytics can never
/// break the app (section 34).
class FirebaseAnalyticsService implements AnalyticsService {
  FirebaseAnalyticsService(this._analytics);

  final FirebaseAnalytics _analytics;

  Future<void> _log(String name, [Map<String, Object>? parameters]) async {
    try {
      await _analytics.logEvent(name: name, parameters: parameters);
    } catch (_) {
      // Analytics is non-critical — never surface a failure to the
      // user or let it interrupt whatever the app was doing.
    }
  }

  @override
  Future<void> appOpened() => _log('app_opened');

  @override
  Future<void> sayNoStarted() => _log('say_no_started');

  @override
  Future<void> categorySelected({required String categoryId}) =>
      _log('category_selected', <String, Object>{'category_id': categoryId});

  @override
  Future<void> situationSelected({
    required String categoryId,
    required String situationId,
  }) =>
      _log('situation_selected', <String, Object>{
        'category_id': categoryId,
        'situation_id': situationId,
      });

  @override
  Future<void> suggestedResponseViewed({
    required String categoryId,
    required String situationId,
  }) =>
      _log('suggested_response_viewed', <String, Object>{
        'category_id': categoryId,
        'situation_id': situationId,
      });

  @override
  Future<void> anotherWayRequested({
    required String categoryId,
    required String situationId,
    required int responseVariantIndex,
  }) =>
      _log('another_way_requested', <String, Object>{
        'category_id': categoryId,
        'situation_id': situationId,
        'response_variant_index': responseVariantIndex,
      });

  @override
  Future<void> realityReminderViewed({
    required String categoryId,
    required String situationId,
  }) =>
      _log('reality_reminder_viewed', <String, Object>{
        'category_id': categoryId,
        'situation_id': situationId,
      });

  @override
  Future<void> saidNoCompleted({required String categoryId, required String situationId}) =>
      _log('said_no_completed', <String, Object>{
        'category_id': categoryId,
        'situation_id': situationId,
      });

  @override
  Future<void> protectedValueSelected({required String protectedValueId}) => _log(
      'protected_value_selected', <String, Object>{'protected_value_id': protectedValueId});

  @override
  Future<void> premiumScreenViewed({required PremiumEntryPoint entryPoint}) => _log(
      'premium_screen_viewed', <String, Object>{'entry_point': entryPoint.analyticsValue});

  @override
  Future<void> premiumPlanSelected({required PlanType planType}) => _log(
      'premium_plan_selected', <String, Object>{'plan_type': planType.analyticsValue});

  @override
  Future<void> purchaseStarted({required PlanType planType}) =>
      _log('purchase_started', <String, Object>{'plan_type': planType.analyticsValue});

  @override
  Future<void> purchaseCompleted({required PlanType planType}) =>
      _log('purchase_completed', <String, Object>{'plan_type': planType.analyticsValue});

  @override
  Future<void> purchaseCancelled({required PlanType planType}) =>
      _log('purchase_cancelled', <String, Object>{'plan_type': planType.analyticsValue});

  @override
  Future<void> purchaseFailed({required PlanType planType}) =>
      _log('purchase_failed', <String, Object>{'plan_type': planType.analyticsValue});

  @override
  Future<void> restoreStarted() => _log('restore_started');

  @override
  Future<void> restoreCompleted() => _log('restore_completed');

  @override
  Future<void> restoreNoPurchaseFound() => _log('restore_no_purchase_found');

  @override
  Future<void> personalReminderCreated() => _log('personal_reminder_created');

  @override
  Future<void> personalReminderDeleted() => _log('personal_reminder_deleted');
}
