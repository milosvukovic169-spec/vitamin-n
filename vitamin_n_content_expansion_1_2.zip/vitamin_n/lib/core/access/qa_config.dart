/// TEMPORARY QA UNLOCK — MUST BE FALSE FOR PRODUCTION RELEASE.
///
/// While [qaUnlockAll] is true, every Premium-gated feature
/// (categories, Another Way, Reality Reminders, Challenges) is both
/// FUNCTIONALLY accessible AND visually shown as unlocked (no lock
/// icon) — every gated screen reads [qaUnlockAll] through exactly one
/// place (effectiveIsPremiumProvider, in premium_providers.dart) for
/// BOTH its access decision and its lock-icon decision, so the two
/// can never drift out of sync the way they previously did (a
/// feature being clickable while still showing a stale lock icon).
///
/// This sits ABOVE the real Premium/IAP architecture, not in place of
/// it — premiumStatusProvider still reflects the user's real,
/// truthful purchase status; billing, product IDs, and purchase/
/// restore logic are completely untouched. Setting this back to
/// `false` immediately restores the intended production Free/Premium
/// gating everywhere, with no other code changes required.
abstract final class QaConfig {
  static const bool qaUnlockAll = true;
}
