import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:package_info_plus/package_info_plus.dart';

/// The single source of truth for the app's real version/build
/// number — read once from platform package metadata, not hardcoded
/// anywhere in the UI (Phase 6 section 32).
final FutureProvider<PackageInfo> packageInfoProvider = FutureProvider<PackageInfo>((Ref ref) {
  return PackageInfo.fromPlatform();
});
