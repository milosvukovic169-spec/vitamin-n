/// Central registry of the bundled JSON content assets.
///
/// Phase 5 content lives under `assets/content/` and is split by
/// category so it can be **lazily loaded** — only the metadata files
/// are read at startup; a category's situations/responses/reality
/// reminders are only parsed once that category is actually opened.
/// See each feature's local data source for the caching that makes
/// this "load once per session" rather than "load once per screen".
abstract final class AssetPaths {
  // Loaded eagerly at startup — small, needed for Home/Category list.
  static const String categories = 'assets/content/categories.json';
  static const String protectedValues = 'assets/content/protected_values.json';
  static const String supportMessages = 'assets/content/support_messages.json';

  // Loaded lazily, one category at a time, on first access.
  static String situationsForCategory(String categoryId) =>
      'assets/content/situations/${_slug(categoryId)}.json';

  static String responsesForCategory(String categoryId) =>
      'assets/content/responses/${_slug(categoryId)}.json';

  static String realityRemindersForCategory(String categoryId) =>
      'assets/content/reality_reminders/${_slug(categoryId)}.json';

  static const String notifications = 'assets/data/notifications.json';

  static const List<String> challengeFiles = <String>[
    'assets/content/challenges/digital_boundaries.json',
    'assets/content/challenges/people_pleasing_reset.json',
    'assets/content/challenges/work_boundaries.json',
    'assets/content/challenges/time_protection.json',
    'assets/content/challenges/mindful_spending_boundaries.json',
    'assets/content/challenges/evening_boundaries.json',
  ];

  /// Turns a category id like `cat_listening_support` into the
  /// filename stem `listening_support`, matching the spec's
  /// per-category filenames exactly.
  static String _slug(String categoryId) =>
      categoryId.startsWith('cat_') ? categoryId.substring(4) : categoryId;
}
