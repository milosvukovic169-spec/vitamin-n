import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'app_database.dart';

/// The single shared Drift database instance for the whole app.
/// Every feature's local data source depends on this rather than
/// constructing its own connection.
final Provider<AppDatabase> appDatabaseProvider = Provider<AppDatabase>((Ref ref) {
  final AppDatabase db = AppDatabase();
  ref.onDispose(db.close);
  return db;
});
