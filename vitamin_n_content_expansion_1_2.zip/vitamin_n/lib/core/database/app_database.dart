import 'dart:io';

import 'package:drift/drift.dart';
import 'package:drift/native.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import 'tables/active_challenges_table.dart';
import 'tables/courses_table.dart';
import 'tables/entries_table.dart';
import 'tables/favorites_table.dart';
import 'tables/personal_reminders_table.dart';
import 'tables/settings_table.dart';

part 'app_database.g.dart';

/// The single local database for all mutable, user-generated data
/// (entries, course progress, favorites, settings, active challenge).
///
/// Static reference content (categories, situations, refusal
/// responses, etc.) is intentionally NOT stored here — it's read
/// directly from bundled JSON assets by each feature's data source.
/// This keeps "what the app can offer" (content, expandable by
/// editing JSON) cleanly separate from "what the user did" (this
/// database).
///
/// Run `dart run build_runner build --delete-conflicting-outputs`
/// after any table change to regenerate `app_database.g.dart`.
@DriftDatabase(
  tables: <Type>[Courses, Entries, Settings, Favorites, ActiveChallenges, PersonalReminders],
)
class AppDatabase extends _$AppDatabase {
  AppDatabase() : super(_openConnection());

  /// Test-only constructor: pass an in-memory executor.
  AppDatabase.forTesting(super.executor);

  /// v2 added indexes on Entries(createdAt), Entries(categoryId) and
  /// Entries(situationId) for History/Insights query performance.
  /// v3 (Phase 6) adds the PersonalReminders table — see [migration]
  /// below for how existing databases pick each up without losing
  /// data.
  @override
  int get schemaVersion => 3;

  @override
  MigrationStrategy get migration => MigrationStrategy(
        onCreate: (Migrator m) async {
          // New installs: the current table definitions already
          // declare the three @TableIndex annotations, so a full
          // createAll() creates every table AND those indexes
          // together in one step. Nothing further needed for a
          // fresh database.
          await m.createAll();
        },
        onUpgrade: (Migrator m, int from, int to) async {
          if (from < 2) {
            // Existing (Phase 3) databases already have every table
            // with all of their data intact — this only adds the
            // three new indexes. No table is dropped, altered, or
            // recreated, and no row is touched. Raw SQL is used
            // deliberately here (rather than a generated Index
            // getter) so this migration's correctness never depends
            // on matching Drift's internal naming for generated
            // schema objects — only on the exact index name/column
            // pairing already declared on the Entries table.
            await m.database.customStatement(
              'CREATE INDEX IF NOT EXISTS idx_entries_created_at '
              'ON entries (created_at)',
            );
            await m.database.customStatement(
              'CREATE INDEX IF NOT EXISTS idx_entries_category_id '
              'ON entries (category_id)',
            );
            await m.database.customStatement(
              'CREATE INDEX IF NOT EXISTS idx_entries_situation_id '
              'ON entries (situation_id)',
            );
          }
          if (from < 3) {
            // Adds the new PersonalReminders table only — every
            // other table and its data is completely untouched.
            // Personal Reminders were dormant (unreachable through
            // any UI) before Phase 6, so there is no prior data in
            // any format to carry forward here; this is a pure
            // additive schema change.
            await m.createTable(personalReminders);
          }
        },
      );

  /// Deletes the user-owned dynamic content Phase 6 section 30 lists:
  /// Entries (History/Insights source data), Courses, Favorites,
  /// ActiveChallenges and PersonalReminders — as one atomic
  /// transaction. Static curated JSON content is untouched (it was
  /// never in this database to begin with).
  ///
  /// The Settings table is deliberately left alone. It holds
  /// onboarding state and per-Challenge step-completion progress —
  /// neither is in section 30's list — and, per section 31, clearing
  /// local data must never be able to accidentally wipe a future
  /// Premium entitlement flag, which would also live in Settings once
  /// Phase 7 adds real billing. Only the tables named above are ever
  /// touched here.
  Future<void> clearAllUserData() {
    return transaction(() async {
      await delete(entries).go();
      await delete(courses).go();
      await delete(favorites).go();
      await delete(activeChallenges).go();
      await delete(personalReminders).go();
    });
  }
}

LazyDatabase _openConnection() {
  return LazyDatabase(() async {
    final Directory dbFolder = await getApplicationDocumentsDirectory();
    final File file = File(p.join(dbFolder.path, 'vitamin_n.sqlite'));
    return NativeDatabase.createInBackground(file);
  });
}
