import 'package:drift/drift.dart';

/// Generic key-value settings storage. New settings only ever need a
/// new key, never a schema migration.
@DataClassName('SettingRow')
class Settings extends Table {
  TextColumn get key => text()();
  TextColumn get value => text()();

  @override
  Set<Column> get primaryKey => <Column>{key};
}
