import 'package:drift/drift.dart';

/// Storage for the Vitamin Course cycle. See the `Course` domain
/// entity for the behavioral contract — tokens are visual progress
/// only, not days, not a streak, and never refill on a schedule.
@DataClassName('CourseRow')
class Courses extends Table {
  IntColumn get id => integer().autoIncrement()();
  IntColumn get cycleNumber => integer()();
  IntColumn get tokensRemaining => integer()();
  DateTimeColumn get startedAt => dateTime()();
  DateTimeColumn get completedAt => dateTime().nullable()();
}
