import 'package:drift/drift.dart';

/// A user-marked favorite pointing at a piece of static content by
/// type + id (e.g. a refusal response or reality reminder).
@DataClassName('FavoriteRow')
class Favorites extends Table {
  TextColumn get id => text()();
  TextColumn get entityType => text()();
  TextColumn get entityId => text()();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => <Column>{id};

  @override
  List<Set<Column>> get uniqueKeys => <Set<Column>>[
        <Column>{entityType, entityId},
      ];
}
