import 'package:drift/drift.dart';

import 'courses_table.dart';

/// Storage for completed "I SAID NO" records — the durable result of
/// the locked Say No flow, and the basis for History and Insights.
///
/// Indexed on the three columns History/Insights filter and group by
/// most often, so those queries stay fast as entries accumulate into
/// the thousands rather than scanning the whole table.
@TableIndex(name: 'idx_entries_created_at', columns: <Symbol>{#createdAt})
@TableIndex(name: 'idx_entries_category_id', columns: <Symbol>{#categoryId})
@TableIndex(name: 'idx_entries_situation_id', columns: <Symbol>{#situationId})
@DataClassName('EntryRow')
class Entries extends Table {
  TextColumn get id => text()();
  TextColumn get categoryId => text()();
  TextColumn get situationId => text()();
  TextColumn get refusalResponseId => text().nullable()();

  /// JSON-encoded list of protected value ids. Kept as a single text
  /// column rather than a join table since it's always read/written
  /// as a whole with the entry, never queried by individual value on
  /// its own — aggregation happens in the repository layer.
  TextColumn get protectedValueIds => text()();

  TextColumn get personalReminderNote => text().nullable()();

  /// A free-text protected value the user typed under "Other",
  /// alongside (not replacing) [protectedValueIds].
  TextColumn get customProtectedValue => text().nullable()();

  /// Whether the Reflection Pause screen was shown during this flow —
  /// kept for future analysis of the pause's effect, never surfaced
  /// to the user as a stat.
  BoolColumn get reflectionPauseShown =>
      boolean().withDefault(const Constant(false))();

  IntColumn get courseId => integer().references(Courses, #id)();
  DateTimeColumn get createdAt => dateTime()();

  @override
  Set<Column> get primaryKey => <Column>{id};
}
