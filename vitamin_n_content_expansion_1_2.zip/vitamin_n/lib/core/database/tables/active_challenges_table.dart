import 'package:drift/drift.dart';

/// Records which Challenge Program the user has chosen to focus on.
/// Deliberately holds no progress counter, score or streak — only
/// "what" and "since when".
@DataClassName('ActiveChallengeRow')
class ActiveChallenges extends Table {
  IntColumn get id => integer().autoIncrement()();
  TextColumn get programId => text()();
  DateTimeColumn get startedAt => dateTime()();
}
