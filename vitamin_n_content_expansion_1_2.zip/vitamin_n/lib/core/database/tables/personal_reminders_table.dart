import 'package:drift/drift.dart';

/// Storage for Personal Reminders — optional, user-authored notes
/// ("a note from me to myself for next time"). Per Phase 6 section 5:
/// NOT notifications, NOT tasks, NOT scheduled, NOT part of Say No
/// logging. A standalone reminder (no category, no situation) must be
/// valid, so [id] — not situationId — is the primary key, and both
/// [categoryId] and [situationId] are nullable.
///
/// The reminder body is named [reminderText] in Dart (Drift's Table
/// DSL already defines a `text()` builder method on every table, so a
/// column getter literally named `text` would collide with it); the
/// underlying SQL column is still named `text` via `.named(...)` to
/// match the field name the spec asks for.
@DataClassName('PersonalReminderRow')
class PersonalReminders extends Table {
  TextColumn get id => text()();
  TextColumn get reminderText => text().named('text')();
  TextColumn get categoryId => text().nullable()();
  TextColumn get situationId => text().nullable()();
  BoolColumn get isActive => boolean().withDefault(const Constant(true))();
  DateTimeColumn get createdAt => dateTime()();
  DateTimeColumn get updatedAt => dateTime()();

  @override
  Set<Column> get primaryKey => <Column>{id};
}
