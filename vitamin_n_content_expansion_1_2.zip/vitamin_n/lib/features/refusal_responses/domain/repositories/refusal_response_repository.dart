import '../entities/refusal_response.dart';

/// Category-scoped for the same lazy-loading reason as
/// SituationRepository — a category's response file covers every
/// situation in that category, so the caller supplies both ids and
/// only that one file is ever read.
abstract class RefusalResponseRepository {
  Future<List<RefusalResponse>> getBySituation({
    required String categoryId,
    required String situationId,
  });
}
