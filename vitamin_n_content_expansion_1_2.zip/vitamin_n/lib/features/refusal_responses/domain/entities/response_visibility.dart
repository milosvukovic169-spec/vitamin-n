import 'refusal_response.dart';

/// Pure logic for how many responses are visible and what the
/// "show more" affordance should say, kept separate from the widget
/// so the exact gating rules are directly unit-testable without
/// pumping a widget tree.
abstract final class ResponseVisibility {
  /// How many of [totalAuthored] responses are actually shown, given
  /// [isPremium]. Free is always capped at
  /// [RefusalResponse.freeCount] (1); Premium is capped at
  /// [RefusalResponse.premiumDisplayCap] (4) even if more exists.
  static int visibleCount(int totalAuthored, {required bool isPremium}) {
    final int cap = isPremium ? RefusalResponse.premiumDisplayCap : RefusalResponse.freeCount;
    return totalAuthored.clamp(0, cap);
  }

  /// The label for the button that would move from [currentIndex]
  /// (0-based) to the next response — or null if there's nothing
  /// further to show at this tier. Free users never get this
  /// affordance at all (they see the locked "Another way 🔒" label
  /// instead, handled separately by the screen); this only applies
  /// to Premium's in-place cycling.
  static String? nextButtonLabelForPremium({
    required int currentIndex,
    required int visibleLimit,
  }) {
    if (currentIndex >= visibleLimit - 1) return null;
    final int nextIndex = currentIndex + 1;
    return nextIndex == 3 ? 'One more way' : 'Another way';
  }
}
