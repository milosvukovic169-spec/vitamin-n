import '../../domain/entities/refusal_response.dart';
import '../../domain/repositories/refusal_response_repository.dart';
import '../datasources/refusal_response_local_data_source.dart';

class RefusalResponseRepositoryImpl implements RefusalResponseRepository {
  RefusalResponseRepositoryImpl(this._dataSource);

  final RefusalResponseLocalDataSource _dataSource;

  /// One entry per category: a situationId -> responses index, built
  /// once when that category is first opened and reused for every
  /// "Another way" tap for the rest of the session — never a re-scan
  /// of the raw list.
  final Map<String, Map<String, List<RefusalResponse>>> _cache =
      <String, Map<String, List<RefusalResponse>>>{};

  Future<Map<String, List<RefusalResponse>>> _loadCategory(String categoryId) async {
    final Map<String, List<RefusalResponse>>? cached = _cache[categoryId];
    if (cached != null) {
      return cached;
    }

    final List<RefusalResponse> raw = await _dataSource.loadForCategory(categoryId);
    final Map<String, List<RefusalResponse>> bySituation =
        <String, List<RefusalResponse>>{};
    for (final RefusalResponse response in raw) {
      (bySituation[response.situationId] ??= <RefusalResponse>[]).add(response);
    }
    for (final List<RefusalResponse> list in bySituation.values) {
      list.sort((RefusalResponse a, RefusalResponse b) =>
          a.sortOrder.compareTo(b.sortOrder));
    }

    _cache[categoryId] = bySituation;
    return bySituation;
  }

  @override
  Future<List<RefusalResponse>> getBySituation({
    required String categoryId,
    required String situationId,
  }) async {
    final Map<String, List<RefusalResponse>> bySituation =
        await _loadCategory(categoryId);
    return bySituation[situationId] ?? const <RefusalResponse>[];
  }
}
