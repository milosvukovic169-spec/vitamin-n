import '../../../../core/constants/asset_paths.dart';
import '../../../../core/json/json_asset_loader.dart';
import '../../domain/entities/refusal_response.dart';

class RefusalResponseLocalDataSource {
  RefusalResponseLocalDataSource({
    JsonAssetLoader loader = const JsonAssetLoader(),
  }) : _loader = loader;

  final JsonAssetLoader _loader;

  Future<List<RefusalResponse>> loadForCategory(String categoryId) async {
    final List<Map<String, dynamic>> raw = await _loader
        .loadList(AssetPaths.responsesForCategory(categoryId));
    return raw.map(_parse).toList();
  }

  RefusalResponse _parse(Map<String, dynamic> json) {
    return RefusalResponse(
      id: json['id'] as String,
      situationId: json['situationId'] as String,
      text: json['text'] as String,
      sortOrder: json['sortOrder'] as int,
      style: json['style'] as String?,
    );
  }
}
