import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../situations/presentation/providers/situation_providers.dart'
    show CategoryAndSituationId;
import '../../data/datasources/refusal_response_local_data_source.dart';
import '../../data/repositories/refusal_response_repository_impl.dart';
import '../../domain/entities/refusal_response.dart';
import '../../domain/repositories/refusal_response_repository.dart';

final Provider<RefusalResponseRepository> refusalResponseRepositoryProvider =
    Provider<RefusalResponseRepository>((Ref ref) {
  return RefusalResponseRepositoryImpl(RefusalResponseLocalDataSource());
});

final FutureProviderFamily<List<RefusalResponse>, CategoryAndSituationId>
    refusalResponsesForSituationProvider =
    FutureProvider.family<List<RefusalResponse>, CategoryAndSituationId>(
        (Ref ref, CategoryAndSituationId key) {
  return ref.watch(refusalResponseRepositoryProvider).getBySituation(
        categoryId: key.categoryId,
        situationId: key.situationId,
      );
});
