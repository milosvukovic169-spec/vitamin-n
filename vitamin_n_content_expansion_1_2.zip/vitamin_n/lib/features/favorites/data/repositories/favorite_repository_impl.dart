import 'package:uuid/uuid.dart';

import '../../../../core/database/app_database.dart';
import '../../domain/entities/favorite.dart';
import '../../domain/repositories/favorite_repository.dart';
import '../datasources/favorite_local_data_source.dart';

class FavoriteRepositoryImpl implements FavoriteRepository {
  FavoriteRepositoryImpl(this._dataSource, {Uuid uuid = const Uuid()})
      : _uuid = uuid;

  final FavoriteLocalDataSource _dataSource;
  final Uuid _uuid;

  Favorite _toEntity(FavoriteRow row) {
    return Favorite(
      id: row.id,
      entityType: row.entityType,
      entityId: row.entityId,
      createdAt: row.createdAt,
    );
  }

  @override
  Future<List<Favorite>> getAll() async {
    final rows = await _dataSource.getAllRows();
    return rows.map(_toEntity).toList();
  }

  @override
  Future<List<Favorite>> getByType(String entityType) async {
    final rows = await _dataSource.getByTypeRows(entityType);
    return rows.map(_toEntity).toList();
  }

  @override
  Future<bool> isFavorite(String entityType, String entityId) async {
    final row = await _dataSource.findRow(entityType, entityId);
    return row != null;
  }

  @override
  Future<void> toggle(String entityType, String entityId) async {
    final existing = await _dataSource.findRow(entityType, entityId);

    if (existing != null) {
      await _dataSource.deleteById(existing.id);
      return;
    }

    await _dataSource.insertRow(
      FavoritesCompanion.insert(
        id: _uuid.v4(),
        entityType: entityType,
        entityId: entityId,
        createdAt: DateTime.now(),
      ),
    );
  }
}
