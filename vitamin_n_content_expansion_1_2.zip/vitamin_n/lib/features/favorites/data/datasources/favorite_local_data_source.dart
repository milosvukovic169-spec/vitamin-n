import 'package:drift/drift.dart';

import '../../../../core/database/app_database.dart';

class FavoriteLocalDataSource {
  FavoriteLocalDataSource(this._db);

  final AppDatabase _db;

  Future<List<FavoriteRow>> getAllRows() {
    return (_db.select(_db.favorites)
          ..orderBy([(tbl) => OrderingTerm.desc(tbl.createdAt)]))
        .get();
  }

  Future<List<FavoriteRow>> getByTypeRows(String entityType) {
    return (_db.select(_db.favorites)
          ..where((tbl) => tbl.entityType.equals(entityType))
          ..orderBy([(tbl) => OrderingTerm.desc(tbl.createdAt)]))
        .get();
  }

  Future<FavoriteRow?> findRow(String entityType, String entityId) {
    return (_db.select(_db.favorites)
          ..where((tbl) =>
              tbl.entityType.equals(entityType) & tbl.entityId.equals(entityId))
          ..limit(1))
        .getSingleOrNull();
  }

  Future<void> insertRow(FavoritesCompanion companion) {
    return _db.into(_db.favorites).insert(companion);
  }

  Future<void> deleteById(String id) {
    return (_db.delete(_db.favorites)..where((tbl) => tbl.id.equals(id))).go();
  }
}
