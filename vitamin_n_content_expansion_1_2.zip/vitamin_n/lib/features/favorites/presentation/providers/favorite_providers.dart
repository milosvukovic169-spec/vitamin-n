import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/database/app_database_provider.dart';
import '../../data/datasources/favorite_local_data_source.dart';
import '../../data/repositories/favorite_repository_impl.dart';
import '../../domain/entities/favorite.dart';
import '../../domain/repositories/favorite_repository.dart';

final Provider<FavoriteRepository> favoriteRepositoryProvider =
    Provider<FavoriteRepository>((Ref ref) {
  final db = ref.watch(appDatabaseProvider);
  return FavoriteRepositoryImpl(FavoriteLocalDataSource(db));
});

final FutureProvider<List<Favorite>> allFavoritesProvider =
    FutureProvider<List<Favorite>>((Ref ref) {
  return ref.watch(favoriteRepositoryProvider).getAll();
});
