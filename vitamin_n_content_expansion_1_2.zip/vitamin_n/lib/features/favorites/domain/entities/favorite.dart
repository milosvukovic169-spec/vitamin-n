/// A user-marked favorite pointing at a piece of static content by
/// type + id, so the Library screen can offer quick access without
/// duplicating content.
class Favorite {
  const Favorite({
    required this.id,
    required this.entityType,
    required this.entityId,
    required this.createdAt,
  });

  final String id;
  final String entityType;
  final String entityId;
  final DateTime createdAt;
}

/// The known kinds of content a Favorite can point at.
abstract final class FavoriteEntityType {
  static const String refusalResponse = 'refusal_response';
  static const String realityReminder = 'reality_reminder';
  static const String supportMessage = 'support_message';
}
