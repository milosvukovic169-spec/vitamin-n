import '../entities/favorite.dart';

abstract class FavoriteRepository {
  Future<List<Favorite>> getAll();
  Future<List<Favorite>> getByType(String entityType);
  Future<bool> isFavorite(String entityType, String entityId);
  Future<void> toggle(String entityType, String entityId);
}
