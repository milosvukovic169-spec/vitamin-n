import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/datasources/support_message_local_data_source.dart';
import '../../data/repositories/support_message_repository_impl.dart';
import '../../domain/entities/support_message.dart';
import '../../domain/repositories/support_message_repository.dart';

final Provider<SupportMessageRepository> supportMessageRepositoryProvider =
    Provider<SupportMessageRepository>((Ref ref) {
  return SupportMessageRepositoryImpl(SupportMessageLocalDataSource());
});

final FutureProvider<SupportMessage?> todaysSupportMessageProvider =
    FutureProvider<SupportMessage?>((Ref ref) {
  return ref.watch(supportMessageRepositoryProvider).pickForDate(DateTime.now());
});

/// A freshly random message — used by Home, which wants a random pick
/// rather than the stable daily one.
final FutureProvider<SupportMessage?> randomSupportMessageProvider =
    FutureProvider<SupportMessage?>((Ref ref) {
  return ref.watch(supportMessageRepositoryProvider).pickRandom();
});
