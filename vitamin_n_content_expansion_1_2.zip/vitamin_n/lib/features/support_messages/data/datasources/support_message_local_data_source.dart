import '../../../../core/constants/asset_paths.dart';
import '../../../../core/json/json_asset_loader.dart';
import '../../domain/entities/support_message.dart';

class SupportMessageLocalDataSource {
  SupportMessageLocalDataSource({
    JsonAssetLoader loader = const JsonAssetLoader(),
  }) : _loader = loader;

  final JsonAssetLoader _loader;

  Future<List<SupportMessage>> loadAll() async {
    final List<Map<String, dynamic>> raw =
        await _loader.loadList(AssetPaths.supportMessages);
    return raw.map(_parse).toList()
      ..sort((SupportMessage a, SupportMessage b) =>
          a.sortOrder.compareTo(b.sortOrder));
  }

  SupportMessage _parse(Map<String, dynamic> json) {
    return SupportMessage(
      id: json['id'] as String,
      text: json['text'] as String,
      sortOrder: json['sortOrder'] as int,
    );
  }
}
