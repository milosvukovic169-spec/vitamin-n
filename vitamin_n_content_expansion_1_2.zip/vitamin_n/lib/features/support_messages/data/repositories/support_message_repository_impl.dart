import 'dart:math';

import '../../domain/entities/support_message.dart';
import '../../domain/repositories/support_message_repository.dart';
import '../datasources/support_message_local_data_source.dart';

class SupportMessageRepositoryImpl implements SupportMessageRepository {
  SupportMessageRepositoryImpl(this._dataSource);

  final SupportMessageLocalDataSource _dataSource;
  List<SupportMessage>? _cache;

  Future<List<SupportMessage>> _loadAll() async {
    final List<SupportMessage>? cached = _cache;
    if (cached != null) {
      return cached;
    }
    final List<SupportMessage> loaded = await _dataSource.loadAll();
    _cache = loaded;
    return loaded;
  }

  @override
  Future<List<SupportMessage>> getAll() => _loadAll();

  @override
  Future<SupportMessage?> pickForDate(DateTime date) async {
    final List<SupportMessage> all = await _loadAll();
    if (all.isEmpty) {
      return null;
    }
    final int dayOfYear = int.parse(
      '${date.year}${date.month.toString().padLeft(2, '0')}${date.day.toString().padLeft(2, '0')}',
    );
    return all[dayOfYear % all.length];
  }

  @override
  Future<SupportMessage?> pickRandom({Random? random}) async {
    final List<SupportMessage> all = await _loadAll();
    if (all.isEmpty) {
      return null;
    }
    final Random rng = random ?? Random();
    return all[rng.nextInt(all.length)];
  }
}
