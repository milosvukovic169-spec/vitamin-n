import 'dart:math';

import '../entities/support_message.dart';

abstract class SupportMessageRepository {
  Future<List<SupportMessage>> getAll();

  /// Deterministically picks one message per calendar day, so the
  /// Home screen's support card stays stable across app opens within
  /// the same day.
  Future<SupportMessage?> pickForDate(DateTime date);

  Future<SupportMessage?> pickRandom({Random? random});
}
