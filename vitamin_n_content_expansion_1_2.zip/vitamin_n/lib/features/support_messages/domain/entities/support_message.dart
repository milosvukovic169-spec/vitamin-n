/// A short, calm supportive message shown on Home and after a
/// confirmed Say No entry.
class SupportMessage {
  const SupportMessage({
    required this.id,
    required this.text,
    required this.sortOrder,
  });

  final String id;
  final String text;
  final int sortOrder;

  @override
  bool operator ==(Object other) => other is SupportMessage && other.id == id;

  @override
  int get hashCode => id.hashCode;
}
