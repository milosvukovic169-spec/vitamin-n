import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../situations/presentation/providers/situation_providers.dart'
    show CategoryAndSituationId;
import '../../data/datasources/reality_reminder_local_data_source.dart';
import '../../data/repositories/reality_reminder_repository_impl.dart';
import '../../domain/entities/reality_reminder.dart';
import '../../domain/repositories/reality_reminder_repository.dart';

final Provider<RealityReminderRepository> realityReminderRepositoryProvider =
    Provider<RealityReminderRepository>((Ref ref) {
  return RealityReminderRepositoryImpl(RealityReminderLocalDataSource());
});

final FutureProviderFamily<List<RealityReminder>, CategoryAndSituationId>
    realityRemindersForSituationProvider =
    FutureProvider.family<List<RealityReminder>, CategoryAndSituationId>(
        (Ref ref, CategoryAndSituationId key) {
  return ref.watch(realityReminderRepositoryProvider).getBySituation(
        categoryId: key.categoryId,
        situationId: key.situationId,
      );
});
