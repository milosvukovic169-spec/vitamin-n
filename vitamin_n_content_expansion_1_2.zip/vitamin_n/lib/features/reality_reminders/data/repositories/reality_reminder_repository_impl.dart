import '../../domain/entities/reality_reminder.dart';
import '../../domain/repositories/reality_reminder_repository.dart';
import '../datasources/reality_reminder_local_data_source.dart';

class RealityReminderRepositoryImpl implements RealityReminderRepository {
  RealityReminderRepositoryImpl(this._dataSource);

  final RealityReminderLocalDataSource _dataSource;

  final Map<String, Map<String, List<RealityReminder>>> _cache =
      <String, Map<String, List<RealityReminder>>>{};

  Future<Map<String, List<RealityReminder>>> _loadCategory(String categoryId) async {
    final Map<String, List<RealityReminder>>? cached = _cache[categoryId];
    if (cached != null) {
      return cached;
    }

    final List<RealityReminder> raw = await _dataSource.loadForCategory(categoryId);
    final Map<String, List<RealityReminder>> bySituation =
        <String, List<RealityReminder>>{};
    for (final RealityReminder reminder in raw) {
      (bySituation[reminder.situationId] ??= <RealityReminder>[]).add(reminder);
    }
    for (final List<RealityReminder> list in bySituation.values) {
      list.sort((RealityReminder a, RealityReminder b) =>
          a.sortOrder.compareTo(b.sortOrder));
    }

    _cache[categoryId] = bySituation;
    return bySituation;
  }

  @override
  Future<List<RealityReminder>> getBySituation({
    required String categoryId,
    required String situationId,
  }) async {
    final Map<String, List<RealityReminder>> bySituation =
        await _loadCategory(categoryId);
    return bySituation[situationId] ?? const <RealityReminder>[];
  }
}
