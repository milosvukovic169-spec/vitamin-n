import '../../../../core/constants/asset_paths.dart';
import '../../../../core/json/json_asset_loader.dart';
import '../../domain/entities/reality_reminder.dart';

class RealityReminderLocalDataSource {
  RealityReminderLocalDataSource({
    JsonAssetLoader loader = const JsonAssetLoader(),
  }) : _loader = loader;

  final JsonAssetLoader _loader;

  Future<List<RealityReminder>> loadForCategory(String categoryId) async {
    final List<Map<String, dynamic>> raw = await _loader
        .loadList(AssetPaths.realityRemindersForCategory(categoryId));
    return raw.map(_parse).toList();
  }

  RealityReminder _parse(Map<String, dynamic> json) {
    return RealityReminder(
      id: json['id'] as String,
      situationId: json['situationId'] as String,
      text: json['text'] as String,
      sortOrder: json['sortOrder'] as int,
      dimension: json['dimension'] as String?,
    );
  }
}
