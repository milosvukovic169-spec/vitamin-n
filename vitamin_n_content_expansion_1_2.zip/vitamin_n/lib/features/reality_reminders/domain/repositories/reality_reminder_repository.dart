import '../entities/reality_reminder.dart';

/// Category-scoped, same rationale as SituationRepository /
/// RefusalResponseRepository.
abstract class RealityReminderRepository {
  Future<List<RealityReminder>> getBySituation({
    required String categoryId,
    required String situationId,
  });
}
