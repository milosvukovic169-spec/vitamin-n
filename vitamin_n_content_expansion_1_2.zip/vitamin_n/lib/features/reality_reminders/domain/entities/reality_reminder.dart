/// A short, grounding statement shown during the "Reality Reminder"
/// step of the Say No flow — linked to a specific Situation (not a
/// whole Category), per the Phase 5 content model, since the
/// insight's value comes from being concrete to what's actually
/// happening.
///
/// Free/Premium gating has two layers, per the final monetization
/// model: [freeCount] governs how many reminders are shown once
/// access is granted (always 1 for Free), but WHETHER a Free user
/// gets any reminder at all for a given situation depends on the
/// situation's category — see [RealityReminderAccess]. This is
/// deliberately a stricter gate than [RefusalResponse]'s, which is
/// available in all three Free categories.
class RealityReminder {
  /// Free users see exactly this many reminders (by [sortOrder]) once
  /// access is granted for the category — one strong,
  /// situation-specific insight, per spec.
  static const int freeCount = 1;

  const RealityReminder({
    required this.id,
    required this.situationId,
    required this.text,
    required this.sortOrder,
    this.dimension,
  });

  final String id;
  final String situationId;
  final String text;
  final int sortOrder;

  /// An optional consequence dimension for Premium's multi-perspective
  /// reminders (Time, Energy, Expectation, Priorities, Reciprocity,
  /// Money, Focus, Rest). Null for the single Free reminder.
  final String? dimension;

  @override
  bool operator ==(Object other) => other is RealityReminder && other.id == id;

  @override
  int get hashCode => id.hashCode;
}

/// Which category a Free user's Reality Reminder access is unlocked
/// for. Per the final monetization model, this is Relationships
/// only — Work and Digital are Free categories for situations and
/// responses, but their Reality Reminder is a locked Premium teaser.
abstract final class RealityReminderAccess {
  static const String freeCategoryId = 'cat_relationships';

  static bool isFreeForCategory(String categoryId) => categoryId == freeCategoryId;
}
