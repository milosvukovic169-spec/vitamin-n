import 'package:drift/drift.dart';

import '../../../../core/database/app_database.dart';

class PersonalReminderLocalDataSource {
  PersonalReminderLocalDataSource(this._db);

  final AppDatabase _db;

  Future<List<PersonalReminderRow>> getAllRows() {
    return (_db.select(_db.personalReminders)
          ..orderBy([(tbl) => OrderingTerm.desc(tbl.updatedAt)]))
        .get();
  }

  Future<PersonalReminderRow?> findRowById(String id) {
    return (_db.select(_db.personalReminders)..where((tbl) => tbl.id.equals(id)))
        .getSingleOrNull();
  }

  Future<List<PersonalReminderRow>> findActiveBySituationId(String situationId) {
    return (_db.select(_db.personalReminders)
          ..where((tbl) =>
              tbl.situationId.equals(situationId) & tbl.isActive.equals(true)))
        .get();
  }

  Future<List<PersonalReminderRow>> findActiveByCategoryIdOnly(String categoryId) {
    return (_db.select(_db.personalReminders)
          ..where((tbl) =>
              tbl.categoryId.equals(categoryId) &
              tbl.situationId.isNull() &
              tbl.isActive.equals(true)))
        .get();
  }

  Future<void> insertRow(PersonalRemindersCompanion companion) {
    return _db.into(_db.personalReminders).insert(companion);
  }

  Future<void> updateRow(PersonalRemindersCompanion companion) {
    return (_db.update(_db.personalReminders)
          ..where((tbl) => tbl.id.equals(companion.id.value)))
        .write(companion);
  }

  Future<void> deleteRow(String id) {
    return (_db.delete(_db.personalReminders)..where((tbl) => tbl.id.equals(id))).go();
  }
}
