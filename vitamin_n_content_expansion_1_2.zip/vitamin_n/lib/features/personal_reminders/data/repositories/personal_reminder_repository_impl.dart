import 'package:drift/drift.dart' show Value;
import 'package:uuid/uuid.dart';

import '../../../../core/database/app_database.dart';
import '../../domain/entities/personal_reminder.dart';
import '../../domain/repositories/personal_reminder_repository.dart';
import '../datasources/personal_reminder_local_data_source.dart';

class PersonalReminderRepositoryImpl implements PersonalReminderRepository {
  PersonalReminderRepositoryImpl(this._dataSource, {Uuid uuid = const Uuid()})
      : _uuid = uuid;

  final PersonalReminderLocalDataSource _dataSource;
  final Uuid _uuid;

  PersonalReminder _toEntity(PersonalReminderRow row) {
    return PersonalReminder(
      id: row.id,
      text: row.reminderText,
      categoryId: row.categoryId,
      situationId: row.situationId,
      isActive: row.isActive,
      createdAt: row.createdAt,
      updatedAt: row.updatedAt,
    );
  }

  @override
  Future<List<PersonalReminder>> getAll() async {
    final rows = await _dataSource.getAllRows();
    return rows.map(_toEntity).toList();
  }

  @override
  Future<PersonalReminder?> getById(String id) async {
    final row = await _dataSource.findRowById(id);
    return row == null ? null : _toEntity(row);
  }

  @override
  Future<List<PersonalReminder>> getActiveBySituationId(String situationId) async {
    final rows = await _dataSource.findActiveBySituationId(situationId);
    return rows.map(_toEntity).toList();
  }

  @override
  Future<List<PersonalReminder>> getActiveByCategoryIdOnly(String categoryId) async {
    final rows = await _dataSource.findActiveByCategoryIdOnly(categoryId);
    return rows.map(_toEntity).toList();
  }

  @override
  Future<PersonalReminder> create({
    required String text,
    String? categoryId,
    String? situationId,
  }) async {
    final DateTime now = DateTime.now();
    final String id = _uuid.v4();
    await _dataSource.insertRow(
      PersonalRemindersCompanion.insert(
        id: id,
        reminderText: text,
        categoryId: Value<String?>(categoryId),
        situationId: Value<String?>(situationId),
        createdAt: now,
        updatedAt: now,
      ),
    );
    return PersonalReminder(
      id: id,
      text: text,
      categoryId: categoryId,
      situationId: situationId,
      isActive: true,
      createdAt: now,
      updatedAt: now,
    );
  }

  @override
  Future<void> update(PersonalReminder reminder) {
    return _dataSource.updateRow(
      PersonalRemindersCompanion(
        id: Value<String>(reminder.id),
        reminderText: Value<String>(reminder.text),
        categoryId: Value<String?>(reminder.categoryId),
        situationId: Value<String?>(reminder.situationId),
        isActive: Value<bool>(reminder.isActive),
        updatedAt: Value<DateTime>(DateTime.now()),
      ),
    );
  }

  @override
  Future<void> setActive(String id, bool isActive) async {
    final PersonalReminderRow? row = await _dataSource.findRowById(id);
    if (row == null) return;
    await _dataSource.updateRow(
      PersonalRemindersCompanion(
        id: Value<String>(id),
        isActive: Value<bool>(isActive),
        updatedAt: Value<DateTime>(DateTime.now()),
      ),
    );
  }

  @override
  Future<void> delete(String id) {
    return _dataSource.deleteRow(id);
  }
}
