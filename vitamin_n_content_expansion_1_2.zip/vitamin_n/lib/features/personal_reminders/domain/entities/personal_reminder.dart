/// A user-authored note — "a note from me to myself for next time" —
/// per Phase 6 section 5. Deliberately NOT a notification, task, or
/// scheduled item: no date/time, no recurrence, nothing beyond plain
/// text and an optional link to a category/situation for context.
///
/// A completely standalone reminder (no category, no situation) is
/// valid — both are nullable. If [situationId] is set, [categoryId]
/// must be the situation's actual category (enforced by
/// [ValidatePersonalReminderPairing], not by this entity itself).
class PersonalReminder {
  const PersonalReminder({
    required this.id,
    required this.text,
    required this.categoryId,
    required this.situationId,
    required this.isActive,
    required this.createdAt,
    required this.updatedAt,
  });

  final String id;
  final String text;
  final String? categoryId;
  final String? situationId;
  final bool isActive;
  final DateTime createdAt;
  final DateTime updatedAt;

  PersonalReminder copyWith({
    String? text,
    String? categoryId,
    bool clearCategoryId = false,
    String? situationId,
    bool clearSituationId = false,
    bool? isActive,
    DateTime? updatedAt,
  }) {
    return PersonalReminder(
      id: id,
      text: text ?? this.text,
      categoryId: clearCategoryId ? null : (categoryId ?? this.categoryId),
      situationId: clearSituationId ? null : (situationId ?? this.situationId),
      isActive: isActive ?? this.isActive,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}

/// A Situation, if selected, must belong to the selected Category —
/// per Phase 6 section 10 ("If Situation is selected, it must
/// correspond to its Category"). Pure validation, no I/O: callers
/// supply the situation's actual category id (already known once a
/// Situation is loaded) rather than this doing any lookup itself.
abstract final class ValidatePersonalReminderPairing {
  static bool isValid({
    required String? categoryId,
    required String? situationId,
    required String? situationsActualCategoryId,
  }) {
    if (situationId == null) {
      // No situation selected — categoryId (present or absent) is
      // always fine on its own.
      return true;
    }
    // A situation was selected: its real category must match.
    return categoryId != null && categoryId == situationsActualCategoryId;
  }
}
