import '../entities/personal_reminder.dart';

abstract class PersonalReminderRepository {
  /// All saved reminders (active and inactive), most recently
  /// updated first.
  Future<List<PersonalReminder>> getAll();

  Future<PersonalReminder?> getById(String id);

  /// The active reminder(s), if any, linked to this exact situation —
  /// used only for the optional contextual-display feature. Exact
  /// match only, never fuzzy.
  Future<List<PersonalReminder>> getActiveBySituationId(String situationId);

  /// The active reminder(s), if any, linked to this exact category
  /// (and with no situation set) — the category-fallback case.
  Future<List<PersonalReminder>> getActiveByCategoryIdOnly(String categoryId);

  Future<PersonalReminder> create({
    required String text,
    String? categoryId,
    String? situationId,
  });

  Future<void> update(PersonalReminder reminder);

  Future<void> setActive(String id, bool isActive);

  Future<void> delete(String id);
}
