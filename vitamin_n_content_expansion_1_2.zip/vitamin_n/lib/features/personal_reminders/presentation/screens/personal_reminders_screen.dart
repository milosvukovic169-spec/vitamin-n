import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../design_system/theme/theme_extensions.dart';
import '../../../../design_system/widgets/primary_button.dart';
import '../../domain/entities/personal_reminder.dart';
import '../providers/personal_reminder_providers.dart';
import '../widgets/personal_reminder_card.dart';
import 'add_edit_personal_reminder_screen.dart';

/// Lists every saved Personal Reminder. A separate, optional feature
/// — reached only from Settings, never part of the active Say No
/// flow (Phase 6 section 3).
class PersonalRemindersScreen extends ConsumerWidget {
  const PersonalRemindersScreen({super.key});

  void _openNew(BuildContext context) {
    Navigator.of(context).push<void>(
      MaterialPageRoute<void>(builder: (_) => const AddEditPersonalReminderScreen()),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppColors colors = context.colors;
    final TextTheme textTheme = Theme.of(context).textTheme;
    final remindersAsync = ref.watch(allPersonalRemindersProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Personal Reminders')),
      body: SafeArea(
        child: remindersAsync.when(
          data: (List<PersonalReminder> reminders) {
            if (reminders.isEmpty) {
              return Center(
                child: Padding(
                  padding: EdgeInsets.all(context.spacing.xl),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      Icon(Icons.eco_outlined, color: colors.sageStrong, size: 28),
                      SizedBox(height: context.spacing.md),
                      Text(
                        'Nothing here yet.',
                        style: textTheme.titleMedium,
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(height: context.spacing.sm),
                      Text(
                        'Save something you want to remember the next time a '
                        'boundary feels difficult.',
                        style: textTheme.bodyMedium,
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(height: context.spacing.lg),
                      PrimaryButton(
                        label: 'New reminder',
                        onPressed: () => _openNew(context),
                      ),
                    ],
                  ),
                ),
              );
            }

            return ListView(
              padding: EdgeInsets.fromLTRB(
                context.spacing.lg,
                context.spacing.lg,
                context.spacing.lg,
                context.spacing.xxl,
              ),
              children: <Widget>[
                Text(
                  'Things you want to remember the next time a boundary '
                  'feels difficult.',
                  style: textTheme.bodyMedium,
                ),
                SizedBox(height: context.spacing.md),
                PrimaryButton(label: 'New reminder', onPressed: () => _openNew(context)),
                SizedBox(height: context.spacing.lg),
                for (final PersonalReminder reminder in reminders)
                  Padding(
                    padding: EdgeInsets.only(bottom: context.spacing.sm),
                    child: PersonalReminderCard(
                      reminder: reminder,
                      onTap: () => Navigator.of(context).push<void>(
                        MaterialPageRoute<void>(
                          builder: (_) =>
                              AddEditPersonalReminderScreen(existing: reminder),
                        ),
                      ),
                    ),
                  ),
              ],
            );
          },
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (Object error, StackTrace stackTrace) => Center(
            child: Text(
              "Couldn't load your reminders. Please try again.",
              style: textTheme.bodyMedium,
            ),
          ),
        ),
      ),
    );
  }
}
