import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/database/app_database_provider.dart';
import '../../data/datasources/personal_reminder_local_data_source.dart';
import '../../data/repositories/personal_reminder_repository_impl.dart';
import '../../domain/entities/personal_reminder.dart';
import '../../domain/repositories/personal_reminder_repository.dart';

final Provider<PersonalReminderRepository> personalReminderRepositoryProvider =
    Provider<PersonalReminderRepository>((Ref ref) {
  final db = ref.watch(appDatabaseProvider);
  return PersonalReminderRepositoryImpl(PersonalReminderLocalDataSource(db));
});

final FutureProvider<List<PersonalReminder>> allPersonalRemindersProvider =
    FutureProvider<List<PersonalReminder>>((Ref ref) {
  return ref.watch(personalReminderRepositoryProvider).getAll();
});

/// Optional contextual display support (Phase 6 section 14): the
/// active reminder(s) for an exact situation match, falling back to
/// an exact category-only match if none exists. Not currently wired
/// into the Say No flow — see the Phase 6 report for why.
final FutureProviderFamily<List<PersonalReminder>, ({String categoryId, String situationId})>
    contextualPersonalRemindersProvider = FutureProvider.family<List<PersonalReminder>,
        ({String categoryId, String situationId})>((Ref ref, key) async {
  final PersonalReminderRepository repo = ref.watch(personalReminderRepositoryProvider);
  final List<PersonalReminder> exact = await repo.getActiveBySituationId(key.situationId);
  if (exact.isNotEmpty) return exact;
  return repo.getActiveByCategoryIdOnly(key.categoryId);
});
