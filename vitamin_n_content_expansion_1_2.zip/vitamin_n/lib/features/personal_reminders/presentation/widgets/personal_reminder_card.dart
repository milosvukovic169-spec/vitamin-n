import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../design_system/theme/theme_extensions.dart';
import '../../../../design_system/widgets/app_card.dart';
import '../../../categories/domain/entities/category.dart';
import '../../../categories/presentation/providers/category_providers.dart';
import '../../domain/entities/personal_reminder.dart';

/// One saved reminder in the list. Shows its optional category
/// context (never the full situation lookup here — that's only
/// needed on the edit screen) and whether it's active, per the
/// accessibility requirement that active/inactive isn't communicated
/// by color alone.
class PersonalReminderCard extends ConsumerWidget {
  const PersonalReminderCard({super.key, required this.reminder, required this.onTap});

  final PersonalReminder reminder;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppColors colors = context.colors;
    final TextTheme textTheme = Theme.of(context).textTheme;
    final String? categoryId = reminder.categoryId;
    final Category? category =
        categoryId == null ? null : ref.watch(categoryByIdProvider(categoryId)).value;

    return Semantics(
      button: true,
      label: reminder.isActive
          ? '${reminder.text}. Active.'
          : '${reminder.text}. Inactive.',
      child: AppCard(
        onTap: onTap,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            if (category != null) ...<Widget>[
              Text(category.name, style: textTheme.bodySmall),
              SizedBox(height: context.spacing.xs / 2),
            ],
            Text(
              reminder.text,
              style: textTheme.titleSmall?.copyWith(
                color: reminder.isActive ? null : colors.textSecondary,
              ),
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
            ),
            if (!reminder.isActive) ...<Widget>[
              SizedBox(height: context.spacing.xs),
              Row(
                children: <Widget>[
                  Icon(Icons.pause_circle_outline, size: 14, color: colors.textSecondary),
                  SizedBox(width: context.spacing.xs / 2),
                  Text('Inactive', style: textTheme.bodySmall),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}
