/// The outcome of a single purchase or restore attempt, as reported
/// by the store. Deliberately doesn't carry the raw store
/// exception/response — see [PurchaseUpdate.errorMessage], which is
/// Vitamin N's own calm, pre-written copy, never a passed-through SDK
/// message (Phase 7 section 14/42).
enum PurchaseOutcome { pending, success, cancelled, error }

class PurchaseUpdate {
  const PurchaseUpdate({
    required this.productId,
    required this.outcome,
    this.errorMessage,
  });

  final String productId;
  final PurchaseOutcome outcome;

  /// Calm, user-safe copy — never a raw billing response code, stack
  /// trace, or SDK message. Null unless [outcome] is
  /// [PurchaseOutcome.error].
  final String? errorMessage;
}

/// The outcome of a Restore Purchases attempt.
enum RestoreOutcome { inProgress, completed, foundNothing, error }
