/// The single, centralized source of truth for Vitamin N's store
/// product identifiers (Phase 7 section 4). Every place that needs a
/// product id — the offerings list, the billing repository, tests —
/// references these constants rather than a hardcoded string, so
/// changing a Play Console / App Store Connect identifier is a
/// one-line change.
///
/// Exactly two products exist: Monthly and Yearly Vitamin N Premium.
/// Both unlock the same single entitlement — see [PremiumStatus].
abstract final class BillingProductIds {
  static const String monthly = 'vitamin_n_premium_monthly';
  static const String yearly = 'vitamin_n_premium_yearly';

  static const Set<String> all = <String>{monthly, yearly};
}
