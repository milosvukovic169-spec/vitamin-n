/// The recurring billing period a [PremiumOffering] represents. Phase
/// 7 will map these to real store products; Phase 6 only needs the
/// shape to exist.
enum BillingPeriod { monthly, yearly }

/// A prepared, not-yet-connected billing offering — the presentation
/// abstraction Phase 6 section 23 asks for, ready to later receive
/// real values from a billing service without any UI rewrite.
///
/// [localizedPrice] is null until a real store is connected — that is
/// deliberately the "safe non-purchase state" the spec requires:
/// there is no fake or hardcoded price anywhere in this app. The
/// Premium screen renders "Pricing coming soon" whenever this is
/// null, and never shows an enabled purchase button in that case.
class PremiumOffering {
  const PremiumOffering({
    required this.productId,
    required this.billingPeriod,
    this.localizedPrice,
  });

  final String productId;
  final BillingPeriod billingPeriod;
  final String? localizedPrice;

  bool get isPurchasable => localizedPrice != null;
}
