/// The shape of "is the user premium" — deliberately minimal.
///
/// [PremiumTier.unknown] exists specifically for Phase 7 section 8/18:
/// while entitlement is still resolving (app just started, store
/// query in flight), the app should not flash "locked" and then
/// "unlocked" content — [unknown] lets gating code choose to wait
/// rather than briefly assume [free]. `isPremium` is false for
/// [unknown] too, so nothing that only checks `isPremium` needs to
/// change; only UI that wants to specifically avoid a flash of
/// content needs to check the tier directly.
enum PremiumTier { unknown, free, premium }

class PremiumStatus {
  const PremiumStatus({required this.tier});

  final PremiumTier tier;

  bool get isPremium => tier == PremiumTier.premium;
  bool get isResolving => tier == PremiumTier.unknown;

  static const PremiumStatus unknown = PremiumStatus(tier: PremiumTier.unknown);
  static const PremiumStatus free = PremiumStatus(tier: PremiumTier.free);
  static const PremiumStatus premium = PremiumStatus(tier: PremiumTier.premium);
}
