import '../entities/premium_offering.dart';
import '../entities/premium_status.dart';
import '../entities/purchase_update.dart';

/// The one place store-specific logic is allowed to live (Phase 7
/// section 5). Premium UI and Premium gating never call a store SDK
/// directly — they depend on this interface (or, for entitlement,
/// on [PremiumRepository], whose real implementation is built on top
/// of this one).
abstract class BillingRepository {
  /// Queries the store for Monthly/Yearly product metadata. Returns
  /// offerings with a null [PremiumOffering.localizedPrice] for any
  /// product the store couldn't resolve — never a fabricated price.
  Future<List<PremiumOffering>> loadProducts();

  /// Starts a purchase for [productId]. Completion/failure is
  /// reported asynchronously via [watchPurchaseUpdates] — the store's
  /// purchase flow is not necessarily synchronous.
  Future<void> purchase(String productId);

  Future<void> restorePurchases();

  /// Fires for every purchase/restore state change the store reports
  /// for the lifetime of this repository.
  Stream<PurchaseUpdate> watchPurchaseUpdates();

  /// Re-derives entitlement from the store's current purchase state
  /// (e.g. after a successful purchase, on app resume, or on demand
  /// from Settings). This is the authoritative source — see Phase 7
  /// section 16.
  Future<PremiumStatus> refreshEntitlement();

  Future<void> dispose();
}
