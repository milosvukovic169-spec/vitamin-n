import '../entities/premium_offering.dart';

/// Extension point for the billing offerings shown on the Premium
/// screen. Phase 6 only ships [StubPremiumOfferingsRepository] (no
/// prices, nothing purchasable); Phase 7 replaces the data source
/// with a real store connection behind this same interface — the
/// Premium screen itself never changes.
abstract class PremiumOfferingsRepository {
  Future<List<PremiumOffering>> getOfferings();
}
