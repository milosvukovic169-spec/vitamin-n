import '../entities/premium_status.dart';

/// The one canonical entitlement abstraction (Phase 7 section 8/25).
/// Real billing lives behind `BillingBackedPremiumRepository` in
/// production; `StubPremiumRepository` remains available as a
/// harmless always-Free fallback. Every feature that gates *extra*
/// content (never core functionality) behind premium depends on this
/// abstraction, never on a store SDK directly.
abstract class PremiumRepository {
  Future<PremiumStatus> getStatus();
  Stream<PremiumStatus> watchStatus();

  /// Re-derives entitlement from the underlying source right now
  /// (rather than waiting for the next reactive update) — used on
  /// app resume so an expired/revoked subscription is eventually
  /// caught even if the app was simply left open, not restarted.
  Future<PremiumStatus> refreshEntitlement();
}
