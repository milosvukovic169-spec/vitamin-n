import 'package:flutter/material.dart';

import '../../../../design_system/theme/theme_extensions.dart';
import '../../../../design_system/widgets/app_card.dart';

/// A calm, non-pressuring prompt pointing toward the Premium screen.
///
/// Per the Copywriting Rules, this must never use urgency, pressure or
/// gamified language ("Unlock now!", countdowns) — it simply offers
/// richer content to those who want it. [onTap] should navigate to
/// the Premium screen; no purchase or entitlement logic lives here.
class PremiumBanner extends StatelessWidget {
  const PremiumBanner({
    super.key,
    required this.onTap,
    this.message = 'Richer content is available with Premium.',
  });

  final VoidCallback onTap;
  final String message;

  @override
  Widget build(BuildContext context) {
    return AppCard(
      onTap: onTap,
      backgroundColor: context.colors.cream,
      child: Row(
        children: <Widget>[
          Expanded(
            child: Text(message, style: Theme.of(context).textTheme.bodyMedium),
          ),
          SizedBox(width: context.spacing.sm),
          Icon(Icons.arrow_forward, size: 18, color: context.colors.sageStrong),
        ],
      ),
    );
  }
}
