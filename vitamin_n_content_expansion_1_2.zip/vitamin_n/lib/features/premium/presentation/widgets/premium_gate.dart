import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../domain/entities/premium_status.dart';
import '../providers/premium_providers.dart';

/// Wraps content that should only be reachable by premium users.
///
/// Per the product rule "Premium unlocks richer content, never basic
/// functionality", this must only ever gate *extra* content (e.g. an
/// expanded set of reality reminders) — never a core flow step. The
/// locked Say No flow must remain fully usable regardless of premium
/// status.
///
/// Since [premiumStatusProvider] currently always resolves to free,
/// [locked] renders for everyone today — that's expected until real
/// billing lands.
class PremiumGate extends ConsumerWidget {
  const PremiumGate({super.key, required this.unlocked, required this.locked});

  final Widget unlocked;
  final Widget locked;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AsyncValue<PremiumStatus> status = ref.watch(premiumStatusProvider);

    return status.when(
      data: (PremiumStatus value) => value.isPremium ? unlocked : locked,
      loading: () => const SizedBox.shrink(),
      error: (Object error, StackTrace stackTrace) => locked,
    );
  }
}
