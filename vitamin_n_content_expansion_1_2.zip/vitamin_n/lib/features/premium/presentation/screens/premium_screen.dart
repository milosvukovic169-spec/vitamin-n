import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/analytics/analytics_providers.dart';
import '../../../../core/analytics/analytics_service.dart';
import '../../../../design_system/theme/theme_extensions.dart';
import '../../../../design_system/widgets/app_card.dart';
import '../../../../design_system/widgets/primary_button.dart';
import '../../domain/entities/premium_offering.dart';
import '../../domain/entities/premium_status.dart';
import '../controllers/purchase_flow_controller.dart';
import '../controllers/purchase_flow_state.dart';
import '../providers/premium_providers.dart';

const List<(IconData, String, String)> _benefits = <(IconData, String, String)>[
  (
    Icons.grid_view_outlined,
    'All boundary categories',
    'Explore Work, Relationships, Availability, Favors, Listening & '
        'Support and more.',
  ),
  (
    Icons.forum_outlined,
    'More ways to say No',
    'Choose wording that feels natural — balanced, concise, direct or warm.',
  ),
  (
    Icons.eco_outlined,
    'Reality Reminders',
    'See what can gradually happen when a boundary is not protected.',
  ),
  (
    Icons.checklist_outlined,
    'Challenges',
    'Explore guided boundary themes at your own pace.',
  ),
];

/// The single, canonical Vitamin N Premium screen — per section 19,
/// every Premium teaser in the app routes here, and nowhere else.
/// [entryPoint] records WHICH restriction sent the user here
/// (section 32) — never screen text, just a controlled enum.
///
/// Visual design preserved unchanged from Phase 6 (section 19 of this
/// phase); only the offerings/purchase area now reflects real store
/// state instead of the Phase 6 placeholder.
class PremiumScreen extends ConsumerStatefulWidget {
  const PremiumScreen({super.key, this.entryPoint = PremiumEntryPoint.settings});

  final PremiumEntryPoint entryPoint;

  @override
  ConsumerState<PremiumScreen> createState() => _PremiumScreenState();
}

class _PremiumScreenState extends ConsumerState<PremiumScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref
          .read(analyticsServiceProvider)
          .premiumScreenViewed(entryPoint: widget.entryPoint);
    });
  }

  @override
  Widget build(BuildContext context) {
    final AppColors colors = context.colors;
    final TextTheme textTheme = Theme.of(context).textTheme;
    final PremiumStatus status =
        ref.watch(premiumStatusProvider).valueOrNull ?? PremiumStatus.unknown;

    return Scaffold(
      appBar: AppBar(title: const Text('Vitamin N Premium')),
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.all(context.spacing.lg),
          children: <Widget>[
            Center(
              child: Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(shape: BoxShape.circle, color: colors.cream),
                child: Icon(Icons.spa, color: colors.sageStrong, size: 28),
              ),
            ),
            SizedBox(height: context.spacing.md),
            Text(
              'Vitamin N Premium',
              style: textTheme.headlineMedium,
              textAlign: TextAlign.center,
            ),
            SizedBox(height: context.spacing.xs),
            Text(
              'More situations. More ways to say No. More context for why '
              'the boundary matters.',
              style: textTheme.bodyMedium,
              textAlign: TextAlign.center,
            ),
            SizedBox(height: context.spacing.xl),
            for (final (IconData icon, String title, String body) in _benefits)
              Padding(
                padding: EdgeInsets.only(bottom: context.spacing.sm),
                child: AppCard(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Icon(icon, color: colors.sageStrong, size: 22),
                      SizedBox(width: context.spacing.md),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(title, style: textTheme.titleSmall),
                            SizedBox(height: context.spacing.xs / 2),
                            Text(body, style: textTheme.bodyMedium),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            SizedBox(height: context.spacing.lg),
            if (status.isPremium)
              const _AlreadyPremiumCard()
            else
              const _PurchaseArea(),
          ],
        ),
      ),
    );
  }
}

class _AlreadyPremiumCard extends StatelessWidget {
  const _AlreadyPremiumCard();

  @override
  Widget build(BuildContext context) {
    final AppColors colors = context.colors;
    final TextTheme textTheme = Theme.of(context).textTheme;

    return AppCard(
      backgroundColor: colors.cream,
      child: Row(
        children: <Widget>[
          Icon(Icons.check_circle, color: colors.sageStrong, size: 22),
          SizedBox(width: context.spacing.md),
          Expanded(
            child: Text(
              'You have Vitamin N Premium.',
              style: textTheme.titleSmall,
            ),
          ),
        ],
      ),
    );
  }
}

class _PurchaseArea extends ConsumerWidget {
  const _PurchaseArea();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final TextTheme textTheme = Theme.of(context).textTheme;
    final AsyncValue<List<PremiumOffering>> offeringsAsync =
        ref.watch(premiumOfferingsProvider);
    final PurchaseFlowState flow = ref.watch(purchaseFlowControllerProvider);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        offeringsAsync.when(
          data: (List<PremiumOffering> offerings) {
            if (offerings.isEmpty) {
              return _UnavailablePlans(
                onRetry: () => ref.invalidate(premiumOfferingsProvider),
              );
            }
            return _OfferingsRow(
              offerings: offerings,
              selectedPlan: flow.selectedPlan,
              onSelect: (BillingPeriod period) =>
                  ref.read(purchaseFlowControllerProvider.notifier).selectPlan(period),
            );
          },
          loading: () => const Padding(
            padding: EdgeInsets.symmetric(vertical: 24),
            child: Center(child: CircularProgressIndicator()),
          ),
          error: (Object error, StackTrace stackTrace) => _UnavailablePlans(
            onRetry: () => ref.invalidate(premiumOfferingsProvider),
          ),
        ),
        SizedBox(height: context.spacing.md),
        _StatusBanner(flow: flow),
        SizedBox(height: context.spacing.md),
        PrimaryButton(
          label: flow.status == PurchaseFlowStatus.purchasing ? 'Purchasing…' : 'Continue',
          loading: flow.status == PurchaseFlowStatus.purchasing,
          onPressed: _canPurchase(offeringsAsync, flow)
              ? () => ref.read(purchaseFlowControllerProvider.notifier).purchase()
              : null,
        ),
        SizedBox(height: context.spacing.md),
        _RenewalDisclosure(offeringsAsync: offeringsAsync, selectedPlan: flow.selectedPlan),
        SizedBox(height: context.spacing.md),
        Center(
          child: TextButton(
            onPressed: flow.isBusy
                ? null
                : () => ref.read(purchaseFlowControllerProvider.notifier).restore(),
            child: Text(
              flow.status == PurchaseFlowStatus.restoring
                  ? 'Checking for previous purchases…'
                  : 'Restore purchases',
              style: textTheme.labelMedium,
            ),
          ),
        ),
      ],
    );
  }

  bool _canPurchase(
    AsyncValue<List<PremiumOffering>> offeringsAsync,
    PurchaseFlowState flow,
  ) {
    if (flow.isBusy || flow.selectedPlan == null) return false;
    final List<PremiumOffering>? offerings = offeringsAsync.valueOrNull;
    if (offerings == null || offerings.isEmpty) return false;
    final PremiumOffering? selected = offerings
        .where((PremiumOffering o) => o.billingPeriod == flow.selectedPlan)
        .firstOrNull;
    // Section 22: purchase button only actionable once product
    // metadata genuinely exists.
    return selected != null && selected.isPurchasable;
  }
}

/// Calm, non-alarming status copy for pending/cancelled/error/restore
/// states (sections 12–15). Idle and completed states render nothing
/// here — a completed purchase is reflected by the whole screen
/// switching to [_AlreadyPremiumCard] once entitlement refreshes.
class _StatusBanner extends StatelessWidget {
  const _StatusBanner({required this.flow});

  final PurchaseFlowState flow;

  @override
  Widget build(BuildContext context) {
    final TextTheme textTheme = Theme.of(context).textTheme;
    final AppColors colors = context.colors;

    final (String?, String?) copy = switch (flow.status) {
      PurchaseFlowStatus.purchasing => (
          'Purchase pending',
          'Your store is still processing this purchase.',
        ),
      PurchaseFlowStatus.purchaseCancelled => (null, null), // no alarming copy — section 13
      PurchaseFlowStatus.purchaseError => (
          "We couldn't complete the purchase.",
          'Please try again.',
        ),
      PurchaseFlowStatus.restoreEmpty => (
          'No purchases found',
          "We couldn't find an active Vitamin N Premium purchase for this store account.",
        ),
      PurchaseFlowStatus.restoreError => (
          "Couldn't check for purchases right now.",
          'Please try again.',
        ),
      _ => (null, null),
    };

    final String? title = copy.$1;
    if (title == null) return const SizedBox.shrink();

    return AppCard(
      backgroundColor: colors.cream,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(title, style: textTheme.titleSmall),
          if (copy.$2 != null) ...<Widget>[
            SizedBox(height: context.spacing.xs),
            Text(copy.$2!, style: textTheme.bodyMedium),
          ],
        ],
      ),
    );
  }
}

/// Calm, non-deceptive auto-renewal disclosure — required by the
/// locked subscription renewal model: both plans are Google Play
/// auto-renewing subscriptions, and the terms must never be hidden.
/// Uses the actual selected offering's localized price/period once a
/// plan is chosen; falls back to a plan-agnostic statement before that.
class _RenewalDisclosure extends StatelessWidget {
  const _RenewalDisclosure({required this.offeringsAsync, required this.selectedPlan});

  final AsyncValue<List<PremiumOffering>> offeringsAsync;
  final BillingPeriod? selectedPlan;

  @override
  Widget build(BuildContext context) {
    final TextTheme textTheme = Theme.of(context).textTheme;
    final List<PremiumOffering> offerings = offeringsAsync.valueOrNull ?? const <PremiumOffering>[];
    final PremiumOffering? selected = selectedPlan == null
        ? null
        : offerings.where((PremiumOffering o) => o.billingPeriod == selectedPlan).firstOrNull;

    final String text;
    if (selected != null && selected.isPurchasable) {
      final String period = selected.billingPeriod == BillingPeriod.monthly ? 'month' : 'year';
      text = '${selected.billingPeriod == BillingPeriod.monthly ? 'Monthly' : 'Yearly'} '
          'renews automatically at ${selected.localizedPrice}/$period until cancelled. '
          'Manage or cancel anytime in Google Play.';
    } else {
      text = 'Monthly and Yearly plans renew automatically at the plan price until '
          'cancelled. Manage or cancel anytime in Google Play.';
    }

    return Text(text, style: textTheme.bodySmall, textAlign: TextAlign.center);
  }
}

class _UnavailablePlans extends StatelessWidget {
  const _UnavailablePlans({required this.onRetry});

  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    final TextTheme textTheme = Theme.of(context).textTheme;

    // Section 21: never a fake fallback price — a retryable
    // unavailable state instead.
    return AppCard(
      backgroundColor: context.colors.cream,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text('Plans are temporarily unavailable.', style: textTheme.titleSmall),
          SizedBox(height: context.spacing.sm),
          Align(
            alignment: Alignment.centerLeft,
            child: TextButton(onPressed: onRetry, child: const Text('Try again')),
          ),
        ],
      ),
    );
  }
}

class _OfferingsRow extends StatelessWidget {
  const _OfferingsRow({
    required this.offerings,
    required this.selectedPlan,
    required this.onSelect,
  });

  final List<PremiumOffering> offerings;
  final BillingPeriod? selectedPlan;
  final ValueChanged<BillingPeriod> onSelect;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        for (final PremiumOffering offering in offerings)
          Expanded(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: context.spacing.xs),
              child: _OfferingCard(
                offering: offering,
                selected: offering.billingPeriod == selectedPlan,
                onTap: () => onSelect(offering.billingPeriod),
              ),
            ),
          ),
      ],
    );
  }
}

class _OfferingCard extends StatelessWidget {
  const _OfferingCard({
    required this.offering,
    required this.selected,
    required this.onTap,
  });

  final PremiumOffering offering;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final AppColors colors = context.colors;
    final TextTheme textTheme = Theme.of(context).textTheme;
    final bool isYearly = offering.billingPeriod == BillingPeriod.yearly;
    final String label = isYearly ? 'Yearly' : 'Monthly';

    // No working purchase button while there is no real price —
    // per section 21/23, a disabled state is the only safe option.
    return Semantics(
      button: true,
      selected: selected,
      label: isYearly ? '$label, Best value' : label,
      child: Opacity(
        opacity: offering.isPurchasable ? 1 : 0.6,
        child: AppCard(
          backgroundColor: selected ? colors.sage.withValues(alpha: 0.18) : colors.cream,
          onTap: offering.isPurchasable ? onTap : null,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Row(
                children: <Widget>[
                  Expanded(child: Text(label, style: textTheme.titleSmall)),
                  if (selected)
                    Icon(Icons.check_circle, size: 18, color: colors.sageStrong),
                ],
              ),
              if (isYearly) ...<Widget>[
                SizedBox(height: context.spacing.xs / 2),
                Container(
                  padding: EdgeInsets.symmetric(
                    horizontal: context.spacing.xs,
                    vertical: 2,
                  ),
                  decoration: BoxDecoration(
                    color: colors.sageStrong,
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Text(
                    'Best value',
                    style: textTheme.labelSmall?.copyWith(color: colors.textOnSage),
                  ),
                ),
              ],
              SizedBox(height: context.spacing.xs),
              Text(
                offering.localizedPrice ?? 'Pricing coming soon',
                style: textTheme.bodyMedium,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
