import '../../domain/entities/premium_offering.dart';

enum PurchaseFlowStatus {
  idle,
  purchasing,
  purchaseCompleted,
  purchaseCancelled,
  purchaseError,
  restoring,
  restoreCompleted,
  restoreEmpty,
  restoreError,
}

class PurchaseFlowState {
  const PurchaseFlowState({
    this.selectedPlan,
    this.status = PurchaseFlowStatus.idle,
    this.errorMessage,
  });

  final BillingPeriod? selectedPlan;
  final PurchaseFlowStatus status;
  final String? errorMessage;

  bool get isBusy =>
      status == PurchaseFlowStatus.purchasing || status == PurchaseFlowStatus.restoring;

  PurchaseFlowState copyWith({
    BillingPeriod? selectedPlan,
    PurchaseFlowStatus? status,
    String? errorMessage,
    bool clearError = false,
  }) {
    return PurchaseFlowState(
      selectedPlan: selectedPlan ?? this.selectedPlan,
      status: status ?? this.status,
      errorMessage: clearError ? null : (errorMessage ?? this.errorMessage),
    );
  }
}
