import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/analytics/analytics_providers.dart';
import '../../../../core/analytics/analytics_service.dart';
import '../../domain/entities/billing_product_ids.dart';
import '../../domain/entities/premium_offering.dart';
import '../../domain/entities/purchase_update.dart';
import '../../domain/repositories/billing_repository.dart';
import '../providers/premium_providers.dart';
import 'purchase_flow_state.dart';

/// Drives the Premium screen's purchase/restore interaction — plan
/// selection, the purchase button, and Restore purchases. Reacts to
/// [BillingRepository.watchPurchaseUpdates] so a purchase completed
/// or cancelled outside this controller's own call (e.g. a purchase
/// that was already pending from a previous app session) still
/// updates the UI.
class PurchaseFlowController extends Notifier<PurchaseFlowState> {
  @override
  PurchaseFlowState build() {
    final BillingRepository billing = ref.watch(billingRepositoryProvider);
    final StreamSubscription<PurchaseUpdate> sub =
        billing.watchPurchaseUpdates().listen(_handleUpdate);
    ref.onDispose(sub.cancel);
    return const PurchaseFlowState();
  }

  void selectPlan(BillingPeriod period) {
    state = state.copyWith(selectedPlan: period);
    unawaited(ref.read(analyticsServiceProvider).premiumPlanSelected(
          planType: _planTypeFor(period),
        ));
  }

  PlanType _planTypeFor(BillingPeriod period) =>
      period == BillingPeriod.monthly ? PlanType.monthly : PlanType.yearly;

  String _productIdFor(BillingPeriod period) {
    return period == BillingPeriod.monthly
        ? BillingProductIds.monthly
        : BillingProductIds.yearly;
  }

  /// Starts a purchase for the currently selected plan. A no-op if no
  /// plan is selected or a purchase/restore is already in flight —
  /// the double-tap protection section 22 asks for.
  Future<void> purchase() async {
    final BillingPeriod? period = state.selectedPlan;
    if (period == null || state.isBusy) return;

    state = state.copyWith(status: PurchaseFlowStatus.purchasing, clearError: true);
    unawaited(ref.read(analyticsServiceProvider).purchaseStarted(
          planType: _planTypeFor(period),
        ));
    try {
      await ref.read(billingRepositoryProvider).purchase(_productIdFor(period));
    } catch (_) {
      // The repository already catches its own expected failure
      // modes and reports them via watchPurchaseUpdates() instead of
      // throwing — this is a second layer of defense against any
      // other unanticipated exception, so there is no remaining path
      // to a permanently stuck "purchasing" state.
      state = state.copyWith(
        status: PurchaseFlowStatus.purchaseError,
        errorMessage: "We couldn't complete the purchase.",
      );
    }
  }

  /// Restores prior purchases. Reports [PurchaseFlowStatus.restoreEmpty]
  /// if nothing was found within a bounded window — the store's
  /// purchase stream has no explicit "nothing to restore" signal, so
  /// a short, deliberate wait is the standard way to distinguish
  /// "still checking" from "confirmed nothing found".
  Future<void> restore() async {
    if (state.isBusy) return;

    state = state.copyWith(status: PurchaseFlowStatus.restoring, clearError: true);
    final AnalyticsService analytics = ref.read(analyticsServiceProvider);
    unawaited(analytics.restoreStarted());

    try {
      await ref.read(billingRepositoryProvider).restorePurchases();
    } catch (_) {
      // Without this, a failure here (offline, store unavailable, any
      // SDK-level exception) would leave state stuck on "restoring"
      // forever — the UI shows "Checking for previous purchases…"
      // with no way back to usable, since this provider is not
      // autoDispose and nothing else would ever reset it.
      state = state.copyWith(
        status: PurchaseFlowStatus.restoreError,
        errorMessage: "Couldn't check for purchases right now. Please try again.",
      );
      return;
    }

    await Future<void>.delayed(const Duration(seconds: 2));
    if (state.status == PurchaseFlowStatus.restoring) {
      state = state.copyWith(status: PurchaseFlowStatus.restoreEmpty);
      unawaited(analytics.restoreNoPurchaseFound());
    }
  }

  void _handleUpdate(PurchaseUpdate update) {
    final AnalyticsService analytics = ref.read(analyticsServiceProvider);
    final PlanType planType = update.productId == BillingProductIds.yearly
        ? PlanType.yearly
        : PlanType.monthly;
    final bool wasRestoring = state.status == PurchaseFlowStatus.restoring;

    switch (update.outcome) {
      case PurchaseOutcome.pending:
        state = state.copyWith(status: PurchaseFlowStatus.purchasing);
      case PurchaseOutcome.success:
        state = state.copyWith(
          status: wasRestoring
              ? PurchaseFlowStatus.restoreCompleted
              : PurchaseFlowStatus.purchaseCompleted,
        );
        if (wasRestoring) {
          unawaited(analytics.restoreCompleted());
        } else {
          unawaited(analytics.purchaseCompleted(planType: planType));
        }
      case PurchaseOutcome.cancelled:
        state = state.copyWith(status: PurchaseFlowStatus.purchaseCancelled);
        unawaited(analytics.purchaseCancelled(planType: planType));
      case PurchaseOutcome.error:
        state = state.copyWith(
          status: PurchaseFlowStatus.purchaseError,
          errorMessage: update.errorMessage ?? "We couldn't complete the purchase.",
        );
        unawaited(analytics.purchaseFailed(planType: planType));
    }
  }
}

final NotifierProvider<PurchaseFlowController, PurchaseFlowState> purchaseFlowControllerProvider =
    NotifierProvider<PurchaseFlowController, PurchaseFlowState>(PurchaseFlowController.new);
