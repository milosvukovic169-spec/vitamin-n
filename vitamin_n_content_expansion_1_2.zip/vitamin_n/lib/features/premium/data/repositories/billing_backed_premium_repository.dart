import 'dart:async';

import '../../../settings/domain/repositories/settings_repository.dart';
import '../../domain/entities/premium_status.dart';
import '../../domain/entities/purchase_update.dart';
import '../../domain/repositories/billing_repository.dart';
import '../../domain/repositories/premium_repository.dart';

/// The real [PremiumRepository], driven by a [BillingRepository]
/// rather than always reporting Free (see StubPremiumRepository for
/// the Phase 6 placeholder this replaces in production).
///
/// Offline/caching strategy (Phase 7 section 16/17): on
/// [initialize], the last known entitlement is read from Settings and
/// emitted immediately, so a Premium user briefly offline at app
/// start doesn't see Free content flash before Premium — but the
/// cache is never treated as final. A fresh [BillingRepository]
/// refresh always follows, and the store's answer overwrites the
/// cache and is what every later [watchStatus] emission reflects.
/// There is no path by which a stale cached `true` can persist
/// indefinitely without ever being re-checked against the store.
class BillingBackedPremiumRepository implements PremiumRepository {
  BillingBackedPremiumRepository(this._billing, this._settings);

  final BillingRepository _billing;
  final SettingsRepository _settings;

  final StreamController<PremiumStatus> _controller =
      StreamController<PremiumStatus>.broadcast();
  StreamSubscription<PurchaseUpdate>? _purchaseSub;
  PremiumStatus _current = PremiumStatus.unknown;
  bool _initialized = false;

  /// Must be called once before this repository is used — normally
  /// from the provider that constructs it. Deliberately not done in
  /// the constructor so it can run asynchronously without blocking
  /// app startup (section 18: billing init must not block Home).
  Future<void> initialize() async {
    if (_initialized) return;
    _initialized = true;

    final bool cachedIsPremium =
        await _settings.getBool(SettingsKeys.cachedPremiumEntitlement);
    _emit(cachedIsPremium ? PremiumStatus.premium : PremiumStatus.unknown);

    _purchaseSub = _billing.watchPurchaseUpdates().listen((PurchaseUpdate update) {
      if (update.outcome == PurchaseOutcome.success) {
        // A successful purchase or restore for either product
        // unlocks the same single entitlement (section 8) — react
        // directly rather than calling refreshEntitlement() again,
        // which for the real implementation would re-trigger
        // restorePurchases() and risk looping back through this same
        // stream.
        unawaited(_settings.setBool(SettingsKeys.cachedPremiumEntitlement, true));
        _emit(PremiumStatus.premium);
      }
    });

    // Awaited deliberately, NOT fire-and-forget: this method is
    // already called unawaited by the provider that constructs this
    // repository (see premium_providers.dart), so awaiting here does
    // not block app startup. What it DOES do is make this
    // repository's own internal sequencing deterministic — the
    // earlier version fired this unawaited from inside an already-
    // unawaited method, which meant the initial refresh could resolve
    // at an unpredictable time relative to whatever happened next
    // (e.g. a purchase completing, or a later explicit
    // refreshEntitlement() call), occasionally letting a stale result
    // overwrite a fresher one. Awaiting it removes that race entirely.
    await refreshEntitlement();
  }

  void _emit(PremiumStatus status) {
    _current = status;
    if (!_controller.isClosed) {
      _controller.add(status);
    }
  }

  @override
  Future<PremiumStatus> getStatus() async => _current;

  @override
  Stream<PremiumStatus> watchStatus() => _controller.stream;

  @override
  Future<PremiumStatus> refreshEntitlement() async {
    try {
      final PremiumStatus resolved = await _billing.refreshEntitlement();
      // A definite Free or Premium answer updates cache/emits
      // normally. PremiumTier.unknown is reserved for genuine
      // failures (offline, store unavailable) — see
      // InAppPurchaseBillingRepository.refreshEntitlement() /
      // resolveEntitlementViaRestore() for exactly when that happens;
      // it is deliberately never cached or emitted as if it were an
      // authoritative Free.
      if (resolved.tier != PremiumTier.unknown) {
        await _settings.setBool(SettingsKeys.cachedPremiumEntitlement, resolved.isPremium);
        _emit(resolved);
      }
      return resolved;
    } catch (_) {
      // A transient/offline failure must not force a Premium user
      // down to Free — keep whatever was last emitted (cached value
      // or previous resolution) rather than assuming Free.
      return _current;
    }
  }

  Future<void> dispose() async {
    await _purchaseSub?.cancel();
    await _controller.close();
  }
}
