import 'dart:async';

import '../../domain/entities/billing_product_ids.dart';
import '../../domain/entities/premium_offering.dart';
import '../../domain/entities/premium_status.dart';
import '../../domain/entities/purchase_update.dart';
import '../../domain/repositories/billing_repository.dart';

/// A fully controllable, deterministic [BillingRepository] for tests
/// (Phase 7 section 35). No real store call is ever made. Every
/// scenario the spec asks to test is directly triggerable:
/// product load, successful purchase, cancellation, pending, failure,
/// restore success, restore-empty, and entitlement expiry.
class FakeBillingRepository implements BillingRepository {
  FakeBillingRepository({
    this.productsAvailable = true,
    this.localizedPrices = const <String, String>{
      BillingProductIds.monthly: '€3.99',
      BillingProductIds.yearly: '€24.99',
    },
    this.throwOnPurchase = false,
    this.throwOnRestore = false,
  });

  /// Set to false to simulate "store unavailable" (section 11) — no
  /// products load.
  bool productsAvailable;

  /// Product id -> localized price string this fake reports. Empty or
  /// missing entries simulate "missing product metadata" (section 36).
  Map<String, String> localizedPrices;

  /// Simulates purchase()/restorePurchases() throwing outright (e.g.
  /// a store-level exception before any purchase stream event could
  /// ever arrive) — the exact scenario the billing audit's stuck-state
  /// fixes exist for.
  bool throwOnPurchase;
  bool throwOnRestore;

  final StreamController<PurchaseUpdate> _updates =
      StreamController<PurchaseUpdate>.broadcast();
  PremiumStatus _entitlement = PremiumStatus.free;
  bool _purchasePending = false;
  int purchaseCallCount = 0;
  int restoreCallCount = 0;

  @override
  Future<List<PremiumOffering>> loadProducts() async {
    if (!productsAvailable) return const <PremiumOffering>[];
    return <PremiumOffering>[
      PremiumOffering(
        productId: BillingProductIds.monthly,
        billingPeriod: BillingPeriod.monthly,
        localizedPrice: localizedPrices[BillingProductIds.monthly],
      ),
      PremiumOffering(
        productId: BillingProductIds.yearly,
        billingPeriod: BillingPeriod.yearly,
        localizedPrice: localizedPrices[BillingProductIds.yearly],
      ),
    ];
  }

  /// Test control: simulate the store completing a pending purchase
  /// successfully.
  void simulatePurchaseSuccess(String productId) {
    _purchasePending = false;
    _entitlement = PremiumStatus.premium;
    _updates.add(PurchaseUpdate(productId: productId, outcome: PurchaseOutcome.success));
  }

  void simulatePurchaseCancelled(String productId) {
    _purchasePending = false;
    _updates.add(PurchaseUpdate(productId: productId, outcome: PurchaseOutcome.cancelled));
  }

  void simulatePurchaseError(String productId, {String? errorMessage}) {
    _purchasePending = false;
    _updates.add(PurchaseUpdate(
      productId: productId,
      outcome: PurchaseOutcome.error,
      errorMessage: errorMessage ?? "We couldn't complete the purchase.",
    ));
  }

  /// Test control: simulate a subscription expiring/being revoked.
  void simulateEntitlementExpired() {
    _entitlement = PremiumStatus.free;
  }

  @override
  Future<void> purchase(String productId) async {
    purchaseCallCount += 1;
    if (throwOnPurchase) {
      throw Exception('simulated store failure');
    }
    if (_purchasePending) {
      // Section 12: no repeated purchase requests while one is
      // pending — this fake enforces the same rule a real
      // implementation must.
      return;
    }
    _purchasePending = true;
    _updates.add(PurchaseUpdate(productId: productId, outcome: PurchaseOutcome.pending));
  }

  @override
  Future<void> restorePurchases() async {
    restoreCallCount += 1;
    if (throwOnRestore) {
      throw Exception('simulated store failure');
    }
    if (_entitlement.isPremium) {
      simulatePurchaseSuccess(BillingProductIds.monthly);
    }
    // If no entitlement exists, callers observe this via
    // refreshEntitlement() resolving to PremiumStatus.free — this
    // fake deliberately doesn't need a separate "restore" stream
    // event type beyond the existing purchase outcomes, since a
    // successful restore and a successful purchase converge on the
    // same entitlement result.
  }

  @override
  Stream<PurchaseUpdate> watchPurchaseUpdates() => _updates.stream;

  @override
  Future<PremiumStatus> refreshEntitlement() async => _entitlement;

  @override
  Future<void> dispose() async {
    await _updates.close();
  }
}
