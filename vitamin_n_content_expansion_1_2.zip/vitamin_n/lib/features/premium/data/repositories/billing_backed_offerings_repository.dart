import '../../domain/entities/premium_offering.dart';
import '../../domain/repositories/billing_repository.dart';
import '../../domain/repositories/premium_offerings_repository.dart';

/// The real [PremiumOfferingsRepository], delegating to whatever
/// [BillingRepository] is wired up (real store or a fake in tests).
/// Replaces StubPremiumOfferingsRepository in production.
class BillingBackedOfferingsRepository implements PremiumOfferingsRepository {
  BillingBackedOfferingsRepository(this._billing);

  final BillingRepository _billing;

  @override
  Future<List<PremiumOffering>> getOfferings() => _billing.loadProducts();
}
