import '../../domain/entities/premium_status.dart';
import '../../domain/repositories/premium_repository.dart';

/// Always reports [PremiumStatus.free]. Swap this out for a real
/// implementation (backed by `in_app_purchase` + receipt validation)
/// when billing is introduced — nothing that depends on
/// [PremiumRepository] will need to change.
class StubPremiumRepository implements PremiumRepository {
  const StubPremiumRepository();

  @override
  Future<PremiumStatus> getStatus() async => PremiumStatus.free;

  @override
  Stream<PremiumStatus> watchStatus() {
    return Stream<PremiumStatus>.value(PremiumStatus.free);
  }

  @override
  Future<PremiumStatus> refreshEntitlement() async => PremiumStatus.free;
}
