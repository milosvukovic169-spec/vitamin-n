import 'dart:async';

import 'package:in_app_purchase/in_app_purchase.dart';

import '../../domain/entities/billing_product_ids.dart';
import '../../domain/entities/premium_offering.dart';
import '../../domain/entities/premium_status.dart';
import '../../domain/entities/purchase_update.dart';
import '../../domain/repositories/billing_repository.dart';
import 'restore_based_entitlement_resolver.dart';

/// The real store-backed [BillingRepository], using Flutter's
/// official `in_app_purchase` package (Phase 7 section 6). This is
/// the only file in the app that imports `in_app_purchase` directly —
/// everything else (Premium UI, gating, entitlement) depends on the
/// [BillingRepository] interface.
///
/// Verification approach: this MVP trusts the store SDK's own
/// reported [PurchaseDetails.status] (`purchased`/`restored`) as
/// sufficient client-side confirmation, matching section 10's
/// "verified using available store purchase state" — there is no
/// server-side receipt validation, since section 6 explicitly rules
/// out adding a backend for this phase. This is a real, accepted
/// limitation: a determined attacker with a rooted/patched device
/// could in principle fake a local purchase result. Documented in the
/// Phase 7 report as a known MVP tradeoff, not an oversight.
///
/// NOTE: written against the `in_app_purchase` API surface from
/// training knowledge; this has not been compiled or run against a
/// real Play Console product or device in this sandbox (no Flutter
/// toolchain, no store connection here) — please validate locally.
class InAppPurchaseBillingRepository implements BillingRepository {
  InAppPurchaseBillingRepository({InAppPurchase? inAppPurchase})
      : _iap = inAppPurchase ?? InAppPurchase.instance;

  final InAppPurchase _iap;
  final StreamController<PurchaseUpdate> _updates =
      StreamController<PurchaseUpdate>.broadcast();
  StreamSubscription<List<PurchaseDetails>>? _subscription;
  final Set<String> _pendingProductIds = <String>{};

  /// Call once, early (e.g. from the entitlement repository's own
  /// initialization) — wires the store's purchase stream to
  /// [watchPurchaseUpdates].
  void listen() {
    _subscription ??= _iap.purchaseStream.listen(
      _handlePurchaseUpdates,
      onError: (Object error) {
        // The stream itself failing is not tied to one product; there
        // is nothing user-actionable to surface here beyond letting
        // whoever initiated a purchase see a generic error via their
        // own await, so this is intentionally swallowed rather than
        // crashing anything (section 34/48: billing/analytics
        // failures must never break the app).
      },
    );
  }

  Future<void> _handlePurchaseUpdates(List<PurchaseDetails> purchases) async {
    for (final PurchaseDetails purchase in purchases) {
      // Each purchase is handled independently and defensively: an
      // exception thrown inside a StreamSubscription's onData
      // callback does NOT route to listen()'s onError handler (that's
      // only for errors delivered through the stream itself) — it
      // becomes an unhandled async error. Wrapping per-purchase means
      // one failure (most likely completePurchase() below) can never
      // silently abort processing of the rest of this batch, and
      // never escapes uncaught either.
      try {
        switch (purchase.status) {
          case PurchaseStatus.pending:
            _updates.add(PurchaseUpdate(
              productId: purchase.productID,
              outcome: PurchaseOutcome.pending,
            ));
          case PurchaseStatus.purchased:
          case PurchaseStatus.restored:
            _pendingProductIds.remove(purchase.productID);
            _updates.add(PurchaseUpdate(
              productId: purchase.productID,
              outcome: PurchaseOutcome.success,
            ));
          case PurchaseStatus.canceled:
            _pendingProductIds.remove(purchase.productID);
            _updates.add(PurchaseUpdate(
              productId: purchase.productID,
              outcome: PurchaseOutcome.cancelled,
            ));
          case PurchaseStatus.error:
            _pendingProductIds.remove(purchase.productID);
            _updates.add(PurchaseUpdate(
              productId: purchase.productID,
              outcome: PurchaseOutcome.error,
              // Deliberately not forwarding purchase.error's raw
              // message — sections 14/42 require calm, generic,
              // non-technical copy only.
              errorMessage: "We couldn't complete the purchase.",
            ));
        }

        if (purchase.pendingCompletePurchase) {
          await _iap.completePurchase(purchase);
        }
      } catch (_) {
        // This purchase's acknowledgement failed — make sure it
        // isn't left permanently stuck in _pendingProductIds (which
        // would trigger the same "double-tap guard latches shut
        // forever" bug class fixed elsewhere in this file), and
        // report it through the normal error channel so any UI
        // watching this product's state doesn't hang indefinitely.
        _pendingProductIds.remove(purchase.productID);
        _updates.add(PurchaseUpdate(
          productId: purchase.productID,
          outcome: PurchaseOutcome.error,
          errorMessage: "We couldn't complete the purchase.",
        ));
      }
    }
  }

  @override
  Future<List<PremiumOffering>> loadProducts() async {
    try {
      final bool available = await _iap.isAvailable();
      if (!available) return const <PremiumOffering>[];

      final ProductDetailsResponse response =
          await _iap.queryProductDetails(BillingProductIds.all);
      if (response.error != null) return const <PremiumOffering>[];

      final Map<String, ProductDetails> byId = <String, ProductDetails>{
        for (final ProductDetails p in response.productDetails) p.id: p,
      };

      return <PremiumOffering>[
        PremiumOffering(
          productId: BillingProductIds.monthly,
          billingPeriod: BillingPeriod.monthly,
          localizedPrice: byId[BillingProductIds.monthly]?.price,
        ),
        PremiumOffering(
          productId: BillingProductIds.yearly,
          billingPeriod: BillingPeriod.yearly,
          localizedPrice: byId[BillingProductIds.yearly]?.price,
        ),
      ];
    } catch (_) {
      // Section 21: an unexpected failure here must still land on the
      // same "Plans are temporarily unavailable, Try again" state —
      // never a fake price, never an uncaught crash.
      return const <PremiumOffering>[];
    }
  }

  @override
  Future<void> purchase(String productId) async {
    // Section 12/22: never issue a second purchase request for a
    // product that already has one in flight.
    if (_pendingProductIds.contains(productId)) return;

    try {
      final ProductDetailsResponse response =
          await _iap.queryProductDetails(<String>{productId});
      final ProductDetails? details = response.productDetails
          .where((ProductDetails p) => p.id == productId)
          .firstOrNull;
      if (details == null) {
        _updates.add(PurchaseUpdate(
          productId: productId,
          outcome: PurchaseOutcome.error,
          errorMessage: "We couldn't complete the purchase.",
        ));
        return;
      }

      _pendingProductIds.add(productId);
      final PurchaseParam param = PurchaseParam(productDetails: details);
      // Vitamin N Premium is a subscription; in_app_purchase models
      // both non-consumables and subscriptions through the same
      // buyNonConsumable entry point on Android.
      await _iap.buyNonConsumable(purchaseParam: param);
    } catch (_) {
      // Without this, a failure here (e.g. buyNonConsumable() itself
      // throwing before Play even shows a purchase sheet) would leave
      // productId stuck in _pendingProductIds forever — the
      // double-tap guard above would then silently block every future
      // purchase attempt for this product until the app restarts, and
      // the exception would propagate uncaught to whatever called
      // purchase(), leaving the UI's "purchasing…" state stuck too.
      _pendingProductIds.remove(productId);
      _updates.add(PurchaseUpdate(
        productId: productId,
        outcome: PurchaseOutcome.error,
        errorMessage: "We couldn't complete the purchase.",
      ));
    }
  }

  @override
  Future<void> restorePurchases() async {
    await _iap.restorePurchases();
  }

  @override
  Stream<PurchaseUpdate> watchPurchaseUpdates() => _updates.stream;

  @override
  Future<PremiumStatus> refreshEntitlement() async {
    // See restore_based_entitlement_resolver.dart for the full
    // rationale and honest limitations of this approach — in short,
    // this distinguishes "the restore query failed" (stay unknown,
    // preserve whatever was cached) from "the restore query
    // succeeded and found nothing" (genuinely conclude Free), which
    // is what makes subscription expiry/revocation actually able to
    // return the user to Free instead of a cached Premium persisting
    // forever.
    return resolveEntitlementViaRestore(
      triggerRestore: _iap.restorePurchases,
      purchaseUpdates: _updates.stream,
      premiumProductIds: BillingProductIds.all,
    );
  }

  @override
  Future<void> dispose() async {
    await _subscription?.cancel();
    await _updates.close();
  }
}
