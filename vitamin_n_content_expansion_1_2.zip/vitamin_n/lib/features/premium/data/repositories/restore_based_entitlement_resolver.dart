import 'dart:async';

import '../../domain/entities/premium_status.dart';
import '../../domain/entities/purchase_update.dart';

/// The client-side algorithm for turning a store "restore" call into
/// a definite Free/Premium answer, extracted as a pure, SDK-independent
/// function so it can be unit-tested without the real `in_app_purchase`
/// plugin (which needs a real platform to run against).
///
/// WHY THIS EXISTS (see the Phase 7 billing audit): the naive
/// approach — call restorePurchases() and immediately return
/// PremiumStatus.unknown, relying on a later purchase-success stream
/// event — has no way to ever conclude Free again once a subscription
/// has genuinely expired, because no event fires for "you no longer
/// own this". A cached true entitlement would then persist forever.
///
/// This function distinguishes three cases:
///  - the restore call itself throws (offline / store unavailable) ->
///    unknown — we genuinely don't know, so the caller should keep
///    whatever cached value it already has rather than guessing.
///  - the restore call succeeds and a Premium purchase surfaces
///    within [window] -> premium.
///  - the restore call succeeds and NOTHING surfaces within [window]
///    -> free — Play Billing's queryPurchasesAsync (which
///    restorePurchases() wraps on Android) only returns purchases it
///    currently considers owned/active, so a completed query
///    returning nothing is a genuine, actionable signal that the
///    subscription is no longer active.
///
/// IMPORTANT HONEST LIMITATION (do not remove this comment when
/// touching this file): Play Billing's client-side purchase query is
/// what most lightweight apps use for entitlement checks like this,
/// and it correctly reflects the common cases — a cancelled-but-
/// still-within-the-paid-period subscription is still returned as
/// owned (so the user correctly keeps access until the period ends),
/// and a subscription in Google's payment grace period is also still
/// returned as owned. However, it is NOT a substitute for real,
/// tamper-resistant, timely revocation handling: (1) it only reflects
/// reality at the moment this function is called, not in real time —
/// see RootShell's app-resume trigger for when that happens; (2) a
/// sufficiently modified/rooted client could in principle spoof a
/// local response; (3) Google's own guidance for production-grade
/// subscription state (renewals, grace period edge cases, refunds,
/// chargebacks) is server-side verification via the Google Play
/// Developer API and Real-time Developer Notifications — which this
/// MVP deliberately does not implement, per the explicit "no custom
/// backend" constraint. This is a documented, deliberate tradeoff,
/// not an oversight.
Future<PremiumStatus> resolveEntitlementViaRestore({
  required Future<void> Function() triggerRestore,
  required Stream<PurchaseUpdate> purchaseUpdates,
  required Set<String> premiumProductIds,
  Duration window = const Duration(seconds: 3),
}) async {
  bool sawActivePremiumPurchase = false;
  final StreamSubscription<PurchaseUpdate> subscription = purchaseUpdates.listen(
    (PurchaseUpdate update) {
      if (update.outcome == PurchaseOutcome.success &&
          premiumProductIds.contains(update.productId)) {
        sawActivePremiumPurchase = true;
      }
    },
  );

  try {
    await triggerRestore();
  } catch (_) {
    // The query itself failed — offline, store unavailable, etc. We
    // genuinely don't know the answer; do NOT conclude Free here.
    await subscription.cancel();
    return PremiumStatus.unknown;
  }

  // Give the store's response a bounded window to arrive via the
  // purchase stream before concluding nothing is owned.
  await Future<void>.delayed(window);
  await subscription.cancel();

  return sawActivePremiumPurchase ? PremiumStatus.premium : PremiumStatus.free;
}
