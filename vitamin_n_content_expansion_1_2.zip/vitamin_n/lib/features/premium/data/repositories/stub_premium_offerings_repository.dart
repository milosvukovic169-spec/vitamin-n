import '../../domain/entities/billing_product_ids.dart';
import '../../domain/entities/premium_offering.dart';
import '../../domain/repositories/premium_offerings_repository.dart';

/// Reports Monthly/Yearly offerings shaped correctly for the Premium
/// screen, but with [PremiumOffering.localizedPrice] left null — no
/// real store connected. Kept as the fallback used only if
/// [BillingBackedOfferingsRepository] can't be constructed; the
/// stub's product ids are the same centralized constants everything
/// else uses (Phase 7 section 4), never a second hardcoded copy.
class StubPremiumOfferingsRepository implements PremiumOfferingsRepository {
  const StubPremiumOfferingsRepository();

  @override
  Future<List<PremiumOffering>> getOfferings() async => const <PremiumOffering>[
        PremiumOffering(
          productId: BillingProductIds.monthly,
          billingPeriod: BillingPeriod.monthly,
        ),
        PremiumOffering(
          productId: BillingProductIds.yearly,
          billingPeriod: BillingPeriod.yearly,
        ),
      ];
}
