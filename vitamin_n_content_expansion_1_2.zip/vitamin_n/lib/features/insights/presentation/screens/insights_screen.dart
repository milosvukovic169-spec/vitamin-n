import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../design_system/theme/theme_extensions.dart';
import '../../../../design_system/widgets/app_card.dart';
import '../../domain/entities/insights_time_range.dart';
import '../providers/insights_providers.dart';
import '../widgets/insights_summary_card.dart';
import '../widgets/protected_value_bar_row.dart';

class InsightsScreen extends ConsumerWidget {
  const InsightsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final TextTheme textTheme = Theme.of(context).textTheme;
    final AsyncValue<InsightsAggregates> aggregatesAsync =
        ref.watch(insightsAggregatesProvider);
    final AsyncValue<List<String>> patternsAsync = ref.watch(insightPatternsProvider);
    final InsightsTimeRange selectedRange =
        ref.watch(insightsTimeRangeControllerProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Insights')),
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.all(context.spacing.lg),
          children: <Widget>[
            Text(
              'A clearer view of what you\u2019ve been protecting.',
              style: textTheme.bodyMedium,
            ),
            SizedBox(height: context.spacing.lg),
            _TimeRangeSelector(selected: selectedRange),
            SizedBox(height: context.spacing.lg),
            aggregatesAsync.when(
              data: (InsightsAggregates aggregates) {
                if (aggregates.totalEntries == 0) {
                  return const _InsightsEmptyState();
                }
                return _InsightsContent(
                  aggregates: aggregates,
                  patterns: patternsAsync.value ?? const <String>[],
                  rangeLabel: rangeLabelFor(selectedRange),
                );
              },
              loading: () => const Padding(
                padding: EdgeInsets.only(top: 48),
                child: Center(child: CircularProgressIndicator()),
              ),
              error: (Object error, StackTrace stackTrace) =>
                  Text('Could not load Insights: $error'),
            ),
          ],
        ),
      ),
    );
  }
}

class _TimeRangeSelector extends ConsumerWidget {
  const _TimeRangeSelector({required this.selected});

  final InsightsTimeRange selected;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final controller = ref.read(insightsTimeRangeControllerProvider.notifier);

    Widget segment(String label, InsightsTimeRange value, VoidCallback onTap) {
      final bool isSelected = selected == value;
      return Expanded(
        child: Semantics(
          button: true,
          selected: isSelected,
          label: label,
          child: InkWell(
            onTap: onTap,
            borderRadius: context.radius.mdRadius,
            child: Container(
              constraints: const BoxConstraints(minHeight: 48),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: isSelected ? context.colors.sage : Colors.transparent,
                borderRadius: context.radius.mdRadius,
              ),
              child: Text(
                label,
                style: Theme.of(context).textTheme.labelMedium?.copyWith(
                      color: isSelected
                          ? context.colors.textOnSage
                          : context.colors.textPrimary,
                    ),
              ),
            ),
          ),
        ),
      );
    }

    return Container(
      padding: EdgeInsets.all(context.spacing.xs),
      decoration: BoxDecoration(
        color: context.colors.cream,
        borderRadius: context.radius.mdRadius,
      ),
      child: Row(
        children: <Widget>[
          segment('This week', InsightsTimeRange.week, controller.setWeek),
          segment('This month', InsightsTimeRange.month, controller.setMonth),
          segment('All time', InsightsTimeRange.allTime, controller.setAllTime),
        ],
      ),
    );
  }
}

class _InsightsContent extends StatelessWidget {
  const _InsightsContent({
    required this.aggregates,
    required this.patterns,
    required this.rangeLabel,
  });

  final InsightsAggregates aggregates;
  final List<String> patterns;
  final String rangeLabel;

  @override
  Widget build(BuildContext context) {
    final TextTheme textTheme = Theme.of(context).textTheme;

    // 1-2 entries: protected values only, per the low-data rule.
    final bool showCategorySection = aggregates.totalEntries >= 3;

    final List<MapEntry<String, int>> sortedValues =
        aggregates.protectedValueCounts.entries.toList()
          ..sort((a, b) => b.value.compareTo(a.value));
    final int maxValueCount = sortedValues.isEmpty ? 0 : sortedValues.first.value;

    final List<MapEntry<String, int>> sortedCategories =
        aggregates.categoryCounts.entries.toList()
          ..sort((a, b) => b.value.compareTo(a.value));
    final int maxCategoryCount =
        sortedCategories.isEmpty ? 0 : sortedCategories.first.value;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text('What you protected', style: textTheme.titleLarge),
        SizedBox(height: context.spacing.sm),
        AppCard(
          child: Column(
            children: <Widget>[
              for (final MapEntry<String, int> entry in sortedValues)
                ProtectedValueBarRow(
                  label: entry.key,
                  count: entry.value,
                  maxCount: maxValueCount,
                ),
            ],
          ),
        ),
        if (showCategorySection && sortedCategories.isNotEmpty) ...<Widget>[
          SizedBox(height: context.spacing.lg),
          Text('Where boundaries showed up', style: textTheme.titleLarge),
          SizedBox(height: context.spacing.sm),
          AppCard(
            child: Column(
              children: <Widget>[
                for (final MapEntry<String, int> entry in sortedCategories)
                  ProtectedValueBarRow(
                    label: entry.key,
                    count: entry.value,
                    maxCount: maxCategoryCount,
                  ),
              ],
            ),
          ),
        ],
        if (patterns.isNotEmpty) ...<Widget>[
          SizedBox(height: context.spacing.lg),
          AppCard(
            backgroundColor: context.colors.beige,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                for (final String message in patterns)
                  Padding(
                    padding: EdgeInsets.symmetric(vertical: context.spacing.xs),
                    child: Text(message, style: textTheme.bodyLarge),
                  ),
              ],
            ),
          ),
        ],
        SizedBox(height: context.spacing.lg),
        InsightsSummaryCard(
          rangeTitle: rangeLabel[0].toUpperCase() + rangeLabel.substring(1),
          totalEntries: aggregates.totalEntries,
          mostProtectedLabel: sortedValues.isEmpty ? null : sortedValues.first.key,
          mostFrequentCategoryLabel:
              sortedCategories.isEmpty ? null : sortedCategories.first.key,
        ),
      ],
    );
  }
}

class _InsightsEmptyState extends StatelessWidget {
  const _InsightsEmptyState();

  @override
  Widget build(BuildContext context) {
    final TextTheme textTheme = Theme.of(context).textTheme;
    return Padding(
      padding: EdgeInsets.only(top: context.spacing.xxl),
      child: Column(
        children: <Widget>[
          Text(
            'Your patterns are still forming.',
            style: textTheme.titleMedium,
            textAlign: TextAlign.center,
          ),
          SizedBox(height: context.spacing.sm),
          Text(
            'Add a few protected choices and your Insights will begin '
            'to take shape.',
            style: textTheme.bodyMedium,
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
