import 'package:flutter/material.dart';

import '../../../../design_system/theme/theme_extensions.dart';
import '../../../../design_system/widgets/app_card.dart';

/// The optional weekly/monthly summary card — plain facts, no score,
/// no grade, no comparison to anyone else.
class InsightsSummaryCard extends StatelessWidget {
  const InsightsSummaryCard({
    super.key,
    required this.rangeTitle,
    required this.totalEntries,
    required this.mostProtectedLabel,
    required this.mostFrequentCategoryLabel,
  });

  final String rangeTitle;
  final int totalEntries;
  final String? mostProtectedLabel;
  final String? mostFrequentCategoryLabel;

  @override
  Widget build(BuildContext context) {
    final TextTheme textTheme = Theme.of(context).textTheme;

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(rangeTitle, style: textTheme.titleMedium),
          SizedBox(height: context.spacing.md),
          Text(
            '$totalEntries protected choice${totalEntries == 1 ? '' : 's'}',
            style: textTheme.headlineMedium,
          ),
          if (mostProtectedLabel != null) ...<Widget>[
            SizedBox(height: context.spacing.md),
            Text('Most protected', style: textTheme.bodySmall),
            Text(mostProtectedLabel!, style: textTheme.titleSmall),
          ],
          if (mostFrequentCategoryLabel != null) ...<Widget>[
            SizedBox(height: context.spacing.sm),
            Text('Most frequent category', style: textTheme.bodySmall),
            Text(mostFrequentCategoryLabel!, style: textTheme.titleSmall),
          ],
        ],
      ),
    );
  }
}
