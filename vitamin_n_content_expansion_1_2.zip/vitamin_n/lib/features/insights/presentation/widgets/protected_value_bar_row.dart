import 'package:flutter/material.dart';

import '../../../../design_system/theme/theme_extensions.dart';

/// One row in "What you protected" — a label, a simple proportional
/// bar, and the exact count. Deliberately plain (no flashy chart, no
/// percentages) per the founder spec. The count is real text, not
/// just implied by bar length, so it's available to screen readers
/// and isn't conveyed by color/length alone.
class ProtectedValueBarRow extends StatelessWidget {
  const ProtectedValueBarRow({
    super.key,
    required this.label,
    required this.count,
    required this.maxCount,
  });

  final String label;
  final int count;
  final int maxCount;

  @override
  Widget build(BuildContext context) {
    final AppColors colors = context.colors;
    final double fraction = maxCount == 0 ? 0 : count / maxCount;

    return Semantics(
      label: '$label, $count',
      child: Padding(
        padding: EdgeInsets.symmetric(vertical: context.spacing.xs),
        child: Row(
          children: <Widget>[
            SizedBox(
              width: 88,
              child: Text(label, style: Theme.of(context).textTheme.bodyMedium),
            ),
            Expanded(
              child: ClipRRect(
                borderRadius: context.radius.smRadius,
                child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                    return Stack(
                      children: <Widget>[
                        Container(height: 10, color: colors.cream),
                        AnimatedContainer(
                          duration: const Duration(milliseconds: 300),
                          curve: Curves.easeOut,
                          height: 10,
                          width: constraints.maxWidth * fraction,
                          color: colors.sageStrong,
                        ),
                      ],
                    );
                  },
                ),
              ),
            ),
            SizedBox(width: context.spacing.sm),
            SizedBox(
              width: 28,
              child: Text(
                '$count',
                textAlign: TextAlign.right,
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
