import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../categories/domain/entities/category.dart';
import '../../../categories/presentation/providers/category_providers.dart';
import '../../../entries/domain/entities/entry.dart';
import '../../../entries/presentation/providers/entry_providers.dart';
import '../../../protected_values/domain/entities/protected_value.dart';
import '../../../protected_values/presentation/providers/protected_value_providers.dart';
import '../../domain/entities/insights_time_range.dart';
import '../../domain/usecases/generate_insight_patterns_usecase.dart';

class InsightsTimeRangeController extends Notifier<InsightsTimeRange> {
  @override
  InsightsTimeRange build() => InsightsTimeRange.month;

  void setWeek() => state = InsightsTimeRange.week;
  void setMonth() => state = InsightsTimeRange.month;
  void setAllTime() => state = InsightsTimeRange.allTime;
}

final NotifierProvider<InsightsTimeRangeController, InsightsTimeRange>
    insightsTimeRangeControllerProvider =
    NotifierProvider<InsightsTimeRangeController, InsightsTimeRange>(
        InsightsTimeRangeController.new);

String rangeLabelFor(InsightsTimeRange range) {
  switch (range) {
    case InsightsTimeRange.week:
      return 'this week';
    case InsightsTimeRange.month:
      return 'this month';
    case InsightsTimeRange.allTime:
      return 'overall';
  }
}

/// Every number Insights needs for the currently-selected time range,
/// pre-resolved from ids to display labels. Fetched via the
/// repository's range-aware, SQL-backed aggregate methods — never
/// computed by fetching the whole table into a widget.
class InsightsAggregates {
  const InsightsAggregates({
    required this.totalEntries,
    required this.protectedValueCounts,
    required this.categoryCounts,
    required this.weekdayDistribution,
  });

  final int totalEntries;

  /// label -> count.
  final Map<String, int> protectedValueCounts;

  /// category name -> count.
  final Map<String, int> categoryCounts;

  /// ISO weekday (1 = Monday .. 7 = Sunday) -> count.
  final Map<int, int> weekdayDistribution;
}

final FutureProvider<InsightsAggregates> insightsAggregatesProvider =
    FutureProvider<InsightsAggregates>((Ref ref) async {
  final InsightsTimeRange range = ref.watch(insightsTimeRangeControllerProvider);
  final ResolvedDateRange resolved = resolveInsightsTimeRange(range);
  final repository = ref.watch(entryRepositoryProvider);

  final List<Entry> entries =
      await repository.getEntriesForRange(resolved.start, resolved.end);
  final Map<String, int> valueCountsById = await repository.getProtectedValueCounts(
    start: resolved.start,
    end: resolved.end,
  );
  final Map<String, int> categoryCountsById = await repository.getCategoryCounts(
    start: resolved.start,
    end: resolved.end,
  );
  final Map<int, int> weekday = await repository.getWeekdayDistribution(
    start: resolved.start,
    end: resolved.end,
  );

  final List<ProtectedValue> values =
      await ref.watch(protectedValueRepositoryProvider).getAll();
  final List<Category> categories =
      await ref.watch(categoryRepositoryProvider).getAll();
  final Map<String, String> valueLabelById = <String, String>{
    for (final ProtectedValue v in values) v.id: v.label,
  };
  final Map<String, String> categoryNameById = <String, String>{
    for (final Category c in categories) c.id: c.name,
  };

  final Map<String, int> protectedValueCounts = <String, int>{};
  valueCountsById.forEach((String id, int count) {
    final String? label = valueLabelById[id];
    if (label != null) {
      protectedValueCounts[label] = count;
    }
  });

  final Map<String, int> categoryCounts = <String, int>{};
  categoryCountsById.forEach((String id, int count) {
    final String? name = categoryNameById[id];
    if (name != null) {
      categoryCounts[name] = count;
    }
  });

  return InsightsAggregates(
    totalEntries: entries.length,
    protectedValueCounts: protectedValueCounts,
    categoryCounts: categoryCounts,
    weekdayDistribution: weekday,
  );
});

const GenerateInsightPatternsUseCase _generatePatterns =
    GenerateInsightPatternsUseCase();

final Provider<AsyncValue<List<String>>> insightPatternsProvider =
    Provider<AsyncValue<List<String>>>((Ref ref) {
  final AsyncValue<InsightsAggregates> aggregatesAsync =
      ref.watch(insightsAggregatesProvider);
  final String rangeLabel =
      rangeLabelFor(ref.watch(insightsTimeRangeControllerProvider));

  return aggregatesAsync.whenData((InsightsAggregates a) {
    return _generatePatterns(
      totalEntries: a.totalEntries,
      protectedValueCounts: a.protectedValueCounts,
      categoryCounts: a.categoryCounts,
      weekdayDistribution: a.weekdayDistribution,
      rangeLabel: rangeLabel,
    );
  });
});
