/// The time range Insights is scoped to. Default is [month], per the
/// founder spec.
enum InsightsTimeRange { week, month, allTime }

/// A resolved, half-open [start, end) date range for a given
/// [InsightsTimeRange], relative to a reference "now". Pure and
/// deterministic — `now` is always a parameter, never read from the
/// system clock internally — so range boundaries are fully testable.
class ResolvedDateRange {
  const ResolvedDateRange({required this.start, required this.end});

  final DateTime start;
  final DateTime end;
}

ResolvedDateRange resolveInsightsTimeRange(InsightsTimeRange range, {DateTime? now}) {
  final DateTime reference = now ?? DateTime.now();
  final DateTime startOfToday =
      DateTime(reference.year, reference.month, reference.day);
  final DateTime end = startOfToday.add(const Duration(days: 1));

  switch (range) {
    case InsightsTimeRange.week:
      final DateTime startOfWeek =
          startOfToday.subtract(Duration(days: startOfToday.weekday - 1));
      return ResolvedDateRange(start: startOfWeek, end: end);
    case InsightsTimeRange.month:
      return ResolvedDateRange(
        start: DateTime(reference.year, reference.month),
        end: end,
      );
    case InsightsTimeRange.allTime:
      // A practical epoch rather than a nullable range — keeps every
      // call site simple (always a concrete start/end) without
      // needing a separate "no filter" branch throughout the app.
      return ResolvedDateRange(start: DateTime(2000), end: end);
  }
}
