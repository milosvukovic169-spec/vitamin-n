/// Generates calm, deterministic, descriptive pattern statements from
/// the user's own data. No AI, no prediction, no diagnosis — every
/// message is a direct restatement of a stored count.
///
/// Respects the low-data rules exactly:
/// - fewer than 3 entries: no pattern messages at all (empty list)
/// - 3–5 entries: at most one message (the single most protected
///   value) — a "simple frequency summary"
/// - 6+ entries: up to three messages (protected value, category,
///   and a weekday-vs-weekend comparison when one side is clearly
///   ahead) — "broader descriptive patterns"
///
/// Never presents weak data as a meaningful trend, and never uses
/// judgmental or clinical language — see the founder spec's banned
/// phrase list, none of which this class can produce since every
/// message is built from a small fixed set of neutral templates.
class GenerateInsightPatternsUseCase {
  const GenerateInsightPatternsUseCase();

  static const int _simpleSummaryThreshold = 3;
  static const int _broaderPatternThreshold = 6;

  List<String> call({
    required int totalEntries,
    required Map<String, int> protectedValueCounts,
    required Map<String, int> categoryCounts,
    required Map<int, int> weekdayDistribution,
    required String rangeLabel,
  }) {
    if (totalEntries < _simpleSummaryThreshold) {
      return const <String>[];
    }

    final List<String> messages = <String>[];

    final MapEntry<String, int>? topValue = _topEntry(protectedValueCounts);
    if (topValue != null) {
      messages.add('You protected your ${topValue.key} most often $rangeLabel.');
    }

    if (totalEntries >= _broaderPatternThreshold) {
      final MapEntry<String, int>? topCategory = _topEntry(categoryCounts);
      if (topCategory != null) {
        messages.add('${topCategory.key} was your most frequent boundary category.');
      }

      final int weekdayTotal = <int>[1, 2, 3, 4, 5]
          .fold(0, (int sum, int day) => sum + (weekdayDistribution[day] ?? 0));
      final int weekendTotal = <int>[6, 7]
          .fold(0, (int sum, int day) => sum + (weekdayDistribution[day] ?? 0));

      if (weekdayTotal > weekendTotal) {
        messages.add('You recorded more boundaries on weekdays than weekends.');
      } else if (weekendTotal > weekdayTotal) {
        messages.add('You recorded more boundaries on weekends than weekdays.');
      }
    }

    return messages;
  }

  MapEntry<String, int>? _topEntry(Map<String, int> counts) {
    if (counts.isEmpty) return null;
    MapEntry<String, int>? top;
    for (final MapEntry<String, int> entry in counts.entries) {
      if (top == null || entry.value > top.value) {
        top = entry;
      }
    }
    return top;
  }
}
