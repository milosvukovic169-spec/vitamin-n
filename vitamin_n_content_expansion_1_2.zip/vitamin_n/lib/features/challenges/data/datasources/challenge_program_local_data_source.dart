import '../../../../core/constants/asset_paths.dart';
import '../../../../core/json/json_asset_loader.dart';
import '../../domain/entities/challenge_program.dart';

class ChallengeProgramLocalDataSource {
  ChallengeProgramLocalDataSource({
    JsonAssetLoader loader = const JsonAssetLoader(),
  }) : _loader = loader;

  final JsonAssetLoader _loader;

  /// Reads all 6 (small) challenge files. Only ever called when the
  /// Challenges screen is opened — never at app startup.
  Future<List<ChallengeProgram>> loadAll() async {
    final List<ChallengeProgram> programs = <ChallengeProgram>[];
    for (final String path in AssetPaths.challengeFiles) {
      final Map<String, dynamic> json = await _loader.loadObject(path);
      programs.add(_parse(json));
    }
    return programs;
  }

  ChallengeProgram _parse(Map<String, dynamic> json) {
    final List<dynamic> rawSteps = json['steps'] as List<dynamic>;
    final List<ChallengeStep> steps = rawSteps
        .map((dynamic s) => ChallengeStep(
              id: (s as Map<String, dynamic>)['id'] as String,
              text: s['text'] as String,
              sortOrder: s['sortOrder'] as int,
            ))
        .toList()
      ..sort((ChallengeStep a, ChallengeStep b) => a.sortOrder.compareTo(b.sortOrder));

    return ChallengeProgram(
      id: json['id'] as String,
      title: json['title'] as String,
      description: json['description'] as String,
      iconName: json['iconName'] as String,
      suggestedCategoryId: json['suggestedCategoryId'] as String?,
      steps: steps,
    );
  }
}
