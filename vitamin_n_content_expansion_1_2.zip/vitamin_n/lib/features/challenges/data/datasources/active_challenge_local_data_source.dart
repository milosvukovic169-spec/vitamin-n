import 'package:drift/drift.dart';

import '../../../../core/database/app_database.dart';

class ActiveChallengeLocalDataSource {
  ActiveChallengeLocalDataSource(this._db);

  final AppDatabase _db;

  Future<ActiveChallengeRow?> getMostRecentRow() {
    return (_db.select(_db.activeChallenges)
          ..orderBy([(tbl) => OrderingTerm.desc(tbl.startedAt)])
          ..limit(1))
        .getSingleOrNull();
  }

  Future<ActiveChallengeRow> replaceWith(String programId, DateTime startedAt) {
    return _db.transaction<ActiveChallengeRow>(() async {
      await _db.delete(_db.activeChallenges).go();
      final int id = await _db.into(_db.activeChallenges).insert(
            ActiveChallengesCompanion.insert(
              programId: programId,
              startedAt: startedAt,
            ),
          );
      return ActiveChallengeRow(id: id, programId: programId, startedAt: startedAt);
    });
  }

  Future<void> clearAll() {
    return _db.delete(_db.activeChallenges).go();
  }
}
