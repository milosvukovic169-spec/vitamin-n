import 'dart:convert';

import '../../../settings/domain/repositories/settings_repository.dart';
import '../../domain/repositories/challenge_progress_repository.dart';

class ChallengeProgressRepositoryImpl implements ChallengeProgressRepository {
  ChallengeProgressRepositoryImpl(this._settings);

  final SettingsRepository _settings;

  String _keyFor(String challengeId) => 'challenge_progress:$challengeId';

  @override
  Future<Set<String>> getCompletedStepIds(String challengeId) async {
    final String? raw = await _settings.getString(_keyFor(challengeId));
    if (raw == null) return const <String>{};
    final dynamic decoded = jsonDecode(raw);
    return (decoded as List<dynamic>).map((dynamic e) => e as String).toSet();
  }

  @override
  Future<void> toggleStep(String challengeId, String stepId) async {
    final Set<String> current = (await getCompletedStepIds(challengeId)).toSet();
    if (!current.add(stepId)) {
      current.remove(stepId);
    }
    await _settings.setString(_keyFor(challengeId), jsonEncode(current.toList()));
  }
}
