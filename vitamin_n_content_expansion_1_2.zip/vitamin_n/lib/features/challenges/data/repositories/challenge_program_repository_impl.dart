import '../../domain/repositories/challenge_program_repository.dart';
import '../datasources/challenge_program_local_data_source.dart';

class ChallengeProgramRepositoryImpl implements ChallengeProgramRepository {
  ChallengeProgramRepositoryImpl(this._dataSource);

  final ChallengeProgramLocalDataSource _dataSource;
  List<ChallengeProgram>? _cache;

  Future<List<ChallengeProgram>> _loadAll() async {
    final List<ChallengeProgram>? cached = _cache;
    if (cached != null) return cached;
    final List<ChallengeProgram> loaded = await _dataSource.loadAll();
    _cache = loaded;
    return loaded;
  }

  @override
  Future<List<ChallengeProgram>> getAll() => _loadAll();

  @override
  Future<ChallengeProgram?> getById(String id) async {
    final List<ChallengeProgram> all = await _loadAll();
    for (final ChallengeProgram program in all) {
      if (program.id == id) return program;
    }
    return null;
  }
}
