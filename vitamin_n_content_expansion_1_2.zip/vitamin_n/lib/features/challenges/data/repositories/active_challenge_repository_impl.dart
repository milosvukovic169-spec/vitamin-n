import '../../../../core/database/app_database.dart';
import '../../domain/entities/active_challenge.dart';
import '../../domain/repositories/active_challenge_repository.dart';
import '../datasources/active_challenge_local_data_source.dart';

class ActiveChallengeRepositoryImpl implements ActiveChallengeRepository {
  ActiveChallengeRepositoryImpl(this._dataSource);

  final ActiveChallengeLocalDataSource _dataSource;

  ActiveChallenge _toEntity(ActiveChallengeRow row) {
    return ActiveChallenge(
      id: row.id,
      programId: row.programId,
      startedAt: row.startedAt,
    );
  }

  @override
  Future<ActiveChallenge?> getCurrent() async {
    final ActiveChallengeRow? row = await _dataSource.getMostRecentRow();
    return row == null ? null : _toEntity(row);
  }

  @override
  Future<ActiveChallenge> setActiveProgram(String programId) async {
    final ActiveChallengeRow row =
        await _dataSource.replaceWith(programId, DateTime.now());
    return _toEntity(row);
  }

  @override
  Future<void> clear() => _dataSource.clearAll();
}
