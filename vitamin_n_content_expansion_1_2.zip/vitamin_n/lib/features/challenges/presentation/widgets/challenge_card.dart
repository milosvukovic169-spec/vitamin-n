import 'package:flutter/material.dart';

import '../../../../design_system/icon_mapping.dart';
import '../../../../design_system/theme/theme_extensions.dart';
import '../../../../design_system/widgets/app_card.dart';

/// One challenge in the Challenges list. Progress is understated —
/// "5 of 14 steps completed", no bar animation, no percentage badge,
/// no streak. Locked (Premium) challenges still show their content
/// (title, description) rather than hiding behind a blank card.
class ChallengeCard extends StatelessWidget {
  const ChallengeCard({
    super.key,
    required this.title,
    required this.description,
    required this.iconName,
    required this.completedSteps,
    required this.totalSteps,
    required this.locked,
    required this.onTap,
  });

  final String title;
  final String description;
  final String iconName;
  final int completedSteps;
  final int totalSteps;
  final bool locked;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final AppColors colors = context.colors;
    final TextTheme textTheme = Theme.of(context).textTheme;

    return AppCard(
      onTap: onTap,
      child: Row(
        children: <Widget>[
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(shape: BoxShape.circle, color: colors.cream),
            child: Icon(
              ContentIconMapper.resolve(iconName),
              color: colors.sageStrong,
              size: 22,
            ),
          ),
          SizedBox(width: context.spacing.md),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Flexible(child: Text(title, style: textTheme.titleMedium)),
                    if (locked) ...<Widget>[
                      SizedBox(width: context.spacing.xs),
                      Icon(Icons.lock_outline, size: 16, color: colors.textSecondary),
                    ],
                  ],
                ),
                SizedBox(height: context.spacing.xs / 2),
                Text(description, style: textTheme.bodyMedium),
                SizedBox(height: context.spacing.xs),
                Text(
                  '$completedSteps of $totalSteps steps completed',
                  style: textTheme.bodySmall,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
