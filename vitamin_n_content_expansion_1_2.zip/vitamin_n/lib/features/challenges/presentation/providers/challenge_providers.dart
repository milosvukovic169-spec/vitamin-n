import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/database/app_database_provider.dart';
import '../../../settings/presentation/providers/settings_providers.dart';
import '../../data/datasources/active_challenge_local_data_source.dart';
import '../../data/datasources/challenge_program_local_data_source.dart';
import '../../data/repositories/active_challenge_repository_impl.dart';
import '../../data/repositories/challenge_program_repository_impl.dart';
import '../../data/repositories/challenge_progress_repository_impl.dart';
import '../../domain/entities/active_challenge.dart';
import '../../domain/repositories/active_challenge_repository.dart';
import '../../domain/repositories/challenge_program_repository.dart';
import '../../domain/repositories/challenge_progress_repository.dart';

final Provider<ChallengeProgramRepository> challengeProgramRepositoryProvider =
    Provider<ChallengeProgramRepository>((Ref ref) {
  return ChallengeProgramRepositoryImpl(ChallengeProgramLocalDataSource());
});

final Provider<ChallengeProgressRepository> challengeProgressRepositoryProvider =
    Provider<ChallengeProgressRepository>((Ref ref) {
  return ChallengeProgressRepositoryImpl(ref.watch(settingsRepositoryProvider));
});

final Provider<ActiveChallengeRepository> activeChallengeRepositoryProvider =
    Provider<ActiveChallengeRepository>((Ref ref) {
  final db = ref.watch(appDatabaseProvider);
  return ActiveChallengeRepositoryImpl(ActiveChallengeLocalDataSource(db));
});

final FutureProvider<List<ChallengeProgram>> challengeProgramsProvider =
    FutureProvider<List<ChallengeProgram>>((Ref ref) {
  return ref.watch(challengeProgramRepositoryProvider).getAll();
});

final FutureProviderFamily<Set<String>, String> challengeCompletedStepIdsProvider =
    FutureProvider.family<Set<String>, String>((Ref ref, String challengeId) {
  return ref.watch(challengeProgressRepositoryProvider).getCompletedStepIds(challengeId);
});

final FutureProvider<ActiveChallenge?> activeChallengeProvider =
    FutureProvider<ActiveChallenge?>((Ref ref) {
  return ref.watch(activeChallengeRepositoryProvider).getCurrent();
});
