/// One lightweight step in a Challenge — a short nudge, not a
/// logged event. Completion is a simple checkbox (see
/// ChallengeProgressRepository), never a streak or score.
class ChallengeStep {
  const ChallengeStep({required this.id, required this.text, required this.sortOrder});

  final String id;
  final String text;
  final int sortOrder;
}

/// A themed, non-competitive set of lightweight steps a user can
/// work through at their own pace (e.g. "Digital Boundaries").
/// Challenges use the existing Say No system — there is no separate
/// boundary-logging mechanism here, just short prompts that may
/// suggest opening Say No with a category pre-filled.
class ChallengeProgram {
  const ChallengeProgram({
    required this.id,
    required this.title,
    required this.description,
    required this.iconName,
    required this.steps,
    this.suggestedCategoryId,
  });

  final String id;
  final String title;
  final String description;
  final String iconName;
  final List<ChallengeStep> steps;

  /// If set, the "Open Say No" CTA for this challenge's steps
  /// pre-filters to this category.
  final String? suggestedCategoryId;
}

/// Challenge access, per the final monetization model: there are NO
/// Free Challenges. Every Challenge Program is Premium-only — a Free
/// user may see a challenge's title/description as a teaser (so they
/// understand what Premium includes) but can never start or progress
/// one. This intentionally has no "free ids" set; the answer is
/// always the same regardless of which challenge is asked about.
abstract final class ChallengeAccess {
  static bool isFree(String challengeId) => false;
}
