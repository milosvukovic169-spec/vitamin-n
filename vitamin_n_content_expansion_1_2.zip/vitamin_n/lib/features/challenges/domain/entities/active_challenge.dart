/// Records which ChallengeProgram the user has chosen to focus on,
/// and since when. The only mutable Challenge state — deliberately no
/// progress counter, score or streak.
class ActiveChallenge {
  const ActiveChallenge({
    required this.id,
    required this.programId,
    required this.startedAt,
  });

  final int id;
  final String programId;
  final DateTime startedAt;
}
