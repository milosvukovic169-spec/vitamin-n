/// Tracks which steps of a Challenge the user has checked off.
///
/// Deliberately minimal: a set of completed step ids per challenge,
/// nothing else. No streak, no score, no completion date history —
/// just "5 of 14 steps completed", per section 24. Backed by the
/// existing Settings key-value store (dynamic per-challenge key),
/// not a new table — this is not a separate boundary-logging system.
abstract class ChallengeProgressRepository {
  Future<Set<String>> getCompletedStepIds(String challengeId);
  Future<void> toggleStep(String challengeId, String stepId);
}
