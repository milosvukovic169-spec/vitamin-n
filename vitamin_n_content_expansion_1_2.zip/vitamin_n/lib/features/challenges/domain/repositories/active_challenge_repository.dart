import '../entities/active_challenge.dart';

abstract class ActiveChallengeRepository {
  Future<ActiveChallenge?> getCurrent();
  Future<ActiveChallenge> setActiveProgram(String programId);
  Future<void> clear();
}
