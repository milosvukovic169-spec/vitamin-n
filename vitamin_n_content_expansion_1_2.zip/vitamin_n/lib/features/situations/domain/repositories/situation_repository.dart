import '../entities/situation.dart';

/// Category-scoped by design: there is deliberately no `getAll()` or
/// global `getById()` here, because either would require loading
/// every category's content file — exactly what Phase 5's lazy
/// loading rules forbid. Every call site that needs a specific
/// situation already knows (or can know) its category id — an Entry
/// always carries both, for example — so requiring it here keeps the
/// "only load what's opened" guarantee enforceable at the type level,
/// not just by convention.
abstract class SituationRepository {
  Future<List<Situation>> getByCategoryId(String categoryId);

  Future<Situation?> getByCategoryAndId({
    required String categoryId,
    required String situationId,
  });
}
