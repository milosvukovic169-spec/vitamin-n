/// A specific, concrete situation a user might want a boundary for,
/// belonging to a Category. Pure domain entity.
class Situation {
  const Situation({
    required this.id,
    required this.categoryId,
    required this.title,
    required this.description,
    required this.sortOrder,
    this.protectedValueIds = const <String>[],
  });

  final String id;
  final String categoryId;
  final String title;
  final String description;
  final int sortOrder;

  /// 2–4 ProtectedValue ids the app pre-suggests as relevant to this
  /// situation (e.g. Overtime -> Time, Energy, Family, Personal
  /// priorities). The user still manually chooses 1–3 after I SAID
  /// NO — this is a suggestion surface only, never an automatic
  /// selection.
  final List<String> protectedValueIds;

  @override
  bool operator ==(Object other) => other is Situation && other.id == id;

  @override
  int get hashCode => id.hashCode;
}
