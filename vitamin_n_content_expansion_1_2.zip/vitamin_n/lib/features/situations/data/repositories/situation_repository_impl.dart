import '../../domain/entities/situation.dart';
import '../../domain/repositories/situation_repository.dart';
import '../datasources/situation_local_data_source.dart';

class SituationRepositoryImpl implements SituationRepository {
  SituationRepositoryImpl(this._dataSource);

  final SituationLocalDataSource _dataSource;

  /// One entry per category, built once and reused for the rest of
  /// the session — the "cache loaded category content" requirement.
  /// Each entry holds both the ordered list (for the situation
  /// picker) and an id-indexed map (so a lookup by id is O(1), never
  /// a re-scan), satisfying the "situationId -> Situation" indexing
  /// the spec calls for directly.
  final Map<String, _CategorySituations> _cache = <String, _CategorySituations>{};

  Future<_CategorySituations> _loadCategory(String categoryId) async {
    final _CategorySituations? cached = _cache[categoryId];
    if (cached != null) {
      return cached;
    }
    final List<Situation> list = await _dataSource.loadForCategory(categoryId);
    final Map<String, Situation> byId = <String, Situation>{
      for (final Situation s in list) s.id: s,
    };
    final _CategorySituations loaded = _CategorySituations(list: list, byId: byId);
    _cache[categoryId] = loaded;
    return loaded;
  }

  @override
  Future<List<Situation>> getByCategoryId(String categoryId) async {
    return (await _loadCategory(categoryId)).list;
  }

  @override
  Future<Situation?> getByCategoryAndId({
    required String categoryId,
    required String situationId,
  }) async {
    return (await _loadCategory(categoryId)).byId[situationId];
  }
}

class _CategorySituations {
  const _CategorySituations({required this.list, required this.byId});
  final List<Situation> list;
  final Map<String, Situation> byId;
}
