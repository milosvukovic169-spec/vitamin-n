/// A local notification content template. Actual scheduling/delivery
/// is a later phase's concern — this feature only provides content.
class NotificationTemplate {
  const NotificationTemplate({
    required this.id,
    required this.type,
    required this.title,
    required this.body,
    required this.sortOrder,
  });

  final String id;
  final String type;
  final String title;
  final String body;
  final int sortOrder;

  @override
  bool operator ==(Object other) =>
      other is NotificationTemplate && other.id == id;

  @override
  int get hashCode => id.hashCode;
}
