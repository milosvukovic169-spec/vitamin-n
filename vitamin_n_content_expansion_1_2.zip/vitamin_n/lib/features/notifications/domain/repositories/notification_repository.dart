import '../entities/notification_template.dart';

abstract class NotificationRepository {
  Future<List<NotificationTemplate>> getAll();
  Future<List<NotificationTemplate>> getByType(String type);
}
