import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/datasources/notification_local_data_source.dart';
import '../../data/repositories/notification_repository_impl.dart';
import '../../domain/entities/notification_template.dart';
import '../../domain/repositories/notification_repository.dart';

final Provider<NotificationRepository> notificationRepositoryProvider =
    Provider<NotificationRepository>((Ref ref) {
  return NotificationRepositoryImpl(NotificationLocalDataSource());
});

final FutureProvider<List<NotificationTemplate>> notificationTemplatesProvider =
    FutureProvider<List<NotificationTemplate>>((Ref ref) {
  return ref.watch(notificationRepositoryProvider).getAll();
});
