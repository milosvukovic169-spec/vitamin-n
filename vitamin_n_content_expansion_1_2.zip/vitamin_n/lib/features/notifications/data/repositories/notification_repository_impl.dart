import '../../domain/entities/notification_template.dart';
import '../../domain/repositories/notification_repository.dart';
import '../datasources/notification_local_data_source.dart';

class NotificationRepositoryImpl implements NotificationRepository {
  NotificationRepositoryImpl(this._dataSource);

  final NotificationLocalDataSource _dataSource;
  List<NotificationTemplate>? _cache;

  Future<List<NotificationTemplate>> _loadAll() async {
    final List<NotificationTemplate>? cached = _cache;
    if (cached != null) {
      return cached;
    }
    final List<NotificationTemplate> loaded = await _dataSource.loadAll();
    _cache = loaded;
    return loaded;
  }

  @override
  Future<List<NotificationTemplate>> getAll() => _loadAll();

  @override
  Future<List<NotificationTemplate>> getByType(String type) async {
    final List<NotificationTemplate> all = await _loadAll();
    return all.where((NotificationTemplate t) => t.type == type).toList();
  }
}
