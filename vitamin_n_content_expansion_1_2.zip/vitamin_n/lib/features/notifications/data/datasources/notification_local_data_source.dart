import '../../../../core/constants/asset_paths.dart';
import '../../../../core/json/json_asset_loader.dart';
import '../../domain/entities/notification_template.dart';

class NotificationLocalDataSource {
  NotificationLocalDataSource({
    JsonAssetLoader loader = const JsonAssetLoader(),
  }) : _loader = loader;

  final JsonAssetLoader _loader;

  Future<List<NotificationTemplate>> loadAll() async {
    final List<Map<String, dynamic>> raw =
        await _loader.loadList(AssetPaths.notifications);
    return raw.map(_parse).toList()
      ..sort((NotificationTemplate a, NotificationTemplate b) =>
          a.sortOrder.compareTo(b.sortOrder));
  }

  NotificationTemplate _parse(Map<String, dynamic> json) {
    return NotificationTemplate(
      id: json['id'] as String,
      type: json['type'] as String,
      title: json['title'] as String,
      body: json['body'] as String,
      sortOrder: json['sortOrder'] as int,
    );
  }
}
