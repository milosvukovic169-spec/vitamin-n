import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/database/app_database_provider.dart';
import '../../data/datasources/entry_local_data_source.dart';
import '../../data/repositories/entry_repository_impl.dart';
import '../../domain/entities/entry.dart';
import '../../domain/repositories/entry_repository.dart';

final Provider<EntryRepository> entryRepositoryProvider =
    Provider<EntryRepository>((Ref ref) {
  final db = ref.watch(appDatabaseProvider);
  return EntryRepositoryImpl(EntryLocalDataSource(db));
});

final FutureProvider<List<Entry>> allEntriesProvider =
    FutureProvider<List<Entry>>((Ref ref) {
  return ref.watch(entryRepositoryProvider).getAll();
});

final FutureProvider<Map<String, int>> protectedValueCountsProvider =
    FutureProvider<Map<String, int>>((Ref ref) {
  return ref.watch(entryRepositoryProvider).countByProtectedValueId();
});

final FutureProvider<Map<String, int>> categoryCountsProvider =
    FutureProvider<Map<String, int>>((Ref ref) {
  return ref.watch(entryRepositoryProvider).countByCategoryId();
});
