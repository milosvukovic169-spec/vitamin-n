import '../entities/entry.dart';

abstract class EntryRepository {
  Future<Entry> create(Entry entry);

  /// Updates an existing Entry's editable fields (protected values,
  /// custom protected value, personal reminder note). Never changes
  /// [Entry.courseId] or [Entry.createdAt] — editing a record does
  /// not turn it back into an unconfirmed event, and must never
  /// affect Course progress.
  Future<void> update(Entry entry);

  /// Deletes an Entry. This is record management only — it never
  /// restores an N token to a completed Course. The Course reflects
  /// the historical action that occurred; History is just the record
  /// of it.
  Future<void> delete(String id);

  Future<Entry?> getEntryById(String id);

  Future<List<Entry>> getAll();
  Future<List<Entry>> getRecent({int limit = 20});
  Future<List<Entry>> getByCategoryId(String categoryId);

  Future<List<Entry>> getBetween(DateTime start, DateTime end);

  /// Same as [getBetween] — named to match the Phase 4 spec's
  /// repository method naming for History/Insights call sites.
  Future<List<Entry>> getEntriesForRange(DateTime start, DateTime end);

  /// A live view of entries in [start, end) — used by History so the
  /// list updates automatically after an edit or delete without the
  /// screen needing to manually re-fetch.
  Stream<List<Entry>> watchEntriesForRange(DateTime start, DateTime end);

  /// How many entries protected each ProtectedValue id — the basis
  /// for an Insights view framed around "what was protected", never
  /// around how many times the user said no. Pass [start]/[end] to
  /// scope to a time range; omit both for all time.
  Future<Map<String, int>> getProtectedValueCounts({DateTime? start, DateTime? end});

  /// How many entries fall under each Category id, computed via a
  /// grouped SQL query rather than in Dart. Pass [start]/[end] to
  /// scope to a time range; omit both for all time.
  Future<Map<String, int>> getCategoryCounts({DateTime? start, DateTime? end});

  /// Entry counts by ISO weekday (1 = Monday .. 7 = Sunday). Pass
  /// [start]/[end] to scope to a time range; omit both for all time.
  Future<Map<int, int>> getWeekdayDistribution({DateTime? start, DateTime? end});

  // --- Deprecated aliases kept for backward compatibility with
  // existing callers (Phase 1 providers); prefer the range-aware
  // methods above for new code. ---
  Future<Map<String, int>> countByProtectedValueId();
  Future<Map<String, int>> countByCategoryId();
}
