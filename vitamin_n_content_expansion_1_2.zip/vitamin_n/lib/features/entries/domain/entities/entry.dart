/// A single completed "I SAID NO" record — the durable result of the
/// locked Say No flow. Pure domain entity: how fields are persisted
/// (JSON-encoded text column, boolean column, etc.) is entirely the
/// data layer's concern.
class Entry {
  const Entry({
    required this.id,
    required this.categoryId,
    required this.situationId,
    required this.refusalResponseId,
    required this.protectedValueIds,
    required this.customProtectedValue,
    required this.personalReminderNote,
    required this.reflectionPauseShown,
    required this.courseId,
    required this.createdAt,
  });

  final String id;
  final String categoryId;
  final String situationId;
  final String? refusalResponseId;
  final List<String> protectedValueIds;
  final String? customProtectedValue;
  final String? personalReminderNote;
  final bool reflectionPauseShown;
  final int courseId;
  final DateTime createdAt;

  /// Only exposes the fields History's Edit screen is allowed to
  /// change (protected values, custom protected value, personal
  /// reminder note). There is deliberately no way to change
  /// [categoryId], [situationId], [courseId] or [createdAt] through
  /// this — editing a record must never turn it into a different
  /// historical event or affect Course progress.
  Entry copyWithEditableFields({
    List<String>? protectedValueIds,
    String? customProtectedValue,
    bool clearCustomProtectedValue = false,
    String? personalReminderNote,
    bool clearPersonalReminderNote = false,
  }) {
    return Entry(
      id: id,
      categoryId: categoryId,
      situationId: situationId,
      refusalResponseId: refusalResponseId,
      protectedValueIds: protectedValueIds ?? this.protectedValueIds,
      customProtectedValue: clearCustomProtectedValue
          ? null
          : (customProtectedValue ?? this.customProtectedValue),
      personalReminderNote: clearPersonalReminderNote
          ? null
          : (personalReminderNote ?? this.personalReminderNote),
      reflectionPauseShown: reflectionPauseShown,
      courseId: courseId,
      createdAt: createdAt,
    );
  }
}
