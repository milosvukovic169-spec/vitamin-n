import 'dart:convert';

import 'package:drift/drift.dart' show Value;

import '../../../../core/database/app_database.dart';
import '../../domain/entities/entry.dart';
import '../../domain/repositories/entry_repository.dart';
import '../datasources/entry_local_data_source.dart';

class EntryRepositoryImpl implements EntryRepository {
  EntryRepositoryImpl(this._dataSource);

  final EntryLocalDataSource _dataSource;

  Entry _toEntity(EntryRow row) {
    final dynamic decoded = jsonDecode(row.protectedValueIds);
    return Entry(
      id: row.id,
      categoryId: row.categoryId,
      situationId: row.situationId,
      refusalResponseId: row.refusalResponseId,
      protectedValueIds:
          (decoded as List<dynamic>).map((dynamic e) => e as String).toList(),
      customProtectedValue: row.customProtectedValue,
      personalReminderNote: row.personalReminderNote,
      reflectionPauseShown: row.reflectionPauseShown,
      courseId: row.courseId,
      createdAt: row.createdAt,
    );
  }

  EntriesCompanion _toCompanion(Entry entry) {
    return EntriesCompanion.insert(
      id: entry.id,
      categoryId: entry.categoryId,
      situationId: entry.situationId,
      refusalResponseId: Value<String?>(entry.refusalResponseId),
      protectedValueIds: jsonEncode(entry.protectedValueIds),
      customProtectedValue: Value<String?>(entry.customProtectedValue),
      personalReminderNote: Value<String?>(entry.personalReminderNote),
      reflectionPauseShown: Value<bool>(entry.reflectionPauseShown),
      courseId: entry.courseId,
      createdAt: entry.createdAt,
    );
  }

  @override
  Future<Entry> create(Entry entry) async {
    await _dataSource.insertRow(_toCompanion(entry));
    return entry;
  }

  @override
  Future<void> update(Entry entry) async {
    // Editable fields only: protected values (+ custom) and personal
    // reminder note. categoryId, situationId, refusalResponseId,
    // courseId and createdAt are deliberately NOT part of this
    // companion, so an edit can never turn the entry into a
    // different historical event or touch Course attribution.
    await _dataSource.updateRow(
      entry.id,
      EntriesCompanion(
        protectedValueIds: Value<String>(jsonEncode(entry.protectedValueIds)),
        customProtectedValue: Value<String?>(entry.customProtectedValue),
        personalReminderNote: Value<String?>(entry.personalReminderNote),
      ),
    );
  }

  @override
  Future<void> delete(String id) {
    // Record management only — never touches the Courses table, so
    // deleting an old entry can never restore an N token.
    return _dataSource.deleteRow(id);
  }

  @override
  Future<Entry?> getEntryById(String id) async {
    final EntryRow? row = await _dataSource.getRowById(id);
    return row == null ? null : _toEntity(row);
  }

  @override
  Future<List<Entry>> getAll() async {
    final List<EntryRow> rows = await _dataSource.getAllRows();
    return rows.map(_toEntity).toList();
  }

  @override
  Future<List<Entry>> getRecent({int limit = 20}) async {
    final List<EntryRow> rows = await _dataSource.getRecentRows(limit);
    return rows.map(_toEntity).toList();
  }

  @override
  Future<List<Entry>> getByCategoryId(String categoryId) async {
    final List<EntryRow> rows = await _dataSource.getByCategoryIdRows(categoryId);
    return rows.map(_toEntity).toList();
  }

  @override
  Future<List<Entry>> getBetween(DateTime start, DateTime end) async {
    final List<EntryRow> rows = await _dataSource.getBetweenRows(start, end);
    return rows.map(_toEntity).toList();
  }

  @override
  Future<List<Entry>> getEntriesForRange(DateTime start, DateTime end) =>
      getBetween(start, end);

  @override
  Stream<List<Entry>> watchEntriesForRange(DateTime start, DateTime end) {
    return _dataSource
        .watchBetweenRows(start, end)
        .map((List<EntryRow> rows) => rows.map(_toEntity).toList());
  }

  @override
  Future<Map<String, int>> getProtectedValueCounts({
    DateTime? start,
    DateTime? end,
  }) async {
    // protectedValueIds is a JSON-encoded column (an entry can
    // protect 1-3 values), not a single real column, so this can't
    // be expressed as a plain SQL GROUP BY the way category counts
    // can — it's aggregated in Dart over the (already range-limited)
    // rows instead. See categoryCounts for the SQL-side equivalent.
    final List<Entry> entries = start != null && end != null
        ? await getBetween(start, end)
        : await getAll();

    final Map<String, int> counts = <String, int>{};
    for (final Entry entry in entries) {
      for (final String valueId in entry.protectedValueIds) {
        counts.update(valueId, (int count) => count + 1, ifAbsent: () => 1);
      }
    }
    return counts;
  }

  @override
  Future<Map<String, int>> getCategoryCounts({DateTime? start, DateTime? end}) {
    return _dataSource.categoryCounts(start: start, end: end);
  }

  @override
  Future<Map<int, int>> getWeekdayDistribution({
    DateTime? start,
    DateTime? end,
  }) async {
    final List<Entry> entries = start != null && end != null
        ? await getBetween(start, end)
        : await getAll();

    final Map<int, int> counts = <int, int>{};
    for (final Entry entry in entries) {
      final int weekday = entry.createdAt.weekday; // 1 = Monday .. 7 = Sunday
      counts.update(weekday, (int count) => count + 1, ifAbsent: () => 1);
    }
    return counts;
  }

  @override
  Future<Map<String, int>> countByProtectedValueId() => getProtectedValueCounts();

  @override
  Future<Map<String, int>> countByCategoryId() => getCategoryCounts();
}
