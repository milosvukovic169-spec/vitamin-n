import 'package:drift/drift.dart';

import '../../../../core/database/app_database.dart';

/// Wraps the Drift [Entries] table. Returns raw [EntryRow] objects —
/// mapping to/from the domain `Entry` entity happens in
/// `EntryRepositoryImpl`.
class EntryLocalDataSource {
  EntryLocalDataSource(this._db);

  final AppDatabase _db;

  Future<void> insertRow(EntriesCompanion companion) {
    return _db.into(_db.entries).insert(companion);
  }

  Future<void> updateRow(String id, EntriesCompanion companion) {
    return (_db.update(_db.entries)..where((tbl) => tbl.id.equals(id)))
        .write(companion);
  }

  Future<void> deleteRow(String id) {
    return (_db.delete(_db.entries)..where((tbl) => tbl.id.equals(id))).go();
  }

  Future<EntryRow?> getRowById(String id) {
    return (_db.select(_db.entries)..where((tbl) => tbl.id.equals(id)))
        .getSingleOrNull();
  }

  Future<List<EntryRow>> getAllRows() {
    return (_db.select(_db.entries)
          ..orderBy([(tbl) => OrderingTerm.desc(tbl.createdAt)]))
        .get();
  }

  Future<List<EntryRow>> getRecentRows(int limit) {
    return (_db.select(_db.entries)
          ..orderBy([(tbl) => OrderingTerm.desc(tbl.createdAt)])
          ..limit(limit))
        .get();
  }

  Future<List<EntryRow>> getByCategoryIdRows(String categoryId) {
    return (_db.select(_db.entries)
          ..where((tbl) => tbl.categoryId.equals(categoryId))
          ..orderBy([(tbl) => OrderingTerm.desc(tbl.createdAt)]))
        .get();
  }

  Future<List<EntryRow>> getBetweenRows(DateTime start, DateTime end) {
    return (_db.select(_db.entries)
          ..where((tbl) => tbl.createdAt.isBiggerOrEqualValue(start) &
              tbl.createdAt.isSmallerThanValue(end))
          ..orderBy([(tbl) => OrderingTerm.desc(tbl.createdAt)]))
        .get();
  }

  Stream<List<EntryRow>> watchBetweenRows(DateTime start, DateTime end) {
    return (_db.select(_db.entries)
          ..where((tbl) => tbl.createdAt.isBiggerOrEqualValue(start) &
              tbl.createdAt.isSmallerThanValue(end))
          ..orderBy([(tbl) => OrderingTerm.desc(tbl.createdAt)]))
        .watch();
  }

  /// Grouped SQL aggregation for category counts — a real column, so
  /// this is done in SQL rather than by fetching rows into Dart.
  /// [start]/[end] are both null for "all time", or both provided to
  /// scope the range.
  Future<Map<String, int>> categoryCounts({DateTime? start, DateTime? end}) async {
    final countExpr = _db.entries.id.count();
    final query = _db.selectOnly(_db.entries)
      ..addColumns(<Expression<Object>>[_db.entries.categoryId, countExpr])
      ..groupBy(<Expression<Object>>[_db.entries.categoryId]);

    if (start != null && end != null) {
      query.where(
        _db.entries.createdAt.isBiggerOrEqualValue(start) &
            _db.entries.createdAt.isSmallerThanValue(end),
      );
    }

    final rows = await query.get();
    return <String, int>{
      for (final row in rows)
        row.read(_db.entries.categoryId)!: row.read(countExpr)!,
    };
  }
}
