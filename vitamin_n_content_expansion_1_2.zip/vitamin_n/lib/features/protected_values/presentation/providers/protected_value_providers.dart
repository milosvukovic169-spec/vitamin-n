import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/datasources/protected_value_local_data_source.dart';
import '../../data/repositories/protected_value_repository_impl.dart';
import '../../domain/entities/protected_value.dart';
import '../../domain/repositories/protected_value_repository.dart';

final Provider<ProtectedValueRepository> protectedValueRepositoryProvider =
    Provider<ProtectedValueRepository>((Ref ref) {
  return ProtectedValueRepositoryImpl(ProtectedValueLocalDataSource());
});

final FutureProvider<List<ProtectedValue>> protectedValuesProvider =
    FutureProvider<List<ProtectedValue>>((Ref ref) {
  return ref.watch(protectedValueRepositoryProvider).getAll();
});
