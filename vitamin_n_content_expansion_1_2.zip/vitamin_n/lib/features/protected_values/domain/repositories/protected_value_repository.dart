import '../entities/protected_value.dart';

abstract class ProtectedValueRepository {
  Future<List<ProtectedValue>> getAll();
  Future<List<ProtectedValue>> getByIds(List<String> ids);
}
