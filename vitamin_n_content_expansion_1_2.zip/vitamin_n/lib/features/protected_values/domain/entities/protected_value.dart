/// A value a user can select as "what this No protected"
/// (e.g. "My Time", "My Peace").
class ProtectedValue {
  const ProtectedValue({
    required this.id,
    required this.label,
    required this.iconName,
    required this.sortOrder,
  });

  final String id;
  final String label;
  final String iconName;
  final int sortOrder;

  @override
  bool operator ==(Object other) => other is ProtectedValue && other.id == id;

  @override
  int get hashCode => id.hashCode;
}
