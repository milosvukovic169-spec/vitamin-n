import '../../../../core/constants/asset_paths.dart';
import '../../../../core/json/json_asset_loader.dart';
import '../../domain/entities/protected_value.dart';

class ProtectedValueLocalDataSource {
  ProtectedValueLocalDataSource({
    JsonAssetLoader loader = const JsonAssetLoader(),
  }) : _loader = loader;

  final JsonAssetLoader _loader;

  Future<List<ProtectedValue>> loadAll() async {
    final List<Map<String, dynamic>> raw =
        await _loader.loadList(AssetPaths.protectedValues);
    return raw.map(_parse).toList()
      ..sort((ProtectedValue a, ProtectedValue b) =>
          a.sortOrder.compareTo(b.sortOrder));
  }

  ProtectedValue _parse(Map<String, dynamic> json) {
    return ProtectedValue(
      id: json['id'] as String,
      label: json['label'] as String,
      iconName: json['iconName'] as String,
      sortOrder: json['sortOrder'] as int,
    );
  }
}
