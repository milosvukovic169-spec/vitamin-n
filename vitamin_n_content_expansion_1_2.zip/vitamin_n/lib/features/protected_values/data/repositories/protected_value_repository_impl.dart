import '../../domain/entities/protected_value.dart';
import '../../domain/repositories/protected_value_repository.dart';
import '../datasources/protected_value_local_data_source.dart';

class ProtectedValueRepositoryImpl implements ProtectedValueRepository {
  ProtectedValueRepositoryImpl(this._dataSource);

  final ProtectedValueLocalDataSource _dataSource;
  List<ProtectedValue>? _cache;

  Future<List<ProtectedValue>> _loadAll() async {
    final List<ProtectedValue>? cached = _cache;
    if (cached != null) {
      return cached;
    }
    final List<ProtectedValue> loaded = await _dataSource.loadAll();
    _cache = loaded;
    return loaded;
  }

  @override
  Future<List<ProtectedValue>> getAll() => _loadAll();

  @override
  Future<List<ProtectedValue>> getByIds(List<String> ids) async {
    final List<ProtectedValue> all = await _loadAll();
    final Set<String> idSet = ids.toSet();
    return all.where((ProtectedValue v) => idSet.contains(v.id)).toList();
  }
}
