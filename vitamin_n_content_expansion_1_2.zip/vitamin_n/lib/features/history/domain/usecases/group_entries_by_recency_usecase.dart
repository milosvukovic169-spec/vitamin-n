import '../../../entries/domain/entities/entry.dart';

enum HistoryRecencyGroup { today, yesterday, earlierThisWeek, earlierThisMonth, older }

class GroupedHistoryEntries {
  const GroupedHistoryEntries({required this.group, required this.entries});

  final HistoryRecencyGroup group;
  final List<Entry> entries;
}

/// Groups entries into Today / Yesterday / Earlier this week /
/// Earlier this month / Older, per the founder spec's History
/// grouping.
///
/// Pure and deterministic (`now` is a parameter), and assumes
/// [entries] is already sorted newest-first (as every EntryRepository
/// query returns) — it never re-sorts, just partitions.
class GroupEntriesByRecencyUseCase {
  const GroupEntriesByRecencyUseCase();

  List<GroupedHistoryEntries> call(List<Entry> entries, {DateTime? now}) {
    final DateTime reference = now ?? DateTime.now();
    final DateTime startOfToday =
        DateTime(reference.year, reference.month, reference.day);
    final DateTime startOfYesterday = startOfToday.subtract(const Duration(days: 1));
    final DateTime startOfWeek =
        startOfToday.subtract(Duration(days: startOfToday.weekday - 1));
    final DateTime startOfMonth = DateTime(reference.year, reference.month);

    final Map<HistoryRecencyGroup, List<Entry>> buckets = <HistoryRecencyGroup, List<Entry>>{
      for (final HistoryRecencyGroup group in HistoryRecencyGroup.values) group: <Entry>[],
    };

    for (final Entry entry in entries) {
      final DateTime createdAt = entry.createdAt;
      if (!createdAt.isBefore(startOfToday)) {
        buckets[HistoryRecencyGroup.today]!.add(entry);
      } else if (!createdAt.isBefore(startOfYesterday)) {
        buckets[HistoryRecencyGroup.yesterday]!.add(entry);
      } else if (!createdAt.isBefore(startOfWeek)) {
        buckets[HistoryRecencyGroup.earlierThisWeek]!.add(entry);
      } else if (!createdAt.isBefore(startOfMonth)) {
        buckets[HistoryRecencyGroup.earlierThisMonth]!.add(entry);
      } else {
        buckets[HistoryRecencyGroup.older]!.add(entry);
      }
    }

    return <GroupedHistoryEntries>[
      for (final HistoryRecencyGroup group in HistoryRecencyGroup.values)
        if (buckets[group]!.isNotEmpty)
          GroupedHistoryEntries(group: group, entries: buckets[group]!),
    ];
  }
}
