/// Formats an entry's timestamp for display in History, per the
/// founder spec's "Today, 14:35" style. Pure and deterministic (`now`
/// is a parameter) so it's testable without depending on the clock.
String formatEntryTimestamp(DateTime createdAt, {DateTime? now}) {
  final DateTime reference = now ?? DateTime.now();
  final DateTime startOfToday =
      DateTime(reference.year, reference.month, reference.day);
  final DateTime startOfYesterday = startOfToday.subtract(const Duration(days: 1));
  final DateTime entryDay = DateTime(createdAt.year, createdAt.month, createdAt.day);

  final String time =
      '${createdAt.hour.toString().padLeft(2, '0')}:${createdAt.minute.toString().padLeft(2, '0')}';

  if (entryDay == startOfToday) {
    return 'Today, $time';
  }
  if (entryDay == startOfYesterday) {
    return 'Yesterday, $time';
  }

  const List<String> months = <String>[
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
  ];
  final String monthDay = '${createdAt.day} ${months[createdAt.month - 1]}';

  if (createdAt.year != reference.year) {
    return '$monthDay ${createdAt.year}, $time';
  }
  return '$monthDay, $time';
}
