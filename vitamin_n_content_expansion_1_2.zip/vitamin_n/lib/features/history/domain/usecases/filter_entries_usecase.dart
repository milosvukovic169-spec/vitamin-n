import '../../../entries/domain/entities/entry.dart';
import '../entities/history_filter.dart';

/// Applies a [HistoryFilter] to an already-fetched list of entries.
///
/// Pure and deterministic (takes `now` as a parameter rather than
/// reading `DateTime.now()` internally) so it's fully unit-testable
/// without any clock or database dependency.
class FilterEntriesUseCase {
  const FilterEntriesUseCase();

  List<Entry> call(List<Entry> entries, HistoryFilter filter, {DateTime? now}) {
    final DateTime reference = now ?? DateTime.now();

    switch (filter.type) {
      case HistoryFilterType.all:
        return entries;

      case HistoryFilterType.week:
        final DateTime startOfWeek = _startOfWeek(reference);
        return entries
            .where((Entry e) => !e.createdAt.isBefore(startOfWeek))
            .toList();

      case HistoryFilterType.month:
        final DateTime startOfMonth = DateTime(reference.year, reference.month);
        return entries
            .where((Entry e) => !e.createdAt.isBefore(startOfMonth))
            .toList();

      case HistoryFilterType.category:
        return entries
            .where((Entry e) => e.categoryId == filter.categoryId)
            .toList();

      case HistoryFilterType.protectedValue:
        return entries
            .where((Entry e) =>
                e.protectedValueIds.contains(filter.protectedValueId))
            .toList();
    }
  }

  DateTime _startOfWeek(DateTime reference) {
    final DateTime startOfDay =
        DateTime(reference.year, reference.month, reference.day);
    // DateTime.weekday: 1 = Monday .. 7 = Sunday.
    return startOfDay.subtract(Duration(days: startOfDay.weekday - 1));
  }
}
