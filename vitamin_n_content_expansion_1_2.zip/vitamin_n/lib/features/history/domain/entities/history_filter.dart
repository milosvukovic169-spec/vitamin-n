/// The lightweight filter applied to the History list.
enum HistoryFilterType { all, week, month, category, protectedValue }

class HistoryFilter {
  const HistoryFilter._({
    required this.type,
    this.categoryId,
    this.protectedValueId,
  });

  final HistoryFilterType type;
  final String? categoryId;
  final String? protectedValueId;

  static const HistoryFilter all = HistoryFilter._(type: HistoryFilterType.all);
  static const HistoryFilter week = HistoryFilter._(type: HistoryFilterType.week);
  static const HistoryFilter month = HistoryFilter._(type: HistoryFilterType.month);

  factory HistoryFilter.byCategory(String categoryId) {
    return HistoryFilter._(type: HistoryFilterType.category, categoryId: categoryId);
  }

  factory HistoryFilter.byProtectedValue(String protectedValueId) {
    return HistoryFilter._(
      type: HistoryFilterType.protectedValue,
      protectedValueId: protectedValueId,
    );
  }

  bool get isAll => type == HistoryFilterType.all;

  @override
  bool operator ==(Object other) {
    return other is HistoryFilter &&
        other.type == type &&
        other.categoryId == categoryId &&
        other.protectedValueId == protectedValueId;
  }

  @override
  int get hashCode => Object.hash(type, categoryId, protectedValueId);
}
