import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../design_system/theme/theme_extensions.dart';
import '../../../entries/domain/entities/entry.dart';
import '../../domain/usecases/group_entries_by_recency_usecase.dart';
import '../providers/history_providers.dart';
import '../widgets/history_entry_card.dart';
import '../widgets/history_filter_sheet.dart';
import 'entry_detail_screen.dart';

String _groupLabel(HistoryRecencyGroup group) {
  switch (group) {
    case HistoryRecencyGroup.today:
      return 'Today';
    case HistoryRecencyGroup.yesterday:
      return 'Yesterday';
    case HistoryRecencyGroup.earlierThisWeek:
      return 'Earlier this week';
    case HistoryRecencyGroup.earlierThisMonth:
      return 'Earlier this month';
    case HistoryRecencyGroup.older:
      return 'Older';
  }
}

/// One flattened row for the lazily-built list: either a section
/// header or an entry. Flattening once (rather than nesting a
/// ListView per group) is what lets ListView.builder stay lazy across
/// the whole History list, however many groups or entries there are.
sealed class _HistoryListItem {}

class _HeaderItem extends _HistoryListItem {
  _HeaderItem(this.label);
  final String label;
}

class _EntryItem extends _HistoryListItem {
  _EntryItem(this.entry);
  final Entry entry;
}

List<_HistoryListItem> _flatten(List<GroupedHistoryEntries> groups) {
  final List<_HistoryListItem> items = <_HistoryListItem>[];
  for (final GroupedHistoryEntries group in groups) {
    items.add(_HeaderItem(_groupLabel(group.group)));
    for (final Entry entry in group.entries) {
      items.add(_EntryItem(entry));
    }
  }
  return items;
}

class HistoryScreen extends ConsumerWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final TextTheme textTheme = Theme.of(context).textTheme;
    final AsyncValue<List<GroupedHistoryEntries>> groupedAsync =
        ref.watch(groupedHistoryProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('History'),
        actions: <Widget>[
          IconButton(
            icon: const Icon(Icons.tune),
            tooltip: 'Filter',
            onPressed: () => showHistoryFilterSheet(context),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Padding(
              padding: EdgeInsets.fromLTRB(
                context.spacing.lg,
                context.spacing.sm,
                context.spacing.lg,
                context.spacing.md,
              ),
              child: Text(
                'Your protected choices, over time.',
                style: textTheme.bodyMedium,
              ),
            ),
            Expanded(
              child: groupedAsync.when(
                data: (List<GroupedHistoryEntries> groups) {
                  if (groups.isEmpty) {
                    return _HistoryEmptyState(textTheme: textTheme);
                  }
                  final List<_HistoryListItem> items = _flatten(groups);
                  return ListView.builder(
                    padding: EdgeInsets.symmetric(horizontal: context.spacing.lg),
                    itemCount: items.length,
                    itemBuilder: (BuildContext context, int index) {
                      final _HistoryListItem item = items[index];
                      if (item is _HeaderItem) {
                        return Padding(
                          padding: EdgeInsets.only(
                            top: context.spacing.md,
                            bottom: context.spacing.sm,
                          ),
                          child: Text(item.label, style: textTheme.labelLarge),
                        );
                      }
                      final Entry entry = (item as _EntryItem).entry;
                      return Padding(
                        padding: EdgeInsets.only(bottom: context.spacing.sm),
                        child: HistoryEntryCard(
                          entry: entry,
                          onTap: () {
                            Navigator.of(context).push<void>(
                              MaterialPageRoute<void>(
                                builder: (_) => EntryDetailScreen(entryId: entry.id),
                              ),
                            );
                          },
                        ),
                      );
                    },
                  );
                },
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (Object error, StackTrace stackTrace) =>
                    Center(child: Text('Could not load your History: $error')),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HistoryEmptyState extends StatelessWidget {
  const _HistoryEmptyState({required this.textTheme});

  final TextTheme textTheme;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(context.spacing.xl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Text(
              'Your protected choices will appear here.',
              style: textTheme.titleMedium,
              textAlign: TextAlign.center,
            ),
            SizedBox(height: context.spacing.sm),
            Text(
              'Each time you keep a boundary, Vitamin N will remember '
              'what mattered.',
              style: textTheme.bodyMedium,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
