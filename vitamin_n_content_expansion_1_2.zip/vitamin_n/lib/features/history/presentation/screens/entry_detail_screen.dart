import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../design_system/theme/theme_extensions.dart';
import '../../../../design_system/widgets/app_card.dart';
import '../../../../design_system/widgets/secondary_button.dart';
import '../../../categories/domain/entities/category.dart';
import '../../../categories/presentation/providers/category_providers.dart';
import '../../../entries/domain/entities/entry.dart';
import '../../../entries/presentation/providers/entry_providers.dart';
import '../../../insights/presentation/providers/insights_providers.dart';
import '../../../refusal_responses/domain/entities/refusal_response.dart';
import '../../../refusal_responses/presentation/providers/refusal_response_providers.dart';
import '../../../situations/domain/entities/situation.dart';
import '../../../situations/presentation/providers/situation_providers.dart';
import '../../domain/usecases/format_entry_timestamp.dart';
import '../providers/history_providers.dart';
import 'edit_entry_screen.dart';

/// Shows one BoundaryEntry's full detail. Read-only display plus
/// Edit and Delete — no journaling, no additional data entry beyond
/// what the flow already captured.
class EntryDetailScreen extends ConsumerWidget {
  const EntryDetailScreen({super.key, required this.entryId});

  final String entryId;

  Future<void> _confirmDelete(BuildContext context, WidgetRef ref) async {
    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          backgroundColor: context.colors.surface,
          shape: RoundedRectangleBorder(borderRadius: context.radius.lgRadius),
          title: const Text('Delete this entry?'),
          content: const Text('This removes it from your History and Insights.'),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: const Text('Delete'),
            ),
          ],
        );
      },
    );

    if (confirmed != true) return;

    try {
      // Record management only: this never touches Course progress,
      // so no N token is restored by deleting an old entry.
      await ref.read(entryRepositoryProvider).delete(entryId);
      ref.invalidate(allEntriesStreamProvider);
      ref.invalidate(insightsAggregatesProvider);

      if (context.mounted) Navigator.of(context).pop();
    } catch (_) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("Couldn't delete this entry. Please try again."),
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AsyncValue<Entry?> entryAsync = ref.watch(entryByIdProvider(entryId));

    return Scaffold(
      appBar: AppBar(title: const Text('Entry')),
      body: SafeArea(
        child: entryAsync.when(
          data: (Entry? entry) {
            if (entry == null) {
              return const Center(child: Text('This entry no longer exists.'));
            }
            return _EntryDetailBody(
              entry: entry,
              onEdit: () async {
                await Navigator.of(context).push<void>(
                  MaterialPageRoute<void>(
                    builder: (_) => EditEntryScreen(entryId: entry.id),
                  ),
                );
                ref.invalidate(entryByIdProvider(entryId));
              },
              onDelete: () => _confirmDelete(context, ref),
            );
          },
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (Object error, StackTrace stackTrace) =>
              Center(child: Text('Could not load this entry: $error')),
        ),
      ),
    );
  }
}

class _EntryDetailBody extends ConsumerWidget {
  const _EntryDetailBody({
    required this.entry,
    required this.onEdit,
    required this.onDelete,
  });

  final Entry entry;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final TextTheme textTheme = Theme.of(context).textTheme;
    final AsyncValue<Category?> categoryAsync =
        ref.watch(categoryByIdProvider(entry.categoryId));
    final AsyncValue<Situation?> situationAsync =
        ref.watch(situationByCategoryAndIdProvider(
          (categoryId: entry.categoryId, situationId: entry.situationId),
        ));
    final AsyncValue<Map<String, String>> labelsAsync =
        ref.watch(protectedValueLabelsProvider);
    final AsyncValue<List<RefusalResponse>> responsesAsync =
        ref.watch(refusalResponsesForSituationProvider(
          (categoryId: entry.categoryId, situationId: entry.situationId),
        ));

    final Map<String, String> labels = labelsAsync.value ?? const <String, String>{};
    final List<String> protectedLabels = <String>[
      for (final String id in entry.protectedValueIds)
        if (labels[id] != null) labels[id]!,
      if (entry.customProtectedValue != null &&
          entry.customProtectedValue!.trim().isNotEmpty)
        entry.customProtectedValue!.trim(),
    ];

    String? responseText;
    final List<RefusalResponse>? responses = responsesAsync.value;
    if (responses != null && entry.refusalResponseId != null) {
      for (final RefusalResponse response in responses) {
        if (response.id == entry.refusalResponseId) {
          responseText = response.text;
          break;
        }
      }
    }

    return ListView(
      padding: EdgeInsets.all(context.spacing.lg),
      children: <Widget>[
        Text(categoryAsync.value?.name ?? '', style: textTheme.bodyMedium),
        Text(situationAsync.value?.title ?? '', style: textTheme.headlineMedium),
        SizedBox(height: context.spacing.xs),
        Text(formatEntryTimestamp(entry.createdAt), style: textTheme.bodyMedium),
        SizedBox(height: context.spacing.lg),
        if (responseText != null) ...<Widget>[
          Text('Response used', style: textTheme.titleSmall),
          SizedBox(height: context.spacing.xs),
          AppCard(child: Text(responseText, style: textTheme.bodyLarge)),
          SizedBox(height: context.spacing.lg),
        ],
        if (protectedLabels.isNotEmpty) ...<Widget>[
          Text('Protected', style: textTheme.titleSmall),
          SizedBox(height: context.spacing.xs),
          AppCard(child: Text(protectedLabels.join(' · '), style: textTheme.bodyLarge)),
          SizedBox(height: context.spacing.lg),
        ],
        if (entry.personalReminderNote != null &&
            entry.personalReminderNote!.trim().isNotEmpty) ...<Widget>[
          Text('Personal reminder', style: textTheme.titleSmall),
          SizedBox(height: context.spacing.xs),
          AppCard(child: Text(entry.personalReminderNote!, style: textTheme.bodyLarge)),
          SizedBox(height: context.spacing.lg),
        ],
        Row(
          children: <Widget>[
            Expanded(child: SecondaryButton(label: 'Edit', onPressed: onEdit)),
            SizedBox(width: context.spacing.md),
            Expanded(child: SecondaryButton(label: 'Delete', onPressed: onDelete)),
          ],
        ),
      ],
    );
  }
}
