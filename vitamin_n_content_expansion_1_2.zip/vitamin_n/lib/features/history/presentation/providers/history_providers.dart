import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../entries/domain/entities/entry.dart';
import '../../../entries/presentation/providers/entry_providers.dart';
import '../../../protected_values/domain/entities/protected_value.dart';
import '../../../protected_values/presentation/providers/protected_value_providers.dart';
import '../../domain/entities/history_filter.dart';
import '../../domain/usecases/filter_entries_usecase.dart';
import '../../domain/usecases/group_entries_by_recency_usecase.dart';

/// A live view of every entry, oldest bound left effectively
/// unbounded — used as the single source History filters/groups from
/// in Dart. Using a Stream (rather than a one-shot Future) means an
/// edit or delete elsewhere immediately reflects here without the
/// screen needing to manually refresh anything.
final StreamProvider<List<Entry>> allEntriesStreamProvider =
    StreamProvider<List<Entry>>((Ref ref) {
  final repository = ref.watch(entryRepositoryProvider);
  return repository.watchEntriesForRange(DateTime(2000), DateTime(2100));
});

class HistoryFilterController extends Notifier<HistoryFilter> {
  @override
  HistoryFilter build() => HistoryFilter.all;

  void setAll() => state = HistoryFilter.all;
  void setWeek() => state = HistoryFilter.week;
  void setMonth() => state = HistoryFilter.month;
  void setCategory(String categoryId) => state = HistoryFilter.byCategory(categoryId);
  void setProtectedValue(String valueId) =>
      state = HistoryFilter.byProtectedValue(valueId);
}

final NotifierProvider<HistoryFilterController, HistoryFilter>
    historyFilterControllerProvider =
    NotifierProvider<HistoryFilterController, HistoryFilter>(
        HistoryFilterController.new);

const FilterEntriesUseCase _filterEntries = FilterEntriesUseCase();
const GroupEntriesByRecencyUseCase _groupEntries = GroupEntriesByRecencyUseCase();

/// The filtered, grouped History list — recomputed whenever either
/// the live entry stream or the selected filter changes. Widgets
/// never filter or group entries themselves; this is the one place
/// that does.
final Provider<AsyncValue<List<GroupedHistoryEntries>>> groupedHistoryProvider =
    Provider<AsyncValue<List<GroupedHistoryEntries>>>((Ref ref) {
  final AsyncValue<List<Entry>> entriesAsync = ref.watch(allEntriesStreamProvider);
  final HistoryFilter filter = ref.watch(historyFilterControllerProvider);

  return entriesAsync.whenData((List<Entry> entries) {
    final List<Entry> filtered = _filterEntries(entries, filter);
    return _groupEntries(filtered);
  });
});

final FutureProviderFamily<Entry?, String> entryByIdProvider =
    FutureProvider.family<Entry?, String>((Ref ref, String id) {
  return ref.watch(entryRepositoryProvider).getEntryById(id);
});

/// id -> label for every ProtectedValue, resolved once and shared by
/// every entry card rather than each card fetching independently.
final FutureProvider<Map<String, String>> protectedValueLabelsProvider =
    FutureProvider<Map<String, String>>((Ref ref) async {
  final List<ProtectedValue> values =
      await ref.watch(protectedValueRepositoryProvider).getAll();
  return <String, String>{for (final ProtectedValue v in values) v.id: v.label};
});
