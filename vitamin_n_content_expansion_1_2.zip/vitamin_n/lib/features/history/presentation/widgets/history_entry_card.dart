import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../design_system/theme/theme_extensions.dart';
import '../../../../design_system/widgets/app_card.dart';
import '../../../categories/domain/entities/category.dart';
import '../../../categories/presentation/providers/category_providers.dart';
import '../../../entries/domain/entities/entry.dart';
import '../../../situations/domain/entities/situation.dart';
import '../../../situations/presentation/providers/situation_providers.dart';
import '../../domain/usecases/format_entry_timestamp.dart';
import '../providers/history_providers.dart';

/// One row in the History list. Deliberately does not show any
/// numbering ("Success #24") — just what was protected and when.
class HistoryEntryCard extends ConsumerWidget {
  const HistoryEntryCard({super.key, required this.entry, required this.onTap});

  final Entry entry;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final TextTheme textTheme = Theme.of(context).textTheme;
    final AsyncValue<Category?> categoryAsync =
        ref.watch(categoryByIdProvider(entry.categoryId));
    final AsyncValue<Situation?> situationAsync =
        ref.watch(situationByCategoryAndIdProvider(
          (categoryId: entry.categoryId, situationId: entry.situationId),
        ));
    final AsyncValue<Map<String, String>> labelsAsync =
        ref.watch(protectedValueLabelsProvider);

    final String categoryName = categoryAsync.value?.name ?? '';
    final String situationTitle = situationAsync.value?.title ?? '';
    final Map<String, String> labels = labelsAsync.value ?? const <String, String>{};

    final List<String> protectedLabels = <String>[
      for (final String id in entry.protectedValueIds)
        if (labels[id] != null) labels[id]!,
      if (entry.customProtectedValue != null &&
          entry.customProtectedValue!.trim().isNotEmpty)
        entry.customProtectedValue!.trim(),
    ];

    return AppCard(
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          if (categoryName.isNotEmpty) Text(categoryName, style: textTheme.bodySmall),
          if (situationTitle.isNotEmpty)
            Text(situationTitle, style: textTheme.titleMedium),
          if (protectedLabels.isNotEmpty) ...<Widget>[
            SizedBox(height: context.spacing.sm),
            Text('Protected:', style: textTheme.bodySmall),
            Text(protectedLabels.join(' · '), style: textTheme.bodyMedium),
          ],
          SizedBox(height: context.spacing.sm),
          Text(
            formatEntryTimestamp(entry.createdAt),
            style: textTheme.bodySmall,
          ),
        ],
      ),
    );
  }
}
