import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../design_system/theme/theme_extensions.dart';
import '../../../categories/domain/entities/category.dart';
import '../../../categories/presentation/providers/category_providers.dart';
import '../../../protected_values/domain/entities/protected_value.dart';
import '../../../protected_values/presentation/providers/protected_value_providers.dart';
import '../providers/history_providers.dart';

Future<void> showHistoryFilterSheet(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (BuildContext context) => const _HistoryFilterSheet(),
  );
}

enum _SheetView { main, category, protectedValue }

class _HistoryFilterSheet extends ConsumerStatefulWidget {
  const _HistoryFilterSheet();

  @override
  ConsumerState<_HistoryFilterSheet> createState() => _HistoryFilterSheetState();
}

class _HistoryFilterSheetState extends ConsumerState<_HistoryFilterSheet> {
  _SheetView _view = _SheetView.main;

  @override
  Widget build(BuildContext context) {
    final AppColors colors = context.colors;

    return SafeArea(
      child: Container(
        decoration: BoxDecoration(
          color: colors.surface,
          borderRadius: BorderRadius.only(
            topLeft: context.radius.xlRadius.topLeft,
            topRight: context.radius.xlRadius.topRight,
          ),
        ),
        padding: EdgeInsets.fromLTRB(
          context.spacing.lg,
          context.spacing.sm,
          context.spacing.lg,
          context.spacing.lg,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Center(
              child: Container(
                width: 40,
                height: 4,
                margin: EdgeInsets.only(bottom: context.spacing.lg),
                decoration: BoxDecoration(
                  color: colors.border,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            _buildBody(context),
          ],
        ),
      ),
    );
  }

  Widget _buildBody(BuildContext context) {
    switch (_view) {
      case _SheetView.main:
        return _MainFilterList(
          onSelectAll: () {
            ref.read(historyFilterControllerProvider.notifier).setAll();
            Navigator.of(context).pop();
          },
          onSelectWeek: () {
            ref.read(historyFilterControllerProvider.notifier).setWeek();
            Navigator.of(context).pop();
          },
          onSelectMonth: () {
            ref.read(historyFilterControllerProvider.notifier).setMonth();
            Navigator.of(context).pop();
          },
          onSelectCategory: () => setState(() => _view = _SheetView.category),
          onSelectProtectedValue: () =>
              setState(() => _view = _SheetView.protectedValue),
        );
      case _SheetView.category:
        return _CategoryFilterList(
          onBack: () => setState(() => _view = _SheetView.main),
          onSelect: (String id) {
            ref.read(historyFilterControllerProvider.notifier).setCategory(id);
            Navigator.of(context).pop();
          },
        );
      case _SheetView.protectedValue:
        return _ProtectedValueFilterList(
          onBack: () => setState(() => _view = _SheetView.main),
          onSelect: (String id) {
            ref
                .read(historyFilterControllerProvider.notifier)
                .setProtectedValue(id);
            Navigator.of(context).pop();
          },
        );
    }
  }
}

class _MainFilterList extends StatelessWidget {
  const _MainFilterList({
    required this.onSelectAll,
    required this.onSelectWeek,
    required this.onSelectMonth,
    required this.onSelectCategory,
    required this.onSelectProtectedValue,
  });

  final VoidCallback onSelectAll;
  final VoidCallback onSelectWeek;
  final VoidCallback onSelectMonth;
  final VoidCallback onSelectCategory;
  final VoidCallback onSelectProtectedValue;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text('Filter History', style: Theme.of(context).textTheme.titleLarge),
        SizedBox(height: context.spacing.sm),
        _FilterTile(label: 'All', onTap: onSelectAll),
        _FilterTile(label: 'This week', onTap: onSelectWeek),
        _FilterTile(label: 'This month', onTap: onSelectMonth),
        _FilterTile(label: 'By category', onTap: onSelectCategory, showChevron: true),
        _FilterTile(
          label: 'By protected value',
          onTap: onSelectProtectedValue,
          showChevron: true,
        ),
      ],
    );
  }
}

class _CategoryFilterList extends ConsumerWidget {
  const _CategoryFilterList({required this.onBack, required this.onSelect});

  final VoidCallback onBack;
  final ValueChanged<String> onSelect;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AsyncValue<List<Category>> categoriesAsync = ref.watch(categoriesProvider);

    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        _SheetSubHeader(title: 'By category', onBack: onBack),
        categoriesAsync.when(
          data: (List<Category> categories) => Column(
            children: <Widget>[
              for (final Category category in categories)
                _FilterTile(label: category.name, onTap: () => onSelect(category.id)),
            ],
          ),
          loading: () => const Padding(
            padding: EdgeInsets.symmetric(vertical: 24),
            child: Center(child: CircularProgressIndicator()),
          ),
          error: (Object error, StackTrace stackTrace) =>
              Text('Could not load categories: $error'),
        ),
      ],
    );
  }
}

class _ProtectedValueFilterList extends ConsumerWidget {
  const _ProtectedValueFilterList({required this.onBack, required this.onSelect});

  final VoidCallback onBack;
  final ValueChanged<String> onSelect;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AsyncValue<List<ProtectedValue>> valuesAsync =
        ref.watch(protectedValuesProvider);

    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        _SheetSubHeader(title: 'By protected value', onBack: onBack),
        valuesAsync.when(
          data: (List<ProtectedValue> values) => Column(
            children: <Widget>[
              for (final ProtectedValue value in values)
                _FilterTile(label: value.label, onTap: () => onSelect(value.id)),
            ],
          ),
          loading: () => const Padding(
            padding: EdgeInsets.symmetric(vertical: 24),
            child: Center(child: CircularProgressIndicator()),
          ),
          error: (Object error, StackTrace stackTrace) =>
              Text('Could not load protected values: $error'),
        ),
      ],
    );
  }
}

class _SheetSubHeader extends StatelessWidget {
  const _SheetSubHeader({required this.title, required this.onBack});

  final String title;
  final VoidCallback onBack;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        IconButton(
          onPressed: onBack,
          icon: const Icon(Icons.arrow_back),
          constraints: const BoxConstraints(minWidth: 48, minHeight: 48),
        ),
        Text(title, style: Theme.of(context).textTheme.titleLarge),
      ],
    );
  }
}

class _FilterTile extends StatelessWidget {
  const _FilterTile({
    required this.label,
    required this.onTap,
    this.showChevron = false,
  });

  final String label;
  final VoidCallback onTap;
  final bool showChevron;

  @override
  Widget build(BuildContext context) {
    return Semantics(
      button: true,
      label: label,
      child: InkWell(
        onTap: onTap,
        child: Container(
          constraints: const BoxConstraints(minHeight: 48),
          padding: EdgeInsets.symmetric(vertical: context.spacing.sm),
          child: Row(
            children: <Widget>[
              Expanded(
                child: Text(label, style: Theme.of(context).textTheme.bodyLarge),
              ),
              if (showChevron)
                Icon(Icons.chevron_right, color: context.colors.textSecondary),
            ],
          ),
        ),
      ),
    );
  }
}
