import '../../../../core/database/app_database.dart';

class SettingsLocalDataSource {
  SettingsLocalDataSource(this._db);

  final AppDatabase _db;

  Future<SettingRow?> findRow(String key) {
    return (_db.select(_db.settings)..where((tbl) => tbl.key.equals(key)))
        .getSingleOrNull();
  }

  Future<void> upsert(String key, String value) {
    return _db.into(_db.settings).insertOnConflictUpdate(
          SettingsCompanion.insert(key: key, value: value),
        );
  }

  Future<void> deleteByKey(String key) {
    return (_db.delete(_db.settings)..where((tbl) => tbl.key.equals(key))).go();
  }
}
