import '../../domain/repositories/settings_repository.dart';
import '../datasources/settings_local_data_source.dart';

class SettingsRepositoryImpl implements SettingsRepository {
  SettingsRepositoryImpl(this._dataSource);

  final SettingsLocalDataSource _dataSource;

  @override
  Future<String?> getString(String key) async {
    final row = await _dataSource.findRow(key);
    return row?.value;
  }

  @override
  Future<void> setString(String key, String value) {
    return _dataSource.upsert(key, value);
  }

  @override
  Future<bool> getBool(String key, {bool defaultValue = false}) async {
    final String? raw = await getString(key);
    if (raw == null) {
      return defaultValue;
    }
    return raw == 'true';
  }

  @override
  Future<void> setBool(String key, bool value) {
    return setString(key, value ? 'true' : 'false');
  }

  @override
  Future<int> getInt(String key, {int defaultValue = 0}) async {
    final String? raw = await getString(key);
    if (raw == null) {
      return defaultValue;
    }
    return int.tryParse(raw) ?? defaultValue;
  }

  @override
  Future<void> setInt(String key, int value) {
    return setString(key, value.toString());
  }

  @override
  Future<void> remove(String key) {
    return _dataSource.deleteByKey(key);
  }
}
