import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:package_info_plus/package_info_plus.dart';

import '../../../../core/app_info/app_info_provider.dart';
import '../../../../design_system/theme/theme_extensions.dart';

class AboutScreen extends ConsumerWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppColors colors = context.colors;
    final TextTheme textTheme = Theme.of(context).textTheme;
    final AsyncValue<PackageInfo> packageInfoAsync = ref.watch(packageInfoProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('About Vitamin N')),
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.all(context.spacing.lg),
          children: <Widget>[
            Center(
              child: Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(shape: BoxShape.circle, color: colors.cream),
                child: Icon(Icons.spa_outlined, color: colors.sageStrong, size: 28),
              ),
            ),
            SizedBox(height: context.spacing.md),
            Text('Vitamin N', style: textTheme.headlineMedium, textAlign: TextAlign.center),
            Text(
              'The daily dose of No.',
              style: textTheme.bodyMedium,
              textAlign: TextAlign.center,
            ),
            SizedBox(height: context.spacing.xl),
            Text('What is Vitamin N?', style: textTheme.titleMedium),
            SizedBox(height: context.spacing.sm),
            Text(
              'Vitamin N helps you build healthier everyday boundaries. It '
              'does not measure productivity. It does not measure time. It '
              'does not measure streaks. It helps you see what you '
              'protected by saying No.',
              style: textTheme.bodyLarge,
            ),
            SizedBox(height: context.spacing.lg),
            Text(
              'Every No to something that does not serve you can also be a '
              'Yes to something you want to protect.',
              style: textTheme.bodyLarge?.copyWith(fontStyle: FontStyle.italic),
            ),
            SizedBox(height: context.spacing.xl),
            Center(
              child: packageInfoAsync.when(
                data: (PackageInfo info) => Text(
                  'Version ${info.version} (${info.buildNumber})',
                  style: textTheme.bodySmall,
                ),
                loading: () => const SizedBox.shrink(),
                error: (Object error, StackTrace stackTrace) => const SizedBox.shrink(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
