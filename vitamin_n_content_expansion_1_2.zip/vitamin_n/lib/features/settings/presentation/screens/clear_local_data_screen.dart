import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/database/app_database_provider.dart';
import '../../../../design_system/theme/theme_extensions.dart';
import '../../../../design_system/widgets/app_card.dart';
import '../../../challenges/presentation/providers/challenge_providers.dart';
import '../../../courses/presentation/providers/course_providers.dart';
import '../../../entries/presentation/providers/entry_providers.dart';
import '../../../favorites/presentation/providers/favorite_providers.dart';
import '../../../history/presentation/providers/history_providers.dart';
import '../../../home/presentation/providers/protected_today_provider.dart';
import '../../../insights/presentation/providers/insights_providers.dart';
import '../../../personal_reminders/presentation/providers/personal_reminder_providers.dart';

/// Lets the user permanently delete their user-owned dynamic content
/// — entries, Course progress, favorites, active Challenge selection
/// and personal reminders (Phase 6 section 30). Settings (onboarding
/// state, per-Challenge step progress, and any future Premium
/// entitlement flag) is intentionally left untouched — see
/// [AppDatabase.clearAllUserData] and section 31. There is no
/// server-side copy to also delete; this is purely local record
/// management.
class ClearLocalDataScreen extends ConsumerStatefulWidget {
  const ClearLocalDataScreen({super.key});

  @override
  ConsumerState<ClearLocalDataScreen> createState() => _ClearLocalDataScreenState();
}

class _ClearLocalDataScreenState extends ConsumerState<ClearLocalDataScreen> {
  bool _clearing = false;
  String? _errorText;

  Future<void> _confirmAndClear() async {
    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          backgroundColor: context.colors.surface,
          shape: RoundedRectangleBorder(borderRadius: context.radius.lgRadius),
          title: const Text('Clear local data?'),
          content: const Text(
            'This will remove your Vitamin N history, progress, favorites '
            'and Personal Reminders from this device.\n\n'
            'This cannot be undone.',
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              child: const Text('Clear data'),
            ),
          ],
        );
      },
    );

    if (confirmed != true) return;

    setState(() {
      _clearing = true;
      _errorText = null;
    });

    try {
      await ref.read(appDatabaseProvider).clearAllUserData();

      // Every FutureProvider reading mutable data needs an explicit
      // refresh — Drift's watch()-based streams (entries, in History)
      // pick the change up on their own, but one-shot Futures don't.
      // Settings-backed providers (onboarding, Challenge step
      // progress) are deliberately NOT invalidated here — Settings
      // itself was never cleared, so their values haven't changed.
      ref.invalidate(currentCourseProvider);
      ref.invalidate(courseHistoryProvider);
      ref.invalidate(allEntriesProvider);
      ref.invalidate(protectedValueCountsProvider);
      ref.invalidate(categoryCountsProvider);
      ref.invalidate(allEntriesStreamProvider);
      ref.invalidate(insightsAggregatesProvider);
      ref.invalidate(todaysProtectedItemsProvider);
      ref.invalidate(allFavoritesProvider);
      ref.invalidate(allPersonalRemindersProvider);
      ref.invalidate(activeChallengeProvider);

      if (!mounted) return;
      setState(() => _clearing = false);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Your local data has been cleared.'),
          behavior: SnackBarBehavior.floating,
        ),
      );
      Navigator.of(context).pop();
    } catch (_) {
      if (mounted) {
        setState(() {
          _clearing = false;
          _errorText = "Couldn't clear your data. Please try again.";
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final TextTheme textTheme = Theme.of(context).textTheme;

    return Scaffold(
      appBar: AppBar(title: const Text('Clear Local Data')),
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.all(context.spacing.lg),
          children: <Widget>[
            Text(
              'This removes your history, progress, favorites and '
              'Personal Reminders from this device.',
              style: textTheme.bodyLarge,
            ),
            SizedBox(height: context.spacing.lg),
            AppCard(
              backgroundColor: context.colors.cream,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text('This will delete:', style: textTheme.titleSmall),
                  SizedBox(height: context.spacing.sm),
                  for (final String item in const <String>[
                    'History and Insights',
                    'Your current Vitamin Course progress',
                    'Favorited responses',
                    'Personal Reminders',
                  ])
                    Padding(
                      padding: EdgeInsets.symmetric(vertical: context.spacing.xs / 2),
                      child: Text('• $item', style: textTheme.bodyMedium),
                    ),
                ],
              ),
            ),
            if (_errorText != null) ...<Widget>[
              SizedBox(height: context.spacing.md),
              Text(
                _errorText!,
                style: textTheme.bodyMedium?.copyWith(color: context.colors.destructive),
              ),
            ],
            SizedBox(height: context.spacing.xl),
            OutlinedButton(
              onPressed: _clearing ? null : _confirmAndClear,
              style: OutlinedButton.styleFrom(
                foregroundColor: context.colors.destructive,
                side: BorderSide(color: context.colors.destructive),
              ),
              child: Text(_clearing ? 'Clearing…' : 'Clear local data'),
            ),
          ],
        ),
      ),
    );
  }
}
