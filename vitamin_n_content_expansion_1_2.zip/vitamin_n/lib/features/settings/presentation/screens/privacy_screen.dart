import 'package:flutter/material.dart';

import '../widgets/static_info_screen.dart';

class PrivacyScreen extends StatelessWidget {
  const PrivacyScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const StaticInfoScreen(
      title: 'Privacy',
      sections: <(String?, String)>[
        (
          'Your data stays on your device',
          'Vitamin N is offline-first. Everything you record — entries, '
              'History, Personal Reminders, Course progress, favorites — is '
              'stored locally on this device. There is no cloud sync: none '
              'of it is sent anywhere.',
        ),
        (
          'No account. Limited usage analytics.',
          'There is no sign-up and no account. Vitamin N may collect '
              'limited product usage analytics — such as which general '
              'features are used and how far someone gets through the Say '
              'No flow — to help us understand how the app is used and '
              'improve it. This never includes anything you write.',
        ),
        (
          'Personal Reminders and other free-form text',
          'Personal Reminders, custom situation text, and anything else '
              'you type are stored locally and never sent as analytics '
              'events, to us, or to anyone else. Nothing you write is '
              'processed by AI.',
        ),
        (
          'Purchases',
          'Vitamin N Premium purchases are handled entirely by Google '
              'Play. Vitamin N does not see or store your payment details.',
        ),
        (
          'Content updates',
          'The situations, responses and reminders you see are bundled '
              'with the app itself, not downloaded from a server — so using '
              'Vitamin N never requires a network connection.',
        ),
        (
          'Clearing your data',
          'You can permanently delete everything Vitamin N has stored on '
              'this device at any time, from Settings › Clear Local Data.',
        ),
      ],
    );
  }
}
