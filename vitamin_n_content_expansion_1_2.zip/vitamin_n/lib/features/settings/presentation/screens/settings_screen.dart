import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:package_info_plus/package_info_plus.dart';

import '../../../../core/analytics/analytics_service.dart';
import '../../../../core/app_info/app_info_provider.dart';
import '../../../../design_system/theme/theme_extensions.dart';
import '../../../personal_reminders/presentation/screens/personal_reminders_screen.dart';
import '../../../premium/presentation/screens/premium_screen.dart';
import '../widgets/settings_row.dart';
import '../widgets/settings_section_label.dart';
import 'about_screen.dart';
import 'clear_local_data_screen.dart';
import 'disclaimer_screen.dart';
import 'privacy_screen.dart';

/// Grouped, card-based settings — per Phase 6 section 4's exact
/// structure. Deliberately not a dense Material ListTile screen.
class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  void _open(BuildContext context, Widget screen) {
    Navigator.of(context).push<void>(MaterialPageRoute<void>(builder: (_) => screen));
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AsyncValue<PackageInfo> packageInfoAsync = ref.watch(packageInfoProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.all(context.spacing.lg),
          children: <Widget>[
            SettingsRow(
              icon: Icons.spa_outlined,
              label: 'Vitamin N Premium',
              description: 'More situations. More ways to say No.',
              onTap: () => _open(
                context,
                const PremiumScreen(entryPoint: PremiumEntryPoint.settings),
              ),
            ),
            SizedBox(height: context.spacing.sm),
            SettingsRow(
              icon: Icons.bookmark_border,
              label: 'Personal Reminders',
              description: 'Things you want to remember next time.',
              onTap: () => _open(context, const PersonalRemindersScreen()),
            ),
            SizedBox(height: context.spacing.xl),
            const SettingsSectionLabel('Privacy & Data'),
            SettingsRow(
              icon: Icons.lock_outline,
              label: 'Privacy',
              onTap: () => _open(context, const PrivacyScreen()),
            ),
            SizedBox(height: context.spacing.sm),
            SettingsRow(
              icon: Icons.info_outline,
              label: 'Disclaimer',
              onTap: () => _open(context, const DisclaimerScreen()),
            ),
            SizedBox(height: context.spacing.sm),
            SettingsRow(
              icon: Icons.delete_outline,
              label: 'Clear local data',
              destructive: true,
              onTap: () => _open(context, const ClearLocalDataScreen()),
            ),
            SizedBox(height: context.spacing.xl),
            const SettingsSectionLabel('About Vitamin N'),
            SettingsRow(
              icon: Icons.eco_outlined,
              label: 'What is Vitamin N?',
              onTap: () => _open(context, const AboutScreen()),
            ),
            SizedBox(height: context.spacing.sm),
            _AppVersionRow(packageInfoAsync: packageInfoAsync),
          ],
        ),
      ),
    );
  }
}

/// A quiet, non-navigable row just showing the app's real version —
/// per section 32, read from platform package metadata, never
/// hardcoded.
class _AppVersionRow extends StatelessWidget {
  const _AppVersionRow({required this.packageInfoAsync});

  final AsyncValue<PackageInfo> packageInfoAsync;

  @override
  Widget build(BuildContext context) {
    final AppColors colors = context.colors;
    final TextTheme textTheme = Theme.of(context).textTheme;

    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: context.spacing.md,
        vertical: context.spacing.md,
      ),
      decoration: BoxDecoration(
        color: colors.surface,
        borderRadius: context.radius.lgRadius,
      ),
      child: Row(
        children: <Widget>[
          Icon(Icons.info_outline, color: colors.textSecondary, size: 18),
          SizedBox(width: context.spacing.md),
          Text('App version', style: textTheme.titleSmall),
          const Spacer(),
          packageInfoAsync.when(
            data: (PackageInfo info) => Text(info.version, style: textTheme.bodySmall),
            loading: () => const SizedBox.shrink(),
            error: (Object error, StackTrace stackTrace) => const SizedBox.shrink(),
          ),
        ],
      ),
    );
  }
}
