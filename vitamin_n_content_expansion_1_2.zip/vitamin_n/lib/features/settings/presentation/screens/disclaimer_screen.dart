import 'package:flutter/material.dart';

import '../widgets/static_info_screen.dart';

class DisclaimerScreen extends StatelessWidget {
  const DisclaimerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const StaticInfoScreen(
      title: 'Disclaimer',
      sections: <(String?, String)>[
        (
          null,
          'Vitamin N focuses on everyday personal boundaries and mindful '
              'choices — ordinary moments like an unwanted invitation, extra '
              'work, or a spending decision.',
        ),
        (
          'What Vitamin N is not',
          'Vitamin N is not therapy, medical advice, mental-health '
              'treatment, crisis support, addiction treatment, legal '
              'advice, or financial advice. It does not diagnose, treat, '
              'or evaluate any condition.',
        ),
        (
          'If a situation is more serious',
          'Curated content is intended for ordinary everyday boundary '
              'situations. It is not designed for guidance involving abuse, '
              'violence, coercive control, self-harm, suicide, medical '
              'emergencies, or serious mental-health crises. If something '
              "you're facing falls into one of these areas, please reach "
              'out to an appropriate qualified professional or a trusted '
              'local service, rather than relying on this app.',
        ),
        (
          'Reality Reminders',
          'The educational reminders shown in Vitamin N describe things '
              'that can sometimes happen — never a guaranteed outcome, and '
              'never a diagnosis of you or anyone else.',
        ),
      ],
    );
  }
}
