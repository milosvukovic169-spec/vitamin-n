import 'package:flutter/material.dart';

import '../../../../design_system/theme/theme_extensions.dart';
import '../../../../design_system/widgets/app_card.dart';

/// One destination row in the Settings screen. Deliberately not a
/// Material ListTile — a rounded, soft-shadowed card matching the
/// rest of the app, per Phase 6's visual reference.
class SettingsRow extends StatelessWidget {
  const SettingsRow({
    super.key,
    required this.icon,
    required this.label,
    required this.onTap,
    this.description,
    this.destructive = false,
  });

  final IconData icon;
  final String label;
  final String? description;
  final VoidCallback onTap;
  final bool destructive;

  @override
  Widget build(BuildContext context) {
    final AppColors colors = context.colors;
    final TextTheme textTheme = Theme.of(context).textTheme;
    final Color accent = destructive ? colors.destructive : colors.sageStrong;

    return AppCard(
      onTap: onTap,
      elevated: false,
      child: Row(
        children: <Widget>[
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(shape: BoxShape.circle, color: colors.cream),
            child: Icon(icon, color: accent, size: 20),
          ),
          SizedBox(width: context.spacing.md),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  label,
                  style: textTheme.titleSmall?.copyWith(
                    color: destructive ? accent : null,
                  ),
                ),
                if (description != null) ...<Widget>[
                  SizedBox(height: context.spacing.xs / 2),
                  Text(description!, style: textTheme.bodySmall),
                ],
              ],
            ),
          ),
          Icon(Icons.chevron_right, color: colors.textSecondary, size: 20),
        ],
      ),
    );
  }
}
