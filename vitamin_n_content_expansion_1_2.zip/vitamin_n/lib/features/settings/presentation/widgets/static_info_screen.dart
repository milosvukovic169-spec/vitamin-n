import 'package:flutter/material.dart';

import '../../../../design_system/theme/theme_extensions.dart';

/// Shared layout for simple, calm "read this text" screens — Privacy,
/// Disclaimer, About. One widget rather than three near-identical
/// screen implementations.
class StaticInfoScreen extends StatelessWidget {
  const StaticInfoScreen({
    super.key,
    required this.title,
    required this.sections,
  });

  final String title;

  /// Each entry is an optional heading paired with a body paragraph.
  final List<(String? heading, String body)> sections;

  @override
  Widget build(BuildContext context) {
    final TextTheme textTheme = Theme.of(context).textTheme;

    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.all(context.spacing.lg),
          children: <Widget>[
            for (final (String? heading, String body) in sections) ...<Widget>[
              if (heading != null) ...<Widget>[
                Text(heading, style: textTheme.titleMedium),
                SizedBox(height: context.spacing.sm),
              ],
              Text(body, style: textTheme.bodyLarge),
              SizedBox(height: context.spacing.lg),
            ],
          ],
        ),
      ),
    );
  }
}
