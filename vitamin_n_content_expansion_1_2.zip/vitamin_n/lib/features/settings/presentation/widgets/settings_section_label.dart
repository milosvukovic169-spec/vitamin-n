import 'package:flutter/material.dart';

import '../../../../design_system/theme/theme_extensions.dart';

/// A small, quiet label above a group of [SettingsRow]s (e.g.
/// "Privacy & Data"). Deliberately understated — this is a grouping
/// hint, not a headline; [SectionHeader] (used for Home's prominent
/// content sections) would be too heavy here.
class SettingsSectionLabel extends StatelessWidget {
  const SettingsSectionLabel(this.text, {super.key});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: context.spacing.sm, left: context.spacing.xs),
      child: Text(
        text,
        style: Theme.of(context).textTheme.labelMedium?.copyWith(
              color: context.colors.textSecondary,
              letterSpacing: 0.5,
            ),
      ),
    );
  }
}
