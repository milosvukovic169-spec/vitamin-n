import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/database/app_database_provider.dart';
import '../../data/datasources/settings_local_data_source.dart';
import '../../data/repositories/settings_repository_impl.dart';
import '../../domain/repositories/settings_repository.dart';

final Provider<SettingsRepository> settingsRepositoryProvider =
    Provider<SettingsRepository>((Ref ref) {
  final db = ref.watch(appDatabaseProvider);
  return SettingsRepositoryImpl(SettingsLocalDataSource(db));
});

final FutureProvider<bool> onboardingCompletedProvider =
    FutureProvider<bool>((Ref ref) {
  return ref
      .watch(settingsRepositoryProvider)
      .getBool(SettingsKeys.onboardingCompleted);
});
