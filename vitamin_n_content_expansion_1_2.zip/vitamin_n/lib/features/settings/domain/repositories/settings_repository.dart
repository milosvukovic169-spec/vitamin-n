abstract class SettingsRepository {
  Future<String?> getString(String key);
  Future<void> setString(String key, String value);

  Future<bool> getBool(String key, {bool defaultValue = false});
  Future<void> setBool(String key, bool value);

  Future<int> getInt(String key, {int defaultValue = 0});
  Future<void> setInt(String key, int value);

  Future<void> remove(String key);
}

/// Known settings keys, centralized so features never hardcode raw
/// strings scattered across the codebase.
abstract final class SettingsKeys {
  static const String onboardingCompleted = 'onboarding_completed';
  static const String personalReminderText = 'personal_reminder_text';
  static const String remindersEnabled = 'reminders_enabled';

  /// How many Say No flows have been fully completed — drives the
  /// Reflection Pause visibility rule (shown every time for the
  /// first 15, ~20% of the time afterwards).
  static const String completedFlowCount = 'completed_flow_count';

  /// ISO8601 timestamp of the most recently completed flow — drives
  /// the "show again after a period of inactivity" rule.
  static const String lastFlowCompletedAt = 'last_flow_completed_at';

  /// A locally cached copy of the last known Premium entitlement
  /// (Phase 7 section 16/17) — used only for immediate UX continuity
  /// while a fresh store check is in flight (e.g. brief offline
  /// periods on app start), never as the permanent source of truth.
  /// The store's answer always wins once available; this key is
  /// overwritten every time [BillingBackedPremiumRepository]
  /// successfully refreshes entitlement, and is deliberately NOT
  /// touched by Clear Local Data (section 26/31) — clearing local
  /// content must never look like cancelling a subscription.
  static const String cachedPremiumEntitlement = 'cached_premium_entitlement';
}
