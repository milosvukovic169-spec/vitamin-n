import '../../domain/entities/category.dart';
import '../../domain/repositories/category_repository.dart';
import '../datasources/category_local_data_source.dart';

/// Implements [CategoryRepository] against [CategoryLocalDataSource],
/// adding an in-memory cache since this content never changes at
/// runtime — every read after the first is synchronous-fast.
class CategoryRepositoryImpl implements CategoryRepository {
  CategoryRepositoryImpl(this._dataSource);

  final CategoryLocalDataSource _dataSource;
  List<Category>? _cache;

  Future<List<Category>> _loadAll() async {
    final List<Category>? cached = _cache;
    if (cached != null) {
      return cached;
    }
    final List<Category> loaded = await _dataSource.loadAll();
    _cache = loaded;
    return loaded;
  }

  @override
  Future<List<Category>> getAll() => _loadAll();

  @override
  Future<Category?> getById(String id) async {
    final List<Category> all = await _loadAll();
    for (final Category category in all) {
      if (category.id == id) {
        return category;
      }
    }
    return null;
  }
}
