import '../../../../core/constants/asset_paths.dart';
import '../../../../core/json/json_asset_loader.dart';
import '../../domain/entities/category.dart';

/// Reads and parses the bundled Category content. This is the only
/// place in the Categories feature allowed to know about JSON or
/// asset paths — the domain entity itself stays serialization-free.
class CategoryLocalDataSource {
  CategoryLocalDataSource({JsonAssetLoader loader = const JsonAssetLoader()})
      : _loader = loader;

  final JsonAssetLoader _loader;

  Future<List<Category>> loadAll() async {
    final List<Map<String, dynamic>> raw =
        await _loader.loadList(AssetPaths.categories);
    return raw.map(_parse).toList()
      ..sort((Category a, Category b) => a.sortOrder.compareTo(b.sortOrder));
  }

  Category _parse(Map<String, dynamic> json) {
    return Category(
      id: json['id'] as String,
      name: json['name'] as String,
      description: json['description'] as String,
      iconName: json['iconName'] as String,
      colorToken: json['colorToken'] as String,
      sortOrder: json['sortOrder'] as int,
    );
  }
}
