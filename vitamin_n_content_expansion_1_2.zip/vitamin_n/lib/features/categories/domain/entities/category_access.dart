/// The single source of truth for which categories are available to
/// Free users. Per Phase 5 section 5: Relationships, Work and Digital
/// are the three complete Free categories; "Other/Custom" is always
/// usable since it's user-authored, not curated content. Everything
/// else requires Premium.
abstract final class CategoryAccess {
  static const String otherCategoryId = 'cat_other';

  static const Set<String> freeCategoryIds = <String>{
    'cat_relationships',
    'cat_work',
    'cat_digital',
    otherCategoryId,
  };

  static bool isFree(String categoryId) => freeCategoryIds.contains(categoryId);

  static bool requiresPremium(String categoryId) => !isFree(categoryId);
}
