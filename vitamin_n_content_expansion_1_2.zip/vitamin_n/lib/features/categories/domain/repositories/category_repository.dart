import '../entities/category.dart';

/// Read-only access to Category content. The domain layer only ever
/// depends on this abstraction — never on how categories are actually
/// stored (JSON today, potentially something else later).
abstract class CategoryRepository {
  Future<List<Category>> getAll();
  Future<Category?> getById(String id);
}
