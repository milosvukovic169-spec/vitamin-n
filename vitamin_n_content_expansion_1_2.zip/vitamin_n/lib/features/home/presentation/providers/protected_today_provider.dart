import 'package:flutter/material.dart' show IconData;
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../design_system/icon_mapping.dart';
import '../../../entries/domain/entities/entry.dart';
import '../../../entries/presentation/providers/entry_providers.dart';
import '../../../protected_values/domain/entities/protected_value.dart';
import '../../../protected_values/presentation/providers/protected_value_providers.dart';

/// A protected value to show on Home's "Today You Protected" card,
/// resolved from real [Entry] data — never fixed demo values.
class ProtectedTodayItem {
  const ProtectedTodayItem({required this.label, required this.icon});

  final String label;
  final IconData icon;
}

/// The most relevant protected values from today's real Entries, most
/// recent first, capped at 4. Returns an empty list when nothing has
/// been protected yet today — the card shows a calm empty state for
/// that case rather than fabricating content.
final FutureProvider<List<ProtectedTodayItem>> todaysProtectedItemsProvider =
    FutureProvider<List<ProtectedTodayItem>>((Ref ref) async {
  final DateTime now = DateTime.now();
  final DateTime startOfDay = DateTime(now.year, now.month, now.day);
  final DateTime endOfDay = startOfDay.add(const Duration(days: 1));

  final List<Entry> todaysEntries = await ref
      .watch(entryRepositoryProvider)
      .getBetween(startOfDay, endOfDay);

  if (todaysEntries.isEmpty) {
    return const <ProtectedTodayItem>[];
  }

  // Most recent entries first, so the card reflects what was just
  // protected rather than an arbitrary insertion order.
  final List<Entry> sorted = List<Entry>.of(todaysEntries)
    ..sort((Entry a, Entry b) => b.createdAt.compareTo(a.createdAt));

  final List<ProtectedValue> allValues =
      await ref.watch(protectedValueRepositoryProvider).getAll();
  final Map<String, ProtectedValue> valuesById = <String, ProtectedValue>{
    for (final ProtectedValue value in allValues) value.id: value,
  };

  final List<ProtectedTodayItem> items = <ProtectedTodayItem>[];
  final Set<String> seenLabels = <String>{};

  void addIfNew(String label, IconData icon) {
    if (seenLabels.add(label) && items.length < 4) {
      items.add(ProtectedTodayItem(label: label, icon: icon));
    }
  }

  for (final Entry entry in sorted) {
    for (final String valueId in entry.protectedValueIds) {
      final ProtectedValue? value = valuesById[valueId];
      if (value != null) {
        addIfNew(value.label, ContentIconMapper.resolve(value.iconName));
      }
    }
    final String? custom = entry.customProtectedValue;
    if (custom != null && custom.trim().isNotEmpty) {
      addIfNew(custom.trim(), ContentIconMapper.resolve('star'));
    }
    if (items.length >= 4) break;
  }

  return items;
});
