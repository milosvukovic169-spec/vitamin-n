import 'package:flutter/material.dart';

import '../../../../design_system/animation/app_animated_switcher.dart';
import '../../../../design_system/theme/theme_extensions.dart';
import '../../../../design_system/widgets/app_card.dart';

/// A single calm, supportive line — "You protected your peace."-style
/// content sourced from the Support Messages JSON. Purely
/// presentational: the caller supplies the text to show.
class SupportMessageCard extends StatelessWidget {
  const SupportMessageCard({super.key, required this.message});

  final String? message;

  @override
  Widget build(BuildContext context) {
    final TextTheme textTheme = Theme.of(context).textTheme;

    return AppCard(
      backgroundColor: context.colors.beige,
      child: Row(
        children: <Widget>[
          Icon(Icons.eco_outlined, color: context.colors.sageStrong, size: 20),
          SizedBox(width: context.spacing.md),
          Expanded(
            child: AppAnimatedSwitcher(
              child: Text(
                message ?? ' ',
                key: ValueKey<String?>(message),
                style: textTheme.titleSmall,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
