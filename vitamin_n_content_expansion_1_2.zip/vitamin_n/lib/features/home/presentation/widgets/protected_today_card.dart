import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../design_system/theme/theme_extensions.dart';
import '../../../../design_system/widgets/app_card.dart';
import '../../../../design_system/widgets/section_header.dart';
import '../../../../design_system/widgets/value_chip.dart';
import '../providers/protected_today_provider.dart';

/// A warm, affirming summary of what the user protected today —
/// loaded from real, persisted Entry data. Shows a calm empty state
/// when nothing has been protected yet today, rather than fabricated
/// placeholder values.
class ProtectedTodayCard extends ConsumerWidget {
  const ProtectedTodayCard({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AsyncValue<List<ProtectedTodayItem>> itemsAsync =
        ref.watch(todaysProtectedItemsProvider);

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          const SectionHeader(
            title: 'Today You Protected',
            subtitle: 'What mattered enough to hold onto',
          ),
          SizedBox(height: context.spacing.md),
          itemsAsync.when(
            data: (List<ProtectedTodayItem> items) {
              if (items.isEmpty) {
                return Text(
                  'Nothing yet today — that\'s alright. Whenever you\'re '
                  'ready, protecting something starts with one No.',
                  style: Theme.of(context).textTheme.bodyMedium,
                );
              }
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Wrap(
                    spacing: context.spacing.sm,
                    runSpacing: context.spacing.sm,
                    children: <Widget>[
                      for (final ProtectedTodayItem item in items)
                        ValueChip(label: item.label, icon: item.icon, selected: true),
                    ],
                  ),
                  SizedBox(height: context.spacing.sm),
                  Text(
                    '${items.length} thing${items.length == 1 ? '' : 's'} that '
                    'mattered, protected today.',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ],
              );
            },
            loading: () => const Padding(
              padding: EdgeInsets.symmetric(vertical: 8),
              child: SizedBox(
                height: 20,
                width: 20,
                child: CircularProgressIndicator(strokeWidth: 2),
              ),
            ),
            error: (Object error, StackTrace stackTrace) => Text(
              'Could not load today\'s entries.',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ),
        ],
      ),
    );
  }
}
