import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show HapticFeedback;
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../app/routes.dart';
import '../../../../core/analytics/analytics_providers.dart';
import '../../../../design_system/theme/theme_extensions.dart';
import '../../../../design_system/widgets/app_card.dart';
import '../../../../design_system/widgets/course_board.dart';
import '../../../../design_system/widgets/primary_button.dart';
import '../../../boundary/domain/entities/say_no_result.dart';
import '../../../boundary/presentation/controllers/say_no_flow_controller.dart';
import '../../../courses/domain/entities/course.dart';
import '../../../courses/presentation/providers/course_providers.dart';
import '../../../support_messages/presentation/providers/support_message_providers.dart';
import '../providers/protected_today_provider.dart';
import '../widgets/home_greeting.dart';
import '../widgets/protected_today_card.dart';
import '../widgets/support_message_card.dart';

/// Home displays the real Course from the database. When returning
/// from a completed Say No flow, it plays a genuine "one token
/// disappearing" animation from the *previous* board state to the
/// new one — it never just rebuilds with a smaller number.
class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  // Home renders from this local snapshot rather than directly from
  // the async provider, so the token-removal animation can be staged
  // deliberately (old state -> pulse -> new state) instead of the
  // board just jumping straight to its final value on rebuild.
  int? _displayedTokensRemaining;
  int? _displayedCycleNumber;
  int? _justConsumedIndex;
  bool _consumedResultThisBuild = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _handleReturnToHome());
  }

  void _seedDisplayedStateIfNeeded(Course course) {
    if (_displayedTokensRemaining == null) {
      _displayedTokensRemaining = course.tokensRemaining;
      _displayedCycleNumber = course.cycleNumber;
    }
  }

  Future<void> _handleReturnToHome() async {
    if (_consumedResultThisBuild) return;
    final flowState = ref.read(sayNoFlowControllerProvider);
    if (flowState.submissionStatus != SubmissionStatus.success ||
        flowState.result == null) {
      return;
    }
    _consumedResultThisBuild = true;
    final SayNoResult result = flowState.result!;
    final bool reduceMotion = MediaQuery.of(context).disableAnimations;

    // Make sure we have a "before" snapshot to animate from. If Home
    // hasn't rendered a course yet at all (cold start straight into
    // the flow), fall back to the provider's current cached value.
    if (_displayedTokensRemaining == null) {
      final AsyncValue<Course> cached = ref.read(currentCourseProvider);
      final Course? course = cached.value;
      if (course != null) _seedDisplayedStateIfNeeded(course);
    }

    final bool completedACourse = result.startedNewCourse;
    // The board we should be animating on is the OLD cycle — its
    // state just before this token was consumed was one token fuller
    // than after.
    final int beforeTokens =
        completedACourse ? 1 : result.updatedCourse.tokensRemaining + 1;
    final int beforeCycle =
        completedACourse ? result.updatedCourse.cycleNumber - 1 : result.updatedCourse.cycleNumber;
    final int afterTokens = completedACourse ? 0 : result.updatedCourse.tokensRemaining;
    final int consumedIndex = afterTokens; // 0-indexed: the token that just emptied

    setState(() {
      _displayedTokensRemaining = beforeTokens;
      _displayedCycleNumber = beforeCycle;
    });

    if (reduceMotion) {
      // Respect Reduce Motion: update straight to the final state,
      // no pulse, no staged delay.
      setState(() => _displayedTokensRemaining = afterTokens);
    } else {
      await Future<void>.delayed(const Duration(milliseconds: 120));
      if (!mounted) return;
      HapticFeedback.lightImpact();
      setState(() {
        _justConsumedIndex = consumedIndex;
        _displayedTokensRemaining = afterTokens;
      });
      await Future<void>.delayed(const Duration(milliseconds: 420));
      if (!mounted) return;
      setState(() => _justConsumedIndex = null);
    }

    ref.invalidate(currentCourseProvider);
    ref.invalidate(randomSupportMessageProvider);
    ref.invalidate(todaysProtectedItemsProvider);

    if (completedACourse) {
      await _showCourseCompleteDialog();
      if (!mounted) return;
      setState(() {
        _displayedCycleNumber = result.updatedCourse.cycleNumber;
        _displayedTokensRemaining = Course.tokensPerCourse;
      });
    }

    ref.read(sayNoFlowControllerProvider.notifier).reset();
  }

  Future<void> _showCourseCompleteDialog() {
    return showDialog<void>(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          backgroundColor: context.colors.surface,
          shape: RoundedRectangleBorder(borderRadius: context.radius.lgRadius),
          title: const Text('Course complete'),
          content: const Text(
            'Thirty moments in which you protected what mattered.\n\n'
            'Vitamin N · New course begun',
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: const Text('Begin the next course'),
            ),
          ],
        );
      },
    );
  }

  void _handleSayNoTap() {
    unawaited(ref.read(analyticsServiceProvider).sayNoStarted());
    context.push(AppRoutes.sayNoCategory);
  }

  @override
  Widget build(BuildContext context) {
    final courseAsync = ref.watch(currentCourseProvider);
    final supportMessageAsync = ref.watch(randomSupportMessageProvider);
    final bool reduceMotion = MediaQuery.of(context).disableAnimations;

    courseAsync.whenData(_seedDisplayedStateIfNeeded);

    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.fromLTRB(
            context.spacing.lg,
            context.spacing.lg,
            context.spacing.lg,
            context.spacing.xxl,
          ),
          children: <Widget>[
            const HomeGreeting(),
            SizedBox(height: context.spacing.xl),
            if (_displayedTokensRemaining != null && _displayedCycleNumber != null)
              CourseBoard(
                tokensRemaining: _displayedTokensRemaining!,
                totalTokens: Course.tokensPerCourse,
                cycleNumber: _displayedCycleNumber!,
                justConsumedIndex: _justConsumedIndex,
                reduceMotion: reduceMotion,
              )
            else
              courseAsync.when(
                data: (_) => const SizedBox.shrink(),
                loading: () => const AppCard(
                  child: SizedBox(
                    height: 120,
                    child: Center(child: CircularProgressIndicator()),
                  ),
                ),
                error: (Object error, StackTrace stackTrace) =>
                    AppCard(child: Text('Could not load your Course: $error')),
              ),
            SizedBox(height: context.spacing.lg),
            PrimaryButton(
              label: 'Say No',
              icon: Icons.front_hand_outlined,
              onPressed: _handleSayNoTap,
            ),
            SizedBox(height: context.spacing.lg),
            const ProtectedTodayCard(),
            SizedBox(height: context.spacing.lg),
            supportMessageAsync.when(
              data: (message) => SupportMessageCard(message: message?.text),
              loading: () => const SupportMessageCard(message: null),
              error: (Object error, StackTrace stackTrace) =>
                  const SupportMessageCard(message: null),
            ),
          ],
        ),
      ),
    );
  }
}
