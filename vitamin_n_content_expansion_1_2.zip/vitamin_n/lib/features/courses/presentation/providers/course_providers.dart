import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/database/app_database_provider.dart';
import '../../data/datasources/course_local_data_source.dart';
import '../../data/repositories/course_repository_impl.dart';
import '../../domain/entities/course.dart';
import '../../domain/repositories/course_repository.dart';

final Provider<CourseRepository> courseRepositoryProvider =
    Provider<CourseRepository>((Ref ref) {
  final db = ref.watch(appDatabaseProvider);
  return CourseRepositoryImpl(CourseLocalDataSource(db));
});

/// The current, in-progress Course (creating the first one on first
/// launch). Widgets that display the CourseBoard / N tokens watch this.
final FutureProvider<Course> currentCourseProvider =
    FutureProvider<Course>((Ref ref) {
  return ref.watch(courseRepositoryProvider).getOrCreateCurrent();
});

final FutureProvider<List<Course>> courseHistoryProvider =
    FutureProvider<List<Course>>((Ref ref) {
  return ref.watch(courseRepositoryProvider).getHistory();
});
