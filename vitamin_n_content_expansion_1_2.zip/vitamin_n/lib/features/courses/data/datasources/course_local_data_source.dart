import 'package:drift/drift.dart';

import '../../../../core/database/app_database.dart';

/// Wraps the Drift [Courses] table. Returns raw [CourseRow] objects —
/// mapping to the domain `Course` entity happens in
/// `CourseRepositoryImpl`, keeping this class's only concern I/O.
class CourseLocalDataSource {
  CourseLocalDataSource(this._db);

  final AppDatabase _db;

  Future<CourseRow?> getCurrentOpenRow() {
    return (_db.select(_db.courses)
          ..where((tbl) => tbl.completedAt.isNull())
          ..orderBy([(tbl) => OrderingTerm.desc(tbl.cycleNumber)])
          ..limit(1))
        .getSingleOrNull();
  }

  Future<CourseRow?> getLastRow() {
    return (_db.select(_db.courses)
          ..orderBy([(tbl) => OrderingTerm.desc(tbl.cycleNumber)])
          ..limit(1))
        .getSingleOrNull();
  }

  Future<List<CourseRow>> getAllRows() {
    return (_db.select(_db.courses)
          ..orderBy([(tbl) => OrderingTerm.desc(tbl.cycleNumber)]))
        .get();
  }

  Future<CourseRow> insertRow({
    required int cycleNumber,
    required int tokensRemaining,
    required DateTime startedAt,
  }) async {
    final int id = await _db.into(_db.courses).insert(
          CoursesCompanion.insert(
            cycleNumber: cycleNumber,
            tokensRemaining: tokensRemaining,
            startedAt: startedAt,
          ),
        );
    return CourseRow(
      id: id,
      cycleNumber: cycleNumber,
      tokensRemaining: tokensRemaining,
      startedAt: startedAt,
      completedAt: null,
    );
  }

  Future<void> updateTokensRemaining(int id, int tokensRemaining) {
    return (_db.update(_db.courses)..where((tbl) => tbl.id.equals(id)))
        .write(CoursesCompanion(tokensRemaining: Value<int>(tokensRemaining)));
  }

  Future<void> markCompleted(int id, DateTime completedAt) {
    return (_db.update(_db.courses)..where((tbl) => tbl.id.equals(id)))
        .write(CoursesCompanion(
      tokensRemaining: const Value<int>(0),
      completedAt: Value<DateTime?>(completedAt),
    ));
  }

  /// Runs [action] inside a Drift transaction. Every query made
  /// against this data source's [_db] while [action] is running is
  /// automatically part of the same transaction — no explicit
  /// transaction handle needs to be threaded through.
  Future<T> runInTransaction<T>(Future<T> Function() action) {
    return _db.transaction(action);
  }
}
