import '../../../../core/database/app_database.dart';
import '../../domain/entities/course.dart';
import '../../domain/repositories/course_repository.dart';
import '../datasources/course_local_data_source.dart';

class CourseRepositoryImpl implements CourseRepository {
  CourseRepositoryImpl(this._dataSource);

  final CourseLocalDataSource _dataSource;

  Course _toEntity(CourseRow row) {
    return Course(
      id: row.id,
      cycleNumber: row.cycleNumber,
      tokensRemaining: row.tokensRemaining,
      startedAt: row.startedAt,
      completedAt: row.completedAt,
    );
  }

  Future<CourseRow> _createNextCourseRow() async {
    final CourseRow? last = await _dataSource.getLastRow();
    final int nextCycleNumber = last == null ? 1 : last.cycleNumber + 1;
    return _dataSource.insertRow(
      cycleNumber: nextCycleNumber,
      tokensRemaining: Course.tokensPerCourse,
      startedAt: DateTime.now(),
    );
  }

  @override
  Future<Course> getOrCreateCurrent() async {
    final CourseRow? current = await _dataSource.getCurrentOpenRow();
    if (current != null) {
      return _toEntity(current);
    }
    final CourseRow created = await _createNextCourseRow();
    return _toEntity(created);
  }

  @override
  Future<CourseTokenConsumptionResult> consumeToken() {
    return _dataSource.runInTransaction<CourseTokenConsumptionResult>(() async {
      final CourseRow current =
          await _dataSource.getCurrentOpenRow() ?? await _createNextCourseRow();

      final int remaining = current.tokensRemaining - 1;

      if (remaining > 0) {
        await _dataSource.updateTokensRemaining(current.id, remaining);
        return CourseTokenConsumptionResult(
          consumedFromCourseId: current.id,
          updatedCourse: _toEntity(current).copyWith(tokensRemaining: remaining),
          startedNewCourse: false,
        );
      }

      final DateTime completedAt = DateTime.now();
      await _dataSource.markCompleted(current.id, completedAt);
      final CourseRow nextRow = await _createNextCourseRow();

      return CourseTokenConsumptionResult(
        consumedFromCourseId: current.id,
        updatedCourse: _toEntity(nextRow),
        startedNewCourse: true,
      );
    });
  }

  @override
  Future<List<Course>> getHistory() async {
    final List<CourseRow> rows = await _dataSource.getAllRows();
    return rows.map(_toEntity).toList();
  }
}
