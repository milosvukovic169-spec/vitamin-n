/// A single cycle of the Vitamin Course — 30 N tokens that represent
/// visual progress only.
///
/// Tokens do not represent days, and they do not refill on a
/// schedule. A token is removed only when the user completes a Say No
/// entry. When [tokensRemaining] reaches zero, [completedAt] is set
/// and a new Course begins automatically, starting again at 30. This
/// is a progress cycle, never a game — there is no score, streak or
/// penalty attached to it.
class Course {
  const Course({
    required this.id,
    required this.cycleNumber,
    required this.tokensRemaining,
    required this.startedAt,
    required this.completedAt,
  });

  static const int tokensPerCourse = 30;

  final int id;
  final int cycleNumber;
  final int tokensRemaining;
  final DateTime startedAt;
  final DateTime? completedAt;

  bool get isComplete => tokensRemaining <= 0;

  Course copyWith({int? tokensRemaining, DateTime? completedAt}) {
    return Course(
      id: id,
      cycleNumber: cycleNumber,
      tokensRemaining: tokensRemaining ?? this.tokensRemaining,
      startedAt: startedAt,
      completedAt: completedAt ?? this.completedAt,
    );
  }
}
