import '../entities/course.dart';

/// The result of consuming one token, used to drive the "New Course
/// Ready" moment without the repository knowing anything about UI.
class CourseTokenConsumptionResult {
  const CourseTokenConsumptionResult({
    required this.consumedFromCourseId,
    required this.updatedCourse,
    required this.startedNewCourse,
  });

  /// The id of the course the removed token actually belonged to —
  /// i.e. the course that was current at the moment of consumption.
  /// Callers attributing an Entry to "the course this boundary
  /// happened in" should use this, not [updatedCourse].
  final int consumedFromCourseId;

  /// The course to display going forward. If [startedNewCourse] is
  /// true, this is the freshly-started next course (30 tokens); if
  /// false, it's the same course with one fewer token remaining.
  final Course updatedCourse;
  final bool startedNewCourse;
}

abstract class CourseRepository {
  /// Returns the current, not-yet-complete Course, creating the very
  /// first one (cycle 1, 30 tokens) if none exists yet.
  Future<Course> getOrCreateCurrent();

  /// Removes one token from the current Course, auto-starting the
  /// next cycle if this empties it.
  Future<CourseTokenConsumptionResult> consumeToken();

  Future<List<Course>> getHistory();
}
