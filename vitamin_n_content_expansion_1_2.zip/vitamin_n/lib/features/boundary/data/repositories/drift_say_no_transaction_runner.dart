import '../../../../core/database/app_database.dart';
import '../../domain/repositories/say_no_transaction_runner.dart';

/// Drift-backed [SayNoTransactionRunner].
///
/// Relies on Drift's ambient transaction propagation: any query
/// issued through [_db] — including from a *different* repository
/// object, as long as it was constructed against this same
/// [AppDatabase] instance — automatically joins the transaction
/// started here. This is what makes cross-repository atomicity
/// possible without merging CourseRepository and EntryRepository into
/// one class: [ConfirmSayNoUseCase] calls both through their normal
/// interfaces, and as long as both concrete implementations share
/// this database instance (guaranteed by the DI wiring in
/// `say_no_providers.dart`, which reads both from the single
/// `appDatabaseProvider`), their writes are part of the same
/// transaction. If the inner `Future` throws for any reason, Drift
/// rolls back everything written during [action] — including writes
/// made by nested `db.transaction()` calls inside a repository, since
/// Drift supports transaction nesting via savepoints that roll back
/// together with the outer transaction.
class DriftSayNoTransactionRunner implements SayNoTransactionRunner {
  DriftSayNoTransactionRunner(this._db);

  final AppDatabase _db;

  @override
  Future<T> run<T>(Future<T> Function() action) => _db.transaction(action);
}
