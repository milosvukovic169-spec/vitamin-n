import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../app/routes.dart';
import '../../../../design_system/theme/theme_extensions.dart';
import '../../../../design_system/widgets/primary_button.dart';
import '../../../premium/presentation/providers/premium_providers.dart';
import '../../../reality_reminders/domain/entities/reality_reminder.dart';
import '../../../reality_reminders/presentation/providers/reality_reminder_providers.dart';
import '../controllers/say_no_flow_controller.dart';
import '../widgets/flow_header.dart';
import '../widgets/flow_scaffold.dart';
import '../widgets/locked_reality_reminder_card.dart';
import '../widgets/reality_reminder_card.dart';

/// Step 5 — Reality Reminder.
///
/// Final monetization model: Free access to this step is gated by
/// CATEGORY, not by the same three Free categories responses use.
/// Relationships is the only Free category where a Free user sees a
/// real reminder; Work and Digital show [LockedRealityReminderCard]
/// instead — informational only, never blocking — and Other/Custom
/// has no curated content to show at all, so nothing is rendered for
/// it rather than inventing something. Continue always works
/// regardless of any of this.
class RealityReminderScreen extends ConsumerStatefulWidget {
  const RealityReminderScreen({super.key});

  @override
  ConsumerState<RealityReminderScreen> createState() =>
      _RealityReminderScreenState();
}

class _RealityReminderScreenState extends ConsumerState<RealityReminderScreen> {
  int _visibleIndex = 0;

  void _handleContinue() {
    context.push(AppRoutes.sayNoConfirm);
  }

  @override
  Widget build(BuildContext context) {
    final flowState = ref.watch(sayNoFlowControllerProvider);
    final String? categoryId = flowState.selectedCategoryId;
    final String? situationId = flowState.selectedSituationId;

    if (categoryId == null || situationId == null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) context.go(AppRoutes.sayNoCategory);
      });
      return const FlowScaffold(child: SizedBox.shrink());
    }

    final bool isPremium = ref.watch(effectiveIsPremiumProvider);
    final bool hasFreeAccessForCategory =
        RealityReminderAccess.isFreeForCategory(categoryId);
    // Other/Custom never has curated reminder content — showing a
    // locked teaser for it would promise something that doesn't
    // exist, so it's excluded from the gate entirely and simply
    // renders nothing below, the same as if content were empty.
    final bool isCustomCategory = categoryId == 'cat_other';
    final bool showLockedTeaser =
        !isPremium && !hasFreeAccessForCategory && !isCustomCategory;

    return FlowScaffold(
      bottomBar: PrimaryButton(label: 'Continue', onPressed: _handleContinue),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          const FlowHeader(title: 'Something to notice'),
          if (showLockedTeaser)
            const LockedRealityReminderCard()
          else
            _RealReminderContent(
              categoryId: categoryId,
              situationId: situationId,
              isPremium: isPremium,
              visibleIndex: _visibleIndex,
              onShowAnother: () => setState(() => _visibleIndex += 1),
            ),
        ],
      ),
    );
  }
}

class _RealReminderContent extends ConsumerWidget {
  const _RealReminderContent({
    required this.categoryId,
    required this.situationId,
    required this.isPremium,
    required this.visibleIndex,
    required this.onShowAnother,
  });

  final String categoryId;
  final String situationId;
  final bool isPremium;
  final int visibleIndex;
  final VoidCallback onShowAnother;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AsyncValue<List<RealityReminder>> remindersAsync = ref.watch(
      realityRemindersForSituationProvider(
        (categoryId: categoryId, situationId: situationId),
      ),
    );

    return remindersAsync.when(
      data: (List<RealityReminder> reminders) {
        if (reminders.isEmpty) {
          // No curated content for this situation — never invented,
          // per spec. Silently render nothing further.
          return const SizedBox.shrink();
        }

        final int visibleLimit =
            isPremium ? reminders.length : RealityReminder.freeCount;
        final int clampedIndex = visibleIndex.clamp(0, visibleLimit - 1);
        final RealityReminder current = reminders[clampedIndex];

        if (ref.read(sayNoFlowControllerProvider).selectedRealityReminderId !=
            current.id) {
          WidgetsBinding.instance.addPostFrameCallback((_) {
            ref
                .read(sayNoFlowControllerProvider.notifier)
                .selectRealityReminder(current.id);
          });
        }

        final bool canShowAnother = isPremium && clampedIndex < visibleLimit - 1;

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            RealityReminderCard(text: current.text),
            if (canShowAnother)
              Center(
                child: Padding(
                  padding: EdgeInsets.only(top: context.spacing.md),
                  child: TextButton(
                    onPressed: onShowAnother,
                    child: const Text('Show another perspective'),
                  ),
                ),
              ),
          ],
        );
      },
      loading: () => const Padding(
        padding: EdgeInsets.only(top: 24),
        child: Center(child: CircularProgressIndicator()),
      ),
      error: (Object error, StackTrace stackTrace) =>
          Text('Could not load a reminder: $error'),
    );
  }
}
