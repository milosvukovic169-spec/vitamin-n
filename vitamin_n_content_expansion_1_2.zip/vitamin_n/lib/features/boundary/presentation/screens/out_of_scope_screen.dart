import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../app/routes.dart';
import '../../../../design_system/theme/theme_extensions.dart';
import '../../../../design_system/widgets/primary_button.dart';
import '../../domain/services/scope_guard.dart';
import '../controllers/say_no_flow_controller.dart';
import '../widgets/flow_scaffold.dart';

/// Shown when a custom "Other" situation appears to reference a topic
/// outside Vitamin N's scope. Ends the flow calmly — no attempt to
/// generate alternative guidance for the topic.
class OutOfScopeScreen extends ConsumerWidget {
  const OutOfScopeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final TextTheme textTheme = Theme.of(context).textTheme;

    return FlowScaffold(
      showBackButton: false,
      bottomBar: PrimaryButton(
        label: 'Return to Home',
        onPressed: () {
          ref.read(sayNoFlowControllerProvider.notifier).reset();
          context.go(AppRoutes.home);
        },
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Icon(Icons.spa_outlined, color: context.colors.sageStrong, size: 32),
          SizedBox(height: context.spacing.lg),
          Text(ScopeGuard.scopeMessageTitle, style: textTheme.headlineMedium),
          SizedBox(height: context.spacing.md),
          Text(ScopeGuard.scopeMessageBody, style: textTheme.bodyLarge),
        ],
      ),
    );
  }
}
