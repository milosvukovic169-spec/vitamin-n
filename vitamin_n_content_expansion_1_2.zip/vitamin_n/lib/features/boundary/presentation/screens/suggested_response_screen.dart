import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../app/routes.dart';
import '../../../../core/analytics/analytics_providers.dart';
import '../../../../design_system/theme/theme_extensions.dart';
import '../../../../design_system/widgets/app_card.dart';
import '../../../../design_system/widgets/primary_button.dart';
import '../../../favorites/domain/entities/favorite.dart';
import '../../../favorites/presentation/providers/favorite_providers.dart';
import '../../../premium/presentation/providers/premium_providers.dart';
import '../../../refusal_responses/domain/entities/refusal_response.dart';
import '../../../refusal_responses/domain/entities/response_visibility.dart';
import '../../../refusal_responses/presentation/providers/refusal_response_providers.dart';
import '../controllers/say_no_flow_controller.dart';
import '../widgets/flow_header.dart';
import '../widgets/flow_scaffold.dart';
import '../widgets/premium_response_teaser_sheet.dart';
import '../widgets/suggested_response_card.dart';

const String _fallbackResponseText =
    'Take a moment to say this in your own words — you know this '
    'situation better than any suggestion could.';

final FutureProviderFamily<bool, String> _isFavoriteProvider =
    FutureProvider.family<bool, String>((Ref ref, String responseId) {
  return ref
      .watch(favoriteRepositoryProvider)
      .isFavorite(FavoriteEntityType.refusalResponse, responseId);
});

/// Step 4 — Suggested Response.
///
/// Final monetization model: Free users see exactly ONE response —
/// the Recommended one — with no cycling at all; the affordance below
/// it is always the locked "Another way 🔒" opening the Premium
/// teaser. Premium users can cycle through up to
/// [RefusalResponse.premiumDisplayCap] responses (normally 3,
/// occasionally 4), replacing the text in the same card each time —
/// never more than one response on screen at once, for anyone.
class SuggestedResponseScreen extends ConsumerStatefulWidget {
  const SuggestedResponseScreen({super.key});

  @override
  ConsumerState<SuggestedResponseScreen> createState() =>
      _SuggestedResponseScreenState();
}

class _SuggestedResponseScreenState
    extends ConsumerState<SuggestedResponseScreen> {
  bool _justCopied = false;
  int _visibleIndex = 0;

  void _handleCopy(String text) {
    Clipboard.setData(ClipboardData(text: text));
    HapticFeedback.lightImpact();
    setState(() => _justCopied = true);
    Future<void>.delayed(const Duration(seconds: 2), () {
      if (mounted) setState(() => _justCopied = false);
    });
  }

  Future<void> _handleToggleFavorite(String responseId) async {
    try {
      await ref
          .read(favoriteRepositoryProvider)
          .toggle(FavoriteEntityType.refusalResponse, responseId);
      ref.invalidate(_isFavoriteProvider(responseId));
    } catch (_) {
      // Favoriting is a nice-to-have, not part of the core Say No
      // flow — a failure here should never interrupt anything, just
      // silently leave the favorite state unchanged rather than
      // propagate an uncaught exception.
    }
  }

  @override
  Widget build(BuildContext context) {
    final flowState = ref.watch(sayNoFlowControllerProvider);
    final String? categoryId = flowState.selectedCategoryId;
    final String? situationId = flowState.selectedSituationId;
    final bool isCustomSituation = situationId == 'sit_custom_other';

    if (categoryId == null || situationId == null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) context.go(AppRoutes.sayNoCategory);
      });
      return const FlowScaffold(child: SizedBox.shrink());
    }

    if (isCustomSituation) {
      return FlowScaffold(
        bottomBar: PrimaryButton(
          label: 'Continue',
          onPressed: () => context.push(AppRoutes.sayNoReality),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const FlowHeader(title: 'Suggested response'),
            AppCard(
              child: Text(
                _fallbackResponseText,
                style: Theme.of(context).textTheme.titleLarge,
                textAlign: TextAlign.center,
              ),
            ),
            _philosophyLine(context),
          ],
        ),
      );
    }

    final AsyncValue<List<RefusalResponse>> responsesAsync = ref.watch(
      refusalResponsesForSituationProvider(
        (categoryId: categoryId, situationId: situationId),
      ),
    );
    final bool isPremium = ref.watch(effectiveIsPremiumProvider);

    return FlowScaffold(
      bottomBar: PrimaryButton(
        label: 'Continue',
        onPressed: () => context.push(AppRoutes.sayNoReality),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          const FlowHeader(title: 'Suggested response'),
          responsesAsync.when(
            data: (List<RefusalResponse> responses) {
              if (responses.isEmpty) {
                return AppCard(
                  child: Text(
                    _fallbackResponseText,
                    style: Theme.of(context).textTheme.titleLarge,
                    textAlign: TextAlign.center,
                  ),
                );
              }

              // Free: exactly 1 (the Recommended response). Premium:
              // up to premiumDisplayCap, even if more is authored.
              final int visibleLimit = ResponseVisibility.visibleCount(
                responses.length,
                isPremium: isPremium,
              );
              final int clampedIndex = _visibleIndex.clamp(0, visibleLimit - 1);
              final RefusalResponse current = responses[clampedIndex];

              if (flowState.selectedRefusalResponseId != current.id) {
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  ref
                      .read(sayNoFlowControllerProvider.notifier)
                      .selectRefusalResponse(current.id);
                });
              }

              final AsyncValue<bool> favoriteAsync =
                  ref.watch(_isFavoriteProvider(current.id));

              final String? premiumNextLabel = isPremium
                  ? ResponseVisibility.nextButtonLabelForPremium(
                      currentIndex: clampedIndex,
                      visibleLimit: visibleLimit,
                    )
                  : null;

              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  SuggestedResponseCard(
                    responseKey: current.id,
                    text: current.text,
                    isFavorite: favoriteAsync.value ?? false,
                    copyLabel: _justCopied ? 'Copied' : 'Copy',
                    onCopy: () => _handleCopy(current.text),
                    onToggleFavorite: () => _handleToggleFavorite(current.id),
                  ),
                  _philosophyLine(context),
                  if (!isPremium)
                    Center(
                      child: TextButton(
                        onPressed: () => showPremiumResponseTeaser(context),
                        child: const Text('Another way 🔒'),
                      ),
                    )
                  else if (premiumNextLabel != null)
                    Center(
                      child: TextButton(
                        onPressed: () {
                          final int nextIndex = clampedIndex + 1;
                          setState(() => _visibleIndex = nextIndex);
                          unawaited(ref.read(analyticsServiceProvider).anotherWayRequested(
                                categoryId: categoryId,
                                situationId: situationId,
                                responseVariantIndex: nextIndex,
                              ));
                        },
                        child: Text(premiumNextLabel),
                      ),
                    ),
                ],
              );
            },
            loading: () => const Padding(
              padding: EdgeInsets.only(top: 48),
              child: Center(child: CircularProgressIndicator()),
            ),
            error: (Object error, StackTrace stackTrace) =>
                Text('Could not load a response: $error'),
          ),
        ],
      ),
    );
  }

  Widget _philosophyLine(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: context.spacing.lg),
      child: Text(
        'The best boundary is one you can genuinely say.',
        textAlign: TextAlign.center,
        style: Theme.of(context)
            .textTheme
            .bodySmall
            ?.copyWith(color: context.colors.textSecondary),
      ),
    );
  }
}
