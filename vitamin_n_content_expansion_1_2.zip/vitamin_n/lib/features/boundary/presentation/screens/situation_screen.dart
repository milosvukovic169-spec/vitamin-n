import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../app/routes.dart';
import '../../../../design_system/theme/theme_extensions.dart';
import '../../../../design_system/widgets/primary_button.dart';
import '../../../situations/domain/entities/situation.dart';
import '../../../situations/presentation/providers/situation_providers.dart';
import '../../domain/services/scope_guard.dart';
import '../controllers/say_no_flow_controller.dart';
import '../widgets/flow_header.dart';
import '../widgets/flow_scaffold.dart';
import '../widgets/situation_tile.dart';

/// Step 3 — Choose Situation. For the "Other" category, this screen
/// instead shows a single free-text field (per the founder spec's
/// "Other: Custom everyday situation") and checks it against the
/// scope guard before continuing.
class SituationScreen extends ConsumerStatefulWidget {
  const SituationScreen({super.key});

  @override
  ConsumerState<SituationScreen> createState() => _SituationScreenState();
}

class _SituationScreenState extends ConsumerState<SituationScreen> {
  final TextEditingController _searchController = TextEditingController();
  final TextEditingController _customController = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _searchController.dispose();
    _customController.dispose();
    super.dispose();
  }

  void _proceedAfterSituationChosen(String situationId) {
    ref.read(sayNoFlowControllerProvider.notifier).selectSituation(situationId);
    context.push(AppRoutes.sayNoResponse);
  }

  void _handleCustomContinue() {
    final String text = _customController.text.trim();
    if (text.isEmpty) return;

    if (ScopeGuard.isOutOfScope(text)) {
      context.push(AppRoutes.sayNoOutOfScope);
      return;
    }

    ref.read(sayNoFlowControllerProvider.notifier).setCustomSituationText(text);
    _proceedAfterSituationChosen('sit_custom_other');
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(sayNoFlowControllerProvider);
    final String? categoryId = state.selectedCategoryId;

    if (categoryId == null) {
      // Defensive: flow state was lost (e.g. deep link). Send back
      // to the start rather than crash on a null category.
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) context.go(AppRoutes.sayNoCategory);
      });
      return const FlowScaffold(child: SizedBox.shrink());
    }

    if (state.isCategoryOther) {
      return FlowScaffold(
        bottomBar: PrimaryButton(
          label: 'Continue',
          onPressed: _customController.text.trim().isEmpty
              ? null
              : _handleCustomContinue,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const FlowHeader(
              title: 'What is happening?',
              subtitle: 'Describe the boundary in your own words.',
            ),
            TextField(
              controller: _customController,
              maxLines: 3,
              onChanged: (_) => setState(() {}),
              decoration: const InputDecoration(
                hintText: 'e.g. Being asked to change weekend plans again',
              ),
            ),
          ],
        ),
      );
    }

    final AsyncValue<List<Situation>> situationsAsync =
        ref.watch(situationsByCategoryIdProvider(categoryId));

    return FlowScaffold(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          const FlowHeader(
            title: 'What is happening?',
            subtitle: 'Choose the situation that is closest to yours.',
          ),
          TextField(
            controller: _searchController,
            onChanged: (String value) => setState(() => _query = value.toLowerCase()),
            decoration: const InputDecoration(
              hintText: 'Search',
              prefixIcon: Icon(Icons.search),
            ),
          ),
          SizedBox(height: context.spacing.md),
          situationsAsync.when(
            data: (List<Situation> situations) {
              final List<Situation> filtered = _query.isEmpty
                  ? situations
                  : situations
                      .where((Situation s) => s.title.toLowerCase().contains(_query))
                      .toList();

              if (filtered.isEmpty) {
                return Padding(
                  padding: EdgeInsets.only(top: context.spacing.xl),
                  child: Text(
                    'No matching situations. Try a different search.',
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                );
              }

              return Column(
                children: <Widget>[
                  for (final Situation situation in filtered) ...<Widget>[
                    SituationTile(
                      title: situation.title,
                      selected: situation.id == state.selectedSituationId,
                      onTap: () => _proceedAfterSituationChosen(situation.id),
                    ),
                    SizedBox(height: context.spacing.sm),
                  ],
                ],
              );
            },
            loading: () => const Padding(
              padding: EdgeInsets.only(top: 48),
              child: Center(child: CircularProgressIndicator()),
            ),
            error: (Object error, StackTrace stackTrace) =>
                Text('Could not load situations: $error'),
          ),
        ],
      ),
    );
  }
}
