import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../app/routes.dart';
import '../../../../design_system/theme/theme_extensions.dart';
import '../../../../design_system/widgets/primary_button.dart';
import '../widgets/flow_scaffold.dart';

/// Step 7 — Final Confirmation. Pressing "I SAID NO" only advances to
/// Protected Values — the entry is NOT persisted and the N token is
/// NOT removed until Protected Values are confirmed. Guards against
/// double-tap by disabling itself the instant it's pressed.
class FinalConfirmationScreen extends ConsumerStatefulWidget {
  const FinalConfirmationScreen({super.key});

  @override
  ConsumerState<FinalConfirmationScreen> createState() =>
      _FinalConfirmationScreenState();
}

class _FinalConfirmationScreenState
    extends ConsumerState<FinalConfirmationScreen> {
  bool _confirmed = false;

  void _handleConfirm() {
    if (_confirmed) return;
    setState(() => _confirmed = true);
    HapticFeedback.mediumImpact();
    context.push(AppRoutes.sayNoProtectedValues);
  }

  @override
  Widget build(BuildContext context) {
    final TextTheme textTheme = Theme.of(context).textTheme;

    return FlowScaffold(
      bottomBar: PrimaryButton(
        label: 'I SAID NO',
        onPressed: _confirmed ? null : _handleConfirm,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text('Ready when you are.', style: textTheme.headlineMedium),
          SizedBox(height: context.spacing.md),
          Text(
            'Confirm only after you have actually said No or kept the boundary.',
            style: textTheme.bodyLarge,
          ),
        ],
      ),
    );
  }
}
