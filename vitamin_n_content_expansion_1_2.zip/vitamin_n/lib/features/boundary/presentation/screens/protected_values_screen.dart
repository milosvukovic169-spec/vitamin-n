import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../app/routes.dart';
import '../../../../design_system/icon_mapping.dart';
import '../../../../design_system/theme/theme_extensions.dart';
import '../../../../design_system/widgets/app_card.dart';
import '../../../../design_system/widgets/primary_button.dart';
import '../../../protected_values/domain/entities/protected_value.dart';
import '../../../protected_values/presentation/providers/protected_value_providers.dart';
import '../controllers/say_no_flow_controller.dart';
import '../widgets/flow_header.dart';
import '../widgets/flow_scaffold.dart';
import '../widgets/protected_value_chip.dart';

/// Step 8 — Protected Values, followed immediately by Step 9
/// (persistence). Only after this screen's Continue succeeds does the
/// Entry get saved and the Course token get consumed.
class ProtectedValuesScreen extends ConsumerStatefulWidget {
  const ProtectedValuesScreen({super.key});

  @override
  ConsumerState<ProtectedValuesScreen> createState() =>
      _ProtectedValuesScreenState();
}

class _ProtectedValuesScreenState extends ConsumerState<ProtectedValuesScreen> {
  final TextEditingController _customController = TextEditingController();

  @override
  void dispose() {
    _customController.dispose();
    super.dispose();
  }

  Future<void> _handleContinue() async {
    HapticFeedback.selectionClick();
    await ref.read(sayNoFlowControllerProvider.notifier).submit();

    if (!mounted) return;
    final state = ref.read(sayNoFlowControllerProvider);
    if (state.submissionStatus == SubmissionStatus.success) {
      context.go(AppRoutes.home);
    }
  }

  @override
  Widget build(BuildContext context) {
    final flowState = ref.watch(sayNoFlowControllerProvider);
    final controller = ref.read(sayNoFlowControllerProvider.notifier);
    final AsyncValue<List<ProtectedValue>> valuesAsync =
        ref.watch(protectedValuesProvider);

    final bool showOtherField =
        flowState.selectedProtectedValueIds.contains('val_other');

    return FlowScaffold(
      bottomBar: PrimaryButton(
        label: 'Continue',
        loading: flowState.isSubmitting,
        onPressed: flowState.hasAtLeastOneProtectedValue && !flowState.isSubmitting
            ? _handleContinue
            : null,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          const FlowHeader(
            title: 'What did you protect?',
            subtitle: 'Choose what mattered most in this moment.',
          ),
          valuesAsync.when(
            data: (List<ProtectedValue> values) {
              final bool limitReached = !flowState.canSelectMoreProtectedValues;
              return Wrap(
                spacing: context.spacing.sm,
                runSpacing: context.spacing.sm,
                children: <Widget>[
                  for (final ProtectedValue value in values)
                    ProtectedValueChip(
                      label: value.label,
                      icon: ContentIconMapper.resolve(value.iconName),
                      selected: flowState.selectedProtectedValueIds.contains(value.id),
                      selectionLimitReached: limitReached,
                      onTap: () {
                        HapticFeedback.selectionClick();
                        controller.toggleProtectedValue(value.id);
                      },
                    ),
                ],
              );
            },
            loading: () => const Padding(
              padding: EdgeInsets.only(top: 24),
              child: Center(child: CircularProgressIndicator()),
            ),
            error: (Object error, StackTrace stackTrace) =>
                Text('Could not load values: $error'),
          ),
          if (showOtherField) ...<Widget>[
            SizedBox(height: context.spacing.md),
            TextField(
              controller: _customController,
              onChanged: controller.setCustomProtectedValueText,
              decoration: const InputDecoration(hintText: 'Name what you protected'),
            ),
          ],
          if (flowState.submissionStatus == SubmissionStatus.error) ...<Widget>[
            SizedBox(height: context.spacing.lg),
            AppCard(
              backgroundColor: context.colors.beige,
              child: Text(
                flowState.errorMessage ?? "Something didn't save. Please try again.",
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ),
          ],
        ],
      ),
    );
  }
}
