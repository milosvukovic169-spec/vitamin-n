import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/database/app_database_provider.dart';
import '../../../courses/presentation/providers/course_providers.dart';
import '../../../entries/presentation/providers/entry_providers.dart';
import '../../data/repositories/drift_say_no_transaction_runner.dart';
import '../../domain/repositories/say_no_transaction_runner.dart';
import '../../domain/usecases/confirm_say_no_usecase.dart';

/// Shares the exact same [AppDatabase] instance used by
/// [courseRepositoryProvider] and [entryRepositoryProvider] — this is
/// what makes the transaction below actually cover both repositories'
/// writes, not just look like it does.
final Provider<SayNoTransactionRunner> sayNoTransactionRunnerProvider =
    Provider<SayNoTransactionRunner>((Ref ref) {
  final db = ref.watch(appDatabaseProvider);
  return DriftSayNoTransactionRunner(db);
});

/// The single entry point for confirming a Say No entry — what the
/// "I SAID NO" confirmation step of the locked flow calls. Screens
/// never touch EntryRepository or CourseRepository directly.
final Provider<ConfirmSayNoUseCase> confirmSayNoUseCaseProvider =
    Provider<ConfirmSayNoUseCase>((Ref ref) {
  return ConfirmSayNoUseCase(
    entryRepository: ref.watch(entryRepositoryProvider),
    courseRepository: ref.watch(courseRepositoryProvider),
    transactionRunner: ref.watch(sayNoTransactionRunnerProvider),
  );
});
