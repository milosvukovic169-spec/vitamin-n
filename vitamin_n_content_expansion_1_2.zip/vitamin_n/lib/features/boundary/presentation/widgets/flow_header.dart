import 'package:flutter/material.dart';

import '../../../../design_system/theme/theme_extensions.dart';

/// The shared title + subtitle header used at the top of every "one
/// screen = one decision" step in the Say No flow.
class FlowHeader extends StatelessWidget {
  const FlowHeader({super.key, required this.title, this.subtitle});

  final String title;
  final String? subtitle;

  @override
  Widget build(BuildContext context) {
    final TextTheme textTheme = Theme.of(context).textTheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(title, style: textTheme.headlineMedium),
        if (subtitle != null) ...<Widget>[
          SizedBox(height: context.spacing.xs),
          Text(subtitle!, style: textTheme.bodyMedium),
        ],
        SizedBox(height: context.spacing.xl),
      ],
    );
  }
}
