import 'package:flutter/material.dart';

import '../../../../design_system/theme/theme_extensions.dart';
import '../../../../design_system/widgets/app_card.dart';

/// One selectable row on the Choose Situation step. Large touch
/// target, no icon clutter — just a clear title and calm selection
/// state.
class SituationTile extends StatelessWidget {
  const SituationTile({
    super.key,
    required this.title,
    required this.selected,
    required this.onTap,
  });

  final String title;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final AppColors colors = context.colors;

    return Semantics(
      button: true,
      selected: selected,
      label: title,
      child: AppCard(
        onTap: onTap,
        backgroundColor: selected ? colors.sage.withValues(alpha: 0.18) : null,
        padding: EdgeInsets.symmetric(
          horizontal: context.spacing.md,
          vertical: context.spacing.md,
        ),
        elevated: false,
        child: Row(
          children: <Widget>[
            Expanded(
              child: Text(title, style: Theme.of(context).textTheme.bodyLarge),
            ),
            Icon(
              selected ? Icons.check_circle : Icons.circle_outlined,
              color: selected ? colors.sageStrong : colors.border,
              size: 22,
            ),
          ],
        ),
      ),
    );
  }
}
