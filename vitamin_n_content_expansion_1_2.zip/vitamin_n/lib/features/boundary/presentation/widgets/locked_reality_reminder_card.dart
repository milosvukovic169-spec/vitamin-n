import 'package:flutter/material.dart';

import '../../../../core/analytics/analytics_service.dart';
import '../../../../design_system/theme/theme_extensions.dart';
import '../../../../design_system/widgets/app_card.dart';
import '../../../premium/presentation/screens/premium_screen.dart';

/// Shown in place of a Reality Reminder for a Free user in a category
/// where this feature isn't unlocked (Work, Digital). Per the final
/// monetization model: never silently remove the step, never a
/// full-screen paywall, and the flow's Continue button must remain
/// fully usable regardless — this is purely informational.
class LockedRealityReminderCard extends StatelessWidget {
  const LockedRealityReminderCard({super.key});

  @override
  Widget build(BuildContext context) {
    final AppColors colors = context.colors;
    final TextTheme textTheme = Theme.of(context).textTheme;

    return AppCard(
      onTap: () => Navigator.of(context).push<void>(
        MaterialPageRoute<void>(
                  builder: (_) => const PremiumScreen(entryPoint: PremiumEntryPoint.realityReminder),
                ),
      ),
      backgroundColor: colors.cream,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Icon(Icons.lock_outline, size: 18, color: colors.textSecondary),
              SizedBox(width: context.spacing.xs),
              Text('Reality Reminder', style: textTheme.titleSmall),
            ],
          ),
          SizedBox(height: context.spacing.sm),
          Text(
            "See what can gradually happen when this boundary isn't protected.",
            style: textTheme.bodyMedium,
          ),
          SizedBox(height: context.spacing.sm),
          Row(
            children: <Widget>[
              Text(
                'Unlock with Vitamin N Premium',
                style: textTheme.labelMedium?.copyWith(color: colors.sageStrong),
              ),
              SizedBox(width: context.spacing.xs),
              Icon(Icons.arrow_forward, size: 16, color: colors.sageStrong),
            ],
          ),
        ],
      ),
    );
  }
}
