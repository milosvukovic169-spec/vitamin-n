import 'package:flutter/material.dart';

import '../../../../design_system/widgets/value_chip.dart';

/// A selectable protected-value chip for the Protected Values step.
/// Thin wrapper over the shared [ValueChip] that additionally renders
/// as disabled once the 1–3 selection limit is reached and this chip
/// isn't already selected — a case specific to this step, not a
/// general [ValueChip] concern.
class ProtectedValueChip extends StatelessWidget {
  const ProtectedValueChip({
    super.key,
    required this.label,
    required this.icon,
    required this.selected,
    required this.selectionLimitReached,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final bool selected;
  final bool selectionLimitReached;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final bool enabled = selected || !selectionLimitReached;

    return ValueChip(
      label: label,
      icon: icon,
      selected: selected,
      enabled: enabled,
      onTap: enabled ? onTap : null,
    );
  }
}
