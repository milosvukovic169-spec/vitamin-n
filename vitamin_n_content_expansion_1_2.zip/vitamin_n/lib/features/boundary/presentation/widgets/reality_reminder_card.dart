import 'package:flutter/material.dart';

import '../../../../design_system/theme/theme_extensions.dart';
import '../../../../design_system/widgets/app_card.dart';

/// The single calm, educational reminder card on the Reality Reminder
/// step, with its "Based on common experiences" caption above it.
class RealityReminderCard extends StatelessWidget {
  const RealityReminderCard({super.key, required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    final TextTheme textTheme = Theme.of(context).textTheme;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text('Based on common experiences', style: textTheme.bodySmall),
        SizedBox(height: context.spacing.sm),
        AppCard(
          child: Text(text, style: textTheme.bodyLarge),
        ),
      ],
    );
  }
}
