import 'package:flutter/material.dart';

import '../../../../design_system/animation/app_animated_switcher.dart';
import '../../../../design_system/theme/theme_extensions.dart';
import '../../../../design_system/widgets/app_card.dart';

/// The single prominent response card on the Suggested Response step,
/// with compact Copy / Favorite actions below the text.
///
/// Per the locked Free Response UX, "Another way" never adds a second
/// card — it replaces the text IN THIS SAME card. [responseKey]
/// (typically the response's id) drives that: passing a new key
/// triggers [AppAnimatedSwitcher]'s subtle fade transition instead of
/// the text just snapping to the new value.
class SuggestedResponseCard extends StatelessWidget {
  const SuggestedResponseCard({
    super.key,
    required this.responseKey,
    required this.text,
    required this.isFavorite,
    required this.onCopy,
    required this.onToggleFavorite,
    this.copyLabel = 'Copy',
  });

  final Object responseKey;
  final String text;
  final bool isFavorite;
  final String copyLabel;
  final VoidCallback onCopy;
  final VoidCallback onToggleFavorite;

  @override
  Widget build(BuildContext context) {
    final AppColors colors = context.colors;
    final TextTheme textTheme = Theme.of(context).textTheme;

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Padding(
            padding: EdgeInsets.symmetric(vertical: context.spacing.sm),
            child: AppAnimatedSwitcher(
              child: Text(
                text,
                key: ValueKey<Object>(responseKey),
                style: textTheme.titleLarge,
                textAlign: TextAlign.center,
              ),
            ),
          ),
          SizedBox(height: context.spacing.md),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              TextButton.icon(
                onPressed: onCopy,
                icon: const Icon(Icons.copy_outlined, size: 18),
                label: Text(copyLabel),
              ),
              SizedBox(width: context.spacing.lg),
              TextButton.icon(
                onPressed: onToggleFavorite,
                icon: Icon(
                  isFavorite ? Icons.favorite : Icons.favorite_border,
                  size: 18,
                  color: isFavorite ? colors.sageStrong : null,
                ),
                label: Text(isFavorite ? 'Favorited' : 'Favorite'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
