import 'package:flutter/material.dart';

import '../../../../design_system/theme/theme_extensions.dart';

/// The shared scaffold for every screen in the Say No flow: warm
/// cream background, safe-area padding, optional back navigation, and
/// a scrollable body so nothing overflows on smaller phones or larger
/// system font sizes.
class FlowScaffold extends StatelessWidget {
  const FlowScaffold({
    super.key,
    required this.child,
    this.showBackButton = true,
    this.bottomBar,
    this.scrollable = true,
  });

  final Widget child;
  final bool showBackButton;
  final Widget? bottomBar;
  final bool scrollable;

  @override
  Widget build(BuildContext context) {
    final Widget body = Padding(
      padding: EdgeInsets.fromLTRB(
        context.spacing.lg,
        context.spacing.md,
        context.spacing.lg,
        context.spacing.xl,
      ),
      child: child,
    );

    final Widget? bottomBarWidget = bottomBar;

    return Scaffold(
      appBar: showBackButton
          ? AppBar(
              leading: BackButton(
                onPressed: () => Navigator.of(context).maybePop(),
              ),
            )
          : null,
      body: SafeArea(
        child: scrollable
            ? SingleChildScrollView(child: body)
            : body,
      ),
      bottomNavigationBar: bottomBarWidget == null
          ? null
          : SafeArea(
              minimum: EdgeInsets.all(context.spacing.lg),
              child: bottomBarWidget,
            ),
    );
  }
}
