import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/analytics/analytics_service.dart';
import '../../../../design_system/theme/theme_extensions.dart';
import '../../../../design_system/widgets/primary_button.dart';
import '../../../premium/presentation/screens/premium_screen.dart';
import '../../../situations/domain/entities/situation.dart';
import '../../../situations/presentation/providers/situation_providers.dart';

/// Shown when a Free user taps a Premium category. Never a bare
/// paywall — it shows what the category actually contains (situation
/// count + a few real examples) before asking to unlock, per section
/// 8: "The user should understand WHAT they would unlock."
///
/// Loading that category's situations here — only on tap, only for
/// this one category — is itself an instance of the lazy-loading
/// rule: nothing is fetched until the user actually asks to see it.
Future<void> showCategoryPreviewTeaser({
  required BuildContext context,
  required String categoryId,
  required String categoryName,
}) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (BuildContext context) => _CategoryPreviewTeaserSheet(
      categoryId: categoryId,
      categoryName: categoryName,
    ),
  );
}

class _CategoryPreviewTeaserSheet extends ConsumerWidget {
  const _CategoryPreviewTeaserSheet({
    required this.categoryId,
    required this.categoryName,
  });

  final String categoryId;
  final String categoryName;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AppColors colors = context.colors;
    final TextTheme textTheme = Theme.of(context).textTheme;
    final AsyncValue<List<Situation>> situationsAsync =
        ref.watch(situationsByCategoryIdProvider(categoryId));

    return SafeArea(
      child: Container(
        decoration: BoxDecoration(
          color: colors.surface,
          borderRadius: BorderRadius.only(
            topLeft: context.radius.xlRadius.topLeft,
            topRight: context.radius.xlRadius.topRight,
          ),
        ),
        padding: EdgeInsets.fromLTRB(
          context.spacing.lg,
          context.spacing.sm,
          context.spacing.lg,
          context.spacing.lg,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Center(
              child: Container(
                width: 40,
                height: 4,
                margin: EdgeInsets.only(bottom: context.spacing.lg),
                decoration: BoxDecoration(
                  color: colors.border,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            Text('$categoryName 🔒', style: textTheme.titleLarge),
            SizedBox(height: context.spacing.sm),
            situationsAsync.when(
              data: (List<Situation> situations) {
                final List<Situation> examples = situations.take(4).toList();
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      '${situations.length} situations',
                      style: textTheme.bodyMedium,
                    ),
                    SizedBox(height: context.spacing.md),
                    Text('Examples', style: textTheme.labelLarge),
                    SizedBox(height: context.spacing.xs),
                    for (final Situation situation in examples)
                      Padding(
                        padding: EdgeInsets.symmetric(vertical: context.spacing.xs),
                        child: Text('• ${situation.title}', style: textTheme.bodyLarge),
                      ),
                  ],
                );
              },
              loading: () => const Padding(
                padding: EdgeInsets.symmetric(vertical: 24),
                child: Center(child: CircularProgressIndicator()),
              ),
              error: (Object error, StackTrace stackTrace) =>
                  Text('Could not load a preview: $error'),
            ),
            SizedBox(height: context.spacing.lg),
            PrimaryButton(
              label: 'Unlock with Vitamin N Premium',
              // No real billing in Phase 5 — wired to the existing
              // Premium abstraction only.
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context).push<void>(
                  MaterialPageRoute<void>(
                  builder: (_) => const PremiumScreen(entryPoint: PremiumEntryPoint.lockedCategory),
                ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
