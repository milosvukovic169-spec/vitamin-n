import 'package:flutter/material.dart';

import '../../../../design_system/theme/theme_extensions.dart';
import '../../../../design_system/widgets/app_card.dart';

/// One selectable category card on the Choose Category step.
///
/// [locked] never hides the category or shows a bare/empty state —
/// tapping a locked card still opens (via [onTap]) since the caller
/// is responsible for showing the Premium preview teaser rather than
/// a dead end. This widget only renders the lock affordance.
class CategoryCard extends StatelessWidget {
  const CategoryCard({
    super.key,
    required this.title,
    required this.description,
    required this.icon,
    required this.selected,
    required this.onTap,
    this.locked = false,
  });

  final String title;
  final String description;
  final IconData icon;
  final bool selected;
  final bool locked;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final AppColors colors = context.colors;
    final TextTheme textTheme = Theme.of(context).textTheme;

    return Semantics(
      button: true,
      selected: selected,
      label: locked ? '$title, Premium. $description' : '$title. $description',
      child: AppCard(
        onTap: onTap,
        backgroundColor: selected ? colors.sage.withValues(alpha: 0.18) : null,
        child: Row(
          children: <Widget>[
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: colors.cream,
              ),
              child: Icon(icon, color: colors.sageStrong, size: 22),
            ),
            SizedBox(width: context.spacing.md),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Row(
                    children: <Widget>[
                      Flexible(child: Text(title, style: textTheme.titleMedium)),
                      if (locked) ...<Widget>[
                        SizedBox(width: context.spacing.xs),
                        Icon(Icons.lock_outline, size: 16, color: colors.textSecondary),
                      ],
                    ],
                  ),
                  SizedBox(height: context.spacing.xs / 2),
                  Text(description, style: textTheme.bodyMedium),
                ],
              ),
            ),
            SizedBox(width: context.spacing.sm),
            Icon(
              selected ? Icons.check_circle : Icons.chevron_right,
              color: selected ? colors.sageStrong : colors.textSecondary,
              size: 22,
            ),
          ],
        ),
      ),
    );
  }
}
