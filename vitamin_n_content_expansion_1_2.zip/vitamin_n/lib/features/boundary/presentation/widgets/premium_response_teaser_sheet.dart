import 'package:flutter/material.dart';

import '../../../../core/analytics/analytics_service.dart';
import '../../../../design_system/theme/theme_extensions.dart';
import '../../../../design_system/widgets/app_card.dart';
import '../../../../design_system/widgets/primary_button.dart';
import '../../../premium/presentation/screens/premium_screen.dart';

const List<String> _exampleStyles = <String>[
  'Warm',
  'Concise',
  'Direct',
  'Professional',
];

/// The elegant Premium preview shown after the single Free response,
/// per the final monetization model. Never a bare/empty paywall — it
/// explains what unlocking would actually provide.
Future<void> showPremiumResponseTeaser(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (BuildContext context) => const _PremiumResponseTeaserSheet(),
  );
}

class _PremiumResponseTeaserSheet extends StatelessWidget {
  const _PremiumResponseTeaserSheet();

  @override
  Widget build(BuildContext context) {
    final AppColors colors = context.colors;
    final TextTheme textTheme = Theme.of(context).textTheme;

    return SafeArea(
      child: Container(
        decoration: BoxDecoration(
          color: colors.surface,
          borderRadius: BorderRadius.only(
            topLeft: context.radius.xlRadius.topLeft,
            topRight: context.radius.xlRadius.topRight,
          ),
        ),
        padding: EdgeInsets.fromLTRB(
          context.spacing.lg,
          context.spacing.sm,
          context.spacing.lg,
          context.spacing.lg,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Center(
              child: Container(
                width: 40,
                height: 4,
                margin: EdgeInsets.only(bottom: context.spacing.lg),
                decoration: BoxDecoration(
                  color: colors.border,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            Text('Unlock more ways to say No', style: textTheme.titleLarge),
            SizedBox(height: context.spacing.sm),
            Text(
              'Find the wording that feels natural to you — warm, concise, '
              'direct, professional, or without overexplaining.',
              style: textTheme.bodyLarge,
            ),
            SizedBox(height: context.spacing.lg),
            AppCard(
              backgroundColor: colors.cream,
              child: Wrap(
                spacing: context.spacing.sm,
                runSpacing: context.spacing.sm,
                children: <Widget>[
                  for (final String style in _exampleStyles)
                    Chip(
                      label: Text(style),
                      backgroundColor: colors.surface,
                      side: BorderSide(color: colors.border),
                    ),
                ],
              ),
            ),
            SizedBox(height: context.spacing.lg),
            PrimaryButton(
              label: 'Unlock with Vitamin N Premium',
              // No real billing in Phase 5 — this is a placeholder
              // for the future purchase flow, wired to the existing
              // Premium abstraction only.
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.of(context).push<void>(
                  MaterialPageRoute<void>(
                  builder: (_) => const PremiumScreen(entryPoint: PremiumEntryPoint.anotherWay),
                ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
