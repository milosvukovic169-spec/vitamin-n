import '../../domain/entities/say_no_result.dart';

enum SubmissionStatus { idle, submitting, success, error }

/// Immutable state for the entire Say No flow, from category
/// selection through final persistence.
///
/// Deliberately holds only *user selections and flow-local flags* —
/// never fetched content (categories, situations, refusal responses,
/// reality reminders). Each screen reads content reactively from the
/// existing feature providers using the ids stored here; duplicating
/// that content into this state would create two sources of truth.
class SayNoFlowState {
  const SayNoFlowState({
    this.selectedCategoryId,
    this.selectedSituationId,
    this.customSituationText,
    this.selectedRefusalResponseId,
    this.shownRealityReminderIds = const <String>[],
    this.selectedRealityReminderId,
    this.personalReminderNote,
    this.selectedProtectedValueIds = const <String>{},
    this.customProtectedValueText,
    this.submissionStatus = SubmissionStatus.idle,
    this.errorMessage,
    this.result,
  });

  final String? selectedCategoryId;
  final String? selectedSituationId;

  /// Free text entered when the selected category is "Other" — the
  /// situation itself is user-authored rather than picked from JSON.
  final String? customSituationText;

  final String? selectedRefusalResponseId;

  /// Ids of reality reminders already shown this flow, so "Show
  /// another insight" never repeats one and the free-tier cap
  /// (2–3 per situation) can be enforced.
  final List<String> shownRealityReminderIds;
  final String? selectedRealityReminderId;

  /// A previously-saved personal reminder for this exact situation,
  /// loaded read-only for display — never authored during this flow.
  final String? personalReminderNote;

  final Set<String> selectedProtectedValueIds;
  final String? customProtectedValueText;

  final SubmissionStatus submissionStatus;
  final String? errorMessage;
  final SayNoResult? result;

  bool get isCategoryOther => selectedCategoryId == 'cat_other';

  bool get hasAtLeastOneProtectedValue =>
      selectedProtectedValueIds.isNotEmpty ||
      (customProtectedValueText != null &&
          customProtectedValueText!.trim().isNotEmpty);

  bool get canSelectMoreProtectedValues => selectedProtectedValueIds.length < 3;

  bool get isSubmitting => submissionStatus == SubmissionStatus.submitting;

  SayNoFlowState copyWith({
    String? selectedCategoryId,
    String? selectedSituationId,
    String? customSituationText,
    String? selectedRefusalResponseId,
    List<String>? shownRealityReminderIds,
    String? selectedRealityReminderId,
    String? personalReminderNote,
    bool clearPersonalReminderNote = false,
    Set<String>? selectedProtectedValueIds,
    String? customProtectedValueText,
    bool clearCustomProtectedValueText = false,
    SubmissionStatus? submissionStatus,
    String? errorMessage,
    bool clearErrorMessage = false,
    SayNoResult? result,
  }) {
    return SayNoFlowState(
      selectedCategoryId: selectedCategoryId ?? this.selectedCategoryId,
      selectedSituationId: selectedSituationId ?? this.selectedSituationId,
      customSituationText: customSituationText ?? this.customSituationText,
      selectedRefusalResponseId:
          selectedRefusalResponseId ?? this.selectedRefusalResponseId,
      shownRealityReminderIds:
          shownRealityReminderIds ?? this.shownRealityReminderIds,
      selectedRealityReminderId:
          selectedRealityReminderId ?? this.selectedRealityReminderId,
      personalReminderNote: clearPersonalReminderNote
          ? null
          : (personalReminderNote ?? this.personalReminderNote),
      selectedProtectedValueIds:
          selectedProtectedValueIds ?? this.selectedProtectedValueIds,
      customProtectedValueText: clearCustomProtectedValueText
          ? null
          : (customProtectedValueText ?? this.customProtectedValueText),
      submissionStatus: submissionStatus ?? this.submissionStatus,
      errorMessage: clearErrorMessage ? null : (errorMessage ?? this.errorMessage),
      result: result ?? this.result,
    );
  }
}
