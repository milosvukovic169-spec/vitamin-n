import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../core/analytics/analytics_providers.dart';
import '../../../personal_reminders/domain/entities/personal_reminder.dart';
import '../../../personal_reminders/domain/repositories/personal_reminder_repository.dart';
import '../../../personal_reminders/presentation/providers/personal_reminder_providers.dart';
import '../../domain/usecases/confirm_say_no_usecase.dart';
import '../providers/say_no_providers.dart';
import 'say_no_flow_state.dart';

export 'say_no_flow_state.dart' show SayNoFlowState, SubmissionStatus;

/// The single state controller for the entire Say No flow.
///
/// No business logic lives in the flow's widgets — every mutation and
/// the final persistence call go through here. State survives normal
/// route pushes within the flow (it's a single long-lived provider)
/// and is explicitly [reset] on cancellation or after a successful
/// completion, so a stale selection can never leak into the next run.
///
/// Per the Phase 5 locked flow, Reflection Pause is no longer part of
/// the product. [loadPersonalReminderForCurrentSituation] is kept
/// (dormant) rather than removed — a previously-saved personal
/// reminder may be shown contextually by a future feature, but per
/// Phase 5 it must never be loaded or displayed during the active Say
/// No flow, so nothing in this controller calls it anymore.
class SayNoFlowController extends Notifier<SayNoFlowState> {
  @override
  SayNoFlowState build() => const SayNoFlowState();

  void selectCategory(String categoryId) {
    // Changing category invalidates everything chosen for the
    // previous one (situation onward), so start a fresh state that
    // only carries the new category forward.
    state = SayNoFlowState(selectedCategoryId: categoryId);
    unawaited(
      ref.read(analyticsServiceProvider).categorySelected(categoryId: categoryId),
    );
  }

  void selectSituation(String situationId) {
    state = state.copyWith(selectedSituationId: situationId);
    final String? categoryId = state.selectedCategoryId;
    if (categoryId != null) {
      unawaited(ref.read(analyticsServiceProvider).situationSelected(
            categoryId: categoryId,
            situationId: situationId,
          ));
    }
  }

  void setCustomSituationText(String text) {
    state = state.copyWith(customSituationText: text);
  }

  Future<void> loadPersonalReminderForCurrentSituation() async {
    final String? situationId = state.selectedSituationId;
    if (situationId == null || situationId.isEmpty) {
      return;
    }
    final PersonalReminderRepository reminders =
        ref.read(personalReminderRepositoryProvider);
    final List<PersonalReminder> matches =
        await reminders.getActiveBySituationId(situationId);
    final PersonalReminder? note = matches.isEmpty ? null : matches.first;
    state = state.copyWith(
      personalReminderNote: note?.text,
      clearPersonalReminderNote: note == null,
    );
  }

  void selectRefusalResponse(String responseId) {
    final bool isFirstView = state.selectedRefusalResponseId == null;
    state = state.copyWith(selectedRefusalResponseId: responseId);
    final String? categoryId = state.selectedCategoryId;
    final String? situationId = state.selectedSituationId;
    if (isFirstView && categoryId != null && situationId != null) {
      unawaited(ref.read(analyticsServiceProvider).suggestedResponseViewed(
            categoryId: categoryId,
            situationId: situationId,
          ));
    }
  }

  void selectRealityReminder(String reminderId) {
    final bool isFirstView = state.selectedRealityReminderId == null;
    final List<String> shown = <String>{
      ...state.shownRealityReminderIds,
      reminderId,
    }.toList();
    state = state.copyWith(
      selectedRealityReminderId: reminderId,
      shownRealityReminderIds: shown,
    );
    final String? categoryId = state.selectedCategoryId;
    final String? situationId = state.selectedSituationId;
    if (isFirstView && categoryId != null && situationId != null) {
      unawaited(ref.read(analyticsServiceProvider).realityReminderViewed(
            categoryId: categoryId,
            situationId: situationId,
          ));
    }
  }

  void toggleProtectedValue(String valueId) {
    final Set<String> current = Set<String>.from(state.selectedProtectedValueIds);
    if (current.contains(valueId)) {
      current.remove(valueId);
    } else {
      if (current.length >= 3) {
        return;
      }
      current.add(valueId);
      unawaited(
        ref.read(analyticsServiceProvider).protectedValueSelected(protectedValueId: valueId),
      );
    }
    state = state.copyWith(selectedProtectedValueIds: current);
  }

  void setCustomProtectedValueText(String text) {
    state = state.copyWith(
      customProtectedValueText: text,
      clearCustomProtectedValueText: text.trim().isEmpty,
    );
  }

  /// Confirms the entry: consumes a Course token and persists the
  /// Entry. Guards against duplicate submission — a second call while
  /// one is already in flight, or after success, is a no-op.
  Future<void> submit() async {
    if (state.isSubmitting || state.submissionStatus == SubmissionStatus.success) {
      return;
    }
    if (!state.hasAtLeastOneProtectedValue) {
      return;
    }

    state = state.copyWith(
      submissionStatus: SubmissionStatus.submitting,
      clearErrorMessage: true,
    );

    try {
      final ConfirmSayNoUseCase useCase = ref.read(confirmSayNoUseCaseProvider);
      final result = await useCase(
        categoryId: state.selectedCategoryId!,
        situationId: state.selectedSituationId!,
        refusalResponseId: state.selectedRefusalResponseId,
        protectedValueIds: state.selectedProtectedValueIds.toList(),
        customProtectedValue: state.customProtectedValueText,
        personalReminderNote: state.personalReminderNote,
        // Reflection Pause is no longer part of the product (Phase 5).
        reflectionPauseShown: false,
      );

      state = state.copyWith(
        submissionStatus: SubmissionStatus.success,
        result: result,
      );
      unawaited(ref.read(analyticsServiceProvider).saidNoCompleted(
            categoryId: state.selectedCategoryId!,
            situationId: state.selectedSituationId!,
          ));
    } catch (_) {
      state = state.copyWith(
        submissionStatus: SubmissionStatus.error,
        errorMessage:
            "We couldn't save this just now. Your choices are still here — please try again.",
      );
    }
  }

  void clearError() {
    state = state.copyWith(clearErrorMessage: true);
  }

  /// Clears all flow state. Call after successful completion (once
  /// Home has consumed the result) or on explicit cancellation.
  void reset() {
    state = const SayNoFlowState();
  }
}

final NotifierProvider<SayNoFlowController, SayNoFlowState> sayNoFlowControllerProvider =
    NotifierProvider<SayNoFlowController, SayNoFlowState>(SayNoFlowController.new);
