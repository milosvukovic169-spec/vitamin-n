/// Abstraction for "run this as one atomic unit of work".
///
/// The domain layer depends only on this — never on Drift, SQL, or
/// any persistence detail. The data layer's implementation guarantees
/// that every database write performed inside [action] commits
/// together, or none of them do.
///
/// This exists specifically so [ConfirmSayNoUseCase] can wrap "consume
/// a Course token" and "create the Entry" in one real transaction
/// while still only depending on repository *interfaces* — the
/// concrete implementation is free to be Drift today and something
/// else later without this contract changing.
abstract class SayNoTransactionRunner {
  Future<T> run<T>(Future<T> Function() action);
}
