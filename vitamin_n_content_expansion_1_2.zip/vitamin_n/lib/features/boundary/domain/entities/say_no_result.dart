import '../../../courses/domain/entities/course.dart';
import '../../../entries/domain/entities/entry.dart';

/// The outcome of confirming "I SAID NO", composed from the Entries
/// and Courses domain.
class SayNoResult {
  const SayNoResult({
    required this.entry,
    required this.updatedCourse,
    required this.startedNewCourse,
  });

  final Entry entry;
  final Course updatedCourse;
  final bool startedNewCourse;

  /// True when [entry] was the 30th entry of the course it completed
  /// — i.e. [startedNewCourse] is true. Named separately here for
  /// readability at call sites that only care about showing the
  /// "Course complete" moment.
  bool get completedACourse => startedNewCourse;
}
