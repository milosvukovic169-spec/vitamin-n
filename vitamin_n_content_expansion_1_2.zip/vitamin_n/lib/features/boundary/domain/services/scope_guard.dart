/// Checks free-text custom situation input against Vitamin N's
/// product scope before allowing it into the flow.
///
/// Vitamin N supports everyday personal boundaries only. This is a
/// simple, local, keyword-based check — not a diagnosis, not a
/// classifier, and deliberately conservative (a false positive just
/// asks the person to rephrase or seek other support; a false
/// negative would let an out-of-scope topic through the flow, which
/// is the worse outcome). It never sends text anywhere; everything
/// stays on-device.
abstract final class ScopeGuard {
  static const List<String> _outOfScopeKeywords = <String>[
    // Mental health conditions / crisis
    'suicide', 'suicidal', 'self-harm', 'self harm', 'kill myself',
    'depression', 'depressed', 'anxiety disorder', 'panic attack',
    'trauma', 'ptsd', 'abuse', 'domestic violence', 'crisis',
    // Addiction / substance
    'addiction', 'addicted', 'alcoholic', 'alcoholism', 'drug abuse',
    'overdose', 'gambling addiction', 'quit drinking', 'quit smoking',
    'get sober', 'relapse',
    // Advice categories out of scope
    'medical advice', 'diagnose', 'diagnosis', 'prescription',
    'legal advice', 'lawsuit', 'sue my', 'financial advice',
    'bankruptcy', 'divorce lawyer',
  ];

  /// Returns true if [text] appears to reference an out-of-scope
  /// topic and should be blocked from entering the flow.
  static bool isOutOfScope(String text) {
    final String normalized = text.toLowerCase();
    for (final String keyword in _outOfScopeKeywords) {
      if (normalized.contains(keyword)) {
        return true;
      }
    }
    return false;
  }

  static const String scopeMessageTitle =
      'This topic is outside the intended scope of Vitamin N.';

  static const String scopeMessageBody =
      'Vitamin N focuses on everyday personal boundaries and mindful '
      'choices. If this situation affects your health, safety or '
      'wellbeing, consider seeking support from an appropriate '
      'qualified professional or trusted local service.';
}
