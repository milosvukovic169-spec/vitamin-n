import 'package:uuid/uuid.dart';

import '../../../courses/domain/repositories/course_repository.dart';
import '../../../entries/domain/entities/entry.dart';
import '../../../entries/domain/repositories/entry_repository.dart';
import '../entities/say_no_result.dart';
import '../repositories/say_no_transaction_runner.dart';

/// Confirms a Say No entry: consumes one Course token and persists
/// the Entry as ONE atomic unit of work.
///
/// Both writes happen inside [SayNoTransactionRunner.run]. If the
/// Entry write fails for any reason (a database error, a constraint
/// violation, anything), the Course token consumption — and, if this
/// was the 30th token, the course-completion + next-course-creation —
/// is rolled back too. Neither happens, or both do; there is no
/// partial state. This is enforced by the transaction boundary below,
/// not merely documented — see the rollback test in
/// `confirm_say_no_usecase_test.dart`.
class ConfirmSayNoUseCase {
  ConfirmSayNoUseCase({
    required EntryRepository entryRepository,
    required CourseRepository courseRepository,
    required SayNoTransactionRunner transactionRunner,
    Uuid uuid = const Uuid(),
  })  : _entryRepository = entryRepository,
        _courseRepository = courseRepository,
        _transactionRunner = transactionRunner,
        _uuid = uuid;

  final EntryRepository _entryRepository;
  final CourseRepository _courseRepository;
  final SayNoTransactionRunner _transactionRunner;
  final Uuid _uuid;

  /// [protectedValueIds] must be non-empty (1 to 3, enforced by the
  /// flow controller before this is called) unless [customProtectedValue]
  /// is supplied instead of/alongside a value id.
  Future<SayNoResult> call({
    required String categoryId,
    required String situationId,
    String? refusalResponseId,
    required List<String> protectedValueIds,
    String? customProtectedValue,
    String? personalReminderNote,
    required bool reflectionPauseShown,
  }) async {
    assert(
      protectedValueIds.isNotEmpty || customProtectedValue != null,
      'At least one protected value (or a custom one) must be selected.',
    );

    return _transactionRunner.run<SayNoResult>(() async {
      // Step 1: consume a token (retrieves-or-creates the current
      // Course, decrements it, and — if this was the 30th token —
      // completes it and creates the next Course). All of this is
      // itself inside the outer transaction started above.
      final CourseTokenConsumptionResult tokenResult =
          await _courseRepository.consumeToken();

      // Step 2: build and persist the Entry against the course cycle
      // the token was actually consumed from.
      final Entry entry = Entry(
        id: _uuid.v4(),
        categoryId: categoryId,
        situationId: situationId,
        refusalResponseId: refusalResponseId,
        protectedValueIds: protectedValueIds,
        customProtectedValue: customProtectedValue,
        personalReminderNote: personalReminderNote,
        reflectionPauseShown: reflectionPauseShown,
        courseId: tokenResult.consumedFromCourseId,
        createdAt: DateTime.now(),
      );

      // If this throws, the transaction runner rolls back everything
      // written in Step 1 as well — there is no window where a token
      // is consumed but no Entry exists for it.
      final Entry savedEntry = await _entryRepository.create(entry);

      return SayNoResult(
        entry: savedEntry,
        updatedCourse: tokenResult.updatedCourse,
        startedNewCourse: tokenResult.startedNewCourse,
      );
    });
  }
}
