#!/usr/bin/env bash
# Run this once after unzipping, and again any time a Drift table
# changes. Requires the Flutter SDK on PATH.
set -e

echo "==> flutter pub get"
flutter pub get

echo "==> dart run build_runner build --delete-conflicting-outputs"
dart run build_runner build --delete-conflicting-outputs

echo "==> flutter analyze"
flutter analyze

echo "==> flutter test"
flutter test

echo ""
echo "Done. lib/core/database/app_database.g.dart should now exist."
