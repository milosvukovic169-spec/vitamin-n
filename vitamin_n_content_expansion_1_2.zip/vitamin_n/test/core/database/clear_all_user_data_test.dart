import 'package:drift/native.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/core/database/app_database.dart';

void main() {
  late AppDatabase db;

  setUp(() {
    db = AppDatabase.forTesting(NativeDatabase.memory());
  });

  tearDown(() async {
    await db.close();
  });

  Future<int> seedCourse() {
    return db.into(db.courses).insert(
          CoursesCompanion.insert(
            cycleNumber: 1,
            tokensRemaining: 20,
            startedAt: DateTime(2026, 1, 1),
          ),
        );
  }

  test('clearAllUserData removes Entries, Courses, Favorites, '
      'ActiveChallenges and PersonalReminders', () async {
    final int courseId = await seedCourse();
    await db.into(db.entries).insert(
          EntriesCompanion.insert(
            id: 'entry-1',
            categoryId: 'cat_work',
            situationId: 'sit_overtime',
            protectedValueIds: '["val_time"]',
            courseId: courseId,
            createdAt: DateTime(2026, 1, 2),
          ),
        );
    await db.into(db.favorites).insert(
          FavoritesCompanion.insert(
            id: 'fav-1',
            entityType: 'refusalResponse',
            entityId: 'rr_overtime_1',
            createdAt: DateTime(2026, 1, 2),
          ),
        );
    await db.into(db.activeChallenges).insert(
          ActiveChallengesCompanion.insert(
            programId: 'challenge_work_boundaries',
            startedAt: DateTime(2026, 1, 2),
          ),
        );
    await db.into(db.personalReminders).insert(
          PersonalRemindersCompanion.insert(
            id: 'reminder-1',
            reminderText: 'Check your calendar before saying yes.',
            createdAt: DateTime(2026, 1, 2),
            updatedAt: DateTime(2026, 1, 2),
          ),
        );

    await db.clearAllUserData();

    expect(await db.select(db.entries).get(), isEmpty);
    expect(await db.select(db.courses).get(), isEmpty);
    expect(await db.select(db.favorites).get(), isEmpty);
    expect(await db.select(db.activeChallenges).get(), isEmpty);
    expect(await db.select(db.personalReminders).get(), isEmpty);
  });

  test('clearAllUserData does NOT touch the Settings table — onboarding state, '
      'per-Challenge step progress, and any future Premium entitlement flag '
      'must all survive (spec section 31)', () async {
    await db.into(db.settings).insert(
          SettingsCompanion.insert(key: 'onboarding_completed', value: 'true'),
        );
    await db.into(db.settings).insert(
          SettingsCompanion.insert(
            key: 'challenge_progress:challenge_work_boundaries',
            value: '["challenge_work_boundaries_step_1"]',
          ),
        );

    await seedCourse();
    await db.clearAllUserData();

    final settingsRows = await db.select(db.settings).get();
    expect(settingsRows, hasLength(2), reason: 'Settings must be completely untouched');
    final Set<String> keys = settingsRows.map((row) => row.key).toSet();
    expect(keys, <String>{
      'onboarding_completed',
      'challenge_progress:challenge_work_boundaries',
    });
  });

  test('clearAllUserData does not conceptually cancel a Vitamin N Premium '
      'subscription — the real cached entitlement flag (Phase 7 section 26/31) '
      'survives a clear', () async {
    await db.into(db.settings).insert(
          SettingsCompanion.insert(
            key: 'cached_premium_entitlement',
            value: 'true',
          ),
        );

    await seedCourse();
    await db.clearAllUserData();

    final cachedEntitlementRow = await (db.select(db.settings)
          ..where((tbl) => tbl.key.equals('cached_premium_entitlement')))
        .getSingleOrNull();
    expect(cachedEntitlementRow, isNotNull,
        reason: 'clearing local content must never look like cancelling a purchase');
    expect(cachedEntitlementRow!.value, 'true');
  });

  test('the app remains fully usable immediately after clearing — a new Course '
      'can be created without any error or restart', () async {
    await seedCourse();
    await db.clearAllUserData();

    final int newCourseId = await db.into(db.courses).insert(
          CoursesCompanion.insert(
            cycleNumber: 1,
            tokensRemaining: 30,
            startedAt: DateTime(2026, 1, 5),
          ),
        );

    final courses = await db.select(db.courses).get();
    expect(courses, hasLength(1));
    expect(courses.single.id, newCourseId);
  });
}
