import 'dart:io';

import 'package:drift/drift.dart';
import 'package:drift/native.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:path/path.dart' as p;
import 'package:vitamin_n/core/database/app_database.dart';

/// Simulates a pre-fix (Phase 3) database: the exact same tables as
/// today, at schemaVersion 1, but with `onCreate` deliberately
/// creating tables ONLY — no indexes — via [Migrator.createTable]
/// rather than [Migrator.createAll]. This uses the real, generated
/// table definitions (so column types/constraints are guaranteed to
/// match production exactly) while still faithfully reproducing the
/// index-less schema that actually shipped before this fix.
class _LegacyV1Database extends AppDatabase {
  _LegacyV1Database(super.executor) : super.forTesting();

  @override
  int get schemaVersion => 1;

  @override
  MigrationStrategy get migration => MigrationStrategy(
        onCreate: (Migrator m) async {
          await m.createTable(courses);
          await m.createTable(entries);
          await m.createTable(settings);
          await m.createTable(favorites);
          await m.createTable(activeChallenges);
        },
      );
}

/// Simulates a pre-Phase-6 (v2) database: every table except
/// PersonalReminders, with the v2 indexes already applied — i.e.
/// exactly what a real user's database looked like right before this
/// phase's migration.
class _LegacyV2Database extends AppDatabase {
  _LegacyV2Database(super.executor) : super.forTesting();

  @override
  int get schemaVersion => 2;

  @override
  MigrationStrategy get migration => MigrationStrategy(
        onCreate: (Migrator m) async {
          await m.createTable(courses);
          await m.createTable(entries);
          await m.createTable(settings);
          await m.createTable(favorites);
          await m.createTable(activeChallenges);
          await m.database.customStatement(
            'CREATE INDEX IF NOT EXISTS idx_entries_created_at ON entries (created_at)',
          );
          await m.database.customStatement(
            'CREATE INDEX IF NOT EXISTS idx_entries_category_id ON entries (category_id)',
          );
          await m.database.customStatement(
            'CREATE INDEX IF NOT EXISTS idx_entries_situation_id ON entries (situation_id)',
          );
        },
      );
}

void main() {
  late Directory tempDir;
  late File dbFile;

  setUp(() {
    tempDir = Directory.systemTemp.createTempSync('vitamin_n_migration_test');
    dbFile = File(p.join(tempDir.path, 'legacy.sqlite'));
  });

  tearDown(() {
    if (tempDir.existsSync()) {
      tempDir.deleteSync(recursive: true);
    }
  });

  test(
    'a v1 database (no indexes) upgrades to v2 (indexed) without losing '
    'entries or course data',
    () async {
      // --- Step 1: create and populate a legacy v1 database. ---
      final _LegacyV1Database legacyDb =
          _LegacyV1Database(NativeDatabase(dbFile));

      final int courseId = await legacyDb.into(legacyDb.courses).insert(
            CoursesCompanion.insert(
              cycleNumber: 1,
              tokensRemaining: 27,
              startedAt: DateTime(2026, 1, 1),
            ),
          );

      await legacyDb.into(legacyDb.entries).insert(
            EntriesCompanion.insert(
              id: 'legacy-entry-1',
              categoryId: 'cat_work',
              situationId: 'sit_overtime',
              protectedValueIds: '["val_time"]',
              courseId: courseId,
              createdAt: DateTime(2026, 1, 2, 9, 30),
            ),
          );
      await legacyDb.into(legacyDb.entries).insert(
            EntriesCompanion.insert(
              id: 'legacy-entry-2',
              categoryId: 'cat_money',
              situationId: 'sit_lending_money',
              protectedValueIds: '["val_money","val_peace"]',
              courseId: courseId,
              createdAt: DateTime(2026, 1, 3, 14, 0),
            ),
          );

      // Confirm the legacy schema really has no indexes yet, so the
      // upgrade assertion below is meaningful rather than vacuous.
      final List<Map<String, Object?>> indexesBefore = await legacyDb
          .customSelect(
            "SELECT name FROM sqlite_master WHERE type = 'index' "
            "AND name LIKE 'idx_entries_%'",
          )
          .get()
          .then((rows) => rows.map((r) => r.data).toList());
      expect(indexesBefore, isEmpty);

      await legacyDb.close();

      // --- Step 2: reopen the SAME file with the real, current
      // AppDatabase (schemaVersion 2) — this is what a real app
      // upgrade looks like. ---
      final AppDatabase upgradedDb = AppDatabase.forTesting(NativeDatabase(dbFile));

      final List<Map<String, Object?>> indexesAfter = await upgradedDb
          .customSelect(
            "SELECT name FROM sqlite_master WHERE type = 'index' "
            "AND name LIKE 'idx_entries_%'",
          )
          .get()
          .then((rows) => rows.map((r) => r.data).toList());

      final Set<String?> indexNames =
          indexesAfter.map((row) => row['name'] as String?).toSet();
      expect(indexNames, <String?>{
        'idx_entries_created_at',
        'idx_entries_category_id',
        'idx_entries_situation_id',
      });

      // --- Step 3: existing data must be completely intact. ---
      final courses = await upgradedDb.select(upgradedDb.courses).get();
      expect(courses, hasLength(1));
      expect(courses.single.id, courseId);
      expect(courses.single.cycleNumber, 1);
      expect(courses.single.tokensRemaining, 27);

      final entries = await upgradedDb.select(upgradedDb.entries).get();
      expect(entries, hasLength(2));

      final EntryRow first = entries.firstWhere((e) => e.id == 'legacy-entry-1');
      expect(first.categoryId, 'cat_work');
      expect(first.situationId, 'sit_overtime');
      expect(first.protectedValueIds, '["val_time"]');
      expect(first.courseId, courseId);

      final EntryRow second = entries.firstWhere((e) => e.id == 'legacy-entry-2');
      expect(second.categoryId, 'cat_money');
      expect(second.protectedValueIds, '["val_money","val_peace"]');

      await upgradedDb.close();
    },
  );

  test('a brand-new (v2 from scratch) database also has all three indexes', () async {
    final AppDatabase freshDb = AppDatabase.forTesting(NativeDatabase(dbFile));

    final List<Map<String, Object?>> indexes = await freshDb
        .customSelect(
          "SELECT name FROM sqlite_master WHERE type = 'index' "
          "AND name LIKE 'idx_entries_%'",
        )
        .get()
        .then((rows) => rows.map((r) => r.data).toList());

    final Set<String?> indexNames =
        indexes.map((row) => row['name'] as String?).toSet();
    expect(indexNames, <String?>{
      'idx_entries_created_at',
      'idx_entries_category_id',
      'idx_entries_situation_id',
    });

    await freshDb.close();
  });

  test(
    'a v2 database (no PersonalReminders table) upgrades to v3 without '
    'losing entries or course data',
    () async {
      final _LegacyV2Database legacyDb = _LegacyV2Database(NativeDatabase(dbFile));

      final int courseId = await legacyDb.into(legacyDb.courses).insert(
            CoursesCompanion.insert(
              cycleNumber: 3,
              tokensRemaining: 12,
              startedAt: DateTime(2026, 2, 1),
            ),
          );
      await legacyDb.into(legacyDb.entries).insert(
            EntriesCompanion.insert(
              id: 'v2-entry-1',
              categoryId: 'cat_digital',
              situationId: 'sit_endless_scrolling',
              protectedValueIds: '["val_time"]',
              courseId: courseId,
              createdAt: DateTime(2026, 2, 2, 20, 0),
            ),
          );
      await legacyDb.into(legacyDb.favorites).insert(
            FavoritesCompanion.insert(
              id: 'v2-favorite-1',
              entityType: 'refusalResponse',
              entityId: 'rr_endless_scrolling_1',
              createdAt: DateTime(2026, 2, 2, 20, 5),
            ),
          );

      // Confirm the legacy schema really has no PersonalReminders
      // table yet, so the upgrade assertion below is meaningful.
      final List<Map<String, Object?>> tablesBefore = await legacyDb
          .customSelect(
            "SELECT name FROM sqlite_master WHERE type = 'table' "
            "AND name = 'personal_reminders'",
          )
          .get()
          .then((rows) => rows.map((r) => r.data).toList());
      expect(tablesBefore, isEmpty);

      await legacyDb.close();

      // Reopen the SAME file with the real, current AppDatabase (v3).
      final AppDatabase upgradedDb = AppDatabase.forTesting(NativeDatabase(dbFile));

      final List<Map<String, Object?>> tablesAfter = await upgradedDb
          .customSelect(
            "SELECT name FROM sqlite_master WHERE type = 'table' "
            "AND name = 'personal_reminders'",
          )
          .get()
          .then((rows) => rows.map((r) => r.data).toList());
      expect(tablesAfter, hasLength(1), reason: 'PersonalReminders table must now exist');

      // The new table is usable immediately after upgrade — proving
      // CREATE, UPDATE and DELETE, not just table existence (spec
      // section 17 explicitly requires all three, not fresh-DB-only).
      await upgradedDb.into(upgradedDb.personalReminders).insert(
            PersonalRemindersCompanion.insert(
              id: 'reminder-1',
              reminderText: 'I lost my whole evening.',
              categoryId: const Value<String?>('cat_work'),
              situationId: const Value<String?>('sit_overtime'),
              createdAt: DateTime(2026, 2, 3),
              updatedAt: DateTime(2026, 2, 3),
            ),
          );
      final createdRows = await upgradedDb.select(upgradedDb.personalReminders).get();
      expect(createdRows, hasLength(1));
      expect(createdRows.single.reminderText, 'I lost my whole evening.');
      expect(createdRows.single.isActive, isTrue, reason: 'defaults to active');

      // UPDATE
      await (upgradedDb.update(upgradedDb.personalReminders)
            ..where((tbl) => tbl.id.equals('reminder-1')))
          .write(
        PersonalRemindersCompanion(
          reminderText: const Value<String>('Check the calendar before agreeing.'),
          updatedAt: Value<DateTime>(DateTime(2026, 2, 4)),
        ),
      );
      final updatedRow = await (upgradedDb.select(upgradedDb.personalReminders)
            ..where((tbl) => tbl.id.equals('reminder-1')))
          .getSingle();
      expect(updatedRow.reminderText, 'Check the calendar before agreeing.');

      // DELETE
      await (upgradedDb.delete(upgradedDb.personalReminders)
            ..where((tbl) => tbl.id.equals('reminder-1')))
          .go();
      final afterDelete = await upgradedDb.select(upgradedDb.personalReminders).get();
      expect(afterDelete, isEmpty);

      // Prior data is completely intact.
      final courses = await upgradedDb.select(upgradedDb.courses).get();
      expect(courses, hasLength(1));
      expect(courses.single.id, courseId);
      expect(courses.single.tokensRemaining, 12);

      final entries = await upgradedDb.select(upgradedDb.entries).get();
      expect(entries, hasLength(1));
      expect(entries.single.id, 'v2-entry-1');
      expect(entries.single.categoryId, 'cat_digital');

      final favorites = await upgradedDb.select(upgradedDb.favorites).get();
      expect(favorites, hasLength(1));
      expect(favorites.single.id, 'v2-favorite-1');
      expect(favorites.single.entityId, 'rr_endless_scrolling_1');

      // The v2 indexes are also still present — nothing regressed.
      final indexNames = await upgradedDb
          .customSelect(
            "SELECT name FROM sqlite_master WHERE type = 'index' "
            "AND name LIKE 'idx_entries_%'",
          )
          .get()
          .then((rows) => rows.map((r) => r.data['name'] as String).toSet());
      expect(indexNames, <String>{
        'idx_entries_created_at',
        'idx_entries_category_id',
        'idx_entries_situation_id',
      });

      await upgradedDb.close();
    },
  );

  test('a brand-new (v3 from scratch) database has the PersonalReminders table', () async {
    final AppDatabase freshDb = AppDatabase.forTesting(NativeDatabase(dbFile));

    final List<Map<String, Object?>> tables = await freshDb
        .customSelect(
          "SELECT name FROM sqlite_master WHERE type = 'table' "
          "AND name = 'personal_reminders'",
        )
        .get()
        .then((rows) => rows.map((r) => r.data).toList());
    expect(tables, hasLength(1));

    await freshDb.close();
  });
}
