import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/core/analytics/analytics_service.dart';

import '../../fakes/recording_analytics_service.dart';

void main() {
  late RecordingAnalyticsService analytics;

  setUp(() {
    analytics = RecordingAnalyticsService();
  });

  test('appOpened logs app_opened with no parameters', () async {
    await analytics.appOpened();
    expect(analytics.events.single.name, 'app_opened');
    expect(analytics.events.single.parameters, isEmpty);
  });

  test('categorySelected logs the controlled category_id only', () async {
    await analytics.categorySelected(categoryId: 'cat_work');
    expect(analytics.events.single.name, 'category_selected');
    expect(analytics.events.single.parameters, <String, Object?>{'category_id': 'cat_work'});
  });

  test('situationSelected logs both controlled ids', () async {
    await analytics.situationSelected(categoryId: 'cat_work', situationId: 'sit_overtime');
    expect(analytics.events.single.name, 'situation_selected');
    expect(analytics.events.single.parameters, <String, Object?>{
      'category_id': 'cat_work',
      'situation_id': 'sit_overtime',
    });
  });

  test('anotherWayRequested logs the response_variant_index', () async {
    await analytics.anotherWayRequested(
      categoryId: 'cat_work',
      situationId: 'sit_overtime',
      responseVariantIndex: 2,
    );
    expect(analytics.events.single.parameters['response_variant_index'], 2);
  });

  test('protectedValueSelected logs the controlled protected_value_id', () async {
    await analytics.protectedValueSelected(protectedValueId: 'val_time');
    expect(analytics.events.single.name, 'protected_value_selected');
    expect(analytics.events.single.parameters, <String, Object?>{
      'protected_value_id': 'val_time',
    });
  });

  group('premium_screen_viewed entry_point', () {
    test('settings', () async {
      await analytics.premiumScreenViewed(entryPoint: PremiumEntryPoint.settings);
      expect(analytics.events.single.parameters['entry_point'], 'settings');
    });

    test('locked_category', () async {
      await analytics.premiumScreenViewed(entryPoint: PremiumEntryPoint.lockedCategory);
      expect(analytics.events.single.parameters['entry_point'], 'locked_category');
    });

    test('another_way', () async {
      await analytics.premiumScreenViewed(entryPoint: PremiumEntryPoint.anotherWay);
      expect(analytics.events.single.parameters['entry_point'], 'another_way');
    });

    test('reality_reminder', () async {
      await analytics.premiumScreenViewed(entryPoint: PremiumEntryPoint.realityReminder);
      expect(analytics.events.single.parameters['entry_point'], 'reality_reminder');
    });

    test('challenge', () async {
      await analytics.premiumScreenViewed(entryPoint: PremiumEntryPoint.challenge);
      expect(analytics.events.single.parameters['entry_point'], 'challenge');
    });
  });

  group('plan_type', () {
    test('monthly', () async {
      await analytics.premiumPlanSelected(planType: PlanType.monthly);
      expect(analytics.events.single.parameters['plan_type'], 'monthly');
    });

    test('yearly', () async {
      await analytics.premiumPlanSelected(planType: PlanType.yearly);
      expect(analytics.events.single.parameters['plan_type'], 'yearly');
    });
  });

  test('purchase funnel logs the correct event names for each outcome', () async {
    await analytics.purchaseStarted(planType: PlanType.monthly);
    await analytics.purchaseCompleted(planType: PlanType.monthly);
    await analytics.purchaseCancelled(planType: PlanType.yearly);
    await analytics.purchaseFailed(planType: PlanType.yearly);

    expect(analytics.events.map((e) => e.name), <String>[
      'purchase_started',
      'purchase_completed',
      'purchase_cancelled',
      'purchase_failed',
    ]);
  });

  test('restore funnel logs the correct event names', () async {
    await analytics.restoreStarted();
    await analytics.restoreCompleted();
    await analytics.restoreNoPurchaseFound();

    expect(analytics.events.map((e) => e.name), <String>[
      'restore_started',
      'restore_completed',
      'restore_no_purchase_found',
    ]);
  });

  group('Personal Reminder lifecycle events never carry content', () {
    test('personalReminderCreated has zero parameters', () async {
      await analytics.personalReminderCreated();
      expect(analytics.events.single.name, 'personal_reminder_created');
      expect(analytics.events.single.parameters, isEmpty);
    });

    test('personalReminderDeleted has zero parameters', () async {
      await analytics.personalReminderDeleted();
      expect(analytics.events.single.name, 'personal_reminder_deleted');
      expect(analytics.events.single.parameters, isEmpty);
    });

    test(
      'the actual Personal Reminder screen never passes reminder text into '
      'an analytics call — verified by reading the real source file, not by '
      'convention',
      () {
        final String source = File(
          'lib/features/personal_reminders/presentation/screens/'
          'add_edit_personal_reminder_screen.dart',
        ).readAsStringSync();

        final List<String> analyticsCallLines = source
            .split('\n')
            .where((String line) => line.contains('analyticsServiceProvider'))
            .toList();
        expect(analyticsCallLines, isNotEmpty,
            reason: 'sanity check — this screen must actually call analytics');

        // Look at each analytics call and the few lines around it for
        // anything that could be reminder content.
        final List<String> lines = source.split('\n');
        for (int i = 0; i < lines.length; i++) {
          if (!lines[i].contains('analyticsServiceProvider')) continue;
          final String window = lines.sublist(i, (i + 3).clamp(0, lines.length)).join('\n');
          expect(window.contains('_textController'), isFalse,
              reason: 'an analytics call must never reference the text field controller');
          expect(window.contains('.text,'), isFalse,
              reason: 'an analytics call must never pass raw reminder text');
        }
      },
    );

    test(
      'AnalyticsService.personalReminderCreated/Deleted take zero arguments — '
      'structurally impossible to pass reminder text through them',
      () {
        final String source =
            File('lib/core/analytics/analytics_service.dart').readAsStringSync();
        expect(
          source.contains('Future<void> personalReminderCreated();'),
          isTrue,
        );
        expect(
          source.contains('Future<void> personalReminderDeleted();'),
          isTrue,
        );
      },
    );
  });
}
