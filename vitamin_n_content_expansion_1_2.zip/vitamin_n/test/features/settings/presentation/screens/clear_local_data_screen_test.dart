import 'package:drift/native.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/core/database/app_database.dart';
import 'package:vitamin_n/core/database/app_database_provider.dart';
import 'package:vitamin_n/design_system/theme/app_theme.dart';
import 'package:vitamin_n/features/settings/presentation/screens/clear_local_data_screen.dart';

void main() {
  late AppDatabase db;
  late ProviderContainer container;

  setUp(() {
    db = AppDatabase.forTesting(NativeDatabase.memory());
    container = ProviderContainer(
      overrides: <Override>[appDatabaseProvider.overrideWithValue(db)],
    );
  });

  tearDown(() async {
    container.dispose();
    await db.close();
  });

  Future<void> pumpScreen(WidgetTester tester) async {
    await tester.pumpWidget(
      UncontrolledProviderScope(
        container: container,
        child: MaterialApp(theme: AppTheme.light, home: const ClearLocalDataScreen()),
      ),
    );
    await tester.pump();
    await tester.pump();
  }

  Future<int> seedCourse() {
    return db.into(db.courses).insert(
          CoursesCompanion.insert(
            cycleNumber: 1,
            tokensRemaining: 20,
            startedAt: DateTime(2026, 1, 1),
          ),
        );
  }

  testWidgets('shows the exact confirmation copy', (WidgetTester tester) async {
    await pumpScreen(tester);

    await tester.tap(find.text('Clear local data'));
    await tester.pump();

    expect(find.text('Clear local data?'), findsOneWidget);
    expect(
      find.textContaining(
        'This will remove your Vitamin N history, progress, favorites',
      ),
      findsOneWidget,
    );
  });

  testWidgets('Cancel leaves data intact', (WidgetTester tester) async {
    await seedCourse();
    await pumpScreen(tester);

    await tester.tap(find.text('Clear local data'));
    await tester.pump();
    await tester.tap(find.text('Cancel'));
    await tester.pump();
    await tester.pump();

    final courses = await db.select(db.courses).get();
    expect(courses, hasLength(1), reason: 'Cancel must not delete anything');
  });

  testWidgets('confirming Clear data removes user content', (WidgetTester tester) async {
    await seedCourse();
    await pumpScreen(tester);

    await tester.tap(find.text('Clear local data'));
    await tester.pump();
    await tester.tap(find.text('Clear data'));
    // The clear operation is async; pump through it without
    // pumpAndSettle (bounded, deterministic pumps only).
    await tester.pump();
    await tester.pump();
    await tester.pump();

    final courses = await db.select(db.courses).get();
    expect(courses, isEmpty, reason: 'Confirm must remove the intended user data');
  });
}
