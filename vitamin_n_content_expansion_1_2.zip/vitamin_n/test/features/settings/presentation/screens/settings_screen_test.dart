import 'package:drift/native.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:vitamin_n/core/app_info/app_info_provider.dart';
import 'package:vitamin_n/core/database/app_database.dart';
import 'package:vitamin_n/core/database/app_database_provider.dart';
import 'package:vitamin_n/design_system/theme/app_theme.dart';
import 'package:vitamin_n/features/personal_reminders/presentation/screens/personal_reminders_screen.dart';
import 'package:vitamin_n/features/premium/presentation/screens/premium_screen.dart';
import 'package:vitamin_n/features/settings/presentation/screens/about_screen.dart';
import 'package:vitamin_n/features/settings/presentation/screens/clear_local_data_screen.dart';
import 'package:vitamin_n/features/settings/presentation/screens/disclaimer_screen.dart';
import 'package:vitamin_n/features/settings/presentation/screens/privacy_screen.dart';
import 'package:vitamin_n/features/settings/presentation/screens/settings_screen.dart';

final PackageInfo _fakePackageInfo = PackageInfo(
  appName: 'Vitamin N',
  packageName: 'com.vitaminn.app',
  version: '1.0.0',
  buildNumber: '1',
);

Future<void> _pumpSettings(WidgetTester tester) async {
  // Settings navigates to screens (Premium, Personal Reminders) that
  // depend on Settings -> AppDatabase via Riverpod providers — an
  // in-memory test database avoids the real one's path_provider
  // platform channel, unavailable in widget tests.
  final AppDatabase db = AppDatabase.forTesting(NativeDatabase.memory());
  addTearDown(db.close);

  await tester.pumpWidget(
    ProviderScope(
      overrides: <Override>[
        appDatabaseProvider.overrideWithValue(db),
        packageInfoProvider.overrideWith((Ref ref) async => _fakePackageInfo),
      ],
      child: MaterialApp(theme: AppTheme.light, home: const SettingsScreen()),
    ),
  );
  await tester.pump();
  await tester.pump();
}

/// Settings is a scrollable list; the default 800x600 test surface
/// doesn't show the whole thing at once. Scrolls [finder] into the
/// actual visible viewport (not just built via cache extent) so both
/// text-presence assertions and taps against it are reliable.
Future<void> _scrollUntilVisible(WidgetTester tester, Finder finder) async {
  await tester.dragUntilVisible(
    finder,
    find.byType(Scrollable).first,
    const Offset(0, -150),
  );
  await tester.pump();
}

void main() {
  testWidgets('Settings renders every expected row', (WidgetTester tester) async {
    await _pumpSettings(tester);

    expect(find.text('Vitamin N Premium'), findsOneWidget);
    expect(find.text('Personal Reminders'), findsOneWidget);
    expect(find.text('Privacy'), findsOneWidget);
    expect(find.text('Disclaimer'), findsOneWidget);
    expect(find.text('Clear local data'), findsOneWidget);
    expect(find.text('What is Vitamin N?'), findsOneWidget);
    expect(find.text('Privacy & Data'), findsOneWidget);
    expect(find.text('About Vitamin N'), findsWidgets);

    // Further down than the default test viewport shows — scroll
    // before asserting, rather than weakening or removing the check.
    await _scrollUntilVisible(tester, find.text('App version'));
    expect(find.text('App version'), findsOneWidget);
  });

  testWidgets('tapping Vitamin N Premium opens the canonical Premium screen',
      (WidgetTester tester) async {
    await _pumpSettings(tester);

    await tester.tap(find.text('Vitamin N Premium'));
    await tester.pump();
    await tester.pump();

    expect(find.byType(PremiumScreen), findsOneWidget);
  });

  testWidgets('tapping Personal Reminders opens the Personal Reminders screen',
      (WidgetTester tester) async {
    await _pumpSettings(tester);

    await tester.tap(find.text('Personal Reminders'));
    await tester.pump();
    await tester.pump();

    expect(find.byType(PersonalRemindersScreen), findsOneWidget);
  });

  testWidgets('tapping Privacy opens the Privacy screen', (WidgetTester tester) async {
    await _pumpSettings(tester);

    await tester.tap(find.text('Privacy'));
    await tester.pump();
    await tester.pump();

    expect(find.byType(PrivacyScreen), findsOneWidget);
  });

  testWidgets('tapping Disclaimer opens the Disclaimer screen', (WidgetTester tester) async {
    await _pumpSettings(tester);

    await tester.tap(find.text('Disclaimer'));
    await tester.pump();
    await tester.pump();

    expect(find.byType(DisclaimerScreen), findsOneWidget);
  });

  testWidgets('tapping What is Vitamin N? opens the About screen', (WidgetTester tester) async {
    await _pumpSettings(tester);

    await _scrollUntilVisible(tester, find.text('What is Vitamin N?'));
    await tester.tap(find.text('What is Vitamin N?'));
    await tester.pump();
    await tester.pump();

    expect(find.byType(AboutScreen), findsOneWidget);
  });

  testWidgets('tapping Clear local data opens the Clear Local Data screen',
      (WidgetTester tester) async {
    await _pumpSettings(tester);

    await tester.tap(find.text('Clear local data'));
    await tester.pump();
    await tester.pump();

    expect(find.byType(ClearLocalDataScreen), findsOneWidget);
  });
}
