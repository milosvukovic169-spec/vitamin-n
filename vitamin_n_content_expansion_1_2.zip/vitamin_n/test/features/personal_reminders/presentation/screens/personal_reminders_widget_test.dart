import 'package:drift/native.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/core/database/app_database.dart';
import 'package:vitamin_n/design_system/theme/app_theme.dart';
import 'package:vitamin_n/features/personal_reminders/data/datasources/personal_reminder_local_data_source.dart';
import 'package:vitamin_n/features/personal_reminders/data/repositories/personal_reminder_repository_impl.dart';
import 'package:vitamin_n/features/personal_reminders/domain/entities/personal_reminder.dart';
import 'package:vitamin_n/features/personal_reminders/domain/repositories/personal_reminder_repository.dart';
import 'package:vitamin_n/features/personal_reminders/presentation/providers/personal_reminder_providers.dart';
import 'package:vitamin_n/features/personal_reminders/presentation/screens/add_edit_personal_reminder_screen.dart';
import 'package:vitamin_n/features/personal_reminders/presentation/screens/personal_reminders_screen.dart';

/// A real repository backed by an in-memory Drift database — genuine
/// CRUD behavior in the test, not a hand-rolled fake, without needing
/// platform channels (path_provider) the real app database requires.
ProviderContainer _containerWithInMemoryReminders() {
  final AppDatabase db = AppDatabase.forTesting(NativeDatabase.memory());
  // addTearDown binds to whichever test is currently running,
  // regardless of which function calls it — this ensures the
  // database this helper creates is always closed, even though the
  // helper itself isn't a test body. Without this, each test leaked
  // its own AppDatabase connection, which is exactly what triggered
  // Drift's "multiple database instances" warning.
  addTearDown(db.close);
  final PersonalReminderRepository repo =
      PersonalReminderRepositoryImpl(PersonalReminderLocalDataSource(db));
  return ProviderContainer(
    overrides: <Override>[
      personalReminderRepositoryProvider.overrideWithValue(repo),
    ],
  );
}

void main() {
  group('Delete confirmation (edit screen)', () {
    testWidgets('shows the exact confirmation copy and Cancel leaves the reminder intact',
        (WidgetTester tester) async {
      final ProviderContainer container = _containerWithInMemoryReminders();
      addTearDown(container.dispose);
      final PersonalReminderRepository repo =
          container.read(personalReminderRepositoryProvider);
      final PersonalReminder reminder =
          await repo.create(text: 'Check your calendar before saying yes.');

      await tester.pumpWidget(
        UncontrolledProviderScope(
          container: container,
          child: MaterialApp(
            theme: AppTheme.light,
            home: AddEditPersonalReminderScreen(existing: reminder),
          ),
        ),
      );
      await tester.pump();
      await tester.pump();

      await tester.tap(find.byIcon(Icons.delete_outline));
      await tester.pump();

      expect(find.text('Delete this reminder?'), findsOneWidget);
      expect(find.text('This removes the reminder from Vitamin N.'), findsOneWidget);

      // The underlying screen also has its own "Cancel" button (to
      // abandon the whole edit), which stays in the widget tree while
      // the dialog is open — scope the finder to the dialog so this
      // taps the confirmation's Cancel, not the screen's.
      await tester.tap(
        find.descendant(of: find.byType(AlertDialog), matching: find.text('Cancel')),
      );
      await tester.pump();
      await tester.pump();

      final PersonalReminder? stillThere = await repo.getById(reminder.id);
      expect(stillThere, isNotNull, reason: 'Cancel must not delete anything');
    });

    testWidgets('confirming Delete actually removes the reminder',
        (WidgetTester tester) async {
      final ProviderContainer container = _containerWithInMemoryReminders();
      addTearDown(container.dispose);
      final PersonalReminderRepository repo =
          container.read(personalReminderRepositoryProvider);
      final PersonalReminder reminder =
          await repo.create(text: "You don't have to answer this immediately.");

      await tester.pumpWidget(
        UncontrolledProviderScope(
          container: container,
          child: MaterialApp(
            theme: AppTheme.light,
            home: AddEditPersonalReminderScreen(existing: reminder),
          ),
        ),
      );
      await tester.pump();
      await tester.pump();

      await tester.tap(find.byIcon(Icons.delete_outline));
      await tester.pump();
      await tester.tap(find.text('Delete'));
      await tester.pump();
      await tester.pump();

      final PersonalReminder? gone = await repo.getById(reminder.id);
      expect(gone, isNull);
    });
  });

  group('Personal Reminders — empty state', () {
    testWidgets('shows the exact empty-state copy and a New reminder button',
        (WidgetTester tester) async {
      final ProviderContainer container = _containerWithInMemoryReminders();
      addTearDown(container.dispose);

      await tester.pumpWidget(
        UncontrolledProviderScope(
          container: container,
          child: MaterialApp(theme: AppTheme.light, home: const PersonalRemindersScreen()),
        ),
      );
      await tester.pump();
      await tester.pump();

      expect(find.text('Nothing here yet.'), findsOneWidget);
      expect(
        find.text(
          'Save something you want to remember the next time a boundary feels difficult.',
        ),
        findsOneWidget,
      );
      expect(find.text('New reminder'), findsOneWidget);
    });

    testWidgets('a saved reminder replaces the empty state', (WidgetTester tester) async {
      final ProviderContainer container = _containerWithInMemoryReminders();
      addTearDown(container.dispose);
      await container
          .read(personalReminderRepositoryProvider)
          .create(text: 'You wanted to protect Sunday mornings.');

      await tester.pumpWidget(
        UncontrolledProviderScope(
          container: container,
          child: MaterialApp(theme: AppTheme.light, home: const PersonalRemindersScreen()),
        ),
      );
      await tester.pump();
      await tester.pump();

      expect(find.text('Nothing here yet.'), findsNothing);
      expect(find.text('You wanted to protect Sunday mornings.'), findsOneWidget);
    });
  });
}
