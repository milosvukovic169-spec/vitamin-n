import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/features/personal_reminders/domain/entities/personal_reminder.dart';

void main() {
  group('ValidatePersonalReminderPairing', () {
    test('a completely standalone reminder (no category, no situation) is valid', () {
      expect(
        ValidatePersonalReminderPairing.isValid(
          categoryId: null,
          situationId: null,
          situationsActualCategoryId: null,
        ),
        isTrue,
      );
    });

    test('a category-only reminder (no situation) is valid regardless of category', () {
      expect(
        ValidatePersonalReminderPairing.isValid(
          categoryId: 'cat_work',
          situationId: null,
          situationsActualCategoryId: null,
        ),
        isTrue,
      );
    });

    test('a situation whose category matches the selected category is valid', () {
      expect(
        ValidatePersonalReminderPairing.isValid(
          categoryId: 'cat_work',
          situationId: 'sit_overtime',
          situationsActualCategoryId: 'cat_work',
        ),
        isTrue,
      );
    });

    test('a situation whose category does NOT match the selected category is invalid', () {
      expect(
        ValidatePersonalReminderPairing.isValid(
          categoryId: 'cat_digital',
          situationId: 'sit_overtime',
          situationsActualCategoryId: 'cat_work',
        ),
        isFalse,
      );
    });

    test('a situation selected with no category at all is invalid', () {
      expect(
        ValidatePersonalReminderPairing.isValid(
          categoryId: null,
          situationId: 'sit_overtime',
          situationsActualCategoryId: 'cat_work',
        ),
        isFalse,
      );
    });
  });

  group('PersonalReminder.copyWith', () {
    test('clearCategoryId removes the category even when a new one is not supplied', () {
      final PersonalReminder reminder = PersonalReminder(
        id: 'r1',
        text: 'Check the calendar first.',
        categoryId: 'cat_work',
        situationId: 'sit_overtime',
        isActive: true,
        createdAt: DateTime(2026, 1, 1),
        updatedAt: DateTime(2026, 1, 1),
      );

      final PersonalReminder cleared = reminder.copyWith(clearCategoryId: true);

      expect(cleared.categoryId, isNull);
      expect(cleared.situationId, 'sit_overtime', reason: 'unrelated field untouched');
    });

    test('clearSituationId removes only the situation', () {
      final PersonalReminder reminder = PersonalReminder(
        id: 'r1',
        text: 'Check the calendar first.',
        categoryId: 'cat_work',
        situationId: 'sit_overtime',
        isActive: true,
        createdAt: DateTime(2026, 1, 1),
        updatedAt: DateTime(2026, 1, 1),
      );

      final PersonalReminder cleared = reminder.copyWith(clearSituationId: true);

      expect(cleared.situationId, isNull);
      expect(cleared.categoryId, 'cat_work');
    });

    test('isActive can be toggled independently', () {
      final PersonalReminder reminder = PersonalReminder(
        id: 'r1',
        text: 'Check the calendar first.',
        categoryId: null,
        situationId: null,
        isActive: true,
        createdAt: DateTime(2026, 1, 1),
        updatedAt: DateTime(2026, 1, 1),
      );

      expect(reminder.copyWith(isActive: false).isActive, isFalse);
    });
  });
}
