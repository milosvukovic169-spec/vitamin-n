import 'package:drift/drift.dart' hide isNull, isNotNull;
import 'package:drift/native.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/core/database/app_database.dart';
import 'package:vitamin_n/features/personal_reminders/data/datasources/personal_reminder_local_data_source.dart';
import 'package:vitamin_n/features/personal_reminders/data/repositories/personal_reminder_repository_impl.dart';
import 'package:vitamin_n/features/personal_reminders/domain/entities/personal_reminder.dart';

void main() {
  late AppDatabase db;
  late PersonalReminderRepositoryImpl repo;

  setUp(() {
    db = AppDatabase.forTesting(NativeDatabase.memory());
    repo = PersonalReminderRepositoryImpl(PersonalReminderLocalDataSource(db));
  });

  tearDown(() async {
    await db.close();
  });

  group('create', () {
    test('a completely standalone reminder (no category, no situation) persists', () async {
      final PersonalReminder created = await repo.create(
        text: "You don't have to answer this immediately.",
      );

      expect(created.categoryId, isNull);
      expect(created.situationId, isNull);
      expect(created.isActive, isTrue, reason: 'new reminders default to active');

      final List<PersonalReminder> all = await repo.getAll();
      expect(all, hasLength(1));
      expect(all.single.id, created.id);
    });

    test('a reminder with only a category persists', () async {
      final PersonalReminder created = await repo.create(
        text: 'Check whether this is actually urgent before agreeing.',
        categoryId: 'cat_work',
      );

      expect(created.categoryId, 'cat_work');
      expect(created.situationId, isNull);
    });

    test('a reminder with category and situation persists', () async {
      final PersonalReminder created = await repo.create(
        text: 'I can listen without taking responsibility for the decision.',
        categoryId: 'cat_listening_support',
        situationId: 'sit_asked_to_fix_someones_mood',
      );

      expect(created.categoryId, 'cat_listening_support');
      expect(created.situationId, 'sit_asked_to_fix_someones_mood');
    });

    test('each created reminder gets a unique id', () async {
      final PersonalReminder a = await repo.create(text: 'First.');
      final PersonalReminder b = await repo.create(text: 'Second.');
      expect(a.id, isNot(b.id));
    });
  });

  group('update (edit)', () {
    test('text, category and situation can all be changed', () async {
      final PersonalReminder created = await repo.create(text: 'Original text.');

      await repo.update(
        created.copyWith(
          text: 'Updated text.',
          categoryId: 'cat_time',
          situationId: 'sit_giving_away_personal_time',
        ),
      );

      final PersonalReminder? updated = await repo.getById(created.id);
      expect(updated, isNotNull);
      expect(updated!.text, 'Updated text.');
      expect(updated.categoryId, 'cat_time');
      expect(updated.situationId, 'sit_giving_away_personal_time');
    });

    test('updatedAt changes on edit', () async {
      final PersonalReminder created = await repo.create(text: 'Original text.');
      // Read back what was actually persisted (already truncated to
      // whole-second precision) rather than comparing against the
      // in-memory, full-precision value — otherwise this test would
      // reintroduce the exact mismatch it exists to guard against.
      final PersonalReminder persistedOriginal = (await repo.getById(created.id))!;

      // SQLite/Drift persists DateTime at whole-second precision (the
      // same class of issue fixed for Entry.createdAt in Phase 4), so
      // a short real-time delay between two DateTime.now() calls is
      // not reliably detectable — both can truncate to the same
      // second. Rather than sleeping (arbitrary and still not fully
      // reliable), seed a known, decades-old updatedAt directly at
      // the data layer, then assert the post-update value is after
      // it. This is deterministic regardless of any timestamp
      // storage precision.
      await db.into(db.personalReminders).insertOnConflictUpdate(
            PersonalRemindersCompanion(
              id: Value<String>(created.id),
              reminderText: Value<String>(created.text),
              createdAt: Value<DateTime>(persistedOriginal.createdAt),
              updatedAt: Value<DateTime>(DateTime(2000, 1, 1)),
            ),
          );

      await repo.update(created.copyWith(text: 'Edited.'));

      final PersonalReminder? updated = await repo.getById(created.id);
      expect(updated!.updatedAt.isAfter(DateTime(2000, 1, 1)), isTrue);
      expect(updated.createdAt, persistedOriginal.createdAt,
          reason: 'createdAt must survive an edit');
    });

    test('category can be cleared back to a standalone reminder', () async {
      final PersonalReminder created =
          await repo.create(text: 'Text.', categoryId: 'cat_work');

      await repo.update(created.copyWith(clearCategoryId: true));

      final PersonalReminder? updated = await repo.getById(created.id);
      expect(updated!.categoryId, isNull);
    });
  });

  group('activate / deactivate', () {
    test('setActive(false) deactivates without deleting', () async {
      final PersonalReminder created = await repo.create(text: 'Text.');

      await repo.setActive(created.id, false);

      final PersonalReminder? found = await repo.getById(created.id);
      expect(found, isNotNull, reason: 'deactivating must not delete');
      expect(found!.isActive, isFalse);
    });

    test('setActive(true) reactivates', () async {
      final PersonalReminder created = await repo.create(text: 'Text.');
      await repo.setActive(created.id, false);

      await repo.setActive(created.id, true);

      final PersonalReminder? found = await repo.getById(created.id);
      expect(found!.isActive, isTrue);
    });

    test('setActive on an unknown id is a safe no-op', () async {
      await repo.setActive('does-not-exist', false);
      expect(await repo.getAll(), isEmpty);
    });
  });

  group('delete', () {
    test('removes the reminder entirely', () async {
      final PersonalReminder created = await repo.create(text: 'Text.');

      await repo.delete(created.id);

      expect(await repo.getById(created.id), isNull);
      expect(await repo.getAll(), isEmpty);
    });

    test('deleting one reminder leaves others intact', () async {
      final PersonalReminder a = await repo.create(text: 'Keep me.');
      final PersonalReminder b = await repo.create(text: 'Delete me.');

      await repo.delete(b.id);

      final List<PersonalReminder> remaining = await repo.getAll();
      expect(remaining, hasLength(1));
      expect(remaining.single.id, a.id);
    });
  });

  group('persistence across repository instances (same database)', () {
    test('a reminder created via one repository instance is visible via another', () async {
      await repo.create(text: 'Persisted.');

      final PersonalReminderRepositoryImpl secondRepo =
          PersonalReminderRepositoryImpl(PersonalReminderLocalDataSource(db));
      final List<PersonalReminder> all = await secondRepo.getAll();

      expect(all, hasLength(1));
      expect(all.single.text, 'Persisted.');
    });
  });

  group('empty state', () {
    test('getAll returns an empty list when nothing has been saved', () async {
      expect(await repo.getAll(), isEmpty);
    });
  });

  group('contextual lookup (exact match only)', () {
    test('getActiveBySituationId finds an exact, active match', () async {
      await repo.create(
        text: 'Check whether this is actually urgent before agreeing.',
        categoryId: 'cat_work',
        situationId: 'sit_overtime',
      );

      final List<PersonalReminder> matches =
          await repo.getActiveBySituationId('sit_overtime');
      expect(matches, hasLength(1));
    });

    test('getActiveBySituationId ignores an inactive reminder', () async {
      final PersonalReminder created = await repo.create(
        text: 'Text.',
        categoryId: 'cat_work',
        situationId: 'sit_overtime',
      );
      await repo.setActive(created.id, false);

      expect(await repo.getActiveBySituationId('sit_overtime'), isEmpty);
    });

    test('getActiveBySituationId never matches an unrelated situation', () async {
      await repo.create(
        text: 'Text.',
        categoryId: 'cat_work',
        situationId: 'sit_overtime',
      );

      expect(await repo.getActiveBySituationId('sit_unpaid_work'), isEmpty);
    });

    test('getActiveByCategoryIdOnly only matches reminders with no situation set', () async {
      await repo.create(
        text: 'Situation-specific.',
        categoryId: 'cat_work',
        situationId: 'sit_overtime',
      );
      await repo.create(text: 'Category-only.', categoryId: 'cat_work');

      final List<PersonalReminder> matches =
          await repo.getActiveByCategoryIdOnly('cat_work');
      expect(matches, hasLength(1));
      expect(matches.single.text, 'Category-only.');
    });
  });
}
