import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/design_system/theme/app_theme.dart';
import 'package:vitamin_n/features/entries/presentation/providers/entry_providers.dart';
import 'package:vitamin_n/features/insights/presentation/screens/insights_screen.dart';

import '../../../../fakes/fake_entry_repository.dart';

/// Bounded, deterministic pump sequence — see the equivalent History
/// test for why `pumpAndSettle()` is deliberately not used here.
Future<void> _pumpInsightsScreen(WidgetTester tester) async {
  await tester.pumpWidget(
    ProviderScope(
      overrides: <Override>[
        entryRepositoryProvider.overrideWithValue(const FakeEntryRepository()),
      ],
      child: MaterialApp(theme: AppTheme.light, home: const InsightsScreen()),
    ),
  );
  await tester.pump();
  await tester.pump();
  await tester.pump();
}

void main() {
  testWidgets('InsightsScreen shows the calm empty state with no entries', (
    WidgetTester tester,
  ) async {
    await _pumpInsightsScreen(tester);

    expect(find.text('Insights'), findsOneWidget);
    expect(find.text('Your patterns are still forming.'), findsOneWidget);
    expect(
      find.text(
        'Add a few protected choices and your Insights will begin to take shape.',
      ),
      findsOneWidget,
    );
  });

  testWidgets('InsightsScreen defaults to "This month" selected', (
    WidgetTester tester,
  ) async {
    await _pumpInsightsScreen(tester);

    expect(find.text('This week'), findsOneWidget);
    expect(find.text('This month'), findsOneWidget);
    expect(find.text('All time'), findsOneWidget);
  });
}
