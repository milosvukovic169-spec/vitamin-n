import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/features/insights/domain/entities/insights_time_range.dart';

void main() {
  // Wednesday, 18 March 2026, 15:00.
  final DateTime now = DateTime(2026, 3, 18, 15);

  test('week resolves to Monday 00:00 through the end of today (exclusive)', () {
    final range = resolveInsightsTimeRange(InsightsTimeRange.week, now: now);
    expect(range.start, DateTime(2026, 3, 16)); // Monday
    expect(range.end, DateTime(2026, 3, 19)); // start of tomorrow
  });

  test('month resolves to the 1st of the current month through tomorrow', () {
    final range = resolveInsightsTimeRange(InsightsTimeRange.month, now: now);
    expect(range.start, DateTime(2026, 3, 1));
    expect(range.end, DateTime(2026, 3, 19));
  });

  test('allTime resolves to a wide practical range including everything', () {
    final range = resolveInsightsTimeRange(InsightsTimeRange.allTime, now: now);
    expect(range.start.isBefore(DateTime(2020)), isTrue);
    expect(range.end, DateTime(2026, 3, 19));
  });

  test('the end boundary is always exclusive (start of the following day)', () {
    for (final range in InsightsTimeRange.values) {
      final resolved = resolveInsightsTimeRange(range, now: now);
      expect(resolved.end, DateTime(2026, 3, 19));
    }
  });
}
