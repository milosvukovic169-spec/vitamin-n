import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/features/insights/domain/usecases/generate_insight_patterns_usecase.dart';

void main() {
  const GenerateInsightPatternsUseCase generatePatterns =
      GenerateInsightPatternsUseCase();

  group('low-data rules', () {
    test('0 entries produces no pattern messages', () {
      final result = generatePatterns(
        totalEntries: 0,
        protectedValueCounts: const <String, int>{},
        categoryCounts: const <String, int>{},
        weekdayDistribution: const <int, int>{},
        rangeLabel: 'this month',
      );
      expect(result, isEmpty);
    });

    test('1-2 entries produces no pattern messages', () {
      final result = generatePatterns(
        totalEntries: 2,
        protectedValueCounts: const <String, int>{'Peace': 2},
        categoryCounts: const <String, int>{'Work': 2},
        weekdayDistribution: const <int, int>{1: 2},
        rangeLabel: 'this month',
      );
      expect(result, isEmpty);
    });

    test('3-5 entries produces at most one message (top protected value only)', () {
      final result = generatePatterns(
        totalEntries: 4,
        protectedValueCounts: const <String, int>{'Peace': 3, 'Time': 1},
        categoryCounts: const <String, int>{'Work': 4},
        weekdayDistribution: const <int, int>{1: 2, 2: 2},
        rangeLabel: 'this month',
      );

      expect(result, hasLength(1));
      expect(result.single, 'You protected your Peace most often this month.');
    });

    test('6+ entries can produce up to three messages', () {
      final result = generatePatterns(
        totalEntries: 8,
        protectedValueCounts: const <String, int>{'Peace': 5, 'Time': 3},
        categoryCounts: const <String, int>{'Work': 6, 'Money': 2},
        // Mon-Fri = 6, Sat-Sun = 2 -> weekdays clearly ahead.
        weekdayDistribution: const <int, int>{1: 2, 2: 2, 3: 2, 6: 1, 7: 1},
        rangeLabel: 'this month',
      );

      expect(result, <String>[
        'You protected your Peace most often this month.',
        'Work was your most frequent boundary category.',
        'You recorded more boundaries on weekdays than weekends.',
      ]);
    });
  });

  group('weekday vs weekend comparison', () {
    test('says weekends when weekend count is higher', () {
      final result = generatePatterns(
        totalEntries: 6,
        protectedValueCounts: const <String, int>{'Peace': 6},
        categoryCounts: const <String, int>{'Work': 6},
        weekdayDistribution: const <int, int>{6: 3, 7: 3},
        rangeLabel: 'this month',
      );
      expect(
        result,
        contains('You recorded more boundaries on weekends than weekdays.'),
      );
    });

    test('omits the weekday/weekend message entirely when tied', () {
      final result = generatePatterns(
        totalEntries: 6,
        protectedValueCounts: const <String, int>{'Peace': 6},
        categoryCounts: const <String, int>{'Work': 6},
        weekdayDistribution: const <int, int>{1: 3, 6: 3},
        rangeLabel: 'this month',
      );
      expect(
        result.any((m) => m.contains('weekday') || m.contains('weekend')),
        isFalse,
      );
    });
  });

  test('rangeLabel is threaded through verbatim, never hardcoded', () {
    final result = generatePatterns(
      totalEntries: 3,
      protectedValueCounts: const <String, int>{'Focus': 3},
      categoryCounts: const <String, int>{},
      weekdayDistribution: const <int, int>{},
      rangeLabel: 'this week',
    );
    expect(result.single, contains('this week'));
  });

  test('never produces judgmental or clinical language', () {
    final result = generatePatterns(
      totalEntries: 10,
      protectedValueCounts: const <String, int>{'Peace': 10},
      categoryCounts: const <String, int>{'Work': 10},
      weekdayDistribution: const <int, int>{1: 10},
      rangeLabel: 'this month',
    );

    const List<String> bannedPhrases = <String>[
      'struggle',
      'problem',
      'weak',
      'therapy',
      'anxious',
      'addicted',
    ];
    for (final String message in result) {
      for (final String banned in bannedPhrases) {
        expect(message.toLowerCase().contains(banned), isFalse);
      }
    }
  });
}
