import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/design_system/theme/app_theme.dart';
import 'package:vitamin_n/features/entries/presentation/providers/entry_providers.dart';
import 'package:vitamin_n/features/history/presentation/screens/history_screen.dart';

import '../../../../fakes/fake_entry_repository.dart';

/// Pumps [HistoryScreen] with the entry repository overridden to a
/// deterministic, empty in-memory fake. Uses a bounded two-pump
/// sequence rather than `pumpAndSettle()` — the screen's loading
/// states resolve via microtasks (no real Timer, no asset I/O for the
/// entry data itself), so a fixed pump count is sufficient and never
/// depends on how busy the test isolate happens to be.
Future<void> _pumpHistoryScreen(WidgetTester tester) async {
  await tester.pumpWidget(
    ProviderScope(
      overrides: <Override>[
        entryRepositoryProvider.overrideWithValue(const FakeEntryRepository()),
      ],
      child: MaterialApp(theme: AppTheme.light, home: const HistoryScreen()),
    ),
  );
  await tester.pump();
  await tester.pump();
}

void main() {
  testWidgets('HistoryScreen shows the calm empty state with no entries', (
    WidgetTester tester,
  ) async {
    await _pumpHistoryScreen(tester);

    expect(find.text('History'), findsOneWidget);
    expect(find.text('Your protected choices, over time.'), findsOneWidget);
    expect(find.text('Your protected choices will appear here.'), findsOneWidget);
    expect(
      find.text(
        'Each time you keep a boundary, Vitamin N will remember what mattered.',
      ),
      findsOneWidget,
    );
  });
}
