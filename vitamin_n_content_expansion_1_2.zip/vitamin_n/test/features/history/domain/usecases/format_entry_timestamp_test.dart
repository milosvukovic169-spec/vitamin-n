import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/features/history/domain/usecases/format_entry_timestamp.dart';

void main() {
  final DateTime now = DateTime(2026, 3, 18, 15, 0);

  test('formats a same-day entry as "Today, HH:mm"', () {
    final result = formatEntryTimestamp(DateTime(2026, 3, 18, 14, 35), now: now);
    expect(result, 'Today, 14:35');
  });

  test('formats yesterday as "Yesterday, HH:mm"', () {
    final result = formatEntryTimestamp(DateTime(2026, 3, 17, 9, 2), now: now);
    expect(result, 'Yesterday, 09:02');
  });

  test('formats an older same-year date as "D Mon, HH:mm"', () {
    final result = formatEntryTimestamp(DateTime(2026, 1, 5, 8, 0), now: now);
    expect(result, '5 Jan, 08:00');
  });

  test('includes the year for a date from a previous year', () {
    final result = formatEntryTimestamp(DateTime(2025, 12, 25, 8, 0), now: now);
    expect(result, '25 Dec 2025, 08:00');
  });

  test('pads single-digit minutes and hours', () {
    final result = formatEntryTimestamp(DateTime(2026, 3, 18, 9, 5), now: now);
    expect(result, 'Today, 09:05');
  });
}
