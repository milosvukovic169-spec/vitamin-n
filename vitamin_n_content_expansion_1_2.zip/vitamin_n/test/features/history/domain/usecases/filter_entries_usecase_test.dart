import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/features/entries/domain/entities/entry.dart';
import 'package:vitamin_n/features/history/domain/entities/history_filter.dart';
import 'package:vitamin_n/features/history/domain/usecases/filter_entries_usecase.dart';

Entry _entry({
  required String id,
  required DateTime createdAt,
  String categoryId = 'cat_work',
  List<String> protectedValueIds = const <String>['val_time'],
}) {
  return Entry(
    id: id,
    categoryId: categoryId,
    situationId: 'sit_overtime',
    refusalResponseId: null,
    protectedValueIds: protectedValueIds,
    customProtectedValue: null,
    personalReminderNote: null,
    reflectionPauseShown: false,
    courseId: 1,
    createdAt: createdAt,
  );
}

void main() {
  // A fixed Wednesday reference point, so week/month boundaries are
  // deterministic regardless of when the test suite actually runs.
  final DateTime now = DateTime(2026, 3, 18, 12);
  const FilterEntriesUseCase filterEntries = FilterEntriesUseCase();

  group('HistoryFilterType.all', () {
    test('returns every entry unchanged', () {
      final entries = <Entry>[
        _entry(id: '1', createdAt: DateTime(2020, 1, 1)),
        _entry(id: '2', createdAt: now),
      ];
      expect(filterEntries(entries, HistoryFilter.all, now: now), entries);
    });
  });

  group('HistoryFilterType.week', () {
    test('includes entries from this week only', () {
      final DateTime startOfThisWeek = DateTime(2026, 3, 16); // Monday
      final entries = <Entry>[
        _entry(id: 'in_week', createdAt: startOfThisWeek.add(const Duration(hours: 1))),
        _entry(
          id: 'before_week',
          createdAt: startOfThisWeek.subtract(const Duration(days: 1)),
        ),
      ];

      final result = filterEntries(entries, HistoryFilter.week, now: now);

      expect(result.map((e) => e.id), <String>['in_week']);
    });
  });

  group('HistoryFilterType.month', () {
    test('includes entries from this calendar month only', () {
      final entries = <Entry>[
        _entry(id: 'this_month', createdAt: DateTime(2026, 3, 1, 1)),
        _entry(id: 'last_month', createdAt: DateTime(2026, 2, 28)),
      ];

      final result = filterEntries(entries, HistoryFilter.month, now: now);

      expect(result.map((e) => e.id), <String>['this_month']);
    });
  });

  group('HistoryFilterType.category', () {
    test('includes only entries matching the category id', () {
      final entries = <Entry>[
        _entry(id: 'work', createdAt: now, categoryId: 'cat_work'),
        _entry(id: 'money', createdAt: now, categoryId: 'cat_money'),
      ];

      final result =
          filterEntries(entries, HistoryFilter.byCategory('cat_work'), now: now);

      expect(result.map((e) => e.id), <String>['work']);
    });
  });

  group('HistoryFilterType.protectedValue', () {
    test('includes only entries that protected the given value', () {
      final entries = <Entry>[
        _entry(id: 'peace', createdAt: now, protectedValueIds: <String>['val_peace']),
        _entry(id: 'time', createdAt: now, protectedValueIds: <String>['val_time']),
        _entry(
          id: 'both',
          createdAt: now,
          protectedValueIds: <String>['val_peace', 'val_time'],
        ),
      ];

      final result =
          filterEntries(entries, HistoryFilter.byProtectedValue('val_peace'), now: now);

      expect(result.map((e) => e.id).toSet(), <String>{'peace', 'both'});
    });
  });
}
