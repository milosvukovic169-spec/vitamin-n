import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/features/entries/domain/entities/entry.dart';
import 'package:vitamin_n/features/history/domain/usecases/group_entries_by_recency_usecase.dart';

Entry _entry(String id, DateTime createdAt) {
  return Entry(
    id: id,
    categoryId: 'cat_work',
    situationId: 'sit_overtime',
    refusalResponseId: null,
    protectedValueIds: const <String>['val_time'],
    customProtectedValue: null,
    personalReminderNote: null,
    reflectionPauseShown: false,
    courseId: 1,
    createdAt: createdAt,
  );
}

void main() {
  // Wednesday, 18 March 2026.
  final DateTime now = DateTime(2026, 3, 18, 15);
  const GroupEntriesByRecencyUseCase groupEntries = GroupEntriesByRecencyUseCase();

  test('buckets entries into the correct recency groups', () {
    final entries = <Entry>[
      _entry('today', DateTime(2026, 3, 18, 9)),
      _entry('yesterday', DateTime(2026, 3, 17, 9)),
      _entry('earlier_this_week', DateTime(2026, 3, 16, 9)), // Monday
      _entry('earlier_this_month', DateTime(2026, 3, 2, 9)),
      _entry('older', DateTime(2026, 1, 15, 9)),
    ];

    final result = groupEntries(entries, now: now);

    expect(result.map((g) => g.group), <HistoryRecencyGroup>[
      HistoryRecencyGroup.today,
      HistoryRecencyGroup.yesterday,
      HistoryRecencyGroup.earlierThisWeek,
      HistoryRecencyGroup.earlierThisMonth,
      HistoryRecencyGroup.older,
    ]);
    for (final group in result) {
      expect(group.entries, hasLength(1));
    }
  });

  test('omits empty groups entirely rather than showing an empty header', () {
    final entries = <Entry>[_entry('today', DateTime(2026, 3, 18, 9))];

    final result = groupEntries(entries, now: now);

    expect(result, hasLength(1));
    expect(result.single.group, HistoryRecencyGroup.today);
  });

  test('returns an empty list for an empty input', () {
    expect(groupEntries(const <Entry>[], now: now), isEmpty);
  });

  test('preserves the order entries were given within each group', () {
    final entries = <Entry>[
      _entry('later_today', DateTime(2026, 3, 18, 14)),
      _entry('earlier_today', DateTime(2026, 3, 18, 8)),
    ];

    final result = groupEntries(entries, now: now);

    expect(
      result.single.entries.map((e) => e.id),
      <String>['later_today', 'earlier_today'],
    );
  });
}
