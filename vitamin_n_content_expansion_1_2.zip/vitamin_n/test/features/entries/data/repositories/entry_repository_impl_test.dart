import 'package:drift/native.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/core/database/app_database.dart';
import 'package:vitamin_n/features/boundary/data/repositories/drift_say_no_transaction_runner.dart';
import 'package:vitamin_n/features/boundary/domain/usecases/confirm_say_no_usecase.dart';
import 'package:vitamin_n/features/courses/data/datasources/course_local_data_source.dart';
import 'package:vitamin_n/features/courses/data/repositories/course_repository_impl.dart';
import 'package:vitamin_n/features/entries/data/datasources/entry_local_data_source.dart';
import 'package:vitamin_n/features/entries/data/repositories/entry_repository_impl.dart';
import 'package:vitamin_n/features/entries/domain/entities/entry.dart';

void main() {
  late AppDatabase db;
  late EntryRepositoryImpl entryRepository;
  late CourseRepositoryImpl courseRepository;
  late ConfirmSayNoUseCase confirmSayNo;

  setUp(() {
    db = AppDatabase.forTesting(NativeDatabase.memory());
    entryRepository = EntryRepositoryImpl(EntryLocalDataSource(db));
    courseRepository = CourseRepositoryImpl(CourseLocalDataSource(db));
    confirmSayNo = ConfirmSayNoUseCase(
      entryRepository: entryRepository,
      courseRepository: courseRepository,
      transactionRunner: DriftSayNoTransactionRunner(db),
    );
  });

  tearDown(() async {
    await db.close();
  });

  group('getCategoryCounts (SQL-aggregated)', () {
    test('groups entries by category via SQL', () async {
      await confirmSayNo(
        categoryId: 'cat_work',
        situationId: 'sit_overtime',
        protectedValueIds: const <String>['val_time'],
        reflectionPauseShown: false,
      );
      await confirmSayNo(
        categoryId: 'cat_work',
        situationId: 'sit_overtime',
        protectedValueIds: const <String>['val_time'],
        reflectionPauseShown: false,
      );
      await confirmSayNo(
        categoryId: 'cat_money',
        situationId: 'sit_overtime',
        protectedValueIds: const <String>['val_money'],
        reflectionPauseShown: false,
      );

      final counts = await entryRepository.getCategoryCounts();

      expect(counts['cat_work'], 2);
      expect(counts['cat_money'], 1);
    });

    test('respects the start/end range boundaries', () async {
      await confirmSayNo(
        categoryId: 'cat_work',
        situationId: 'sit_overtime',
        protectedValueIds: const <String>['val_time'],
        reflectionPauseShown: false,
      );

      final DateTime farFuture = DateTime.now().add(const Duration(days: 365));
      final counts = await entryRepository.getCategoryCounts(
        start: farFuture,
        end: farFuture.add(const Duration(days: 1)),
      );

      expect(counts, isEmpty);
    });
  });

  group('getProtectedValueCounts', () {
    test('counts each protected value across multiple entries', () async {
      await confirmSayNo(
        categoryId: 'cat_work',
        situationId: 'sit_overtime',
        protectedValueIds: const <String>['val_peace', 'val_time'],
        reflectionPauseShown: false,
      );
      await confirmSayNo(
        categoryId: 'cat_work',
        situationId: 'sit_overtime',
        protectedValueIds: const <String>['val_peace'],
        reflectionPauseShown: false,
      );

      final counts = await entryRepository.getProtectedValueCounts();

      expect(counts['val_peace'], 2);
      expect(counts['val_time'], 1);
    });
  });

  group('update', () {
    test('changes protected values without touching category/situation/course', () async {
      final result = await confirmSayNo(
        categoryId: 'cat_work',
        situationId: 'sit_overtime',
        protectedValueIds: const <String>['val_time'],
        reflectionPauseShown: false,
      );

      final Entry updated = result.entry.copyWithEditableFields(
        protectedValueIds: <String>['val_peace', 'val_focus'],
        personalReminderNote: 'A note for next time',
      );
      await entryRepository.update(updated);

      final Entry? reloaded = await entryRepository.getEntryById(result.entry.id);
      expect(reloaded, isNotNull);
      expect(reloaded!.protectedValueIds, <String>['val_peace', 'val_focus']);
      expect(reloaded.personalReminderNote, 'A note for next time');
      // Untouched:
      expect(reloaded.categoryId, result.entry.categoryId);
      expect(reloaded.situationId, result.entry.situationId);
      expect(reloaded.courseId, result.entry.courseId);
      // createdAt is stored with whole-second precision (SQLite/Drift
      // normalizes sub-second components on persistence) — Vitamin N
      // does not require sub-second precision, so the assertion
      // compares at the precision the persistence layer actually
      // guarantees rather than the in-memory value's raw precision.
      expect(reloaded.createdAt, _truncatedToSeconds(result.entry.createdAt));
    });
  });

  group('delete', () {
    test('removes the entry but does NOT restore a Course token', () async {
      final result = await confirmSayNo(
        categoryId: 'cat_work',
        situationId: 'sit_overtime',
        protectedValueIds: const <String>['val_time'],
        reflectionPauseShown: false,
      );

      final courseBeforeDelete = await courseRepository.getOrCreateCurrent();
      expect(courseBeforeDelete.tokensRemaining, 29); // one token consumed

      await entryRepository.delete(result.entry.id);

      final Entry? reloaded = await entryRepository.getEntryById(result.entry.id);
      expect(reloaded, isNull);

      final courseAfterDelete = await courseRepository.getOrCreateCurrent();
      expect(
        courseAfterDelete.tokensRemaining,
        29,
        reason: 'Deleting a History entry is record management only — '
            'it must never restore an N token.',
      );
    });
  });
}

/// Drops sub-second components, matching the precision Vitamin N's
/// persistence layer actually guarantees for [Entry.createdAt] —
/// SQLite/Drift normalizes milliseconds/microseconds away on write,
/// and the app has no requirement for sub-second precision.
DateTime _truncatedToSeconds(DateTime dateTime) {
  return DateTime(
    dateTime.year,
    dateTime.month,
    dateTime.day,
    dateTime.hour,
    dateTime.minute,
    dateTime.second,
  );
}
