// Proves Phase 6 section 19/40: every Premium teaser in the app
// routes to the SAME canonical screen, never an independent paywall.
// Reads the actual source files directly (the same technique
// content_validation_test.dart uses for JSON) — a precise, fast,
// deterministic way to verify "one destination, everywhere" without
// needing to drive five separate full navigation flows.
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  const List<(String label, String path)> premiumEntryPoints = <(String, String)>[
    (
      'Another way 🔒 (Suggested Response, via PremiumResponseTeaserSheet)',
      'lib/features/boundary/presentation/widgets/premium_response_teaser_sheet.dart',
    ),
    (
      'Locked Premium category teaser',
      'lib/features/boundary/presentation/widgets/category_preview_teaser_sheet.dart',
    ),
    (
      'Locked Reality Reminder card',
      'lib/features/boundary/presentation/widgets/locked_reality_reminder_card.dart',
    ),
    (
      'Locked Challenge detail body',
      'lib/features/challenges/presentation/screens/challenge_detail_screen.dart',
    ),
    (
      'Settings → Vitamin N Premium',
      'lib/features/settings/presentation/screens/settings_screen.dart',
    ),
  ];

  for (final (String label, String path) in premiumEntryPoints) {
    test('$label routes to the canonical PremiumScreen', () {
      final String source = File(path).readAsStringSync();

      expect(
        source.contains('premium/presentation/screens/premium_screen.dart'),
        isTrue,
        reason: '$path does not import the canonical PremiumScreen',
      );
      expect(
        source.contains('PremiumScreen('),
        isTrue,
        reason: '$path never constructs PremiumScreen — it may be showing '
            'a different/independent paywall',
      );
    });
  }

  test('no screen in the app defines a second, independently-named paywall class', () {
    // A cheap but real guard against regressing into multiple Premium
    // designs: search the whole presentation layer for any other
    // class name suggesting a competing paywall surface.
    final List<FileSystemEntity> allDartFiles =
        Directory('lib').listSync(recursive: true).whereType<File>().where((f) {
      return f.path.endsWith('.dart');
    }).toList();

    final RegExp suspiciousClassNames = RegExp(
      r'class\s+\w*(Paywall|Upgrade(Screen|Sheet|Dialog))\w*',
    );

    for (final FileSystemEntity file in allDartFiles) {
      final String content = (file as File).readAsStringSync();
      final Iterable<RegExpMatch> matches = suspiciousClassNames.allMatches(content);
      for (final RegExpMatch match in matches) {
        fail('Found a possible second paywall surface: "${match.group(0)}" in '
            '${file.path}. Phase 6 requires exactly one canonical Premium screen.');
      }
    }
  });
}
