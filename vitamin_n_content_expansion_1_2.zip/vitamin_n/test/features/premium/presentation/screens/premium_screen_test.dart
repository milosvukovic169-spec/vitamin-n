import 'package:drift/native.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/core/analytics/analytics_providers.dart';
import 'package:vitamin_n/core/database/app_database.dart';
import 'package:vitamin_n/core/database/app_database_provider.dart';
import 'package:vitamin_n/design_system/theme/app_theme.dart';
import 'package:vitamin_n/features/premium/data/repositories/fake_billing_repository.dart';
import 'package:vitamin_n/features/premium/domain/entities/billing_product_ids.dart';
import 'package:vitamin_n/features/premium/presentation/providers/premium_providers.dart';
import 'package:vitamin_n/features/premium/presentation/screens/premium_screen.dart';

import '../../../../fakes/recording_analytics_service.dart';

Future<void> _pumpPremiumScreen(
  WidgetTester tester, {
  required FakeBillingRepository billing,
  RecordingAnalyticsService? analytics,
}) async {
  // premiumStatusProvider's real chain depends on Settings, which
  // depends on AppDatabase — an in-memory test database avoids the
  // real one's path_provider platform channel, unavailable here.
  final AppDatabase db = AppDatabase.forTesting(NativeDatabase.memory());
  addTearDown(db.close);

  await tester.pumpWidget(
    ProviderScope(
      overrides: <Override>[
        appDatabaseProvider.overrideWithValue(db),
        billingRepositoryProvider.overrideWithValue(billing),
        if (analytics != null) analyticsServiceProvider.overrideWithValue(analytics),
      ],
      child: MaterialApp(theme: AppTheme.light, home: const PremiumScreen()),
    ),
  );
  await tester.pump();
  await tester.pump();
  await tester.pump();
}

/// PremiumScreen is a scrollable list with substantial content above
/// the purchase area (icon, headline, tagline, four full benefit
/// cards) — on the default ~800x600 test surface, the Monthly/Yearly
/// offerings, prices, unavailable state, and Restore purchases are
/// all below the fold. This is the exact same class of issue already
/// found and fixed for the Settings screen's "App version" row: a
/// widget slightly past the viewport can still be *built* (Flutter's
/// sliver cache extent covers a bit beyond what's visible) but isn't
/// truly on-screen, so scrolling before asserting is required rather
/// than optional.
Future<void> _scrollUntilVisible(WidgetTester tester, Finder finder) async {
  await tester.dragUntilVisible(
    finder,
    find.byType(Scrollable).first,
    const Offset(0, -200),
  );
  await tester.pump();
}

void main() {
  testWidgets('Monthly and Yearly are both displayed with their real prices',
      (WidgetTester tester) async {
    final billing = FakeBillingRepository(
      localizedPrices: const <String, String>{
        BillingProductIds.monthly: '€3.99',
        BillingProductIds.yearly: '€24.99',
      },
    );
    await _pumpPremiumScreen(tester, billing: billing);

    await _scrollUntilVisible(tester, find.text('Monthly'));
    expect(find.text('Monthly'), findsOneWidget);
    expect(find.text('Yearly'), findsOneWidget);
    expect(find.text('€3.99'), findsOneWidget);
    expect(find.text('€24.99'), findsOneWidget);
  });

  testWidgets('Yearly shows Best value', (WidgetTester tester) async {
    final billing = FakeBillingRepository();
    await _pumpPremiumScreen(tester, billing: billing);

    await _scrollUntilVisible(tester, find.text('Best value'));
    expect(find.text('Best value'), findsOneWidget);
  });

  testWidgets('prices come from billing product data, not a hardcoded string',
      (WidgetTester tester) async {
    final billing = FakeBillingRepository(
      localizedPrices: const <String, String>{
        BillingProductIds.monthly: r'$4.49',
        BillingProductIds.yearly: r'$27.99',
      },
    );
    await _pumpPremiumScreen(tester, billing: billing);

    await _scrollUntilVisible(tester, find.text(r'$4.49'));
    expect(find.text(r'$4.49'), findsOneWidget);
    expect(find.text(r'$27.99'), findsOneWidget);
    expect(find.text('€3.99'), findsNothing);
  });

  testWidgets('missing price shows "Pricing coming soon", never a fake fallback price',
      (WidgetTester tester) async {
    final billing = FakeBillingRepository(localizedPrices: const {});
    await _pumpPremiumScreen(tester, billing: billing);

    await _scrollUntilVisible(tester, find.text('Monthly'));
    expect(find.text('Pricing coming soon'), findsWidgets);
    expect(find.text('€3.99'), findsNothing);
    expect(find.text('€24.99'), findsNothing);
  });

  testWidgets('store unavailable shows a retryable unavailable state, not fake prices',
      (WidgetTester tester) async {
    final billing = FakeBillingRepository(productsAvailable: false);
    await _pumpPremiumScreen(tester, billing: billing);

    await _scrollUntilVisible(tester, find.text('Plans are temporarily unavailable.'));
    expect(find.text('Plans are temporarily unavailable.'), findsOneWidget);
    expect(find.text('Try again'), findsOneWidget);
    expect(find.text('€3.99'), findsNothing);
  });

  testWidgets('Restore purchases is present and available', (WidgetTester tester) async {
    final billing = FakeBillingRepository();
    await _pumpPremiumScreen(tester, billing: billing);

    await _scrollUntilVisible(tester, find.text('Restore purchases'));
    expect(find.text('Restore purchases'), findsOneWidget);
  });

  testWidgets('premium_screen_viewed is logged with the given entry point',
      (WidgetTester tester) async {
    final billing = FakeBillingRepository();
    final analytics = RecordingAnalyticsService();
    await _pumpPremiumScreen(tester, billing: billing, analytics: analytics);

    expect(analytics.events.single.name, 'premium_screen_viewed');
    expect(analytics.events.single.parameters['entry_point'], 'settings');
  });
}
