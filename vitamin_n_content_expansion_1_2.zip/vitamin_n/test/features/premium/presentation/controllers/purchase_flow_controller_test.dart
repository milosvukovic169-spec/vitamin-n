import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/core/analytics/analytics_providers.dart';
import 'package:vitamin_n/features/premium/data/repositories/fake_billing_repository.dart';
import 'package:vitamin_n/features/premium/domain/entities/billing_product_ids.dart';
import 'package:vitamin_n/features/premium/domain/entities/premium_offering.dart';
import 'package:vitamin_n/features/premium/presentation/controllers/purchase_flow_controller.dart';
import 'package:vitamin_n/features/premium/presentation/controllers/purchase_flow_state.dart';
import 'package:vitamin_n/features/premium/presentation/providers/premium_providers.dart';

import '../../../../fakes/recording_analytics_service.dart';

void main() {
  late FakeBillingRepository billing;
  late RecordingAnalyticsService analytics;
  late ProviderContainer container;

  setUp(() {
    billing = FakeBillingRepository();
    analytics = RecordingAnalyticsService();
    container = ProviderContainer(
      overrides: <Override>[
        billingRepositoryProvider.overrideWithValue(billing),
        analyticsServiceProvider.overrideWithValue(analytics),
      ],
    );
    addTearDown(container.dispose);
  });

  test('selecting a plan updates state and logs premium_plan_selected', () {
    container.read(purchaseFlowControllerProvider.notifier).selectPlan(BillingPeriod.yearly);

    expect(container.read(purchaseFlowControllerProvider).selectedPlan, BillingPeriod.yearly);
    expect(analytics.events.single.name, 'premium_plan_selected');
    expect(analytics.events.single.parameters['plan_type'], 'yearly');
  });

  test('purchase() without a selected plan does nothing', () async {
    await container.read(purchaseFlowControllerProvider.notifier).purchase();

    expect(container.read(purchaseFlowControllerProvider).status, PurchaseFlowStatus.idle);
    expect(billing.purchaseCallCount, 0);
  });

  test('purchase() transitions to purchasing and logs purchase_started', () async {
    final notifier = container.read(purchaseFlowControllerProvider.notifier);
    notifier.selectPlan(BillingPeriod.monthly);

    await notifier.purchase();

    expect(container.read(purchaseFlowControllerProvider).status, PurchaseFlowStatus.purchasing);
    expect(analytics.events.map((e) => e.name), contains('purchase_started'));
  });

  test('a successful purchase reactively completes the flow and logs '
      'purchase_completed', () async {
    final notifier = container.read(purchaseFlowControllerProvider.notifier);
    notifier.selectPlan(BillingPeriod.monthly);
    await notifier.purchase();

    billing.simulatePurchaseSuccess(BillingProductIds.monthly);
    await Future<void>.delayed(Duration.zero);

    expect(
      container.read(purchaseFlowControllerProvider).status,
      PurchaseFlowStatus.purchaseCompleted,
    );
    expect(analytics.events.map((e) => e.name), contains('purchase_completed'));
  });

  test('cancellation returns to a calm, non-error state and logs '
      'purchase_cancelled', () async {
    final notifier = container.read(purchaseFlowControllerProvider.notifier);
    notifier.selectPlan(BillingPeriod.monthly);
    await notifier.purchase();

    billing.simulatePurchaseCancelled(BillingProductIds.monthly);
    await Future<void>.delayed(Duration.zero);

    final state = container.read(purchaseFlowControllerProvider);
    expect(state.status, PurchaseFlowStatus.purchaseCancelled);
    expect(state.errorMessage, isNull, reason: 'cancellation is not an error — section 13');
    expect(analytics.events.map((e) => e.name), contains('purchase_cancelled'));
  });

  test('an error reports a calm message and logs purchase_failed', () async {
    final notifier = container.read(purchaseFlowControllerProvider.notifier);
    notifier.selectPlan(BillingPeriod.monthly);
    await notifier.purchase();

    billing.simulatePurchaseError(BillingProductIds.monthly);
    await Future<void>.delayed(Duration.zero);

    final state = container.read(purchaseFlowControllerProvider);
    expect(state.status, PurchaseFlowStatus.purchaseError);
    expect(state.errorMessage, isNotNull);
    expect(analytics.events.map((e) => e.name), contains('purchase_failed'));
  });

  test('purchase() is a no-op while already busy — double-tap protection', () async {
    final notifier = container.read(purchaseFlowControllerProvider.notifier);
    notifier.selectPlan(BillingPeriod.monthly);
    await notifier.purchase();
    final int purchaseStartedCount =
        analytics.events.where((e) => e.name == 'purchase_started').length;

    await notifier.purchase(); // second tap while pending

    expect(
      analytics.events.where((e) => e.name == 'purchase_started').length,
      purchaseStartedCount,
      reason: 'a second purchase_started must not be logged while one is in flight',
    );
  });

  test(
    'BUG FIX: a billing repository failure during purchase() reports '
    'purchaseError instead of leaving the UI stuck on "purchasing" forever',
    () async {
      final FakeBillingRepository throwingBilling =
          FakeBillingRepository(throwOnPurchase: true);
      final ProviderContainer throwingContainer = ProviderContainer(
        overrides: <Override>[
          billingRepositoryProvider.overrideWithValue(throwingBilling),
          analyticsServiceProvider.overrideWithValue(analytics),
        ],
      );
      addTearDown(throwingContainer.dispose);

      final notifier = throwingContainer.read(purchaseFlowControllerProvider.notifier);
      notifier.selectPlan(BillingPeriod.monthly);

      await notifier.purchase();

      final state = throwingContainer.read(purchaseFlowControllerProvider);
      expect(state.status, PurchaseFlowStatus.purchaseError);
      expect(state.errorMessage, isNotNull);
    },
  );

  test(
    'BUG FIX: a second purchase() attempt is possible after a purchaseError — '
    'the double-tap guard does not permanently latch shut',
    () async {
      final FakeBillingRepository throwingBilling =
          FakeBillingRepository(throwOnPurchase: true);
      final ProviderContainer throwingContainer = ProviderContainer(
        overrides: <Override>[billingRepositoryProvider.overrideWithValue(throwingBilling)],
      );
      addTearDown(throwingContainer.dispose);

      final notifier = throwingContainer.read(purchaseFlowControllerProvider.notifier);
      notifier.selectPlan(BillingPeriod.monthly);
      await notifier.purchase();
      expect(
        throwingContainer.read(purchaseFlowControllerProvider).status,
        PurchaseFlowStatus.purchaseError,
      );

      // isBusy must be false after an error — otherwise this second
      // attempt would be silently swallowed by the busy guard.
      await notifier.purchase();

      expect(throwingBilling.purchaseCallCount, 2,
          reason: 'the second attempt must actually have reached the repository');
    },
  );

  test(
    'BUG FIX: a billing repository failure during restore() reports '
    'restoreError instead of leaving the UI stuck on "restoring" forever',
    () async {
      final FakeBillingRepository throwingBilling =
          FakeBillingRepository(throwOnRestore: true);
      final ProviderContainer throwingContainer = ProviderContainer(
        overrides: <Override>[
          billingRepositoryProvider.overrideWithValue(throwingBilling),
          analyticsServiceProvider.overrideWithValue(analytics),
        ],
      );
      addTearDown(throwingContainer.dispose);

      final notifier = throwingContainer.read(purchaseFlowControllerProvider.notifier);
      await notifier.restore();

      final state = throwingContainer.read(purchaseFlowControllerProvider);
      expect(state.status, PurchaseFlowStatus.restoreError);
      expect(state.errorMessage, isNotNull);
      expect(state.isBusy, isFalse,
          reason: 'must not be stuck — Restore must be tappable again');
    },
  );

  test('restoring with an existing purchase completes and logs '
      'restore_completed', () async {
    // Seed an existing purchase on the fake so restore has something
    // to find.
    await billing.purchase(BillingProductIds.monthly);
    billing.simulatePurchaseSuccess(BillingProductIds.monthly);

    final notifier = container.read(purchaseFlowControllerProvider.notifier);
    await notifier.restore();
    await Future<void>.delayed(Duration.zero);

    expect(
      container.read(purchaseFlowControllerProvider).status,
      PurchaseFlowStatus.restoreCompleted,
    );
    expect(analytics.events.map((e) => e.name), contains('restore_started'));
    expect(analytics.events.map((e) => e.name), contains('restore_completed'));
  });

  test('restoring with nothing to find reports restoreEmpty after the '
      'bounded wait, and logs restore_no_purchase_found', () async {
    final notifier = container.read(purchaseFlowControllerProvider.notifier);

    await notifier.restore();

    expect(
      container.read(purchaseFlowControllerProvider).status,
      PurchaseFlowStatus.restoreEmpty,
      reason: 'no purchase exists on this fresh fake billing repository',
    );
    expect(analytics.events.map((e) => e.name), contains('restore_no_purchase_found'));
  });
}
