import 'package:drift/native.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/core/database/app_database.dart';
import 'package:vitamin_n/features/premium/data/repositories/billing_backed_premium_repository.dart';
import 'package:vitamin_n/features/premium/data/repositories/fake_billing_repository.dart';
import 'package:vitamin_n/features/premium/domain/entities/billing_product_ids.dart';
import 'package:vitamin_n/features/premium/domain/entities/premium_status.dart';
import 'package:vitamin_n/features/settings/data/datasources/settings_local_data_source.dart';
import 'package:vitamin_n/features/settings/data/repositories/settings_repository_impl.dart';
import 'package:vitamin_n/features/settings/domain/repositories/settings_repository.dart';

void main() {
  late AppDatabase db;
  late SettingsRepository settings;
  late FakeBillingRepository billing;
  late BillingBackedPremiumRepository repo;

  setUp(() {
    db = AppDatabase.forTesting(NativeDatabase.memory());
    settings = SettingsRepositoryImpl(SettingsLocalDataSource(db));
    billing = FakeBillingRepository();
    repo = BillingBackedPremiumRepository(billing, settings);
  });

  tearDown(() async {
    await repo.dispose();
    await db.close();
  });

  test('starts as unknown until initialize() resolves (no cache, no prior purchase)',
      () async {
    expect((await repo.getStatus()).tier, PremiumTier.unknown);
  });

  test('initialize() resolves to Free when the store reports no entitlement', () async {
    await repo.initialize();
    await Future<void>.delayed(Duration.zero);

    expect((await repo.getStatus()).isPremium, isFalse);
  });

  test('a successful purchase reactively unlocks entitlement without polling', () async {
    await repo.initialize();
    await Future<void>.delayed(Duration.zero);

    final List<PremiumStatus> seen = <PremiumStatus>[];
    final sub = repo.watchStatus().listen(seen.add);

    await billing.purchase(BillingProductIds.monthly);
    billing.simulatePurchaseSuccess(BillingProductIds.monthly);
    await Future<void>.delayed(Duration.zero);

    expect(seen.any((PremiumStatus s) => s.isPremium), isTrue);
    await sub.cancel();
  });

  test('refreshEntitlement() reflects the current store state on demand', () async {
    await repo.initialize();
    await billing.purchase(BillingProductIds.monthly);
    billing.simulatePurchaseSuccess(BillingProductIds.monthly);
    await Future<void>.delayed(Duration.zero);

    final PremiumStatus refreshed = await repo.refreshEntitlement();
    expect(refreshed.isPremium, isTrue);
  });

  test('entitlement expiry: a revoked subscription returns the user to Free', () async {
    await repo.initialize();
    await billing.purchase(BillingProductIds.monthly);
    billing.simulatePurchaseSuccess(BillingProductIds.monthly);
    await Future<void>.delayed(Duration.zero);
    expect((await repo.getStatus()).isPremium, isTrue);

    billing.simulateEntitlementExpired();
    await repo.refreshEntitlement();

    expect((await repo.getStatus()).isPremium, isFalse);
  });

  test('cached entitlement is emitted immediately on initialize(), before the '
      'store round-trip completes — offline/startup continuity (section 16/17)',
      () async {
    await settings.setBool(SettingsKeys.cachedPremiumEntitlement, true);

    final List<PremiumStatus> seen = <PremiumStatus>[];
    final sub = repo.watchStatus().listen(seen.add);

    await repo.initialize();
    expect(seen, isNotEmpty);
    expect(seen.first.isPremium, isTrue, reason: 'cached value emitted immediately');

    await sub.cancel();
  });

  test('the cache is overwritten by a definitive store answer once it resolves',
      () async {
    // Stale cache says premium, but the store (fake, fresh) has no
    // purchase — the store's answer must win.
    await settings.setBool(SettingsKeys.cachedPremiumEntitlement, true);

    await repo.initialize();
    await Future<void>.delayed(Duration.zero);

    expect((await repo.getStatus()).isPremium, isFalse,
        reason: "the store's fresh answer overwrites the stale cache");
    expect(await settings.getBool(SettingsKeys.cachedPremiumEntitlement), isFalse);
  });

  test('a transient refresh failure does not force a premium user down to Free',
      () async {
    await repo.initialize();
    await billing.purchase(BillingProductIds.monthly);
    billing.simulatePurchaseSuccess(BillingProductIds.monthly);
    await Future<void>.delayed(Duration.zero);
    expect((await repo.getStatus()).isPremium, isTrue);

    final _ThrowingBillingRepository throwing = _ThrowingBillingRepository();
    final BillingBackedPremiumRepository resilientRepo =
        BillingBackedPremiumRepository(throwing, settings);
    await resilientRepo.initialize();
    await Future<void>.delayed(Duration.zero);

    // The cache (still premium from the earlier successful purchase)
    // is what gets emitted, not a forced Free.
    expect((await resilientRepo.getStatus()).isPremium, isTrue);
    await resilientRepo.dispose();
  });
}

/// A [FakeBillingRepository] whose refreshEntitlement always throws,
/// simulating a transient/offline failure.
class _ThrowingBillingRepository extends FakeBillingRepository {
  @override
  Future<PremiumStatus> refreshEntitlement() async {
    throw Exception('offline');
  }
}
