import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/features/premium/data/repositories/fake_billing_repository.dart';
import 'package:vitamin_n/features/premium/domain/entities/billing_product_ids.dart';
import 'package:vitamin_n/features/premium/domain/entities/premium_offering.dart';
import 'package:vitamin_n/features/premium/domain/entities/purchase_update.dart';

void main() {
  group('loadProducts', () {
    test('Monthly product maps to the correct id and billing period', () async {
      final FakeBillingRepository billing = FakeBillingRepository();
      final List<PremiumOffering> offerings = await billing.loadProducts();

      final PremiumOffering monthly = offerings
          .firstWhere((PremiumOffering o) => o.billingPeriod == BillingPeriod.monthly);
      expect(monthly.productId, BillingProductIds.monthly);
    });

    test('Yearly product maps to the correct id and billing period', () async {
      final FakeBillingRepository billing = FakeBillingRepository();
      final List<PremiumOffering> offerings = await billing.loadProducts();

      final PremiumOffering yearly = offerings
          .firstWhere((PremiumOffering o) => o.billingPeriod == BillingPeriod.yearly);
      expect(yearly.productId, BillingProductIds.yearly);
    });

    test('localized price is reported per offering', () async {
      final FakeBillingRepository billing = FakeBillingRepository(
        localizedPrices: const <String, String>{
          BillingProductIds.monthly: '€3.99',
          BillingProductIds.yearly: '€24.99',
        },
      );
      final List<PremiumOffering> offerings = await billing.loadProducts();

      expect(
        offerings.firstWhere((o) => o.billingPeriod == BillingPeriod.monthly).localizedPrice,
        '€3.99',
      );
      expect(
        offerings.firstWhere((o) => o.billingPeriod == BillingPeriod.yearly).localizedPrice,
        '€24.99',
      );
    });

    test('missing product metadata reports a null (never fabricated) price', () async {
      final FakeBillingRepository billing = FakeBillingRepository(localizedPrices: const {});
      final List<PremiumOffering> offerings = await billing.loadProducts();

      for (final PremiumOffering offering in offerings) {
        expect(offering.localizedPrice, isNull);
        expect(offering.isPurchasable, isFalse);
      }
    });

    test('store unavailable returns no offerings at all', () async {
      final FakeBillingRepository billing = FakeBillingRepository(productsAvailable: false);
      expect(await billing.loadProducts(), isEmpty);
    });
  });

  group('purchase', () {
    test('starting a purchase emits a pending update', () async {
      final FakeBillingRepository billing = FakeBillingRepository();
      final List<PurchaseUpdate> updates = <PurchaseUpdate>[];
      billing.watchPurchaseUpdates().listen(updates.add);

      await billing.purchase(BillingProductIds.monthly);
      await Future<void>.delayed(Duration.zero);

      expect(updates, hasLength(1));
      expect(updates.single.outcome, PurchaseOutcome.pending);
      expect(updates.single.productId, BillingProductIds.monthly);
    });

    test('a second purchase call while one is pending does not emit a second '
        'pending update (double-tap protection)', () async {
      final FakeBillingRepository billing = FakeBillingRepository();
      final List<PurchaseUpdate> updates = <PurchaseUpdate>[];
      billing.watchPurchaseUpdates().listen(updates.add);

      await billing.purchase(BillingProductIds.monthly);
      await billing.purchase(BillingProductIds.monthly);
      await Future<void>.delayed(Duration.zero);

      expect(billing.purchaseCallCount, 2, reason: 'both calls happened');
      expect(updates, hasLength(1), reason: 'but only one pending update was emitted');
    });

    test('purchase success unlocks entitlement', () async {
      final FakeBillingRepository billing = FakeBillingRepository();
      await billing.purchase(BillingProductIds.monthly);
      billing.simulatePurchaseSuccess(BillingProductIds.monthly);

      expect((await billing.refreshEntitlement()).isPremium, isTrue);
    });

    test('purchase cancellation does not unlock entitlement', () async {
      final FakeBillingRepository billing = FakeBillingRepository();
      final List<PurchaseUpdate> updates = <PurchaseUpdate>[];
      billing.watchPurchaseUpdates().listen(updates.add);

      await billing.purchase(BillingProductIds.monthly);
      billing.simulatePurchaseCancelled(BillingProductIds.monthly);
      await Future<void>.delayed(Duration.zero);

      expect(updates.last.outcome, PurchaseOutcome.cancelled);
      expect((await billing.refreshEntitlement()).isPremium, isFalse);
    });

    test('purchase error reports a calm outcome without unlocking entitlement', () async {
      final FakeBillingRepository billing = FakeBillingRepository();
      final List<PurchaseUpdate> updates = <PurchaseUpdate>[];
      billing.watchPurchaseUpdates().listen(updates.add);

      await billing.purchase(BillingProductIds.monthly);
      billing.simulatePurchaseError(BillingProductIds.monthly);
      await Future<void>.delayed(Duration.zero);

      expect(updates.last.outcome, PurchaseOutcome.error);
      expect(updates.last.errorMessage, isNotNull);
      expect((await billing.refreshEntitlement()).isPremium, isFalse);
    });
  });

  group('restore', () {
    test('restoring with an existing entitlement reports success', () async {
      final FakeBillingRepository billing = FakeBillingRepository();
      await billing.purchase(BillingProductIds.monthly);
      billing.simulatePurchaseSuccess(BillingProductIds.monthly);

      final List<PurchaseUpdate> updates = <PurchaseUpdate>[];
      billing.watchPurchaseUpdates().listen(updates.add);
      await billing.restorePurchases();
      await Future<void>.delayed(Duration.zero);

      expect(billing.restoreCallCount, 1);
      expect(updates.any((u) => u.outcome == PurchaseOutcome.success), isTrue);
    });

    test('restoring with no prior purchase emits nothing (caller times out to '
        '"nothing found")', () async {
      final FakeBillingRepository billing = FakeBillingRepository();
      final List<PurchaseUpdate> updates = <PurchaseUpdate>[];
      billing.watchPurchaseUpdates().listen(updates.add);

      await billing.restorePurchases();
      await Future<void>.delayed(Duration.zero);

      expect(updates, isEmpty);
    });
  });

  group('entitlement expiry', () {
    test('a previously premium entitlement can become free again', () async {
      final FakeBillingRepository billing = FakeBillingRepository();
      await billing.purchase(BillingProductIds.monthly);
      billing.simulatePurchaseSuccess(BillingProductIds.monthly);
      expect((await billing.refreshEntitlement()).isPremium, isTrue);

      billing.simulateEntitlementExpired();

      expect((await billing.refreshEntitlement()).isPremium, isFalse);
    });
  });
}
