import 'dart:async';

import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/features/premium/data/repositories/restore_based_entitlement_resolver.dart';
import 'package:vitamin_n/features/premium/domain/entities/billing_product_ids.dart';
import 'package:vitamin_n/features/premium/domain/entities/premium_status.dart';
import 'package:vitamin_n/features/premium/domain/entities/purchase_update.dart';

/// Deliberately short — these tests are about the algorithm's logic,
/// not its real-world timing, so there is no reason to actually wait
/// multiple seconds per test.
const Duration _testWindow = Duration(milliseconds: 20);

void main() {
  group('resolveEntitlementViaRestore', () {
    test(
      'THE CORE BUG FIX: a restore call that succeeds but surfaces nothing '
      'resolves to Free — not unknown, and not left as a stale cached Premium '
      '(this is exactly the failure mode the Phase 7 billing audit found)',
      () async {
        final StreamController<PurchaseUpdate> updates =
            StreamController<PurchaseUpdate>.broadcast();

        final PremiumStatus result = await resolveEntitlementViaRestore(
          triggerRestore: () async {}, // succeeds, reports nothing
          purchaseUpdates: updates.stream,
          premiumProductIds: BillingProductIds.all,
          window: _testWindow,
        );

        expect(result.tier, PremiumTier.free);
        await updates.close();
      },
    );

    test('a restore call that surfaces a Premium purchase resolves to Premium',
        () async {
      final StreamController<PurchaseUpdate> updates =
          StreamController<PurchaseUpdate>.broadcast();

      final Future<PremiumStatus> resultFuture = resolveEntitlementViaRestore(
        triggerRestore: () async {},
        purchaseUpdates: updates.stream,
        premiumProductIds: BillingProductIds.all,
        window: _testWindow,
      );

      updates.add(const PurchaseUpdate(
        productId: BillingProductIds.monthly,
        outcome: PurchaseOutcome.success,
      ));

      final PremiumStatus result = await resultFuture;
      expect(result.isPremium, isTrue);
      await updates.close();
    });

    test(
      'a restore call that throws (offline / store unavailable) resolves to '
      'unknown — never Free, so a transient failure cannot look like an '
      'actual expiry',
      () async {
        final StreamController<PurchaseUpdate> updates =
            StreamController<PurchaseUpdate>.broadcast();

        final PremiumStatus result = await resolveEntitlementViaRestore(
          triggerRestore: () async => throw Exception('offline'),
          purchaseUpdates: updates.stream,
          premiumProductIds: BillingProductIds.all,
          window: _testWindow,
        );

        expect(result.tier, PremiumTier.unknown);
        await updates.close();
      },
    );

    test('a pending update alone (no success) within the window still '
        'resolves to Free — only success counts as ownership', () async {
      final StreamController<PurchaseUpdate> updates =
          StreamController<PurchaseUpdate>.broadcast();

      final Future<PremiumStatus> resultFuture = resolveEntitlementViaRestore(
        triggerRestore: () async {},
        purchaseUpdates: updates.stream,
        premiumProductIds: BillingProductIds.all,
        window: _testWindow,
      );

      updates.add(const PurchaseUpdate(
        productId: BillingProductIds.monthly,
        outcome: PurchaseOutcome.pending,
      ));

      final PremiumStatus result = await resultFuture;
      expect(result.tier, PremiumTier.free);
      await updates.close();
    });

    test('a success update for an unrelated product id is ignored', () async {
      final StreamController<PurchaseUpdate> updates =
          StreamController<PurchaseUpdate>.broadcast();

      final Future<PremiumStatus> resultFuture = resolveEntitlementViaRestore(
        triggerRestore: () async {},
        purchaseUpdates: updates.stream,
        premiumProductIds: BillingProductIds.all,
        window: _testWindow,
      );

      updates.add(const PurchaseUpdate(
        productId: 'some_other_product',
        outcome: PurchaseOutcome.success,
      ));

      final PremiumStatus result = await resultFuture;
      expect(result.tier, PremiumTier.free);
      await updates.close();
    });

    test('a success update arriving for the Yearly product also resolves to '
        'Premium', () async {
      final StreamController<PurchaseUpdate> updates =
          StreamController<PurchaseUpdate>.broadcast();

      final Future<PremiumStatus> resultFuture = resolveEntitlementViaRestore(
        triggerRestore: () async {},
        purchaseUpdates: updates.stream,
        premiumProductIds: BillingProductIds.all,
        window: _testWindow,
      );

      updates.add(const PurchaseUpdate(
        productId: BillingProductIds.yearly,
        outcome: PurchaseOutcome.success,
      ));

      final PremiumStatus result = await resultFuture;
      expect(result.isPremium, isTrue);
      await updates.close();
    });
  });
}
