// Proves the final monetization model's access rules, per Phase 5's
// monetization correction section 10. Pure logic tests — no widget
// pumping needed, since the rules live in testable helpers/constants
// rather than being buried inside widget build methods.
import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/features/categories/domain/entities/category_access.dart';
import 'package:vitamin_n/features/challenges/domain/entities/challenge_program.dart';
import 'package:vitamin_n/features/reality_reminders/domain/entities/reality_reminder.dart';
import 'package:vitamin_n/features/refusal_responses/domain/entities/refusal_response.dart';
import 'package:vitamin_n/features/refusal_responses/domain/entities/response_visibility.dart';

void main() {
  group('CategoryAccess — categories unaffected by the correction', () {
    test('Relationships, Work, Digital and Other are Free', () {
      expect(CategoryAccess.isFree('cat_relationships'), isTrue);
      expect(CategoryAccess.isFree('cat_work'), isTrue);
      expect(CategoryAccess.isFree('cat_digital'), isTrue);
      expect(CategoryAccess.isFree('cat_other'), isTrue);
    });

    test('the other 7 curated categories require Premium', () {
      const premiumCategories = <String>[
        'cat_money', 'cat_lifestyle', 'cat_time', 'cat_social',
        'cat_availability', 'cat_favors', 'cat_listening_support',
      ];
      for (final String id in premiumCategories) {
        expect(CategoryAccess.isFree(id), isFalse, reason: '$id should require Premium');
        expect(CategoryAccess.requiresPremium(id), isTrue);
      }
    });
  });

  group('RefusalResponse — Free response limit', () {
    test('Free sees exactly 1 response', () {
      expect(RefusalResponse.freeCount, 1);
    });

    test('Premium is capped at 4, even if a situation has more authored', () {
      expect(RefusalResponse.premiumDisplayCap, 4);
    });
  });

  group('ResponseVisibility — the exact cycling rules', () {
    test('Free always sees exactly 1, regardless of how much content exists', () {
      expect(ResponseVisibility.visibleCount(8, isPremium: false), 1);
      expect(ResponseVisibility.visibleCount(1, isPremium: false), 1);
    });

    test('Free never gets a "show more" affordance — the locked label is separate', () {
      final int freeLimit = ResponseVisibility.visibleCount(8, isPremium: false);
      expect(freeLimit, 1);
      expect(0.clamp(0, freeLimit - 1), 0);
    });

    test('Premium sees up to 4 when a situation has 8 authored', () {
      expect(ResponseVisibility.visibleCount(8, isPremium: true), 4);
    });

    test('Premium sees fewer than 4 if fewer than 4 are authored', () {
      expect(ResponseVisibility.visibleCount(2, isPremium: true), 2);
      expect(ResponseVisibility.visibleCount(3, isPremium: true), 3);
    });

    test('Premium cycling: "Another way" for moving to response 2 and 3', () {
      expect(
        ResponseVisibility.nextButtonLabelForPremium(currentIndex: 0, visibleLimit: 4),
        'Another way',
      );
      expect(
        ResponseVisibility.nextButtonLabelForPremium(currentIndex: 1, visibleLimit: 4),
        'Another way',
      );
    });

    test('Premium cycling: "One more way" only for the exceptional 4th response', () {
      expect(
        ResponseVisibility.nextButtonLabelForPremium(currentIndex: 2, visibleLimit: 4),
        'One more way',
      );
    });

    test('Premium cycling: no further label once the visible limit is reached', () {
      expect(
        ResponseVisibility.nextButtonLabelForPremium(currentIndex: 2, visibleLimit: 3),
        isNull,
        reason: 'Only 3 authored/shown — nothing beyond "Another way" x2',
      );
      expect(
        ResponseVisibility.nextButtonLabelForPremium(currentIndex: 3, visibleLimit: 4),
        isNull,
        reason: 'At the cap — no further cycling',
      );
    });
  });

  group('RealityReminderAccess — Free Reality Reminder is Relationships-only', () {
    test('Relationships is Free for Reality Reminder', () {
      expect(RealityReminderAccess.isFreeForCategory('cat_relationships'), isTrue);
    });

    test('Work is locked for Reality Reminder despite being a Free category', () {
      expect(RealityReminderAccess.isFreeForCategory('cat_work'), isFalse);
    });

    test('Digital is locked for Reality Reminder despite being a Free category', () {
      expect(RealityReminderAccess.isFreeForCategory('cat_digital'), isFalse);
    });

    test('every Premium category is also locked for Free Reality Reminder access', () {
      const premiumCategories = <String>[
        'cat_money', 'cat_lifestyle', 'cat_time', 'cat_social',
        'cat_availability', 'cat_favors', 'cat_listening_support',
      ];
      for (final String id in premiumCategories) {
        expect(RealityReminderAccess.isFreeForCategory(id), isFalse);
      }
    });

    test('Free reminder count, once access is granted, is exactly 1', () {
      expect(RealityReminder.freeCount, 1);
    });
  });

  group('ChallengeAccess — no Free Challenges at all', () {
    const allChallengeIds = <String>[
      'challenge_digital_boundaries',
      'challenge_people_pleasing_reset',
      'challenge_work_boundaries',
      'challenge_time_protection',
      'challenge_mindful_spending_boundaries',
      'challenge_evening_boundaries',
    ];

    test('every known challenge is Premium-only', () {
      for (final String id in allChallengeIds) {
        expect(ChallengeAccess.isFree(id), isFalse, reason: '$id must not be Free');
      }
    });

    test('an unrecognized challenge id is also never Free', () {
      expect(ChallengeAccess.isFree('challenge_unknown'), isFalse);
    });
  });
}
