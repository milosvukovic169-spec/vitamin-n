import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/core/analytics/analytics_providers.dart';
import 'package:vitamin_n/features/boundary/presentation/controllers/say_no_flow_controller.dart';

import '../../../../fakes/recording_analytics_service.dart';

/// Verifies the SAY NO funnel analytics events (Phase 7 section 31)
/// actually fire from [SayNoFlowController], and only when they
/// genuinely should — not on every rebuild, and not twice for the
/// same view.
void main() {
  late RecordingAnalyticsService analytics;
  late ProviderContainer container;

  setUp(() {
    analytics = RecordingAnalyticsService();
    container = ProviderContainer(
      overrides: <Override>[analyticsServiceProvider.overrideWithValue(analytics)],
    );
    addTearDown(container.dispose);
  });

  test('selectCategory logs category_selected with the chosen category', () {
    container.read(sayNoFlowControllerProvider.notifier).selectCategory('cat_work');

    expect(analytics.events.single.name, 'category_selected');
    expect(analytics.events.single.parameters['category_id'], 'cat_work');
  });

  test('selectSituation logs situation_selected with both ids', () {
    final notifier = container.read(sayNoFlowControllerProvider.notifier);
    notifier.selectCategory('cat_work');
    notifier.selectSituation('sit_overtime');

    final situationEvent =
        analytics.events.firstWhere((e) => e.name == 'situation_selected');
    expect(situationEvent.parameters, <String, Object?>{
      'category_id': 'cat_work',
      'situation_id': 'sit_overtime',
    });
  });

  test('selectRefusalResponse logs suggested_response_viewed only on the '
      'first response shown for this flow', () {
    final notifier = container.read(sayNoFlowControllerProvider.notifier);
    notifier.selectCategory('cat_work');
    notifier.selectSituation('sit_overtime');
    analytics.events.clear();

    notifier.selectRefusalResponse('rr_overtime_1');
    notifier.selectRefusalResponse('rr_overtime_2'); // e.g. cycling via "Another way"
    notifier.selectRefusalResponse('rr_overtime_3');

    final viewedEvents =
        analytics.events.where((e) => e.name == 'suggested_response_viewed').toList();
    expect(viewedEvents, hasLength(1),
        reason: 'only the first view counts as reaching this step');
  });

  test('selectRealityReminder logs reality_reminder_viewed only on the first '
      'reminder shown for this flow', () {
    final notifier = container.read(sayNoFlowControllerProvider.notifier);
    notifier.selectCategory('cat_relationships');
    notifier.selectSituation('sit_unwanted_call');
    analytics.events.clear();

    notifier.selectRealityReminder('rem_unwanted_call_1');
    notifier.selectRealityReminder('rem_unwanted_call_2');

    final viewedEvents =
        analytics.events.where((e) => e.name == 'reality_reminder_viewed').toList();
    expect(viewedEvents, hasLength(1));
  });

  test('toggleProtectedValue logs protected_value_selected only when '
      'selecting, not when deselecting', () {
    final notifier = container.read(sayNoFlowControllerProvider.notifier);

    notifier.toggleProtectedValue('val_time');
    notifier.toggleProtectedValue('val_time'); // deselect

    expect(analytics.events, hasLength(1));
    expect(analytics.events.single.name, 'protected_value_selected');
    expect(analytics.events.single.parameters['protected_value_id'], 'val_time');
  });
}
