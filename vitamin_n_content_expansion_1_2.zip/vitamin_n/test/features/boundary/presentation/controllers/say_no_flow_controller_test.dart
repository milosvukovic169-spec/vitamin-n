import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/features/boundary/presentation/controllers/say_no_flow_controller.dart';

void main() {
  group('SayNoFlowController', () {
    late ProviderContainer container;

    setUp(() {
      container = ProviderContainer();
      addTearDown(container.dispose);
    });

    test('requires at least one protected value before it is satisfied', () {
      final state = container.read(sayNoFlowControllerProvider);
      expect(state.hasAtLeastOneProtectedValue, isFalse);
    });

    test('toggling a protected value selects it, and hasAtLeastOneProtectedValue becomes true', () {
      final notifier = container.read(sayNoFlowControllerProvider.notifier);
      notifier.toggleProtectedValue('val_peace');

      final state = container.read(sayNoFlowControllerProvider);
      expect(state.selectedProtectedValueIds, contains('val_peace'));
      expect(state.hasAtLeastOneProtectedValue, isTrue);
    });

    test('toggling a selected value again deselects it', () {
      final notifier = container.read(sayNoFlowControllerProvider.notifier);
      notifier.toggleProtectedValue('val_peace');
      notifier.toggleProtectedValue('val_peace');

      final state = container.read(sayNoFlowControllerProvider);
      expect(state.selectedProtectedValueIds, isEmpty);
    });

    test('never allows selecting more than 3 protected values', () {
      final notifier = container.read(sayNoFlowControllerProvider.notifier);
      notifier.toggleProtectedValue('val_peace');
      notifier.toggleProtectedValue('val_health');
      notifier.toggleProtectedValue('val_time');
      notifier.toggleProtectedValue('val_family'); // should be ignored

      final state = container.read(sayNoFlowControllerProvider);
      expect(state.selectedProtectedValueIds.length, 3);
      expect(state.selectedProtectedValueIds, isNot(contains('val_family')));
      expect(state.canSelectMoreProtectedValues, isFalse);
    });

    test('selecting a category clears any previously selected situation', () {
      final notifier = container.read(sayNoFlowControllerProvider.notifier);
      notifier.selectCategory('cat_work');
      notifier.selectSituation('sit_overtime');

      notifier.selectCategory('cat_money');

      final state = container.read(sayNoFlowControllerProvider);
      expect(state.selectedCategoryId, 'cat_money');
      expect(state.selectedSituationId, isNull);
    });

    test('reset clears all flow state back to initial', () {
      final notifier = container.read(sayNoFlowControllerProvider.notifier);
      notifier.selectCategory('cat_work');
      notifier.toggleProtectedValue('val_peace');

      notifier.reset();

      final state = container.read(sayNoFlowControllerProvider);
      expect(state.selectedCategoryId, isNull);
      expect(state.selectedProtectedValueIds, isEmpty);
      expect(state.submissionStatus, SubmissionStatus.idle);
    });

    test('a custom protected value text alone satisfies the "at least one" rule', () {
      final notifier = container.read(sayNoFlowControllerProvider.notifier);
      notifier.setCustomProtectedValueText('Quiet evenings');

      final state = container.read(sayNoFlowControllerProvider);
      expect(state.hasAtLeastOneProtectedValue, isTrue);
    });
  });
}
