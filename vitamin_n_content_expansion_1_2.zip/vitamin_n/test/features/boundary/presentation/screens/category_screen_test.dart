import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/design_system/theme/app_theme.dart';
import 'package:vitamin_n/design_system/theme/theme_extensions.dart';
import 'package:vitamin_n/features/boundary/presentation/screens/category_screen.dart';
import 'package:vitamin_n/features/categories/domain/entities/category.dart';
import 'package:vitamin_n/features/categories/domain/repositories/category_repository.dart';
import 'package:vitamin_n/features/categories/presentation/providers/category_providers.dart';

/// A deterministic in-memory [CategoryRepository]. Resolving via
/// `Future.value` (rather than real asset I/O) means the underlying
/// FutureProvider settles on the very next microtask — no real
/// Timer, no dependency on how fast the test binding can read from
/// the asset bundle, and therefore no flakiness tied to how loaded
/// the test isolate happens to be when running the full suite.
class _FakeCategoryRepository implements CategoryRepository {
  const _FakeCategoryRepository(this._categories);

  final List<Category> _categories;

  @override
  Future<List<Category>> getAll() async => _categories;

  @override
  Future<Category?> getById(String id) async {
    for (final Category category in _categories) {
      if (category.id == id) return category;
    }
    return null;
  }
}

const List<Category> _testCategories = <Category>[
  Category(
    id: 'cat_test_one',
    name: 'Test Category One',
    description: 'A first deterministic test category.',
    iconName: 'leaf',
    colorToken: 'sage',
    sortOrder: 1,
  ),
  Category(
    id: 'cat_test_two',
    name: 'Test Category Two',
    description: 'A second deterministic test category.',
    iconName: 'briefcase',
    colorToken: 'beige',
    sortOrder: 2,
  ),
];

/// Pumps [CategoryScreen] with the repository overridden by fake,
/// synchronous-ish data, then deterministically advances exactly the
/// two frames needed to move from the FutureProvider's loading state
/// to its resolved state.
///
/// Deliberately NOT `pumpAndSettle()`: the loading branch renders a
/// [CircularProgressIndicator], whose indeterminate animation repeats
/// forever and never stops scheduling frames on its own.
/// `pumpAndSettle()` waits until no more frames are scheduled, so
/// pairing it with that indicator is inherently racy — it depends on
/// the real async gap (asset I/O, in the unmocked case) closing
/// before pumpAndSettle's internal budget is exhausted, which is
/// exactly the kind of timing that varies under full-suite load. A
/// fixed two-pump sequence has no such dependency: the first pump
/// builds the initial (loading) frame and starts the widget tree
/// listening to the provider; the second flushes the already-resolved
/// microtask and rebuilds with data. Both are true regardless of how
/// busy the test isolate is.
Future<void> _pumpCategoryScreen(WidgetTester tester) async {
  await tester.pumpWidget(
    ProviderScope(
      overrides: <Override>[
        categoryRepositoryProvider.overrideWithValue(
          const _FakeCategoryRepository(_testCategories),
        ),
      ],
      child: MaterialApp(
        theme: AppTheme.light,
        home: const CategoryScreen(),
      ),
    ),
  );

  await tester.pump(); // Build the loading frame; provider starts resolving.
  await tester.pump(); // Flush the resolved future; rebuild with data.
}

void main() {
  testWidgets(
    'CategoryScreen renders its header and the categories from the repository',
    (WidgetTester tester) async {
      await _pumpCategoryScreen(tester);

      expect(find.text('What are you saying No to?'), findsOneWidget);
      expect(find.text('Choose the area that fits this moment.'), findsOneWidget);
      expect(find.text('Test Category One'), findsOneWidget);
      expect(find.text('Test Category Two'), findsOneWidget);

      // The loading indicator must be gone once data has resolved —
      // proves we didn't just get lucky pumping past it.
      expect(find.byType(CircularProgressIndicator), findsNothing);
    },
  );

  testWidgets(
    'CategoryScreen renders with the app theme applied',
    (WidgetTester tester) async {
      await _pumpCategoryScreen(tester);

      expect(find.byType(CategoryScreen), findsOneWidget);

      // A concrete, themed value — the category icon's color — must
      // match AppTheme.light's token exactly. If the theme's
      // ThemeExtensions weren't registered, resolving this color
      // inside the widget tree would have thrown during the pumps
      // above rather than merely producing the wrong color.
      final Icon leafIcon = tester.widget<Icon>(
        find.descendant(
          of: find.byType(CategoryScreen),
          matching: find.byIcon(Icons.eco_outlined),
        ),
      );
      expect(leafIcon.color, AppColors.light.sageStrong);
    },
  );
}
