import 'package:drift/native.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/core/database/app_database.dart';
import 'package:vitamin_n/core/database/app_database_provider.dart';
import 'package:vitamin_n/design_system/theme/app_theme.dart';
import 'package:vitamin_n/features/boundary/presentation/widgets/locked_reality_reminder_card.dart';
import 'package:vitamin_n/features/premium/presentation/screens/premium_screen.dart';

void main() {
  testWidgets('tapping the locked Reality Reminder card opens the canonical Premium screen',
      (WidgetTester tester) async {
    // Phase 7: PremiumScreen now watches premiumStatusProvider, whose
    // real chain depends on Settings -> AppDatabase (path_provider,
    // unavailable in widget tests) — an in-memory database avoids it.
    final AppDatabase db = AppDatabase.forTesting(NativeDatabase.memory());
    addTearDown(db.close);

    await tester.pumpWidget(
      ProviderScope(
        overrides: <Override>[appDatabaseProvider.overrideWithValue(db)],
        child: MaterialApp(
          theme: AppTheme.light,
          home: const Scaffold(body: LockedRealityReminderCard()),
        ),
      ),
    );
    await tester.pump();

    expect(find.byType(PremiumScreen), findsNothing);

    await tester.tap(find.byType(LockedRealityReminderCard));
    await tester.pump();
    await tester.pump();

    expect(find.byType(PremiumScreen), findsOneWidget);
  });
}
