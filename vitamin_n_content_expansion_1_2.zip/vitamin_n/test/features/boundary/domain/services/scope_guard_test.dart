import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/features/boundary/domain/services/scope_guard.dart';

void main() {
  group('ScopeGuard.isOutOfScope', () {
    test('flags mental health crisis keywords', () {
      expect(ScopeGuard.isOutOfScope('I feel suicidal lately'), isTrue);
      expect(ScopeGuard.isOutOfScope('dealing with self-harm urges'), isTrue);
      expect(ScopeGuard.isOutOfScope('my therapist says it is trauma'), isTrue);
    });

    test('flags addiction and substance keywords', () {
      expect(ScopeGuard.isOutOfScope('trying to quit drinking'), isTrue);
      expect(ScopeGuard.isOutOfScope('worried about gambling addiction'), isTrue);
    });

    test('flags out-of-scope advice categories', () {
      expect(ScopeGuard.isOutOfScope('need medical advice about this'), isTrue);
      expect(ScopeGuard.isOutOfScope('thinking about a divorce lawyer'), isTrue);
    });

    test('is case-insensitive', () {
      expect(ScopeGuard.isOutOfScope('SUICIDE'), isTrue);
    });

    test('allows everyday boundary topics through', () {
      expect(ScopeGuard.isOutOfScope('my neighbor keeps borrowing tools'), isFalse);
      expect(
        ScopeGuard.isOutOfScope('coworker keeps asking me to cover shifts'),
        isFalse,
      );
      expect(ScopeGuard.isOutOfScope('friend wants to borrow my car again'), isFalse);
    });
  });
}
