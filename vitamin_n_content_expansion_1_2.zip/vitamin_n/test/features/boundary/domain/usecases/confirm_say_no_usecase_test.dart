import 'package:drift/native.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/core/database/app_database.dart';
import 'package:vitamin_n/features/boundary/data/repositories/drift_say_no_transaction_runner.dart';
import 'package:vitamin_n/features/boundary/domain/usecases/confirm_say_no_usecase.dart';
import 'package:vitamin_n/features/courses/data/datasources/course_local_data_source.dart';
import 'package:vitamin_n/features/courses/data/repositories/course_repository_impl.dart';
import 'package:vitamin_n/features/courses/domain/entities/course.dart';
import 'package:vitamin_n/features/entries/data/datasources/entry_local_data_source.dart';
import 'package:vitamin_n/features/entries/data/repositories/entry_repository_impl.dart';
import 'package:vitamin_n/features/entries/domain/entities/entry.dart';
import 'package:vitamin_n/features/entries/domain/repositories/entry_repository.dart';

void main() {
  late AppDatabase db;
  late ConfirmSayNoUseCase useCase;
  late CourseRepositoryImpl courseRepository;
  late EntryRepositoryImpl entryRepository;

  setUp(() {
    db = AppDatabase.forTesting(NativeDatabase.memory());
    courseRepository = CourseRepositoryImpl(CourseLocalDataSource(db));
    entryRepository = EntryRepositoryImpl(EntryLocalDataSource(db));
    useCase = ConfirmSayNoUseCase(
      entryRepository: entryRepository,
      courseRepository: courseRepository,
      transactionRunner: DriftSayNoTransactionRunner(db),
    );
  });

  tearDown(() async {
    await db.close();
  });

  test('first entry creates course cycle 1 with 29 tokens remaining', () async {
    final result = await useCase(
      categoryId: 'cat_work',
      situationId: 'sit_overtime',
      protectedValueIds: <String>['val_time'],
      reflectionPauseShown: false,
    );

    expect(result.updatedCourse.cycleNumber, 1);
    expect(result.updatedCourse.tokensRemaining, 29);
    expect(result.startedNewCourse, isFalse);

    final entries = await entryRepository.getAll();
    expect(entries, hasLength(1));
    expect(entries.single.categoryId, 'cat_work');
    expect(entries.single.protectedValueIds, <String>['val_time']);
  });

  test('the 30th entry completes the course and immediately starts the next one', () async {
    for (int i = 0; i < Course.tokensPerCourse; i++) {
      await useCase(
        categoryId: 'cat_work',
        situationId: 'sit_overtime',
        protectedValueIds: <String>['val_time'],
        reflectionPauseShown: false,
      );
    }

    final entries = await entryRepository.getAll();
    expect(entries, hasLength(Course.tokensPerCourse));

    final history = await courseRepository.getHistory();
    expect(history, hasLength(2));

    final completed = history.firstWhere((c) => c.cycleNumber == 1);
    expect(completed.isComplete, isTrue);
    expect(completed.completedAt, isNotNull);

    final current = await courseRepository.getOrCreateCurrent();
    expect(current.cycleNumber, 2);
    expect(current.tokensRemaining, Course.tokensPerCourse);
  });

  test('the entry that completes a course is attributed to that course, not the new one', () async {
    for (int i = 0; i < Course.tokensPerCourse; i++) {
      await useCase(
        categoryId: 'cat_work',
        situationId: 'sit_overtime',
        protectedValueIds: <String>['val_time'],
        reflectionPauseShown: false,
      );
    }

    final entries = await entryRepository.getAll();
    final history = await courseRepository.getHistory();
    final completedCourseId = history.firstWhere((c) => c.cycleNumber == 1).id;

    for (final entry in entries) {
      expect(entry.courseId, completedCourseId);
    }
  });

  test('persists customProtectedValue and reflectionPauseShown fields', () async {
    final result = await useCase(
      categoryId: 'cat_other',
      situationId: 'sit_custom_other',
      protectedValueIds: const <String>[],
      customProtectedValue: 'Quiet mornings',
      reflectionPauseShown: true,
    );

    expect(result.entry.customProtectedValue, 'Quiet mornings');
    expect(result.entry.reflectionPauseShown, isTrue);

    final reloaded = await entryRepository.getAll();
    expect(reloaded.single.customProtectedValue, 'Quiet mornings');
    expect(reloaded.single.reflectionPauseShown, isTrue);
  });

  group('atomicity / rollback', () {
    test(
      'if the Entry write fails, the Course token consumption is rolled back too',
      () async {
        // A real course already exists with a known starting point.
        final Course before = await courseRepository.getOrCreateCurrent();
        expect(before.tokensRemaining, Course.tokensPerCourse);

        final failingUseCase = ConfirmSayNoUseCase(
          entryRepository: _ThrowingEntryRepository(),
          courseRepository: courseRepository,
          transactionRunner: DriftSayNoTransactionRunner(db),
        );

        await expectLater(
          () => failingUseCase(
            categoryId: 'cat_work',
            situationId: 'sit_overtime',
            protectedValueIds: <String>['val_time'],
            reflectionPauseShown: false,
          ),
          throwsA(isA<Exception>()),
        );

        // The course must be exactly as it was before the failed
        // attempt — the token consumption inside the same transaction
        // must have been rolled back, not just "not returned".
        final Course after = await courseRepository.getOrCreateCurrent();
        expect(after.id, before.id);
        expect(after.tokensRemaining, Course.tokensPerCourse);
        expect(after.cycleNumber, 1);

        // And, independently, no entry exists at all.
        final entries = await entryRepository.getAll();
        expect(entries, isEmpty);
      },
    );

    test(
      'a failed attempt does not affect a subsequent successful attempt',
      () async {
        final failingUseCase = ConfirmSayNoUseCase(
          entryRepository: _ThrowingEntryRepository(),
          courseRepository: courseRepository,
          transactionRunner: DriftSayNoTransactionRunner(db),
        );

        await expectLater(
          () => failingUseCase(
            categoryId: 'cat_work',
            situationId: 'sit_overtime',
            protectedValueIds: <String>['val_time'],
            reflectionPauseShown: false,
          ),
          throwsA(isA<Exception>()),
        );

        final result = await useCase(
          categoryId: 'cat_work',
          situationId: 'sit_overtime',
          protectedValueIds: <String>['val_time'],
          reflectionPauseShown: false,
        );

        // Proves the course wasn't left decremented by the failed
        // attempt: this, the very first *successful* entry, still
        // sees a fresh 30-token course going to 29 — not 28.
        expect(result.updatedCourse.tokensRemaining, 29);
        expect(await entryRepository.getAll(), hasLength(1));
      },
    );
  });
}

/// A domain-layer test double that never touches the database and
/// always throws — used to prove that a failure in the Entry write
/// rolls back whatever the (real, Drift-backed) Course repository
/// already wrote inside the same transaction.
class _ThrowingEntryRepository implements EntryRepository {
  @override
  Future<Entry> create(Entry entry) async {
    throw Exception('simulated entry write failure');
  }

  @override
  Future<void> update(Entry entry) => throw UnimplementedError();

  @override
  Future<void> delete(String id) => throw UnimplementedError();

  @override
  Future<Entry?> getEntryById(String id) => throw UnimplementedError();

  @override
  Future<List<Entry>> getAll() => throw UnimplementedError();

  @override
  Future<List<Entry>> getRecent({int limit = 20}) => throw UnimplementedError();

  @override
  Future<List<Entry>> getByCategoryId(String categoryId) =>
      throw UnimplementedError();

  @override
  Future<List<Entry>> getBetween(DateTime start, DateTime end) =>
      throw UnimplementedError();

  @override
  Future<List<Entry>> getEntriesForRange(DateTime start, DateTime end) =>
      throw UnimplementedError();

  @override
  Stream<List<Entry>> watchEntriesForRange(DateTime start, DateTime end) =>
      throw UnimplementedError();

  @override
  Future<Map<String, int>> getProtectedValueCounts({
    DateTime? start,
    DateTime? end,
  }) =>
      throw UnimplementedError();

  @override
  Future<Map<String, int>> getCategoryCounts({DateTime? start, DateTime? end}) =>
      throw UnimplementedError();

  @override
  Future<Map<int, int>> getWeekdayDistribution({
    DateTime? start,
    DateTime? end,
  }) =>
      throw UnimplementedError();

  @override
  Future<Map<String, int>> countByProtectedValueId() =>
      throw UnimplementedError();

  @override
  Future<Map<String, int>> countByCategoryId() => throw UnimplementedError();
}
