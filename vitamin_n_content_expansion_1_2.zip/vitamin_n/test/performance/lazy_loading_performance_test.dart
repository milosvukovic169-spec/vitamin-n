// Proves the Phase 5 performance rules (section 21/27) are actually
// enforced, not just documented: a category's content is read from
// disk at most once per session, a different category's file is
// never touched until it's actually opened, and Challenges are never
// loaded until the Challenges screen asks for them.
import 'package:flutter/services.dart' show rootBundle;
import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/core/json/json_asset_loader.dart';
import 'package:vitamin_n/features/challenges/data/datasources/challenge_program_local_data_source.dart';
import 'package:vitamin_n/features/challenges/data/repositories/challenge_program_repository_impl.dart';
import 'package:vitamin_n/features/reality_reminders/data/datasources/reality_reminder_local_data_source.dart';
import 'package:vitamin_n/features/reality_reminders/data/repositories/reality_reminder_repository_impl.dart';
import 'package:vitamin_n/features/refusal_responses/data/datasources/refusal_response_local_data_source.dart';
import 'package:vitamin_n/features/refusal_responses/data/repositories/refusal_response_repository_impl.dart';
import 'package:vitamin_n/features/situations/data/datasources/situation_local_data_source.dart';
import 'package:vitamin_n/features/situations/data/repositories/situation_repository_impl.dart';

/// Wraps the real [JsonAssetLoader] and counts how many times each
/// asset path is actually read, so tests can assert on real I/O
/// behavior rather than trusting the implementation by inspection.
class _CountingJsonAssetLoader extends JsonAssetLoader {
  const _CountingJsonAssetLoader(this._calls);

  final Map<String, int> _calls;

  @override
  Future<List<Map<String, dynamic>>> loadList(String assetPath) async {
    _calls.update(assetPath, (int c) => c + 1, ifAbsent: () => 1);
    return super.loadList(assetPath);
  }

  @override
  Future<Map<String, dynamic>> loadObject(String assetPath) async {
    _calls.update(assetPath, (int c) => c + 1, ifAbsent: () => 1);
    return super.loadObject(assetPath);
  }
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUpAll(() async {
    await rootBundle.loadString('assets/content/categories.json');
  });

  group('Situations — per-category lazy loading', () {
    test('selecting Work does not parse the Relationships situations file', () async {
      final Map<String, int> calls = <String, int>{};
      final SituationRepositoryImpl repo = SituationRepositoryImpl(
        SituationLocalDataSource(loader: _CountingJsonAssetLoader(calls)),
      );

      await repo.getByCategoryId('cat_work');

      expect(calls.keys, contains('assets/content/situations/work.json'));
      expect(calls.keys, isNot(contains('assets/content/situations/relationships.json')));
    });

    test('a category file is read from disk only once, even with repeated calls', () async {
      final Map<String, int> calls = <String, int>{};
      final SituationRepositoryImpl repo = SituationRepositoryImpl(
        SituationLocalDataSource(loader: _CountingJsonAssetLoader(calls)),
      );

      await repo.getByCategoryId('cat_digital');
      await repo.getByCategoryId('cat_digital');
      await repo.getByCategoryAndId(
        categoryId: 'cat_digital',
        situationId: 'sit_endless_scrolling',
      );

      expect(calls['assets/content/situations/digital.json'], 1);
    });

    test('no category file is read until its category is actually requested', () async {
      final Map<String, int> calls = <String, int>{};
      SituationRepositoryImpl(
        SituationLocalDataSource(loader: _CountingJsonAssetLoader(calls)),
      );
      expect(calls, isEmpty);
    });
  });

  group('Refusal responses — indexed per-situation lookup', () {
    test('repeated "Another way" lookups for the same situation hit the cache, not disk',
        () async {
      final Map<String, int> calls = <String, int>{};
      final RefusalResponseRepositoryImpl repo = RefusalResponseRepositoryImpl(
        RefusalResponseLocalDataSource(loader: _CountingJsonAssetLoader(calls)),
      );

      for (int i = 0; i < 5; i++) {
        await repo.getBySituation(categoryId: 'cat_work', situationId: 'sit_overtime');
      }

      expect(calls['assets/content/responses/work.json'], 1);
    });

    test('opening a different situation in the same category still reads that file only once',
        () async {
      final Map<String, int> calls = <String, int>{};
      final RefusalResponseRepositoryImpl repo = RefusalResponseRepositoryImpl(
        RefusalResponseLocalDataSource(loader: _CountingJsonAssetLoader(calls)),
      );

      await repo.getBySituation(categoryId: 'cat_work', situationId: 'sit_overtime');
      await repo.getBySituation(categoryId: 'cat_work', situationId: 'sit_unpaid_work');
      await repo.getBySituation(categoryId: 'cat_work', situationId: 'sit_weekend_work');

      expect(calls['assets/content/responses/work.json'], 1);
    });

    test('a category never opened is never read', () async {
      final Map<String, int> calls = <String, int>{};
      final RefusalResponseRepositoryImpl repo = RefusalResponseRepositoryImpl(
        RefusalResponseLocalDataSource(loader: _CountingJsonAssetLoader(calls)),
      );

      await repo.getBySituation(categoryId: 'cat_digital', situationId: 'sit_endless_scrolling');

      expect(calls.keys, isNot(contains('assets/content/responses/money.json')));
      expect(calls.keys, isNot(contains('assets/content/responses/listening_support.json')));
    });
  });

  group('Reality reminders — same lazy/indexed behavior', () {
    test('a category file is read at most once across repeated situation lookups', () async {
      final Map<String, int> calls = <String, int>{};
      final RealityReminderRepositoryImpl repo = RealityReminderRepositoryImpl(
        RealityReminderLocalDataSource(loader: _CountingJsonAssetLoader(calls)),
      );

      await repo.getBySituation(categoryId: 'cat_relationships', situationId: 'sit_unwanted_call');
      await repo.getBySituation(categoryId: 'cat_relationships', situationId: 'sit_declining_date');

      expect(calls['assets/content/reality_reminders/relationships.json'], 1);
    });
  });

  group('Challenges — lazy loaded, never at construction', () {
    test('constructing the repository does not read any challenge file', () async {
      final Map<String, int> calls = <String, int>{};
      ChallengeProgramRepositoryImpl(
        ChallengeProgramLocalDataSource(loader: _CountingJsonAssetLoader(calls)),
      );
      expect(calls, isEmpty);
    });

    test('getAll() reads each of the 6 challenge files exactly once, and caches after that',
        () async {
      final Map<String, int> calls = <String, int>{};
      final ChallengeProgramRepositoryImpl repo = ChallengeProgramRepositoryImpl(
        ChallengeProgramLocalDataSource(loader: _CountingJsonAssetLoader(calls)),
      );

      await repo.getAll();
      await repo.getAll();
      await repo.getById('challenge_work_boundaries');

      expect(calls.length, 6);
      for (final int count in calls.values) {
        expect(count, 1);
      }
    });
  });
}
