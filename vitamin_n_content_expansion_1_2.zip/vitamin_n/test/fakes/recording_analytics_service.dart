import 'package:vitamin_n/core/analytics/analytics_service.dart';

/// One recorded analytics call — an event name plus its (already
/// controlled-identifier-only) parameters, exactly as
/// [AnalyticsService] would have sent them.
class RecordedAnalyticsEvent {
  const RecordedAnalyticsEvent(this.name, this.parameters);

  final String name;
  final Map<String, Object?> parameters;
}

/// Records every call instead of sending anything anywhere — the
/// fake analytics implementation Phase 7 section 35 requires for
/// tests, and what section 38's "verify correct event names/params"
/// tests assert against.
class RecordingAnalyticsService implements AnalyticsService {
  final List<RecordedAnalyticsEvent> events = <RecordedAnalyticsEvent>[];

  void _record(String name, [Map<String, Object?> parameters = const <String, Object?>{}]) {
    events.add(RecordedAnalyticsEvent(name, parameters));
  }

  @override
  Future<void> appOpened() async => _record('app_opened');

  @override
  Future<void> sayNoStarted() async => _record('say_no_started');

  @override
  Future<void> categorySelected({required String categoryId}) async =>
      _record('category_selected', <String, Object?>{'category_id': categoryId});

  @override
  Future<void> situationSelected({
    required String categoryId,
    required String situationId,
  }) async =>
      _record('situation_selected', <String, Object?>{
        'category_id': categoryId,
        'situation_id': situationId,
      });

  @override
  Future<void> suggestedResponseViewed({
    required String categoryId,
    required String situationId,
  }) async =>
      _record('suggested_response_viewed', <String, Object?>{
        'category_id': categoryId,
        'situation_id': situationId,
      });

  @override
  Future<void> anotherWayRequested({
    required String categoryId,
    required String situationId,
    required int responseVariantIndex,
  }) async =>
      _record('another_way_requested', <String, Object?>{
        'category_id': categoryId,
        'situation_id': situationId,
        'response_variant_index': responseVariantIndex,
      });

  @override
  Future<void> realityReminderViewed({
    required String categoryId,
    required String situationId,
  }) async =>
      _record('reality_reminder_viewed', <String, Object?>{
        'category_id': categoryId,
        'situation_id': situationId,
      });

  @override
  Future<void> saidNoCompleted({
    required String categoryId,
    required String situationId,
  }) async =>
      _record('said_no_completed', <String, Object?>{
        'category_id': categoryId,
        'situation_id': situationId,
      });

  @override
  Future<void> protectedValueSelected({required String protectedValueId}) async => _record(
      'protected_value_selected', <String, Object?>{'protected_value_id': protectedValueId});

  @override
  Future<void> premiumScreenViewed({required PremiumEntryPoint entryPoint}) async => _record(
      'premium_screen_viewed', <String, Object?>{'entry_point': entryPoint.analyticsValue});

  @override
  Future<void> premiumPlanSelected({required PlanType planType}) async => _record(
      'premium_plan_selected', <String, Object?>{'plan_type': planType.analyticsValue});

  @override
  Future<void> purchaseStarted({required PlanType planType}) async =>
      _record('purchase_started', <String, Object?>{'plan_type': planType.analyticsValue});

  @override
  Future<void> purchaseCompleted({required PlanType planType}) async =>
      _record('purchase_completed', <String, Object?>{'plan_type': planType.analyticsValue});

  @override
  Future<void> purchaseCancelled({required PlanType planType}) async =>
      _record('purchase_cancelled', <String, Object?>{'plan_type': planType.analyticsValue});

  @override
  Future<void> purchaseFailed({required PlanType planType}) async =>
      _record('purchase_failed', <String, Object?>{'plan_type': planType.analyticsValue});

  @override
  Future<void> restoreStarted() async => _record('restore_started');

  @override
  Future<void> restoreCompleted() async => _record('restore_completed');

  @override
  Future<void> restoreNoPurchaseFound() async => _record('restore_no_purchase_found');

  @override
  Future<void> personalReminderCreated() async => _record('personal_reminder_created');

  @override
  Future<void> personalReminderDeleted() async => _record('personal_reminder_deleted');
}
