import 'package:vitamin_n/features/entries/domain/entities/entry.dart';
import 'package:vitamin_n/features/entries/domain/repositories/entry_repository.dart';

/// A deterministic, in-memory-only [EntryRepository] for widget
/// tests — no Drift, no asset I/O, no timers. [entries] is fixed at
/// construction; mutating methods are no-ops (a test that needs to
/// verify a mutation should use the real Drift-backed repository in a
/// unit test instead, not a widget test).
class FakeEntryRepository implements EntryRepository {
  const FakeEntryRepository([this.entries = const <Entry>[]]);

  final List<Entry> entries;

  @override
  Future<Entry> create(Entry entry) async => entry;

  @override
  Future<void> update(Entry entry) async {}

  @override
  Future<void> delete(String id) async {}

  @override
  Future<Entry?> getEntryById(String id) async {
    for (final Entry entry in entries) {
      if (entry.id == id) return entry;
    }
    return null;
  }

  @override
  Future<List<Entry>> getAll() async => entries;

  @override
  Future<List<Entry>> getRecent({int limit = 20}) async =>
      entries.take(limit).toList();

  @override
  Future<List<Entry>> getByCategoryId(String categoryId) async {
    return entries.where((Entry e) => e.categoryId == categoryId).toList();
  }

  @override
  Future<List<Entry>> getBetween(DateTime start, DateTime end) async => entries;

  @override
  Future<List<Entry>> getEntriesForRange(DateTime start, DateTime end) async =>
      entries;

  @override
  Stream<List<Entry>> watchEntriesForRange(DateTime start, DateTime end) {
    return Stream<List<Entry>>.value(entries);
  }

  @override
  Future<Map<String, int>> getProtectedValueCounts({
    DateTime? start,
    DateTime? end,
  }) async {
    final Map<String, int> counts = <String, int>{};
    for (final Entry entry in entries) {
      for (final String id in entry.protectedValueIds) {
        counts.update(id, (int c) => c + 1, ifAbsent: () => 1);
      }
    }
    return counts;
  }

  @override
  Future<Map<String, int>> getCategoryCounts({DateTime? start, DateTime? end}) async {
    final Map<String, int> counts = <String, int>{};
    for (final Entry entry in entries) {
      counts.update(entry.categoryId, (int c) => c + 1, ifAbsent: () => 1);
    }
    return counts;
  }

  @override
  Future<Map<int, int>> getWeekdayDistribution({
    DateTime? start,
    DateTime? end,
  }) async {
    final Map<int, int> counts = <int, int>{};
    for (final Entry entry in entries) {
      counts.update(entry.createdAt.weekday, (int c) => c + 1, ifAbsent: () => 1);
    }
    return counts;
  }

  @override
  Future<Map<String, int>> countByProtectedValueId() => getProtectedValueCounts();

  @override
  Future<Map<String, int>> countByCategoryId() => getCategoryCounts();
}
