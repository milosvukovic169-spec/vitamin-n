import 'package:vitamin_n/features/settings/domain/repositories/settings_repository.dart';

/// A pure in-memory [SettingsRepository] for unit tests — no Drift,
/// no platform channels, just a Map.
class FakeSettingsRepository implements SettingsRepository {
  final Map<String, String> _store = <String, String>{};

  @override
  Future<String?> getString(String key) async => _store[key];

  @override
  Future<void> setString(String key, String value) async {
    _store[key] = value;
  }

  @override
  Future<bool> getBool(String key, {bool defaultValue = false}) async {
    final String? raw = _store[key];
    if (raw == null) return defaultValue;
    return raw == 'true';
  }

  @override
  Future<void> setBool(String key, bool value) async {
    _store[key] = value ? 'true' : 'false';
  }

  @override
  Future<int> getInt(String key, {int defaultValue = 0}) async {
    final String? raw = _store[key];
    if (raw == null) return defaultValue;
    return int.tryParse(raw) ?? defaultValue;
  }

  @override
  Future<void> setInt(String key, int value) async {
    _store[key] = value.toString();
  }

  @override
  Future<void> remove(String key) async {
    _store.remove(key);
  }
}
