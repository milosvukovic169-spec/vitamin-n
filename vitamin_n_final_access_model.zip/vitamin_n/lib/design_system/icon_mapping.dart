import 'package:flutter/material.dart';

/// Maps the `iconName` strings used across JSON content (categories,
/// protected values, challenge programs) to a concrete [IconData].
/// Centralized so every feature reading an `iconName` field uses the
/// same mapping instead of duplicating a switch statement.
abstract final class ContentIconMapper {
  static IconData resolve(String iconName) {
    switch (iconName) {
      case 'people':
        return Icons.people_outline;
      case 'briefcase':
        return Icons.work_outline;
      case 'device':
        return Icons.smartphone_outlined;
      case 'wallet':
        return Icons.account_balance_wallet_outlined;
      case 'leaf':
        return Icons.eco_outlined;
      case 'calendar':
        return Icons.calendar_today_outlined;
      case 'spark':
        return Icons.auto_awesome_outlined;
      case 'clock':
        return Icons.schedule_outlined;
      case 'heart':
        return Icons.favorite_border;
      case 'moon':
        return Icons.dark_mode_outlined;
      case 'target':
        return Icons.adjust_outlined;
      case 'shield':
        return Icons.shield_outlined;
      case 'star':
        return Icons.star_border;
      case 'compass':
        return Icons.explore_outlined;
      case 'cloud':
        return Icons.cloud_outlined;
      case 'lock':
        return Icons.lock_outline;
      case 'verified':
        return Icons.verified_outlined;
      case 'self_improvement':
        return Icons.self_improvement_outlined;
      case 'coffee':
        return Icons.local_cafe_outlined;
      case 'psychology':
        return Icons.psychology_outlined;
      case 'handshake':
        return Icons.handshake_outlined;
      case 'hourglass':
        return Icons.hourglass_empty_outlined;
      case 'palette':
        return Icons.palette_outlined;
      case 'balance':
        return Icons.balance_outlined;
      case 'visibility':
        return Icons.visibility_outlined;
      case 'volunteer':
        return Icons.volunteer_activism_outlined;
      case 'gavel':
        return Icons.gavel_outlined;
      case 'crop_free':
        return Icons.crop_free_outlined;
      default:
        return Icons.spa_outlined;
    }
  }
}
