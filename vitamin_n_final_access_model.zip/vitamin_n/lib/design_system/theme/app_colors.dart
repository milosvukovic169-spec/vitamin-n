import 'package:flutter/material.dart';

/// Semantic color tokens for Vitamin N's warm, calm visual language
/// (cream / beige / sage). Accessed via
/// `Theme.of(context).extension<AppColors>()!` — never hardcode a hex
/// value in a screen or widget; add a token here instead.
class AppColors extends ThemeExtension<AppColors> {
  const AppColors({
    required this.background,
    required this.surface,
    required this.surfaceElevated,
    required this.cream,
    required this.beige,
    required this.sage,
    required this.sageStrong,
    required this.textPrimary,
    required this.textSecondary,
    required this.textOnSage,
    required this.border,
    required this.shadow,
    required this.tokenFilled,
    required this.tokenEmpty,
    required this.tokenCeramicSurface,
    required this.destructive,
    required this.tintBlush,
    required this.tintLavender,
    required this.tintBlueGrey,
  });

  final Color background;
  final Color surface;
  final Color surfaceElevated;

  final Color cream;
  final Color beige;
  final Color sage;
  final Color sageStrong;

  final Color textPrimary;
  final Color textSecondary;
  final Color textOnSage;

  final Color border;
  final Color shadow;

  /// N token states on the CourseBoard.
  final Color tokenFilled;
  final Color tokenEmpty;

  /// The off-white ceramic surface of a filled N token (distinct from
  /// [tokenFilled], which is now only used as the printed "N" letter
  /// color, not the token's fill).
  final Color tokenCeramicSurface;

  /// Destructive/warning actions only — Clear Local Data, delete
  /// confirmations. Never used for anything else, so a single
  /// muted terracotta token (matching the app's warm, restrained
  /// palette rather than a harsh alert-red) is enough.
  final Color destructive;

  /// Very restrained (~5–10% perceived tint) category-differentiation
  /// colors — combined with [sage] and [beige], gives categories a
  /// subtle identity without the app feeling colorful. Applied at low
  /// alpha by callers (e.g. CategoryCard), never used at full
  /// strength.
  final Color tintBlush;
  final Color tintLavender;
  final Color tintBlueGrey;

  static const AppColors light = AppColors(
    background: Color(0xFFFBF7F0),
    surface: Color(0xFFF7F2E6),
    surfaceElevated: Color(0xFFFAF6EC),
    cream: Color(0xFFF3ECDD),
    beige: Color(0xFFE8DFCB),
    sage: Color(0xFFA8B79A),
    sageStrong: Color(0xFF2F4F3A),
    textPrimary: Color(0xFF2E2B24),
    textSecondary: Color(0xFF6B665B),
    textOnSage: Color(0xFFFFFFFF),
    border: Color(0xFFE6DFD0),
    shadow: Color(0x1A2E2B24),
    tokenFilled: Color(0xFF7C8F6C),
    tokenEmpty: Color(0xFFE6DFD0),
    tokenCeramicSurface: Color(0xFFFCFAF3),
    destructive: Color(0xFFB3543E),
    tintBlush: Color(0xFFE3CBC4),
    tintLavender: Color(0xFFD7D0DF),
    tintBlueGrey: Color(0xFFCCD5D7),
  );

  static const AppColors dark = AppColors(
    background: Color(0xFF1E1C18),
    surface: Color(0xFF2A2721),
    surfaceElevated: Color(0xFF332F27),
    cream: Color(0xFF3A362C),
    beige: Color(0xFF423D31),
    sage: Color(0xFF8FA07F),
    sageStrong: Color(0xFF8FB39A),
    textPrimary: Color(0xFFF3EFE6),
    textSecondary: Color(0xFFC2BCAC),
    textOnSage: Color(0xFF1E1C18),
    border: Color(0xFF423D31),
    shadow: Color(0x40000000),
    tokenFilled: Color(0xFFA3B593),
    tokenEmpty: Color(0xFF423D31),
    tokenCeramicSurface: Color(0xFF3A362C),
    destructive: Color(0xFFC97A62),
    tintBlush: Color(0xFF4A3A37),
    tintLavender: Color(0xFF3A3742),
    tintBlueGrey: Color(0xFF35403F),
  );

  @override
  AppColors copyWith({
    Color? background,
    Color? surface,
    Color? surfaceElevated,
    Color? cream,
    Color? beige,
    Color? sage,
    Color? sageStrong,
    Color? textPrimary,
    Color? textSecondary,
    Color? textOnSage,
    Color? border,
    Color? shadow,
    Color? tokenFilled,
    Color? tokenEmpty,
    Color? tokenCeramicSurface,
    Color? destructive,
    Color? tintBlush,
    Color? tintLavender,
    Color? tintBlueGrey,
  }) {
    return AppColors(
      background: background ?? this.background,
      surface: surface ?? this.surface,
      surfaceElevated: surfaceElevated ?? this.surfaceElevated,
      cream: cream ?? this.cream,
      beige: beige ?? this.beige,
      sage: sage ?? this.sage,
      sageStrong: sageStrong ?? this.sageStrong,
      textPrimary: textPrimary ?? this.textPrimary,
      textSecondary: textSecondary ?? this.textSecondary,
      textOnSage: textOnSage ?? this.textOnSage,
      border: border ?? this.border,
      shadow: shadow ?? this.shadow,
      tokenFilled: tokenFilled ?? this.tokenFilled,
      tokenEmpty: tokenEmpty ?? this.tokenEmpty,
      tokenCeramicSurface: tokenCeramicSurface ?? this.tokenCeramicSurface,
      destructive: destructive ?? this.destructive,
      tintBlush: tintBlush ?? this.tintBlush,
      tintLavender: tintLavender ?? this.tintLavender,
      tintBlueGrey: tintBlueGrey ?? this.tintBlueGrey,
    );
  }

  @override
  AppColors lerp(ThemeExtension<AppColors>? other, double t) {
    if (other is! AppColors) {
      return this;
    }
    return AppColors(
      background: Color.lerp(background, other.background, t)!,
      surface: Color.lerp(surface, other.surface, t)!,
      surfaceElevated: Color.lerp(surfaceElevated, other.surfaceElevated, t)!,
      cream: Color.lerp(cream, other.cream, t)!,
      beige: Color.lerp(beige, other.beige, t)!,
      sage: Color.lerp(sage, other.sage, t)!,
      sageStrong: Color.lerp(sageStrong, other.sageStrong, t)!,
      textPrimary: Color.lerp(textPrimary, other.textPrimary, t)!,
      textSecondary: Color.lerp(textSecondary, other.textSecondary, t)!,
      textOnSage: Color.lerp(textOnSage, other.textOnSage, t)!,
      border: Color.lerp(border, other.border, t)!,
      shadow: Color.lerp(shadow, other.shadow, t)!,
      tokenFilled: Color.lerp(tokenFilled, other.tokenFilled, t)!,
      tokenEmpty: Color.lerp(tokenEmpty, other.tokenEmpty, t)!,
      tokenCeramicSurface:
          Color.lerp(tokenCeramicSurface, other.tokenCeramicSurface, t)!,
      destructive: Color.lerp(destructive, other.destructive, t)!,
      tintBlush: Color.lerp(tintBlush, other.tintBlush, t)!,
      tintLavender: Color.lerp(tintLavender, other.tintLavender, t)!,
      tintBlueGrey: Color.lerp(tintBlueGrey, other.tintBlueGrey, t)!,
    );
  }
}

/// Convenience accessor: `context.colors.sage` instead of the longer
/// `Theme.of(context).extension<AppColors>()!.sage`.
extension AppColorsContext on BuildContext {
  AppColors get colors => Theme.of(this).extension<AppColors>()!;
}
