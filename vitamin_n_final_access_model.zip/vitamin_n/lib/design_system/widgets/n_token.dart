import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show HapticFeedback;

import '../animation/app_animated_switcher.dart';
import '../theme/app_typography.dart';
import '../theme/theme_extensions.dart';

/// A single N token on the CourseBoard — a soft, off-white ceramic
/// tablet with a printed green "N", filled while unused and an empty
/// outlined circle once consumed.
///
/// Deliberately NOT a pill/capsule (no medicine-dose styling, no
/// glossy half-and-half shading) and NOT a game token (no number, no
/// badge, no metallic/plastic finish) — just a calm, matte ceramic
/// piece with a subtle border and a natural (not glowing) shadow.
///
/// If [onTap] is provided (only ever wired up for a *filled* token —
/// see [CourseBoard]), tapping plays a soft ripple, a gentle haptic
/// tick, and crossfades into the empty state.
class NToken extends StatelessWidget {
  const NToken({
    super.key,
    required this.filled,
    this.size = 44,
    this.onTap,
    this.reduceMotion = false,
    this.index,
  });

  final bool filled;
  final double size;
  final VoidCallback? onTap;
  final bool reduceMotion;

  /// This token's position on the board (0-based). When supplied,
  /// drives a very subtle, DETERMINISTIC per-token variation in color
  /// and size — a organic, "real pills in a bottle aren't perfectly
  /// identical" touch, not randomness. Seeding on the index (rather
  /// than an unseeded Random()) is what makes this safe: the same
  /// token always looks exactly the same across rebuilds, the
  /// consume-animation, and app restarts — nothing flickers or
  /// reshuffles. Null (the default) means no variation at all.
  final int? index;

  /// A tiny, deterministic per-token nudge — never more than a
  /// couple of percent in either direction, so 30 tokens read as
  /// "one calm, consistent set" at a glance, with only a closer look
  /// revealing they're not machine-identical.
  ({double lightnessJitter, double sizeJitter}) _jitterFor(int seed) {
    final math.Random rng = math.Random(seed);
    final double lightness = (rng.nextDouble() - 0.5) * 0.04; // ±2%
    final double sizeDelta = (rng.nextDouble() - 0.5) * 3.0; // ±1.5px
    return (lightnessJitter: lightness, sizeJitter: sizeDelta);
  }

  /// A soft, HSL-lightness-based highlight/shadow pair derived from
  /// [base] — works correctly in both light and dark theme without
  /// hardcoding a "lighter" color, and stays subtle enough to read as
  /// a gentle dome rather than glossy 3D/plastic shine.
  RadialGradient _domeGradient(Color base) {
    final HSLColor hsl = HSLColor.fromColor(base);
    final Color highlight =
        hsl.withLightness((hsl.lightness + 0.05).clamp(0.0, 1.0)).toColor();
    final Color shade =
        hsl.withLightness((hsl.lightness - 0.04).clamp(0.0, 1.0)).toColor();
    return RadialGradient(
      center: const Alignment(-0.35, -0.45),
      radius: 0.9,
      colors: <Color>[highlight, base, shade],
      stops: const <double>[0.0, 0.55, 1.0],
    );
  }

  Widget _bead(BuildContext context, bool isFilled) {
    final AppColors colors = context.colors;

    final ({double lightnessJitter, double sizeJitter}) jitter =
        index != null ? _jitterFor(index!) : (lightnessJitter: 0.0, sizeJitter: 0.0);
    final double effectiveSize = size + jitter.sizeJitter;

    Color baseSurface = colors.tokenCeramicSurface;
    if (jitter.lightnessJitter != 0.0) {
      final HSLColor hsl = HSLColor.fromColor(baseSurface);
      baseSurface = hsl
          .withLightness((hsl.lightness + jitter.lightnessJitter).clamp(0.0, 1.0))
          .toColor();
    }

    return Container(
      key: ValueKey<bool>(isFilled),
      width: effectiveSize,
      height: effectiveSize,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        // Only a filled (unused) tablet gets the dome shading — the
        // consumed/empty state stays a flat outline, reinforcing that
        // it's no longer physically "there".
        gradient: isFilled ? _domeGradient(baseSurface) : null,
        color: isFilled ? null : colors.tokenEmpty,
        border: Border.all(
          color: isFilled ? colors.border : colors.border,
          width: 1,
        ),
        boxShadow: isFilled
            ? <BoxShadow>[
                // A tight, low, grounded shadow — a tablet resting on
                // a surface, not a card floating above one.
                BoxShadow(
                  color: colors.shadow,
                  blurRadius: 4,
                  offset: const Offset(0, 2),
                ),
              ]
            : null,
      ),
      alignment: Alignment.center,
      child: isFilled
          ? Text(
              'N',
              style: AppTypography.serif(
                TextStyle(
                  fontSize: effectiveSize * 0.44,
                  fontWeight: FontWeight.w600,
                  color: colors.sageStrong,
                  height: 1,
                ),
              ),
            )
          : null,
    );
  }

  @override
  Widget build(BuildContext context) {
    final Widget bead = reduceMotion
        ? _bead(context, filled)
        : AppAnimatedSwitcher(child: _bead(context, filled));

    if (onTap == null) {
      return bead;
    }

    return Material(
      color: Colors.transparent,
      shape: const CircleBorder(),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        customBorder: const CircleBorder(),
        // Intentional ripple: the app theme disables Material's
        // default splash everywhere else for a calmer feel, but this
        // one interaction is explicitly designed to include a soft
        // ripple as part of the token-consumed moment.
        splashFactory: InkRipple.splashFactory,
        splashColor: context.colors.sage.withValues(alpha: 0.35),
        onTap: () {
          HapticFeedback.selectionClick();
          onTap!();
        },
        child: Padding(padding: const EdgeInsets.all(3), child: bead),
      ),
    );
  }
}
