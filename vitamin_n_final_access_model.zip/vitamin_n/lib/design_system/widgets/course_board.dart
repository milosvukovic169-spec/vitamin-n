import 'package:flutter/material.dart';

import '../theme/theme_extensions.dart';
import 'app_card.dart';
import 'n_token.dart';

/// Displays the current Vitamin Course as a grid of N tokens — the
/// visual centerpiece of Home.
///
/// Pure presentation: takes [tokensRemaining] / [totalTokens] as
/// props and renders that many filled ceramic tokens vs. empty
/// outlines. If [onTokenTap] is supplied, only *filled* tokens become
/// tappable.
///
/// [newCourseReady] shows a brief, plain-language note — never a
/// celebration — and should only be true for the moment right after
/// a course completes, controlled by the caller.
class CourseBoard extends StatelessWidget {
  const CourseBoard({
    super.key,
    required this.tokensRemaining,
    required this.totalTokens,
    required this.cycleNumber,
    this.newCourseReady = false,
    this.onTokenTap,
    this.reduceMotion = false,
  });

  final int tokensRemaining;
  final int totalTokens;
  final int cycleNumber;
  final bool newCourseReady;
  final void Function(int index)? onTokenTap;
  final bool reduceMotion;

  @override
  Widget build(BuildContext context) {
    final TextTheme textTheme = Theme.of(context).textTheme;

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              Expanded(
                child: Text(
                  newCourseReady ? 'New Course Ready' : 'Vitamin Course',
                  style: textTheme.titleMedium,
                ),
              ),
              Text('Cycle $cycleNumber', style: textTheme.bodySmall),
            ],
          ),
          SizedBox(height: context.spacing.xs),
          Text(
            '$tokensRemaining of $totalTokens N tokens remaining',
            style: textTheme.bodyMedium,
          ),
          SizedBox(height: context.spacing.md),
          Wrap(
            spacing: context.spacing.sm,
            runSpacing: context.spacing.sm,
            children: List<Widget>.generate(totalTokens, (int index) {
              final bool isFilled = index < tokensRemaining;
              return NToken(
                filled: isFilled,
                reduceMotion: reduceMotion,
                onTap: (onTokenTap != null && isFilled)
                    ? () => onTokenTap!(index)
                    : null,
              );
            }),
          ),
        ],
      ),
    );
  }
}
