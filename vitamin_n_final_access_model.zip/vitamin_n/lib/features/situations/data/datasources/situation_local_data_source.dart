import '../../../../core/constants/asset_paths.dart';
import '../../../../core/json/json_asset_loader.dart';
import '../../domain/entities/situation.dart';

class SituationLocalDataSource {
  SituationLocalDataSource({JsonAssetLoader loader = const JsonAssetLoader()})
      : _loader = loader;

  final JsonAssetLoader _loader;

  Future<List<Situation>> loadForCategory(String categoryId) async {
    final List<Map<String, dynamic>> raw = await _loader
        .loadList(AssetPaths.situationsForCategory(categoryId));
    return raw.map(_parse).toList()
      ..sort((Situation a, Situation b) => a.sortOrder.compareTo(b.sortOrder));
  }

  Situation _parse(Map<String, dynamic> json) {
    return Situation(
      id: json['id'] as String,
      categoryId: json['categoryId'] as String,
      title: json['title'] as String,
      description: json['description'] as String,
      sortOrder: json['sortOrder'] as int,
      protectedValueIds: (json['protectedValueIds'] as List<dynamic>? ?? const <dynamic>[])
          .map((dynamic e) => e as String)
          .toList(),
      active: json['active'] as bool? ?? true,
    );
  }
}
