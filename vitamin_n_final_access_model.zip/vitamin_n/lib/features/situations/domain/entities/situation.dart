/// A specific, concrete situation a user might want a boundary for,
/// belonging to a Category. Pure domain entity.
class Situation {
  const Situation({
    required this.id,
    required this.categoryId,
    required this.title,
    required this.description,
    required this.sortOrder,
    this.protectedValueIds = const <String>[],
    this.active = true,
  });

  final String id;
  final String categoryId;
  final String title;
  final String description;
  final int sortOrder;

  /// False for situations retired from active discovery within an
  /// otherwise-active category (e.g. self-directed impulse-spending
  /// situations under Money, which stays active for its genuinely
  /// interpersonal lending/covering-costs situations). Mirrors
  /// [Category.active] exactly — the situation and its content stay
  /// fully intact for History to resolve existing entries; it's
  /// simply excluded from the browsable situation list. Defaults to
  /// true so any situation without this field behaves as before.
  final bool active;

  /// 2–4 ProtectedValue ids the app pre-suggests as relevant to this
  /// situation (e.g. Overtime -> Time, Energy, Family, Personal
  /// priorities). The user still manually chooses 1–3 after I SAID
  /// NO — this is a suggestion surface only, never an automatic
  /// selection.
  final List<String> protectedValueIds;

  @override
  bool operator ==(Object other) => other is Situation && other.id == id;

  @override
  int get hashCode => id.hashCode;
}
