import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/datasources/situation_local_data_source.dart';
import '../../data/repositories/situation_repository_impl.dart';
import '../../domain/entities/situation.dart';
import '../../domain/repositories/situation_repository.dart';

final Provider<SituationRepository> situationRepositoryProvider =
    Provider<SituationRepository>((Ref ref) {
  return SituationRepositoryImpl(SituationLocalDataSource());
});

/// Situations belonging to a given category, in the order the
/// Situation screen should present them — active ones only. Only
/// that category's content file is ever read. Use
/// [situationByCategoryAndIdProvider] instead when resolving a
/// specific, possibly-retired situation (e.g. an existing History
/// entry), since that lookup is intentionally NOT filtered by
/// [Situation.active].
final FutureProviderFamily<List<Situation>, String>
    situationsByCategoryIdProvider =
    FutureProvider.family<List<Situation>, String>((Ref ref, String categoryId) async {
  final List<Situation> all =
      await ref.watch(situationRepositoryProvider).getByCategoryId(categoryId);
  return all.where((Situation s) => s.active).toList();
});

/// A record key rather than two separate params: Riverpod families
/// need a single hashable argument, and Dart records give us that
/// with structural equality for free — no custom key class needed.
typedef CategoryAndSituationId = ({String categoryId, String situationId});

final FutureProviderFamily<Situation?, CategoryAndSituationId>
    situationByCategoryAndIdProvider =
    FutureProvider.family<Situation?, CategoryAndSituationId>(
        (Ref ref, CategoryAndSituationId key) {
  return ref.watch(situationRepositoryProvider).getByCategoryAndId(
        categoryId: key.categoryId,
        situationId: key.situationId,
      );
});
