import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/datasources/category_local_data_source.dart';
import '../../data/repositories/category_repository_impl.dart';
import '../../domain/entities/category.dart';
import '../../domain/repositories/category_repository.dart';

/// Composition root for the Categories feature: this is the only file
/// that knows about the concrete `CategoryRepositoryImpl` /
/// `CategoryLocalDataSource` — everything else in the app depends on
/// the `CategoryRepository` abstraction.
final Provider<CategoryRepository> categoryRepositoryProvider =
    Provider<CategoryRepository>((Ref ref) {
  return CategoryRepositoryImpl(CategoryLocalDataSource());
});

/// Categories available for active browsing/discovery (SAY NO's
/// category picker). Excludes retired categories — use
/// [categoryByIdProvider] instead when resolving a specific,
/// possibly-retired category (e.g. for an existing History entry),
/// since that lookup is intentionally NOT filtered by [Category.active].
final FutureProvider<List<Category>> categoriesProvider =
    FutureProvider<List<Category>>((Ref ref) async {
  final List<Category> all = await ref.watch(categoryRepositoryProvider).getAll();
  return all.where((Category c) => c.active).toList();
});

final FutureProviderFamily<Category?, String> categoryByIdProvider =
    FutureProvider.family<Category?, String>((Ref ref, String id) {
  return ref.watch(categoryRepositoryProvider).getById(id);
});
