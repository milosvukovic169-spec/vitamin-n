/// A top-level grouping of situations (e.g. "Work & Career").
///
/// Pure domain entity — knows nothing about JSON, SQL, or Flutter.
/// Content is static reference data sourced from
/// `assets/data/categories.json`; the mapping from that file lives in
/// the data layer's `CategoryLocalDataSource`, never here.
class Category {
  const Category({
    required this.id,
    required this.name,
    required this.description,
    required this.iconName,
    required this.colorToken,
    required this.sortOrder,
    this.active = true,
  });

  final String id;
  final String name;
  final String description;
  final String iconName;
  final String colorToken;
  final int sortOrder;

  /// False for categories retired from active discovery (e.g.
  /// self-directed categories moved out of Vitamin N's interpersonal-
  /// boundaries scope) — the category and its content stay fully
  /// intact for History/Insights to resolve existing entries by id;
  /// it's simply excluded from the browsable category list. Defaults
  /// to true so any category without this field (the common case)
  /// behaves exactly as before.
  final bool active;

  @override
  bool operator ==(Object other) => other is Category && other.id == id;

  @override
  int get hashCode => id.hashCode;
}
