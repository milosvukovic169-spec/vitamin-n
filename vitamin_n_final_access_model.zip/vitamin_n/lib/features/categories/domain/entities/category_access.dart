/// The single source of truth for category-level access rules.
///
/// As of the final access-model cleanup, NO active category requires
/// Premium just to be opened/browsed — every Free user can open any
/// active category, browse every situation in it, and get at least
/// the first curated response (see ResponseVisibility). What DOES
/// still vary by category is how MUCH is free once inside: Work,
/// Relationships and Social are fully free (all active responses,
/// free Reality Reminder); everything else gives the first response
/// free and gates additional responses/Reality Reminder behind
/// Premium — see [fullyFreeCategoryIds] and RealityReminderAccess.
abstract final class CategoryAccess {
  static const String otherCategoryId = 'cat_other';

  /// Categories where a Free user gets EVERY active response (not
  /// just the first) and a free Reality Reminder. This is a
  /// completely separate question from "can this category be opened
  /// at all" — see [requiresPremium], which is always false now.
  static const Set<String> fullyFreeCategoryIds = <String>{
    'cat_relationships',
    'cat_work',
    'cat_social',
  };

  static bool isFullyFree(String categoryId) => fullyFreeCategoryIds.contains(categoryId);

  /// Always false: no active category is locked at the category
  /// level anymore. Kept as a real method (rather than deleting every
  /// call site) so category-level locking can be reintroduced in one
  /// place later if the product ever needs it again.
  static bool requiresPremium(String categoryId) => false;

  static bool isFree(String categoryId) => !requiresPremium(categoryId);
}
