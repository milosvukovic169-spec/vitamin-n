import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../app/routes.dart';
import '../../../../core/analytics/analytics_providers.dart';
import '../../../../design_system/theme/theme_extensions.dart';
import '../../../../design_system/widgets/app_card.dart';
import '../../../../design_system/widgets/course_board.dart';
import '../../../../design_system/widgets/primary_button.dart';
import '../../../boundary/domain/entities/say_no_result.dart';
import '../../../boundary/presentation/controllers/say_no_flow_controller.dart';
import '../../../courses/domain/entities/course.dart';
import '../../../courses/presentation/providers/course_providers.dart';
import '../../../support_messages/presentation/providers/support_message_providers.dart';
import '../providers/protected_today_provider.dart';
import '../widgets/home_greeting.dart';
import '../widgets/protected_today_card.dart';
import '../widgets/support_message_card.dart';

/// Home displays the real Course from the database. When returning
/// from a completed Say No flow, it simply renders the current,
/// correct token count — no disappearance animation.
class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  int? _displayedTokensRemaining;
  int? _displayedCycleNumber;

  void _seedDisplayedStateIfNeeded(Course course) {
    if (_displayedTokensRemaining == null) {
      _displayedTokensRemaining = course.tokensRemaining;
      _displayedCycleNumber = course.cycleNumber;
    }
  }

  Future<void> _handleReturnToHome(SayNoResult result) async {
    setState(() {
      _displayedTokensRemaining = result.updatedCourse.tokensRemaining;
      _displayedCycleNumber = result.updatedCourse.cycleNumber;
    });

    ref.invalidate(currentCourseProvider);
    ref.invalidate(randomSupportMessageProvider);
    ref.invalidate(todaysProtectedItemsProvider);

    if (result.startedNewCourse) {
      await _showCourseCompleteDialog();
      if (!mounted) return;
    }

    ref.read(sayNoFlowControllerProvider.notifier).reset();
  }

  Future<void> _showCourseCompleteDialog() {
    return showDialog<void>(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          backgroundColor: context.colors.surface,
          shape: RoundedRectangleBorder(borderRadius: context.radius.lgRadius),
          title: const Text('Course complete'),
          content: const Text(
            '${Course.tokensPerCourse} moments in which you protected what mattered.\n\n'
            'Vitamin N · New course begun',
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: const Text('Begin the next course'),
            ),
          ],
        );
      },
    );
  }

  void _handleSayNoTap() {
    unawaited(ref.read(analyticsServiceProvider).sayNoStarted());
    context.push(AppRoutes.sayNoCategory);
  }

  @override
  Widget build(BuildContext context) {
    final courseAsync = ref.watch(currentCourseProvider);
    final supportMessageAsync = ref.watch(randomSupportMessageProvider);
    final bool reduceMotion = MediaQuery.of(context).disableAnimations;

    courseAsync.whenData(_seedDisplayedStateIfNeeded);

    // Fires on every genuine transition to a freshly-completed SAY NO
    // flow — not just the app's very first HomeScreen build. Home
    // stays alive as a preserved bottom-nav tab (never re-created on
    // return from the flow), so relying on initState() here would
    // only ever run this once per app session; ref.listen correctly
    // re-fires each time. The controller resets its own result back
    // to null at the end of _handleReturnToHome, so this only reacts
    // to genuinely new completions, never the same one twice.
    ref.listen<SayNoFlowState>(sayNoFlowControllerProvider, (previous, next) {
      if (next.submissionStatus == SubmissionStatus.success && next.result != null) {
        _handleReturnToHome(next.result!);
      }
    });

    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: EdgeInsets.fromLTRB(
            context.spacing.lg,
            context.spacing.lg,
            context.spacing.lg,
            context.spacing.xxl,
          ),
          children: <Widget>[
            const HomeGreeting(),
            SizedBox(height: context.spacing.xl),
            if (_displayedTokensRemaining != null && _displayedCycleNumber != null)
              CourseBoard(
                tokensRemaining: _displayedTokensRemaining!,
                totalTokens: Course.tokensPerCourse,
                cycleNumber: _displayedCycleNumber!,
                reduceMotion: reduceMotion,
              )
            else
              courseAsync.when(
                data: (_) => const SizedBox.shrink(),
                loading: () => const AppCard(
                  child: SizedBox(
                    height: 120,
                    child: Center(child: CircularProgressIndicator()),
                  ),
                ),
                error: (Object error, StackTrace stackTrace) =>
                    AppCard(child: Text('Could not load your Course: $error')),
              ),
            SizedBox(height: context.spacing.lg),
            PrimaryButton(
              label: 'Say No',
              icon: Icons.front_hand_outlined,
              onPressed: _handleSayNoTap,
            ),
            SizedBox(height: context.spacing.lg),
            const ProtectedTodayCard(),
            SizedBox(height: context.spacing.lg),
            supportMessageAsync.when(
              data: (message) => SupportMessageCard(message: message?.text),
              loading: () => const SupportMessageCard(message: null),
              error: (Object error, StackTrace stackTrace) =>
                  const SupportMessageCard(message: null),
            ),
          ],
        ),
      ),
    );
  }
}
