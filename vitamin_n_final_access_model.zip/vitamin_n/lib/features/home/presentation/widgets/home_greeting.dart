import 'package:flutter/material.dart';

import '../../../../design_system/theme/app_typography.dart';
import '../../../../design_system/theme/theme_extensions.dart';

/// The calm, wordless-logo-style header at the top of Home: a soft
/// botanical mark plus a time-of-day greeting. No streak count, no
/// stats, no "day 12" — just a quiet welcome.
class HomeGreeting extends StatelessWidget {
  const HomeGreeting({super.key, DateTime? now}) : _now = now;

  final DateTime? _now;

  String get _greeting {
    final int hour = (_now ?? DateTime.now()).hour;
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  }

  @override
  Widget build(BuildContext context) {
    final AppColors colors = context.colors;
    final TextTheme textTheme = Theme.of(context).textTheme;

    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: <Widget>[
        Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: colors.cream,
            boxShadow: context.elevation.soft,
          ),
          child: Icon(Icons.spa_outlined, color: colors.sageStrong, size: 24),
        ),
        SizedBox(width: context.spacing.md),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(_greeting, style: textTheme.bodyMedium),
              Text(
                'Your daily dose of No.',
                style: AppTypography.serif(
                  textTheme.headlineMedium!.copyWith(fontWeight: FontWeight.w600),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
