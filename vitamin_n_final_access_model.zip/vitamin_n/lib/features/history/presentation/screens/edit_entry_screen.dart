import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../design_system/icon_mapping.dart';
import '../../../../design_system/theme/theme_extensions.dart';
import '../../../../design_system/widgets/primary_button.dart';
import '../../../../design_system/widgets/value_chip.dart';
import '../../../entries/domain/entities/entry.dart';
import '../../../entries/presentation/providers/entry_providers.dart';
import '../../../insights/presentation/providers/insights_providers.dart';
import '../../../protected_values/domain/entities/protected_value.dart';
import '../../../protected_values/presentation/providers/protected_value_providers.dart';
import '../providers/history_providers.dart';

/// Lets the user edit an existing entry's protected values and
/// personal reminder note only. Per the founder spec: editing can
/// never turn the entry into an unconfirmed event and must never
/// touch Course progress — this screen has no way to change the
/// category, situation, or trigger any Course/token logic at all.
class EditEntryScreen extends ConsumerStatefulWidget {
  const EditEntryScreen({super.key, required this.entryId});

  final String entryId;

  @override
  ConsumerState<EditEntryScreen> createState() => _EditEntryScreenState();
}

class _EditEntryScreenState extends ConsumerState<EditEntryScreen> {
  Set<String>? _selectedValueIds;
  final TextEditingController _noteController = TextEditingController();
  bool _initialized = false;
  bool _saving = false;
  String? _errorText;

  void _initializeFrom(Entry entry) {
    if (_initialized) return;
    _initialized = true;
    _selectedValueIds = entry.protectedValueIds.toSet();
    _noteController.text = entry.personalReminderNote ?? '';
  }

  void _toggle(String id) {
    setState(() {
      final Set<String> current = Set<String>.from(_selectedValueIds ?? <String>{});
      if (current.contains(id)) {
        current.remove(id);
      } else if (current.length < 3) {
        current.add(id);
      }
      _selectedValueIds = current;
    });
  }

  Future<void> _save(Entry original) async {
    if (_selectedValueIds == null || _selectedValueIds!.isEmpty) return;
    setState(() {
      _saving = true;
      _errorText = null;
    });

    final String note = _noteController.text.trim();
    final Entry updated = original.copyWithEditableFields(
      protectedValueIds: _selectedValueIds!.toList(),
      personalReminderNote: note.isEmpty ? null : note,
      clearPersonalReminderNote: note.isEmpty,
    );

    try {
      await ref.read(entryRepositoryProvider).update(updated);
      ref.invalidate(allEntriesStreamProvider);
      ref.invalidate(entryByIdProvider(original.id));
      ref.invalidate(insightsAggregatesProvider);

      if (mounted) Navigator.of(context).pop();
    } catch (_) {
      // Without this, a failed write would leave _saving stuck true
      // forever — the Save button permanently disabled, with no
      // feedback and no way to retry short of leaving the screen and
      // losing the edit.
      if (mounted) {
        setState(() {
          _saving = false;
          _errorText = "Couldn't save these changes. Please try again.";
        });
      }
    }
  }

  @override
  void dispose() {
    _noteController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final AsyncValue<Entry?> entryAsync = ref.watch(entryByIdProvider(widget.entryId));
    final AsyncValue<List<ProtectedValue>> valuesAsync =
        ref.watch(protectedValuesProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Edit entry')),
      body: SafeArea(
        child: entryAsync.when(
          data: (Entry? entry) {
            if (entry == null) {
              return const Center(child: Text('This entry no longer exists.'));
            }
            _initializeFrom(entry);

            return SingleChildScrollView(
              padding: EdgeInsets.all(context.spacing.lg),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    'What did you protect?',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  SizedBox(height: context.spacing.md),
                  valuesAsync.when(
                    data: (List<ProtectedValue> values) {
                      final Set<String> selected = _selectedValueIds ?? <String>{};
                      final bool limitReached = selected.length >= 3;
                      return Wrap(
                        spacing: context.spacing.sm,
                        runSpacing: context.spacing.sm,
                        children: <Widget>[
                          for (final ProtectedValue value in values)
                            ValueChip(
                              label: value.label,
                              icon: ContentIconMapper.resolve(value.iconName),
                              selected: selected.contains(value.id),
                              enabled: selected.contains(value.id) || !limitReached,
                              onTap: (selected.contains(value.id) || !limitReached)
                                  ? () => _toggle(value.id)
                                  : null,
                            ),
                        ],
                      );
                    },
                    loading: () => const CircularProgressIndicator(),
                    error: (Object error, StackTrace stackTrace) =>
                        Text('Could not load values: $error'),
                  ),
                  SizedBox(height: context.spacing.lg),
                  Text(
                    'Personal reminder',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  SizedBox(height: context.spacing.sm),
                  TextField(
                    controller: _noteController,
                    maxLines: 3,
                    decoration: const InputDecoration(
                      hintText: 'Optional note for next time',
                    ),
                  ),
                  SizedBox(height: context.spacing.xl),
                  if (_errorText != null) ...<Widget>[
                    Text(
                      _errorText!,
                      style: Theme.of(context)
                          .textTheme
                          .bodyMedium
                          ?.copyWith(color: context.colors.destructive),
                    ),
                    SizedBox(height: context.spacing.sm),
                  ],
                  PrimaryButton(
                    label: 'Save changes',
                    loading: _saving,
                    onPressed: (_selectedValueIds?.isNotEmpty ?? false) && !_saving
                        ? () => _save(entry)
                        : null,
                  ),
                ],
              ),
            );
          },
          loading: () => const Center(child: CircularProgressIndicator()),
          error: (Object error, StackTrace stackTrace) =>
              Center(child: Text('Could not load this entry: $error')),
        ),
      ),
    );
  }
}
