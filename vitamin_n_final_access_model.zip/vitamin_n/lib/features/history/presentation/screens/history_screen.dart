import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show Clipboard, ClipboardData;
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../../design_system/theme/theme_extensions.dart';
import '../../../entries/domain/entities/entry.dart';
import '../../../refusal_responses/presentation/providers/refusal_response_providers.dart';
import '../../domain/usecases/group_entries_by_recency_usecase.dart';
import '../providers/history_providers.dart';
import '../widgets/history_entry_card.dart';
import '../widgets/history_filter_sheet.dart';
import 'entry_detail_screen.dart';

String _groupLabel(HistoryRecencyGroup group) {
  switch (group) {
    case HistoryRecencyGroup.today:
      return 'Today';
    case HistoryRecencyGroup.yesterday:
      return 'Yesterday';
    case HistoryRecencyGroup.earlierThisWeek:
      return 'Earlier this week';
    case HistoryRecencyGroup.earlierThisMonth:
      return 'Earlier this month';
    case HistoryRecencyGroup.older:
      return 'Older';
  }
}

/// One flattened row for the lazily-built list: either a section
/// header or an entry. Flattening once (rather than nesting a
/// ListView per group) is what lets ListView.builder stay lazy across
/// the whole History list, however many groups or entries there are.
sealed class _HistoryListItem {}

class _HeaderItem extends _HistoryListItem {
  _HeaderItem(this.label);
  final String label;
}

class _EntryItem extends _HistoryListItem {
  _EntryItem(this.entry);
  final Entry entry;
}

List<_HistoryListItem> _flatten(List<GroupedHistoryEntries> groups) {
  final List<_HistoryListItem> items = <_HistoryListItem>[];
  for (final GroupedHistoryEntries group in groups) {
    items.add(_HeaderItem(_groupLabel(group.group)));
    for (final Entry entry in group.entries) {
      items.add(_EntryItem(entry));
    }
  }
  return items;
}

enum _HistoryTab { history, favorites }

/// History | Favorites — one screen, two tabs. Favorites reuses the
/// existing heart/favoriting feature entirely (no new storage); this
/// is purely a discoverability fix for "where did my saved sentences
/// go", per the Favorites Access spec.
class HistoryScreen extends ConsumerStatefulWidget {
  const HistoryScreen({super.key});

  @override
  ConsumerState<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends ConsumerState<HistoryScreen> {
  _HistoryTab _tab = _HistoryTab.history;

  @override
  Widget build(BuildContext context) {
    final TextTheme textTheme = Theme.of(context).textTheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('History'),
        actions: <Widget>[
          if (_tab == _HistoryTab.history)
            IconButton(
              icon: const Icon(Icons.tune),
              tooltip: 'Filter',
              onPressed: () => showHistoryFilterSheet(context),
            ),
        ],
      ),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Padding(
              padding: EdgeInsets.fromLTRB(
                context.spacing.lg,
                context.spacing.sm,
                context.spacing.lg,
                context.spacing.sm,
              ),
              child: _HistoryFavoritesSwitch(
                selected: _tab,
                onChanged: (_HistoryTab tab) => setState(() => _tab = tab),
              ),
            ),
            if (_tab == _HistoryTab.history)
              Padding(
                padding: EdgeInsets.fromLTRB(
                  context.spacing.lg,
                  0,
                  context.spacing.lg,
                  context.spacing.md,
                ),
                child: Text(
                  'Your protected choices, over time.',
                  style: textTheme.bodyMedium,
                ),
              ),
            Expanded(
              child: _tab == _HistoryTab.history
                  ? const _HistoryList()
                  : const _FavoritesList(),
            ),
          ],
        ),
      ),
    );
  }
}

class _HistoryFavoritesSwitch extends StatelessWidget {
  const _HistoryFavoritesSwitch({required this.selected, required this.onChanged});

  final _HistoryTab selected;
  final ValueChanged<_HistoryTab> onChanged;

  Widget _segment(BuildContext context, _HistoryTab tab, String label) {
    final AppColors colors = context.colors;
    final TextTheme textTheme = Theme.of(context).textTheme;
    final bool isSelected = tab == selected;

    return Expanded(
      child: GestureDetector(
        onTap: () => onChanged(tab),
        child: Container(
          padding: EdgeInsets.symmetric(vertical: context.spacing.sm),
          decoration: BoxDecoration(
            color: isSelected
                ? Color.alphaBlend(colors.sage.withValues(alpha: 0.3), colors.cream)
                : Colors.transparent,
            borderRadius: BorderRadius.circular(context.radius.md),
          ),
          alignment: Alignment.center,
          child: Text(
            label,
            style: textTheme.labelMedium?.copyWith(
              color: isSelected ? colors.textPrimary : colors.textSecondary,
              fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final AppColors colors = context.colors;

    return Container(
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        color: colors.surfaceElevated,
        borderRadius: BorderRadius.circular(context.radius.md + 3),
        border: Border.all(color: colors.border, width: 1),
      ),
      child: Row(
        children: <Widget>[
          _segment(context, _HistoryTab.history, 'History'),
          _segment(context, _HistoryTab.favorites, 'Favorites'),
        ],
      ),
    );
  }
}

class _HistoryList extends ConsumerWidget {
  const _HistoryList();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final TextTheme textTheme = Theme.of(context).textTheme;
    final AsyncValue<List<GroupedHistoryEntries>> groupedAsync =
        ref.watch(groupedHistoryProvider);

    return groupedAsync.when(
      data: (List<GroupedHistoryEntries> groups) {
        if (groups.isEmpty) {
          return _HistoryEmptyState(textTheme: textTheme);
        }
        final List<_HistoryListItem> items = _flatten(groups);
        return ListView.builder(
          padding: EdgeInsets.symmetric(horizontal: context.spacing.lg),
          itemCount: items.length,
          itemBuilder: (BuildContext context, int index) {
            final _HistoryListItem item = items[index];
            if (item is _HeaderItem) {
              return Padding(
                padding: EdgeInsets.only(
                  top: context.spacing.md,
                  bottom: context.spacing.sm,
                ),
                child: Text(item.label, style: textTheme.labelLarge),
              );
            }
            final Entry entry = (item as _EntryItem).entry;
            return Padding(
              padding: EdgeInsets.only(bottom: context.spacing.sm),
              child: HistoryEntryCard(
                entry: entry,
                onTap: () {
                  Navigator.of(context).push<void>(
                    MaterialPageRoute<void>(
                      builder: (_) => EntryDetailScreen(entryId: entry.id),
                    ),
                  );
                },
              ),
            );
          },
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (Object error, StackTrace stackTrace) =>
          Center(child: Text('Could not load your History: $error')),
    );
  }
}

/// Deliberately minimal: only the saved sentence, nothing else — no
/// category, situation, timestamp, or Protected Values, per the
/// Favorites spec's explicit "keep it that simple".
class _FavoritesList extends ConsumerWidget {
  const _FavoritesList();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final TextTheme textTheme = Theme.of(context).textTheme;
    final AppColors colors = context.colors;
    final AsyncValue<List<FavoriteSentence>> favoritesAsync =
        ref.watch(favoriteSentencesProvider);

    return favoritesAsync.when(
      data: (List<FavoriteSentence> favorites) {
        if (favorites.isEmpty) {
          return Center(
            child: Padding(
              padding: EdgeInsets.all(context.spacing.xl),
              child: Text(
                'Sentences you save with the heart will appear here.',
                style: textTheme.bodyMedium,
                textAlign: TextAlign.center,
              ),
            ),
          );
        }
        return ListView.builder(
          padding: EdgeInsets.symmetric(
            horizontal: context.spacing.lg,
            vertical: context.spacing.sm,
          ),
          itemCount: favorites.length,
          itemBuilder: (BuildContext context, int index) {
            final FavoriteSentence favorite = favorites[index];
            return Padding(
              padding: EdgeInsets.only(bottom: context.spacing.sm),
              child: GestureDetector(
                onTap: () async {
                  await Clipboard.setData(ClipboardData(text: favorite.text));
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Copied'),
                        behavior: SnackBarBehavior.floating,
                        duration: Duration(seconds: 1),
                      ),
                    );
                  }
                },
                child: Container(
                  padding: EdgeInsets.all(context.spacing.md),
                  decoration: BoxDecoration(
                    color: colors.surface,
                    borderRadius: BorderRadius.circular(context.radius.lg),
                    border: Border.all(color: colors.border, width: 1),
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Icon(Icons.favorite, size: 16, color: colors.destructive),
                      SizedBox(width: context.spacing.sm),
                      Expanded(
                        child: Text(favorite.text, style: textTheme.bodyLarge),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (Object error, StackTrace stackTrace) =>
          Center(child: Text('Could not load your Favorites: $error')),
    );
  }
}

class _HistoryEmptyState extends StatelessWidget {
  const _HistoryEmptyState({required this.textTheme});

  final TextTheme textTheme;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(context.spacing.xl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Text(
              'Your protected choices will appear here.',
              style: textTheme.titleMedium,
              textAlign: TextAlign.center,
            ),
            SizedBox(height: context.spacing.sm),
            Text(
              'Each time you keep a boundary, Vitamin N will remember '
              'what mattered.',
              style: textTheme.bodyMedium,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
