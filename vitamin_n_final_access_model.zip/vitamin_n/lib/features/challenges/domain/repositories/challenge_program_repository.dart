import '../entities/challenge_program.dart' show ChallengeProgram;

export '../entities/challenge_program.dart' show ChallengeProgram;

abstract class ChallengeProgramRepository {
  /// All active challenges. Never called at app startup — only when the
  /// Challenges screen is actually opened, satisfying "Challenges are
  /// lazy-loaded".
  Future<List<ChallengeProgram>> getAll();

  Future<ChallengeProgram?> getById(String id);
}
