import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../app/routes.dart';
import '../../../../design_system/icon_mapping.dart';
import '../../../../design_system/theme/theme_extensions.dart';
import '../../../categories/domain/entities/category.dart';
import '../../../categories/domain/entities/category_access.dart';
import '../../../categories/presentation/providers/category_providers.dart';
import '../../../premium/presentation/providers/premium_providers.dart';
import '../controllers/say_no_flow_controller.dart';
import '../widgets/category_card.dart';
import '../widgets/category_preview_teaser_sheet.dart';
import '../widgets/flow_header.dart';
import '../widgets/flow_scaffold.dart';

/// Step 2 — Choose Category. One screen, one decision: selecting an
/// unlocked category advances automatically with the shared
/// slide+fade transition. A locked (Premium) category instead opens
/// a preview teaser — never a bare paywall, per section 8.
class CategoryScreen extends ConsumerWidget {
  const CategoryScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final AsyncValue<List<Category>> categoriesAsync = ref.watch(categoriesProvider);
    final String? selectedId =
        ref.watch(sayNoFlowControllerProvider).selectedCategoryId;
    final bool isPremium = ref.watch(premiumStatusProvider).value?.isPremium ?? false;

    void handleSelect(Category category) {
      final bool locked = !isPremium && CategoryAccess.requiresPremium(category.id);
      if (locked) {
        showCategoryPreviewTeaser(
          context: context,
          categoryId: category.id,
          categoryName: category.name,
        );
        return;
      }
      ref.read(sayNoFlowControllerProvider.notifier).selectCategory(category.id);
      context.push(AppRoutes.sayNoSituation);
    }

    return FlowScaffold(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          const FlowHeader(
            title: 'What are you saying No to?',
            subtitle: 'Choose the area that fits this moment.',
          ),
          categoriesAsync.when(
            data: (List<Category> categories) => Column(
              children: <Widget>[
                for (final Category category in categories) ...<Widget>[
                  CategoryCard(
                    title: category.name,
                    description: category.description,
                    icon: ContentIconMapper.resolve(category.iconName),
                    selected: category.id == selectedId,
                    locked: !isPremium && CategoryAccess.requiresPremium(category.id),
                    colorToken: category.colorToken,
                    onTap: () => handleSelect(category),
                  ),
                  SizedBox(height: context.spacing.sm),
                ],
              ],
            ),
            loading: () => const Padding(
              padding: EdgeInsets.only(top: 48),
              child: Center(child: CircularProgressIndicator()),
            ),
            error: (Object error, StackTrace stackTrace) =>
                Text('Could not load categories: $error'),
          ),
        ],
      ),
    );
  }
}
