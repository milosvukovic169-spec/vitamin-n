import '../entities/refusal_response.dart';

/// Category-scoped for the same lazy-loading reason as
/// SituationRepository — a category's response file covers every
/// situation in that category, so the caller supplies both ids and
/// only that one file is ever read.
abstract class RefusalResponseRepository {
  Future<List<RefusalResponse>> getBySituation({
    required String categoryId,
    required String situationId,
  });

  /// Loads every response across [categoryIds] and returns them
  /// flattened — used only by the Favorites tab, which needs to
  /// resolve a saved response id without knowing in advance which
  /// category it belongs to. Deliberately NOT called at startup or
  /// anywhere in the normal SAY NO flow, so it doesn't undermine the
  /// per-category lazy loading everywhere else.
  Future<List<RefusalResponse>> getAllAcrossCategories(List<String> categoryIds);
}
