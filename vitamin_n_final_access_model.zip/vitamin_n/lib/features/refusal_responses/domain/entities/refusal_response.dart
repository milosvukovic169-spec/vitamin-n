/// A curated, calm refusal suggestion tied to a specific Situation.
///
/// Free/Premium gating for responses is purely position-based, not a
/// separate flag: [sortOrder] 1 is the single Free response (the
/// Recommended one); [premiumDisplayCap] is the most a Premium user
/// is ever shown, even if a situation's content has more authored —
/// per the final monetization model, Premium depth is normally 3,
/// occasionally 4, never more, regardless of how much is in the JSON.
class RefusalResponse {
  /// Free users see exactly this many responses (by [sortOrder]) —
  /// the single Recommended one. Everything past this is Premium.
  static const int freeCount = 1;

  /// The most responses ever shown to a Premium user for one
  /// situation, even if more exist in the content file. A situation
  /// may be authored with extra responses for future flexibility
  /// without that content ever being exposed today.
  static const int premiumDisplayCap = 4;

  const RefusalResponse({
    required this.id,
    required this.situationId,
    required this.text,
    required this.sortOrder,
    this.style,
    this.active = true,
  });

  final String id;
  final String situationId;
  final String text;
  final int sortOrder;

  /// False for responses retired from the active SAY NO cycle (e.g.
  /// weak/near-duplicate/generic ones pruned during a content cleanup
  /// pass). The response and its text stay fully intact so History
  /// entries and Favorites that already reference it keep resolving
  /// correctly — it's simply excluded from what a live SAY NO flow
  /// offers. Defaults to true so any response without this field
  /// behaves exactly as before.
  final bool active;

  /// An optional tone tag for Premium's expanded response sets (warm,
  /// polite, concise, direct, professional, casual,
  /// without_explanation, text_message). Only populated where a style
  /// genuinely applies — never forced onto every response.
  final String? style;

  @override
  bool operator ==(Object other) => other is RefusalResponse && other.id == id;

  @override
  int get hashCode => id.hashCode;
}
