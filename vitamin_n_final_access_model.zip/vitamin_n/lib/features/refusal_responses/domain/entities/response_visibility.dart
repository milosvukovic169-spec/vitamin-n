import 'refusal_response.dart';

/// Pure logic for how many responses are visible and what the
/// "show more" affordance should say, kept separate from the widget
/// so the exact gating rules are directly unit-testable without
/// pumping a widget tree.
abstract final class ResponseVisibility {
  /// How many of [totalAuthored] responses are actually shown.
  /// [isPremium] is the user's real purchase status;
  /// [isFullyFreeCategory] is CategoryAccess.isFullyFree for the
  /// current category (Work/Relationships/Social) — either one
  /// unlocks the full [RefusalResponse.premiumDisplayCap] ceiling,
  /// since a fully-free category should show every active response
  /// exactly as a Premium user would see them. Free users outside a
  /// fully-free category stay capped at [RefusalResponse.freeCount] (1).
  static int visibleCount(
    int totalAuthored, {
    required bool isPremium,
    bool isFullyFreeCategory = false,
  }) {
    final int cap = (isPremium || isFullyFreeCategory)
        ? RefusalResponse.premiumDisplayCap
        : RefusalResponse.freeCount;
    return totalAuthored.clamp(0, cap);
  }

  /// The label for the button that would move from [currentIndex]
  /// (0-based) to the next response — or null if there's nothing
  /// further to show at this tier. Only used once cycling is
  /// actually unlocked (Premium OR a fully-free category); everyone
  /// else sees the locked "Another way 🔒" affordance instead,
  /// handled separately by the screen.
  static String? nextButtonLabelForPremium({
    required int currentIndex,
    required int visibleLimit,
  }) {
    if (currentIndex >= visibleLimit - 1) return null;
    final int nextIndex = currentIndex + 1;
    return nextIndex == 3 ? 'One more way' : 'Another way';
  }
}
