import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../categories/domain/entities/category.dart';
import '../../../categories/presentation/providers/category_providers.dart'
    show categoryRepositoryProvider;
import '../../../favorites/domain/entities/favorite.dart';
import '../../../favorites/presentation/providers/favorite_providers.dart';
import '../../../situations/presentation/providers/situation_providers.dart'
    show CategoryAndSituationId;
import '../../data/datasources/refusal_response_local_data_source.dart';
import '../../data/repositories/refusal_response_repository_impl.dart';
import '../../domain/entities/refusal_response.dart';
import '../../domain/repositories/refusal_response_repository.dart';

final Provider<RefusalResponseRepository> refusalResponseRepositoryProvider =
    Provider<RefusalResponseRepository>((Ref ref) {
  return RefusalResponseRepositoryImpl(RefusalResponseLocalDataSource());
});

final FutureProviderFamily<List<RefusalResponse>, CategoryAndSituationId>
    refusalResponsesForSituationProvider =
    FutureProvider.family<List<RefusalResponse>, CategoryAndSituationId>(
        (Ref ref, CategoryAndSituationId key) {
  return ref.watch(refusalResponseRepositoryProvider).getBySituation(
        categoryId: key.categoryId,
        situationId: key.situationId,
      );
});

/// The active-only subset for the live SAY NO flow (Suggested
/// Response screen / "Another way" cycling) — use
/// [refusalResponsesForSituationProvider] instead when resolving a
/// specific response regardless of its active state (e.g. an
/// existing History entry or a Favorite), since that lookup is
/// intentionally NOT filtered by [RefusalResponse.active].
final FutureProviderFamily<List<RefusalResponse>, CategoryAndSituationId>
    activeRefusalResponsesForSituationProvider =
    FutureProvider.family<List<RefusalResponse>, CategoryAndSituationId>(
        (Ref ref, CategoryAndSituationId key) async {
  final List<RefusalResponse> all =
      await ref.watch(refusalResponsesForSituationProvider(key).future);
  return all.where((RefusalResponse r) => r.active).toList();
});

/// Every response across every category — including retired
/// (inactive) ones, since a favorite saved before a category was
/// retired must still resolve correctly. Only loaded when the
/// Favorites tab is actually opened (see favoriteSentencesProvider);
/// never at startup.
final FutureProvider<List<RefusalResponse>> _allResponsesProvider =
    FutureProvider<List<RefusalResponse>>((Ref ref) async {
  final List<Category> categories =
      await ref.watch(categoryRepositoryProvider).getAll();
  return ref.watch(refusalResponseRepositoryProvider).getAllAcrossCategories(
        categories.map((Category c) => c.id).toList(),
      );
});

/// One favorited sentence, ready for display — just the text, per
/// the Favorites spec (no category/situation/metadata shown).
class FavoriteSentence {
  const FavoriteSentence({required this.favoriteId, required this.text});

  final String favoriteId;
  final String text;
}

/// Resolves every favorited RefusalResponse to its actual sentence.
/// A favorite whose id no longer resolves to any content (extremely
/// unlikely, but content can theoretically change) is silently
/// skipped rather than shown as broken.
final FutureProvider<List<FavoriteSentence>> favoriteSentencesProvider =
    FutureProvider<List<FavoriteSentence>>((Ref ref) async {
  final List<Favorite> favorites = await ref.watch(allFavoritesProvider.future);
  final List<RefusalResponse> allResponses =
      await ref.watch(_allResponsesProvider.future);
  final Map<String, String> textById = <String, String>{
    for (final RefusalResponse r in allResponses) r.id: r.text,
  };

  return <FavoriteSentence>[
    for (final Favorite f in favorites)
      if (f.entityType == FavoriteEntityType.refusalResponse &&
          textById.containsKey(f.entityId))
        FavoriteSentence(favoriteId: f.id, text: textById[f.entityId]!),
  ];
});
