import 'package:drift/native.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/core/database/app_database.dart';
import 'package:vitamin_n/core/database/app_database_provider.dart';
import 'package:vitamin_n/features/entries/presentation/providers/entry_providers.dart';
import 'package:vitamin_n/features/favorites/domain/entities/favorite.dart';
import 'package:vitamin_n/features/favorites/presentation/providers/favorite_providers.dart';
import 'package:vitamin_n/features/refusal_responses/domain/entities/refusal_response.dart';
import 'package:vitamin_n/features/refusal_responses/presentation/providers/refusal_response_providers.dart';

import '../../fakes/fake_entry_repository.dart';

/// Isolates favoriteSentencesProvider from any widget rendering, so a
/// failure here can only mean the data/resolution chain itself is
/// broken — not tab state, not widget rebuild timing, not pump
/// counts. See the "Isolate Favorites Failure" investigation.
void main() {
  // Plain test() (unlike testWidgets()) does NOT auto-initialize the
  // Flutter test binding — but JsonAssetLoader's real asset I/O goes
  // through rootBundle, which needs ServicesBinding.instance to
  // exist. Without this line, every content-loading call throws
  // "Binding has not yet been initialized" before any real logic
  // even runs.
  TestWidgetsFlutterBinding.ensureInitialized();
  late AppDatabase db;
  late ProviderContainer container;

  setUp(() {
    db = AppDatabase.forTesting(NativeDatabase.memory());
    container = ProviderContainer(
      overrides: <Override>[
        appDatabaseProvider.overrideWithValue(db),
        entryRepositoryProvider.overrideWithValue(const FakeEntryRepository()),
      ],
    );
  });

  tearDown(() async {
    container.dispose();
    await db.close();
  });

  test(
    'favoriteSentencesProvider resolves a favorited rr_overtime_1 to its '
    'current canonical text, and no longer contains it after unfavoriting',
    () async {
      const String responseId = 'rr_overtime_1';

      // Read the canonical text directly from the real content source
      // at test-time — never hard-code it, so this test can't go
      // stale if the response's wording changes later.
      final List<RefusalResponse> workResponses =
          await container.read(refusalResponseRepositoryProvider).getBySituation(
                categoryId: 'cat_work',
                situationId: 'sit_overtime',
              );
      final RefusalResponse target =
          workResponses.firstWhere((RefusalResponse r) => r.id == responseId);
      final String canonicalText = target.text;

      // --- Step 1-4: favorite it, then resolve via the real provider chain.
      await container
          .read(favoriteRepositoryProvider)
          .toggle(FavoriteEntityType.refusalResponse, responseId);

      final List<FavoriteSentence> afterFavorite =
          await container.read(favoriteSentencesProvider.future);

      expect(
        afterFavorite.any((FavoriteSentence f) => f.text == canonicalText),
        isTrue,
        reason: 'favoriteSentencesProvider should resolve the favorited '
            'response id to its current canonical text. Got: '
            '${afterFavorite.map((FavoriteSentence f) => f.text).toList()}',
      );

      // --- Step 6-8: unfavorite, invalidate, confirm it disappears.
      await container
          .read(favoriteRepositoryProvider)
          .toggle(FavoriteEntityType.refusalResponse, responseId);

      // favoriteSentencesProvider watches allFavoritesProvider.future via
      // ref.watch — but a plain container.read(x.future) call on an
      // already-resolved FutureProvider does not automatically
      // re-run just because an upstream repository call happened
      // outside Riverpod's own dependency graph (the toggle() call
      // above went through favoriteRepositoryProvider directly, not
      // through a provider Riverpod knows changed). Invalidate
      // explicitly so the next read is a fresh resolution.
      container.invalidate(allFavoritesProvider);
      container.invalidate(favoriteSentencesProvider);

      final List<FavoriteSentence> afterUnfavorite =
          await container.read(favoriteSentencesProvider.future);

      expect(
        afterUnfavorite.any((FavoriteSentence f) => f.text == canonicalText),
        isFalse,
        reason: 'favoriteSentencesProvider should no longer contain the '
            'sentence after unfavoriting. Got: '
            '${afterUnfavorite.map((FavoriteSentence f) => f.text).toList()}',
      );
    },
  );
}
