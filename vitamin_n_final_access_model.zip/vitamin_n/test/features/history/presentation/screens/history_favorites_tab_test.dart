import 'package:drift/native.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/core/database/app_database.dart';
import 'package:vitamin_n/core/database/app_database_provider.dart';
import 'package:vitamin_n/design_system/theme/app_theme.dart';
import 'package:vitamin_n/features/entries/presentation/providers/entry_providers.dart';
import 'package:vitamin_n/features/favorites/domain/entities/favorite.dart';
import 'package:vitamin_n/features/favorites/presentation/providers/favorite_providers.dart';
import 'package:vitamin_n/features/history/presentation/screens/history_screen.dart';

import '../../../../fakes/fake_entry_repository.dart';

/// A real, known response — sortOrder 1 of Work's "Overtime"
/// situation. Used as the Favorites fixture so this test resolves an
/// actual bundled sentence, not a mocked one.
const String _knownResponseId = 'rr_overtime_1';
const String _knownResponseText = 'I need to head out at my usual time today.';

Future<({ProviderContainer container, AppDatabase db})> _containerWithFavorite({
  required bool seedFavorite,
}) async {
  final AppDatabase db = AppDatabase.forTesting(NativeDatabase.memory());
  final ProviderContainer container = ProviderContainer(
    overrides: <Override>[
      appDatabaseProvider.overrideWithValue(db),
      entryRepositoryProvider.overrideWithValue(const FakeEntryRepository()),
    ],
  );
  if (seedFavorite) {
    await container
        .read(favoriteRepositoryProvider)
        .toggle(FavoriteEntityType.refusalResponse, _knownResponseId);
  }
  return (container: container, db: db);
}

/// Unlike history_screen_test.dart's short bounded pump sequence,
/// this file uses a longer bounded pump loop (not pumpAndSettle) —
/// Favorites resolution loads every category's response file to
/// resolve a saved response id (see _allResponsesProvider), so it
/// needs real margin, but pumpAndSettle risks hanging indefinitely if
/// anything anywhere keeps scheduling frames rather than terminating
/// cleanly like a fixed loop always does.
Future<void> _pumpHistoryScreen(WidgetTester tester, ProviderContainer container) async {
  await tester.pumpWidget(
    UncontrolledProviderScope(
      container: container,
      child: MaterialApp(theme: AppTheme.light, home: const HistoryScreen()),
    ),
  );
  for (int i = 0; i < 20; i++) {
    await tester.pump(const Duration(milliseconds: 50));
  }
}

/// Pumps repeatedly until [finder] locates at least one widget, or
/// [maxIterations] is reached — whichever comes first. More robust
/// than a fixed pump count (adapts to however long the real async
/// chain actually takes on the machine running the test) while
/// staying bounded, unlike pumpAndSettle, which can hang indefinitely
/// if anything anywhere keeps scheduling frames.
Future<void> _pumpUntilFound(
  WidgetTester tester,
  Finder finder, {
  int maxIterations = 60,
  Duration step = const Duration(milliseconds: 50),
}) async {
  for (int i = 0; i < maxIterations; i++) {
    if (finder.evaluate().isNotEmpty) return;
    await tester.pump(step);
  }
}

void main() {
  testWidgets('the Favorites tab shows only the saved sentence — no category, '
      'situation, or metadata', (WidgetTester tester) async {
    final ({ProviderContainer container, AppDatabase db}) result =
        await _containerWithFavorite(seedFavorite: true);
    final ProviderContainer container = result.container;
    addTearDown(container.dispose);
    addTearDown(result.db.close);
    await _pumpHistoryScreen(tester, container);

    await tester.tap(find.text('Favorites'));
    for (int i = 0; i < 20; i++) {
      await tester.pump(const Duration(milliseconds: 50));
    }
    expect(find.text(_knownResponseText), findsOneWidget);
    expect(find.text('Work'), findsNothing);
    expect(find.textContaining('Overtime'), findsNothing);
  });

  testWidgets('Favorites is empty until something is favorited', (WidgetTester tester) async {
    final ({ProviderContainer container, AppDatabase db}) result =
        await _containerWithFavorite(seedFavorite: false);
    final ProviderContainer container = result.container;
    addTearDown(container.dispose);
    addTearDown(result.db.close);
    await _pumpHistoryScreen(tester, container);

    await tester.tap(find.text('Favorites'));
    await _pumpUntilFound(
      tester,
      find.text('Sentences you save with the heart will appear here.'),
    );
    expect(find.text(_knownResponseText), findsNothing);
    expect(
      find.text('Sentences you save with the heart will appear here.'),
      findsOneWidget,
    );
  });

  testWidgets('unfavoriting removes the sentence from Favorites', (WidgetTester tester) async {
    final ({ProviderContainer container, AppDatabase db}) result =
        await _containerWithFavorite(seedFavorite: true);
    final ProviderContainer container = result.container;
    addTearDown(container.dispose);
    addTearDown(result.db.close);

    expect(
      await container.read(favoriteRepositoryProvider).isFavorite(
            FavoriteEntityType.refusalResponse,
            _knownResponseId,
          ),
      isTrue,
    );

    await container
        .read(favoriteRepositoryProvider)
        .toggle(FavoriteEntityType.refusalResponse, _knownResponseId);

    await _pumpHistoryScreen(tester, container);
    await tester.tap(find.text('Favorites'));
    for (int i = 0; i < 20; i++) {
      await tester.pump(const Duration(milliseconds: 50));
    }
    expect(find.text(_knownResponseText), findsNothing);
  });

  testWidgets('switching back to History shows entries again, not Favorites',
      (WidgetTester tester) async {
    final ({ProviderContainer container, AppDatabase db}) result =
        await _containerWithFavorite(seedFavorite: true);
    final ProviderContainer container = result.container;
    addTearDown(container.dispose);
    addTearDown(result.db.close);
    await _pumpHistoryScreen(tester, container);

    await tester.tap(find.text('Favorites'));
    await _pumpUntilFound(tester, find.text(_knownResponseText));
    expect(find.text(_knownResponseText), findsOneWidget);

    await tester.tap(find.descendant(
      of: find.byType(GestureDetector),
      matching: find.text('History'),
    ));
    await _pumpUntilFound(
      tester,
      find.text('Your protected choices will appear here.'),
    );
    expect(find.text(_knownResponseText), findsNothing);
    expect(find.text('Your protected choices will appear here.'), findsOneWidget);
  });
}
