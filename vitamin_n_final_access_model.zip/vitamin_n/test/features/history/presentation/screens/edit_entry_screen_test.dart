import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/design_system/theme/app_theme.dart';
import 'package:vitamin_n/design_system/widgets/primary_button.dart';
import 'package:vitamin_n/features/entries/domain/entities/entry.dart';
import 'package:vitamin_n/features/entries/domain/repositories/entry_repository.dart';
import 'package:vitamin_n/features/entries/presentation/providers/entry_providers.dart';
import 'package:vitamin_n/features/history/presentation/screens/edit_entry_screen.dart';

import '../../../../fakes/fake_entry_repository.dart';

/// A repository whose update() always fails — for proving the
/// stuck-Save-button bug found during the billing audit follow-up is
/// fixed here too.
class _ThrowingEntryRepository extends FakeEntryRepository {
  _ThrowingEntryRepository(super.entries);

  @override
  Future<void> update(Entry entry) async {
    throw Exception('simulated write failure');
  }
}

final Entry _testEntry = Entry(
  id: 'entry-1',
  categoryId: 'cat_work',
  situationId: 'sit_overtime',
  refusalResponseId: 'rr_overtime_1',
  // Pre-populated so the Save button is already enabled on load —
  // EditEntryScreen seeds its selection from the entry's existing
  // protected values.
  protectedValueIds: const <String>['val_time'],
  customProtectedValue: null,
  personalReminderNote: null,
  reflectionPauseShown: false,
  courseId: 1,
  createdAt: DateTime(2026, 1, 1),
);

void main() {
  testWidgets(
    'BUG FIX: a failed save reports an error instead of leaving the Save '
    'button permanently stuck disabled',
    (WidgetTester tester) async {
      final EntryRepository throwingRepo = _ThrowingEntryRepository(<Entry>[_testEntry]);

      await tester.pumpWidget(
        ProviderScope(
          overrides: <Override>[entryRepositoryProvider.overrideWithValue(throwingRepo)],
          child: MaterialApp(
            theme: AppTheme.light,
            home: EditEntryScreen(entryId: _testEntry.id),
          ),
        ),
      );
      await tester.pump();
      await tester.pump();

      await tester.ensureVisible(find.widgetWithText(PrimaryButton, 'Save changes'));
      await tester.tap(find.widgetWithText(PrimaryButton, 'Save changes'));
      await tester.pump();
      await tester.pump();

      expect(find.text("Couldn't save these changes. Please try again."), findsOneWidget);

      final PrimaryButton button =
          tester.widget<PrimaryButton>(find.byType(PrimaryButton));
      expect(button.loading, isFalse, reason: 'must not be stuck showing a spinner');
      expect(button.onPressed, isNotNull,
          reason: 'must be tappable again, not permanently disabled');
    },
  );
}
