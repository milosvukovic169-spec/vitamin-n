// Proves the FINAL access model's rules — pure logic tests, no widget
// pumping needed, since the rules live in testable helpers/constants
// rather than being buried inside widget build methods.
import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/features/categories/domain/entities/category_access.dart';
import 'package:vitamin_n/features/challenges/domain/entities/challenge_program.dart';
import 'package:vitamin_n/features/reality_reminders/domain/entities/reality_reminder.dart';
import 'package:vitamin_n/features/refusal_responses/domain/entities/refusal_response.dart';
import 'package:vitamin_n/features/refusal_responses/domain/entities/response_visibility.dart';

void main() {
  group('CategoryAccess — no category is locked at the category level', () {
    const allActiveCategories = <String>[
      'cat_relationships', 'cat_work', 'cat_social', 'cat_money', 'cat_time',
      'cat_availability', 'cat_favors', 'cat_listening_support', 'cat_other',
      'cat_personal_boundaries',
    ];

    test('every active category is Free to open, none requires Premium', () {
      for (final String id in allActiveCategories) {
        expect(CategoryAccess.isFree(id), isTrue, reason: '$id should be openable Free');
        expect(CategoryAccess.requiresPremium(id), isFalse,
            reason: '$id must not require Premium to open');
      }
    });

    test('even an unrecognized category id never requires Premium to open', () {
      expect(CategoryAccess.requiresPremium('cat_unknown'), isFalse);
    });
  });

  group('CategoryAccess — fully-free categories (all responses + free Reality '
      'Reminder)', () {
    test('Relationships, Work and Social are fully free', () {
      expect(CategoryAccess.isFullyFree('cat_relationships'), isTrue);
      expect(CategoryAccess.isFullyFree('cat_work'), isTrue);
      expect(CategoryAccess.isFullyFree('cat_social'), isTrue);
    });

    test('every other active category is NOT fully free — first response '
        'only, Premium for more', () {
      const otherActiveCategories = <String>[
        'cat_money', 'cat_time', 'cat_availability', 'cat_favors',
        'cat_listening_support', 'cat_other', 'cat_personal_boundaries',
      ];
      for (final String id in otherActiveCategories) {
        expect(CategoryAccess.isFullyFree(id), isFalse,
            reason: '$id should NOT be fully free');
      }
    });
  });

  group('RefusalResponse — response caps', () {
    test('Free (outside a fully-free category) sees exactly 1 response', () {
      expect(RefusalResponse.freeCount, 1);
    });

    test('Premium (or a fully-free category) is capped at 4, even if a '
        'situation has more authored', () {
      expect(RefusalResponse.premiumDisplayCap, 4);
    });
  });

  group('ResponseVisibility — the exact cycling rules', () {
    test('Free outside a fully-free category always sees exactly 1, '
        'regardless of how much content exists', () {
      expect(ResponseVisibility.visibleCount(8, isPremium: false), 1);
      expect(ResponseVisibility.visibleCount(1, isPremium: false), 1);
    });

    test('a fully-free category unlocks the full cap even for a Free user',
        () {
      expect(
        ResponseVisibility.visibleCount(8, isPremium: false, isFullyFreeCategory: true),
        4,
      );
      expect(
        ResponseVisibility.visibleCount(3, isPremium: false, isFullyFreeCategory: true),
        3,
        reason: 'Shows every authored response up to the cap, not more than exists',
      );
    });

    test('Premium sees up to 4 when a situation has 8 authored, regardless '
        'of category', () {
      expect(ResponseVisibility.visibleCount(8, isPremium: true), 4);
    });

    test('Premium sees fewer than 4 if fewer than 4 are authored', () {
      expect(ResponseVisibility.visibleCount(2, isPremium: true), 2);
      expect(ResponseVisibility.visibleCount(3, isPremium: true), 3);
    });

    test('Premium cycling: "Another way" for moving to response 2 and 3', () {
      expect(
        ResponseVisibility.nextButtonLabelForPremium(currentIndex: 0, visibleLimit: 4),
        'Another way',
      );
      expect(
        ResponseVisibility.nextButtonLabelForPremium(currentIndex: 1, visibleLimit: 4),
        'Another way',
      );
    });

    test('cycling: "One more way" only for the exceptional 4th response', () {
      expect(
        ResponseVisibility.nextButtonLabelForPremium(currentIndex: 2, visibleLimit: 4),
        'One more way',
      );
    });

    test('cycling: no further label once the visible limit is reached', () {
      expect(
        ResponseVisibility.nextButtonLabelForPremium(currentIndex: 2, visibleLimit: 3),
        isNull,
        reason: 'Only 3 authored/shown — nothing beyond "Another way" x2',
      );
      expect(
        ResponseVisibility.nextButtonLabelForPremium(currentIndex: 3, visibleLimit: 4),
        isNull,
        reason: 'At the cap — no further cycling',
      );
    });
  });

  group('RealityReminderAccess — Free for Work, Relationships and Social '
      'only', () {
    test('Relationships, Work and Social are Free for Reality Reminder', () {
      expect(RealityReminderAccess.isFreeForCategory('cat_relationships'), isTrue);
      expect(RealityReminderAccess.isFreeForCategory('cat_work'), isTrue);
      expect(RealityReminderAccess.isFreeForCategory('cat_social'), isTrue);
    });

    test('every other active category is locked for Free Reality Reminder '
        'access, even though the category itself is openable Free', () {
      const otherActiveCategories = <String>[
        'cat_money', 'cat_time', 'cat_availability', 'cat_favors',
        'cat_listening_support', 'cat_other', 'cat_personal_boundaries',
      ];
      for (final String id in otherActiveCategories) {
        expect(RealityReminderAccess.isFreeForCategory(id), isFalse,
            reason: '$id Reality Reminder should require Premium');
      }
    });

    test('Free reminder count, once access is granted, is exactly 1', () {
      expect(RealityReminder.freeCount, 1);
    });
  });

  group('ChallengeAccess — unaffected by this pass, no Free Challenges at '
      'all', () {
    const allChallengeIds = <String>[
      'challenge_digital_boundaries',
      'challenge_people_pleasing_reset',
      'challenge_work_boundaries',
      'challenge_time_protection',
      'challenge_mindful_spending_boundaries',
      'challenge_evening_boundaries',
    ];

    test('every known challenge is Premium-only', () {
      for (final String id in allChallengeIds) {
        expect(ChallengeAccess.isFree(id), isFalse, reason: '$id must not be Free');
      }
    });

    test('an unrecognized challenge id is also never Free', () {
      expect(ChallengeAccess.isFree('challenge_unknown'), isFalse);
    });
  });
}
