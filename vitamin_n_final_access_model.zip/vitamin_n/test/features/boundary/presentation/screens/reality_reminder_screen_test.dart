import 'package:drift/native.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:vitamin_n/core/database/app_database.dart';
import 'package:vitamin_n/core/database/app_database_provider.dart';
import 'package:vitamin_n/design_system/theme/app_theme.dart';
import 'package:vitamin_n/design_system/widgets/primary_button.dart';
import 'package:vitamin_n/features/boundary/presentation/controllers/say_no_flow_controller.dart';
import 'package:vitamin_n/features/boundary/presentation/screens/reality_reminder_screen.dart';
import 'package:vitamin_n/features/boundary/presentation/widgets/locked_reality_reminder_card.dart';

/// Builds a container with the flow already pointed at a given
/// category/situation, avoiding the need to drive the whole flow
/// through prior screens just to test this one in isolation.
///
/// Also overrides appDatabaseProvider with an in-memory database:
/// RealityReminderScreen watches premiumStatusProvider, whose real
/// chain depends on Settings -> AppDatabase (path_provider,
/// unavailable in widget tests) — without this override, the chain
/// still resolves safely (AsyncValue.value returns null while
/// pending, correctly defaulting to Free here), but produces a
/// harmless, noisy MissingPluginException warning in the test log.
ProviderContainer _containerFor({
  required String categoryId,
  required String situationId,
}) {
  final AppDatabase db = AppDatabase.forTesting(NativeDatabase.memory());
  // addTearDown binds to whichever test is currently running,
  // regardless of which function calls it.
  addTearDown(db.close);

  final ProviderContainer container = ProviderContainer(
    overrides: <Override>[appDatabaseProvider.overrideWithValue(db)],
  );
  final controller = container.read(sayNoFlowControllerProvider.notifier);
  controller.selectCategory(categoryId);
  controller.selectSituation(situationId);
  return container;
}

Future<void> _pumpRealityReminderScreen(
  WidgetTester tester,
  ProviderContainer container,
) async {
  await tester.pumpWidget(
    UncontrolledProviderScope(
      container: container,
      child: MaterialApp(theme: AppTheme.light, home: const RealityReminderScreen()),
    ),
  );
  await tester.pump();
  await tester.pump();
}

void main() {
  testWidgets(
    'Free user in Work sees a real Reality Reminder — Work is fully free, '
    'including Reality Reminder',
    (WidgetTester tester) async {
      final ProviderContainer container = _containerFor(
        categoryId: 'cat_work',
        situationId: 'sit_overtime',
      );
      addTearDown(container.dispose);

      await _pumpRealityReminderScreen(tester, container);

      expect(find.byType(LockedRealityReminderCard), findsNothing);

      // Continue must remain fully present and enabled regardless.
      final PrimaryButton continueButton = tester.widget<PrimaryButton>(
        find.byType(PrimaryButton),
      );
      expect(continueButton.label, 'Continue');
      expect(continueButton.onPressed, isNotNull);
    },
  );

  testWidgets(
    'Free user in Digital also sees the locked teaser, with Continue still enabled',
    (WidgetTester tester) async {
      final ProviderContainer container = _containerFor(
        categoryId: 'cat_digital',
        situationId: 'sit_endless_scrolling',
      );
      addTearDown(container.dispose);

      await _pumpRealityReminderScreen(tester, container);

      expect(find.byType(LockedRealityReminderCard), findsOneWidget);
      final PrimaryButton continueButton = tester.widget<PrimaryButton>(
        find.byType(PrimaryButton),
      );
      expect(continueButton.onPressed, isNotNull);
    },
  );

  testWidgets(
    'Free user in Relationships sees a real reminder, not the locked teaser',
    (WidgetTester tester) async {
      final ProviderContainer container = _containerFor(
        categoryId: 'cat_relationships',
        situationId: 'sit_unwanted_call',
      );
      addTearDown(container.dispose);

      await _pumpRealityReminderScreen(tester, container);

      expect(find.byType(LockedRealityReminderCard), findsNothing);
      final PrimaryButton continueButton = tester.widget<PrimaryButton>(
        find.byType(PrimaryButton),
      );
      expect(continueButton.onPressed, isNotNull);
    },
  );
}
