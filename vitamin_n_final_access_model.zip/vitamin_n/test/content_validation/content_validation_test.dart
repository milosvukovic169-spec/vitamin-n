// Automated content validation — codifies every rule from Phase 5
// section 26 as a real, repeatable test rather than a one-off manual
// check. Reads the actual bundled JSON files directly from disk
// (working directory is the project root under `flutter test`), so
// this catches a content mistake the same way a CI run would.
import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

const List<String> _categorySlugs = <String>[
  'relationships', 'work', 'digital', 'money', 'lifestyle',
  'time', 'social', 'availability', 'favors', 'listening_support',
];

const List<String> _outOfScopeTerms = <String>[
  'suicide', 'self-harm', 'self harm', 'addiction', 'trauma', 'abuse',
  'diagnos', 'gambling', 'depression', 'anxiety disorder', 'eating disorder',
  'domestic violence', 'crisis',
];

List<dynamic> _readList(String path) {
  final String raw = File(path).readAsStringSync();
  return jsonDecode(raw) as List<dynamic>;
}

Map<String, dynamic> _readObject(String path) {
  final String raw = File(path).readAsStringSync();
  return jsonDecode(raw) as Map<String, dynamic>;
}

void main() {
  late List<Map<String, dynamic>> categories;
  late Set<String> categoryIds;
  late Set<String> protectedValueIds;
  late Map<String, List<Map<String, dynamic>>> situationsByCategory;
  late Set<String> allSituationIds;
  late Map<String, List<Map<String, dynamic>>> responsesByCategory;
  late Map<String, List<Map<String, dynamic>>> remindersByCategory;

  setUpAll(() {
    categories = _readList('assets/content/categories.json').cast<Map<String, dynamic>>();
    categoryIds = categories.map((c) => c['id'] as String).toSet();

    final List<Map<String, dynamic>> values =
        _readList('assets/content/protected_values.json').cast<Map<String, dynamic>>();
    protectedValueIds = values.map((v) => v['id'] as String).toSet();

    situationsByCategory = <String, List<Map<String, dynamic>>>{};
    responsesByCategory = <String, List<Map<String, dynamic>>>{};
    remindersByCategory = <String, List<Map<String, dynamic>>>{};
    for (final String slug in _categorySlugs) {
      situationsByCategory[slug] = _readList('assets/content/situations/$slug.json')
          .cast<Map<String, dynamic>>();
      responsesByCategory[slug] = _readList('assets/content/responses/$slug.json')
          .cast<Map<String, dynamic>>();
      remindersByCategory[slug] =
          _readList('assets/content/reality_reminders/$slug.json').cast<Map<String, dynamic>>();
    }
    allSituationIds = <String>{
      for (final List<Map<String, dynamic>> list in situationsByCategory.values)
        for (final Map<String, dynamic> s in list) s['id'] as String,
    };
  });

  group('unique ids', () {
    test('no duplicate situation ids across any category file', () {
      final List<String> all = <String>[
        for (final List<Map<String, dynamic>> list in situationsByCategory.values)
          for (final Map<String, dynamic> s in list) s['id'] as String,
      ];
      expect(all.toSet().length, all.length);
    });

    test('no duplicate response ids across any category file', () {
      final List<String> all = <String>[
        for (final List<Map<String, dynamic>> list in responsesByCategory.values)
          for (final Map<String, dynamic> r in list) r['id'] as String,
      ];
      expect(all.toSet().length, all.length);
    });

    test('no duplicate reminder ids across any category file', () {
      final List<String> all = <String>[
        for (final List<Map<String, dynamic>> list in remindersByCategory.values)
          for (final Map<String, dynamic> r in list) r['id'] as String,
      ];
      expect(all.toSet().length, all.length);
    });

    test('no duplicate category ids', () {
      final List<String> ids = categories.map((c) => c['id'] as String).toList();
      expect(ids.toSet().length, ids.length);
    });
  });

  group('valid references', () {
    test('every situation references a real category, and matches its own file', () {
      situationsByCategory.forEach((String slug, List<Map<String, dynamic>> situations) {
        for (final Map<String, dynamic> s in situations) {
          expect(categoryIds.contains(s['categoryId']), isTrue,
              reason: '${s['id']} references unknown category ${s['categoryId']}');
          expect(s['categoryId'], 'cat_$slug',
              reason: '${s['id']} is filed under $slug.json but categoryId is ${s['categoryId']}');
        }
      });
    });

    test('every response references a real situation', () {
      responsesByCategory.forEach((String slug, List<Map<String, dynamic>> responses) {
        for (final Map<String, dynamic> r in responses) {
          expect(allSituationIds.contains(r['situationId']), isTrue,
              reason: '${r['id']} references unknown situation ${r['situationId']}');
        }
      });
    });

    test('every reminder references a real situation', () {
      remindersByCategory.forEach((String slug, List<Map<String, dynamic>> reminders) {
        for (final Map<String, dynamic> r in reminders) {
          expect(allSituationIds.contains(r['situationId']), isTrue,
              reason: '${r['id']} references unknown situation ${r['situationId']}');
        }
      });
    });

    test("every situation's protected values reference real ProtectedValue ids", () {
      situationsByCategory.forEach((String slug, List<Map<String, dynamic>> situations) {
        for (final Map<String, dynamic> s in situations) {
          final List<dynamic> ids = s['protectedValueIds'] as List<dynamic>;
          for (final dynamic id in ids) {
            expect(protectedValueIds.contains(id), isTrue,
                reason: '${s['id']} references unknown protected value $id');
          }
        }
      });
    });

    test('every situation suggests 2-4 protected values', () {
      situationsByCategory.forEach((String slug, List<Map<String, dynamic>> situations) {
        for (final Map<String, dynamic> s in situations) {
          final int count = (s['protectedValueIds'] as List<dynamic>).length;
          expect(count >= 2 && count <= 4, isTrue,
              reason: '${s['id']} has $count protected values (need 2-4)');
        }
      });
    });
  });

  group('exposed content completeness', () {
    test('every situation has at least a primary response', () {
      final Set<String> situationsWithResponses = <String>{
        for (final List<Map<String, dynamic>> list in responsesByCategory.values)
          for (final Map<String, dynamic> r in list) r['situationId'] as String,
      };
      for (final String id in allSituationIds) {
        expect(situationsWithResponses.contains(id), isTrue,
            reason: 'situation $id has no responses at all');
      }
    });

    test('every situation has at least 3 responses authored (supports Premium depth)', () {
      // Content-level completeness check only — how many of these
      // are actually shown to a Free vs. Premium user is an app-level
      // decision (RefusalResponse.freeCount / .premiumDisplayCap),
      // tested separately in gating_rules_test.dart. This just
      // ensures every situation has enough authored content to
      // support Premium's "normally 3, occasionally 4" depth.
      for (final MapEntry<String, List<Map<String, dynamic>>> entry
          in responsesByCategory.entries) {
        final Map<String, int> countBySituation = <String, int>{};
        for (final Map<String, dynamic> r in entry.value) {
          final String sid = r['situationId'] as String;
          countBySituation[sid] = (countBySituation[sid] ?? 0) + 1;
        }
        for (final Map<String, dynamic> s in situationsByCategory[entry.key]!) {
          final int count = countBySituation[s['id']] ?? 0;
          expect(count >= 3, isTrue,
              reason: 'situation ${s['id']} has only $count responses authored (need >= 3)');
        }
      }
    });

    test('Relationships, Work and Digital situations each have at least one '
        'Reality Reminder authored', () {
      // Content-level completeness only. Whether a Free user actually
      // SEES that reminder depends on RealityReminderAccess
      // (Relationships-only for Free) — tested in gating_rules_test.dart.
      const List<String> freeCategorySlugs = <String>['relationships', 'work', 'digital'];
      for (final String slug in freeCategorySlugs) {
        final Set<String> situationsWithReminder = <String>{
          for (final Map<String, dynamic> r in remindersByCategory[slug]!)
            r['situationId'] as String,
        };
        for (final Map<String, dynamic> s in situationsByCategory[slug]!) {
          expect(situationsWithReminder.contains(s['id']), isTrue,
              reason: 'situation ${s['id']} has no Reality Reminder authored');
        }
      }
    });

    test('every Premium situation has at least a primary response and reminder', () {
      const List<String> premiumSlugs = <String>[
        'money', 'lifestyle', 'time', 'social', 'availability', 'favors', 'listening_support',
      ];
      for (final String slug in premiumSlugs) {
        final Set<String> withResponse = <String>{
          for (final Map<String, dynamic> r in responsesByCategory[slug]!)
            r['situationId'] as String,
        };
        final Set<String> withReminder = <String>{
          for (final Map<String, dynamic> r in remindersByCategory[slug]!)
            r['situationId'] as String,
        };
        for (final Map<String, dynamic> s in situationsByCategory[slug]!) {
          expect(withResponse.contains(s['id']), isTrue,
              reason: 'Premium situation ${s['id']} has no response');
          expect(withReminder.contains(s['id']), isTrue,
              reason: 'Premium situation ${s['id']} has no reminder');
        }
      }
    });
  });

  group('data quality', () {
    test('no empty strings in any situation/response/reminder text field', () {
      void checkNonEmpty(Map<String, dynamic> item, List<String> fields, String path) {
        for (final String field in fields) {
          final dynamic value = item[field];
          if (value is String) {
            expect(value.trim().isNotEmpty, isTrue,
                reason: '$path: ${item['id']} has empty $field');
          }
        }
      }

      situationsByCategory.forEach((String slug, List<Map<String, dynamic>> list) {
        for (final Map<String, dynamic> s in list) {
          checkNonEmpty(s, <String>['id', 'title', 'description'], 'situations/$slug.json');
        }
      });
      responsesByCategory.forEach((String slug, List<Map<String, dynamic>> list) {
        for (final Map<String, dynamic> r in list) {
          checkNonEmpty(r, <String>['id', 'text'], 'responses/$slug.json');
        }
      });
      remindersByCategory.forEach((String slug, List<Map<String, dynamic>> list) {
        for (final Map<String, dynamic> r in list) {
          checkNonEmpty(r, <String>['id', 'text'], 'reality_reminders/$slug.json');
        }
      });
    });

    test('no exact duplicate response text within the same situation', () {
      responsesByCategory.forEach((String slug, List<Map<String, dynamic>> list) {
        final Map<String, List<String>> textsBySituation = <String, List<String>>{};
        for (final Map<String, dynamic> r in list) {
          (textsBySituation[r['situationId'] as String] ??= <String>[])
              .add(r['text'] as String);
        }
        textsBySituation.forEach((String sid, List<String> texts) {
          expect(texts.toSet().length, texts.length,
              reason: '$slug.json: situation $sid has duplicate response text');
        });
      });
    });

    test('reality reminders avoid banned certainty language (will/always/never/proves)', () {
      final RegExp banned = RegExp(
        r'\b(will|always|never|proves|you are|they are)\b',
        caseSensitive: false,
      );
      remindersByCategory.forEach((String slug, List<Map<String, dynamic>> list) {
        for (final Map<String, dynamic> r in list) {
          expect(banned.hasMatch(r['text'] as String), isFalse,
              reason: 'reality_reminders/$slug.json: ${r['id']} uses banned certainty '
                  'language: "${r['text']}"');
        }
      });
    });

    test('no out-of-scope terms anywhere in situations, responses or reminders', () {
      void checkScope(Map<String, dynamic> item, List<String> fields, String path) {
        for (final String field in fields) {
          final dynamic value = item[field];
          if (value is! String) continue;
          final String lower = value.toLowerCase();
          for (final String term in _outOfScopeTerms) {
            expect(lower.contains(term), isFalse,
                reason: '$path: ${item['id']} contains out-of-scope term "$term"');
          }
        }
      }

      situationsByCategory.forEach((String slug, List<Map<String, dynamic>> list) {
        for (final Map<String, dynamic> s in list) {
          checkScope(s, <String>['title', 'description'], 'situations/$slug.json');
        }
      });
      responsesByCategory.forEach((String slug, List<Map<String, dynamic>> list) {
        for (final Map<String, dynamic> r in list) {
          checkScope(r, <String>['text'], 'responses/$slug.json');
        }
      });
      remindersByCategory.forEach((String slug, List<Map<String, dynamic>> list) {
        for (final Map<String, dynamic> r in list) {
          checkScope(r, <String>['text'], 'reality_reminders/$slug.json');
        }
      });
    });

    test('banned/out-of-scope categories are absent from categories.json', () {
      const List<String> bannedCategoryNames = <String>[
        'gambling', 'addiction', 'therapy', 'mental health', 'legal', 'medical',
      ];
      for (final Map<String, dynamic> c in categories) {
        final String name = (c['name'] as String).toLowerCase();
        for (final String banned in bannedCategoryNames) {
          expect(name.contains(banned), isFalse,
              reason: 'category ${c['id']} name contains banned term "$banned"');
        }
      }
    });
  });

  group('challenges', () {
    late List<Map<String, dynamic>> challenges;

    setUpAll(() {
      const List<String> files = <String>[
        'people_pleasing_reset', 'work_boundaries',
        'time_protection', 'mindful_spending_boundaries',
      ];
      challenges = <Map<String, dynamic>>[
        for (final String f in files) _readObject('assets/content/challenges/$f.json'),
      ];
    });

    test('there are exactly 4 active challenges (2 self-directed ones '
        'were retired from discovery)', () {
      expect(challenges, hasLength(4));
    });

    test('every challenge has 10-20 steps with unique, non-empty ids and text', () {
      for (final Map<String, dynamic> c in challenges) {
        final List<dynamic> steps = c['steps'] as List<dynamic>;
        expect(steps.length >= 10 && steps.length <= 20, isTrue,
            reason: '${c['id']} has ${steps.length} steps (need 10-20)');

        final Set<String> stepIds = <String>{};
        for (final dynamic step in steps) {
          final Map<String, dynamic> s = step as Map<String, dynamic>;
          expect(stepIds.add(s['id'] as String), isTrue,
              reason: '${c['id']} has duplicate step id ${s['id']}');
          expect((s['text'] as String).trim().isNotEmpty, isTrue);
        }
      }
    });

    test("every challenge's suggestedCategoryId (if set) references a real category", () {
      for (final Map<String, dynamic> c in challenges) {
        final dynamic categoryId = c['suggestedCategoryId'];
        if (categoryId != null) {
          expect(categoryIds.contains(categoryId), isTrue,
              reason: '${c['id']} references unknown category $categoryId');
        }
      }
    });
  });
}
